#!/usr/bin/env bash
set -euo pipefail
W="$(cd "$(dirname "$0")" && pwd)"
BUNDLE=sggf1clean2_14
TMP="$W/.package_${BUNDLE}"
rm -rf "$TMP"
mkdir -p "$TMP/assets"
cp "$W/main.py" "$TMP/assets/main.py"
cp "$W/luma_assets_e33.json" "$TMP/assets/luma_assets_e33.json"
rm -f "$W/${BUNDLE}.apk" "$W/${BUNDLE}.tar.gz"
(cd "$TMP" && zip -q -9 "$W/${BUNDLE}.apk" assets/main.py assets/luma_assets_e33.json)
(cd "$TMP" && tar --sort=name --mtime='@0' --owner=0 --group=0 --numeric-owner -czf "$W/${BUNDLE}.tar.gz" assets/main.py assets/luma_assets_e33.json)
rm -rf "$TMP"
echo "Built $BUNDLE from SGGF1Clean2.14 main.py and Luma JSON."
