The complete Cloudflare static-site distribution is in the source package's ../deploy mirror. This folder is the SGGF1Clean2.14 current playable edition.
