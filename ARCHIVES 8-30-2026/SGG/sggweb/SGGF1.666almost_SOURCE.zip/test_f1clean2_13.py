from __future__ import annotations
import ast
import json
import tarfile
import zipfile
from pathlib import Path

P = Path(__file__).resolve().parent
R = P.parent
D = R / "deploy"

checks = 0
def check(condition: bool, message: str) -> None:
    global checks
    checks += 1
    if not condition:
        raise AssertionError(message)

code = (P / "main.py").read_text(encoding="utf-8")
ast.parse(code)
check('VERSION = "F1Clean2.13"' in code, "Runtime version string")
check('if g.c1_dead and not g.c1_flags.get("hellgs_game_over"):' in code,
      "Generic death panel is suppressed only during HELLgs Game Over")
check("class F1Clean2_13StateMachine(F1Clean2_11StateMachine):" in code,
      "Clean2.13 is an additive subclass of the exact Clean2.11 code")
check("c12_binding_matches(event, self.c1_keys['quickload'])" in code,
      "Configured Quickload keyboard binding is handled")
check("button.inflate(*self.HELLGS_QUICKLOAD_HIT_INFLATE)" in code,
      "Mouse Quickload target is enlarged around the existing button")
check("self._read_save('quick')" in code, "Quickload uses the existing shared quicksave slot")
check("event.key == pygame.K_ESCAPE" in code, "Escape remains available after Game Over")
check("# R, movement and all other actions remain locked" in code,
      "Terminal lock documents movement/respawn lockout")
check("HELLGS QUICKLOAD HIT TEST" in code and "HELLGS QUICKLOAD INPUT" in code
      and "HELLGS QUICKLOAD RESULT" in code, "Flight-recorder diagnostics are present")

asset = json.loads((P / "luma_assets_e33.json").read_text(encoding="utf-8"))
check(asset.get("version") == "F1Clean2.13", "Luma JSON version metadata")
check((P / "VERSION").read_text().strip() == "2", "Only two source editions are recorded")

for mirror in (R / "main.py", R / "assets" / "main.py", D / "SGGF1Clean2.13" / "main.py"):
    check(mirror.read_bytes() == (P / "main.py").read_bytes(),
          f"main.py mirror matches: {mirror}")
for mirror in (R / "luma_assets_e33.json", R / "assets" / "luma_assets_e33.json",
               D / "SGGF1Clean2.13" / "luma_assets_e33.json"):
    check(mirror.read_bytes() == (P / "luma_assets_e33.json").read_bytes(),
          f"Luma JSON mirror matches: {mirror}")

catalog = json.loads((D / "versions.json").read_text(encoding="utf-8"))
versions = catalog.get("versions", [])
check([v["version"] for v in versions] == ["SGGF1Clean2.13", "SGGF1.666Cleanup1.0"],
      "Deployment catalogue contains exactly current + permanent legacy")
check(sum(bool(v.get("current")) for v in versions) == 1 and versions[0]["current"],
      "Only Clean2.13 is marked current")
for item in versions:
    check((D / item["path"]).is_file(), f"Catalog launch path exists: {item['path']}")
    check((D / item["image"]).is_file(), f"Catalog image path exists: {item['image']}")
release_dirs = sorted(p.name for p in D.iterdir() if p.is_dir())
check(release_dirs == ["SGGF1.666Cleanup1.0", "SGGF1Clean2.13"],
      "Deployment contains exactly two release directories")
source_release_dirs = sorted(p.name for p in R.iterdir() if p.is_dir() and p.name.startswith("SGGF"))
check(source_release_dirs == ["SGGF1.666Cleanup1.0", "SGGF1Clean2.13"],
      "Source contains exactly legacy + current versioned folders")

apk = P / "sggf1clean2_13.apk"
with zipfile.ZipFile(apk) as z:
    check(z.testzip() is None, "APK ZIP integrity")
    check(z.read("assets/main.py") == (P / "main.py").read_bytes(), "APK main.py payload")
    check(z.read("assets/luma_assets_e33.json") == (P / "luma_assets_e33.json").read_bytes(),
          "APK Luma JSON payload")

tar_path = P / "sggf1clean2_13.tar.gz"
with tarfile.open(tar_path, "r:gz") as t:
    main_member = t.extractfile("assets/main.py")
    json_member = t.extractfile("assets/luma_assets_e33.json")
    check(main_member is not None and main_member.read() == (P / "main.py").read_bytes(),
          "TAR main.py payload")
    check(json_member is not None and json_member.read() == (P / "luma_assets_e33.json").read_bytes(),
          "TAR Luma JSON payload")

print(f"PASS — {checks} Clean2.13 source, state-machine, mirror, catalogue and runtime-package assertions.")
