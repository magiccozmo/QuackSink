SPIFFY'S GIFT — SGGF1.666almost

BASELINE
Built from the exact SGGF1Clean2.14 source and complete Cloudflare site packages. Clean2.14 remains preserved as an earlier source/release archive; this is a new additive candidate, not an overwrite.

HELLGS HINTS
• Progressive Cozmo hints now operate only in HELLgs Inn.
• The first offer appears after 3 successful death quickloads in the cell; the better hint appears at 10; the explicit final spoiler offer appears at 20.
• Only a death quickload that starts and lands in HELLgs advances the counter. Deaths and quickloads elsewhere do not.
• The inherited Clean2.9 hint-suppression hook is neutralized in this release so it no longer deletes the HELLgs hint actor/queue.

HELLGS GAME OVER
• A shared quicksave exists: the button reads QUICKLOAD and uses the existing compatible quicksave.
• No shared quicksave exists: the button reads RESPAWN and restarts the player, fire and challenge timer inside the HELLgs cell.
• This RESPAWN does not create a quicksave, award Tea or leave the challenge. The deliberate quicksave clearing on a new HELLgs run is preserved, so the cross-version save exploit remains the intended escape.
• The configured Quickload key (F9 by default) still quickloads when a save exists. With no save, use the visible RESPAWN button (or the configured respawn key).

YORKSHIRE TEA
• The persistent on-screen counter is labelled YORKSHIRE TEA.
• The first successful loot of the Kitty Caravan Chest queues a one-time Cozmo cameo and the caravan-chest Yorkshire Tea achievement. Restocks do not repeat the reward.

SOUP / EDGE TRANSITIONS
• Edge travel now recognizes an attempted crossing before a high-speed movement step is rejected by the walkmesh boundary. This addresses the 2x soup movement case where the old x<=27 test could become unreachable while the collision clamp correctly held the player at the boundary.

PRESERVATION
• Backward-compatible save loading and the existing HELLgs cross-version exploit are retained.
• The eight curated legacy deployment editions are preserved byte-for-byte.
• Existing Clean2.14 and legacy source snapshots are not modified.
• No GitHub main push or Cloudflare deployment is included in this handoff.

TESTING / LIMITATIONS
Source syntax compilation, JSON parsing, package integrity, mirror parity, catalogue routes, legacy-folder byte identity and runtime archive contents are checked by the build workflow. The local environment does not include Pygame or a live browser/WebAssembly runtime, so live keyboard, mouse, rendering, localStorage, real save/load and gameplay testing remain for Cozmo. This is deliberately named “almost”, not “HellFinal”.
