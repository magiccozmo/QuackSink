SPIFFY'S GIFT — COMPLETE CLOUDFLARE SITE
Current release: SGGF1.666almost
Nine selectable editions are included: the current SGGF1.666almost test candidate plus the eight curated permanent milestones established by Cleanup1.0. The catalogue includes multiple earlier normal-world starts outside HELLgs as well as the optional HELLgs challenge lineage.
