SPIFFY'S GIFT — CURATED SOURCE HANDOFF

Current edition: SGGF1.666almost
The embedded deploy/ folder is the complete Cloudflare site and contains nine selectable editions:
SGGF1.666almost (current), SGGF1.666Cleanup1.0, SGGF1.666f1s, SGGF1.666, SGGF1.6, SGGF1.0, SGGE3.2, SGGE3.1 and SGGE2.0.

The earlier SGGE2.0, SGGE3.x, SGGF1.0 and SGGF1.6 milestones provide playable starts outside the HELLgs cell challenge. HELLgs remains one selectable challenge edition, not the only way to begin the game.

Full source snapshots for Cleanup1.0, F1s and the previous Clean2.14 release are retained alongside the new SGGF1.666almost source. Earlier selected milestone source archives are kept in MILESTONE_SOURCE_ARCHIVES. The ordinary intermediate Clean2 test editions are not included in this curated deployment.

The complete deployment tree under deploy/ mirrors the standalone Cloudflare ZIP. No GitHub main push or Cloudflare deployment was performed by Luma.
