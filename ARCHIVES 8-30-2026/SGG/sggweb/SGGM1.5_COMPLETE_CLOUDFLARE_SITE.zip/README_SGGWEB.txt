SPIFFY'S GIFT — SGG WEB PROJECT

Current edition: SGGM1.5 — BritRun City: Connected Streets and Open Market Square.

M1.4 is a city-geography pass on the exact M1.3a release. It aligns the street graph with Cozmo's named-road plan: Market Road from the southeast gate to Market Square; Peasant Way west to Intersection A; Castle Path north to Castle Exterior; Easy Street north from Gold District to A; and Snob Row west from just north of Little Lantern into Gold District. The Tipsy Turnip remains north of the Square and the Alchemy Shop east of it.

Only placeholder geography and placement data changed. Existing city NPCs and portals are repositioned with safe arrivals. The M1.3a startup correction, all other game systems, historical releases, generic placeholder renderer, and Luma asset JSON are preserved. See versions.json for the browser catalogue.
