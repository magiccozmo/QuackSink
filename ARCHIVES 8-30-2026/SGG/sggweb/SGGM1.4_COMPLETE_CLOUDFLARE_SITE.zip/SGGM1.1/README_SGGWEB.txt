SPIFFY'S GIFT — SGG WEB SOURCE

Current release: SGGM1.1, built from the exact SGGM1.0a source and complete Cloudflare site packages. K1.12 remains the reference for established UI and future NPC/object behavior.

M1.1 refines the continuous-world geography and layer portals, moves Troll Cave and Mudcrab River as requested, removes the outdoor HELLgs entrance, protects the player from the fixed top-right minimap, changes Z to walkmesh visibility and M to new-world fast travel, and restores the current K1.12 UI controls including Export Log and private Player Says.

This remains a geography/navigation/UI milestone. NPC/object/Grella behavior is not wired in and the placeholder art has not yet been repainted. The Luma Draw Engine asset JSON is preserved unchanged. The full source tree, complete Cloudflare site, M1.0a, M1.0, K1.12, and retained legacy editions are included.
