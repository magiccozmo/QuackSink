SPIFFY'S GIFT — CLOUDFLARE DEPLOYMENT

Current release: SGGF1.666f1c. The Front Gate background and its explicit Outside Gate transition marker are rebuilt; all other game areas and systems are retained from F1.666f1b.

The site root and complete version catalogue are included, along with all previous version directories. All previous release folders are preserved unchanged.
