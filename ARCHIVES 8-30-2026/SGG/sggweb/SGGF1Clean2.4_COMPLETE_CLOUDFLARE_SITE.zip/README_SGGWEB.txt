SPIFFY'S GIFT — CLEAN DEPLOYMENT

CURRENT VERSION: SGGF1Clean2.4

This complete Cloudflare site retains thirteen deliberately selected playable editions:
- SGGF1Clean2.4 — repairs the legacy Mountainside cave-entrance name/kind and its hover label.
- SGGF1Clean2.3 — Peak return landing correction.
- SGGF1Clean2.2 — Scenic Overlook summit experience.
- SGGF1Clean2.1 — grounded Mountain Path Peak approach.
- SGGF1Clean2 — preceding clean release.
- SGGF1.666Cleanup1.0, SGGF1.666f1s, SGGF1.666, SGGF1.6, SGGF1.0, SGGE3.2, SGGE3.1 and SGGE2.0.

The 2.4 change is limited to loading the canonical name and door kind for the existing mountain_cave_entrance object (and matching item metadata) from the current world definition. Its saved location, dimensions, area, walk trigger and all other state are preserved. The cave hover now shows the proper Frosty's Cave Entrance label. No artwork, walkmesh or world connection changed.
