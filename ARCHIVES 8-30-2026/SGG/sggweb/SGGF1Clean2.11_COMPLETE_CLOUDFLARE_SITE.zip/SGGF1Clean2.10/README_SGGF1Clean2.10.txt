SPIFFY'S GIFT — SGGF1Clean2.10

BASELINE: SGGF1Clean2.9 (exact pinned source/deployment packages from GitHub main commit f74d1a79f3cade5ccafe90bd226e651a5e94ff97).

CHANGES

• Redroot in the Alchemy Shop now has its own front-side access point, increased interaction reach, and a larger selection target. The other shelf-item access rules remain unchanged.
• The Potent Problem (Recipe) remains on the Alchemy Shop table at the position shown in pics/alchj fix.png. A narrow save migration moves only the known untouched legacy book positions (x=134,y=169 or y=195) to the current table position (x=333,y=304); moved/inventory objects and other saved positions are not reset.
• The existing indigo/teal/brass Mage Lab arch is drawn about 20% larger. In Mage Lab its threshold is anchored to the bottom edge of the screen. Castle Hall's Mage Lab entrance uses the same arch design and proportions, anchored at its existing doorway base. The object identities, walk triggers, collision, destination coordinates and reciprocal connections are unchanged.
• The Ultra Hard Hitbox setting uses neutral generic wording. It no longer names or hints at any platter, seam, vault or door exploit. Its actual setting value and behavior remain unchanged.
• The Log Dir / browser folder selection UI is removed. Log exports always use the browser Downloads mechanism or the desktop user's Downloads folder, ignoring any old saved log-directory preference.
• On every Clean2.10 challenge game start, only the shared save-quick slot is removed. Numbered saves 1–3 and all other game/config/world state remain untouched. This permits a second tab running an edition that does not start in the cell to create the quicksave that the challenge tab can load.

PRESERVATION

Clean2.9 gameplay systems, fast-travel disable, challenge hint suppression, soup prompt behavior, bucket exploit, Cozmo cameos/Tea rewards, guard logic, Fearmonger, Castle Vault artwork, Kelp's original Vault recipe, and the platter-and-wall seam mechanics are retained. The new door artwork changes only its rendered target rectangle; actual doorway object bounds and transition triggers remain unchanged. All 15 earlier selectable deployment editions are retained.

TESTING

Static regression and archive checks are recorded in SGGF1Clean2.10_TEST_RESULTS.txt and test_f1clean2_10.py. The build environment does not have Pygame, so no live in-game/browser field test was run here. Cozmo should verify Redroot pickup, recipe-book placement on a current/older save, both matching door visuals and transitions, log downloads, and the two-tab quicksave escape.
