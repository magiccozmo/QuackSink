SGGF1Clean2.9 browser edition. General controls only; challenge hints and fast travel disabled.
