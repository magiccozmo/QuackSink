CURRENT PLAYABLE EDITION: SGGF1Clean2.11. Complete browser deployment with all earlier selectable milestones preserved.
