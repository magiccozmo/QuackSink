SPIFFY'S GIFT — SGGF1Clean2.11

BASELINE: SGGF1Clean2.10 (exact source and complete Cloudflare deployment from GitHub main commit 883abc88f7292e1a5b4706070d164588b0c8ab90).

CHANGES

• Redroot's front-side approach, 230-unit reach and enlarged selection target no longer depend on the saved object's on_shelf flag. Older saves may preserve a false on_shelf flag even when the original Redroot has not moved, causing Clean2.10's special interaction path to be skipped. Clean2.11 applies the reach/click handling to the untouched Redroot stock by object identity and restores on_shelf only when the object is still at its exact original location (269,293,26,32), is not moved and is not in inventory. No stock position, price, theft rule or other shelf item is changed.
• The Potent Problem (Recipe) is placed at (200,300), centred on the Alchemy Shop's small wooden table. The previous Clean2.10 position (333,304) is explicitly treated as a legacy default and migrated on game start/save load, along with the two earlier untouched legacy positions. A moved or carried book is never reset.

PRESERVATION

The Mage Lab and Castle Hall arch design is unchanged. Both door objects, collision, transitions, walkmeshes, other Alchemy Shop objects, guard/vendor rules, challenge settings, Downloads behavior, two-tab quicksave gate, Vault art and platter-and-wall-seam exploit are inherited unchanged from Clean2.10. All 16 previously selectable editions remain byte-for-byte preserved.

TESTING

See SGGF1Clean2.11_TEST_RESULTS.txt and test_f1clean2_11.py. Python syntax, Luma JSON, explicit old-save flag-gating regression cases, recipe placement/migration guards, all prior deployment preservation, runtime bundle contents and source/deployment mirror parity are checked. The build environment does not have Pygame, so live gameplay must still be confirmed by Cozmo.
