SPIFFY'S GIFT — SGGF1Clean2.9

BASELINE: SGGF1Clean2.8

Clean2.9 is the challenge-mode polish pass requested after Cozmo's Clean2.8 field run.

CHANGES

• Challenge help now contains general controls only (movement, hovered-object interaction, inventory, shop buy/sell, save/load). Puzzle hints have been removed from the help presentation. The graduated Hellgs death/reload hint offers are also suppressed, including when carried in an older save. Exploit-recognition Cozmo cameos, Tea rewards and other challenge achievements remain active.
• The help line adds “F - CONSUME SOUP” only while a soup item is actually in the player's inventory. It disappears again after the soup is consumed or removed.
• The bucket-on-shopkeeper status no longer explains the line-of-sight exploit. The bucket mechanic, theft rules and witness logic are unchanged.
• Fast travel is disabled for this edition. The original E3.3 map, destinations and implementation remain in the code; Clean2.9 overrides only activation/jump entry points so a later edition can re-enable it.
• Alchemy Shop shelf stock has wider mouse hover targets and a front-side access point. Six untouched Clean2.8 shelf items are moved a few pixels toward the counter's front lip. A narrowly-scoped, idempotent save migration adjusts only objects still at their exact old default coordinates; carried, moved, stolen, consumed, or user-repositioned items are retained. Vendor and guard witness rules are untouched.
• The Mage Lab's old generic wooden exit overlay and its matching background-painted wooden door are replaced by a 73-command JSON-drawn indigo stone arch with a teal arcane transom, brass trim, medallion, crystal lights and threshold. The `lab_exit` object ID, automatic south-approach walk-through transition and Castle Hall destination remain.

PRESERVATION

All previous areas, unrelated artwork, NPCs, dialogue, quests, objects, navigation meshes and world connections remain unchanged except for the six approved Alchemy Shop stock y-coordinates and the Mage Lab exit dimensions/trigger. Mage Lab's fatal interactables, Fearmonger, Giant Camp Game Over, Mudcrab River behavior, Vault, Kelp's original Vault art, platter-and-wall-seam exploit, and all previous selectable versions remain intact. No prior release was overwritten or removed.

TESTING

Static regression checks and archive parity checks are supplied in `test_f1clean2_9.py` and `SGGF1Clean2.9_TEST_RESULTS.txt`. Pygame is not installed in the build environment, so no live runtime/browser playtest was performed here. Cozmo's field test remains required, especially the two independent gold-pouch theft/guard outcomes (Naz and Lout).
