Spiffy's Gift — complete Cloudflare site. Current playable edition: SGGF1Clean2.11. All earlier selected editions remain available in the version catalogue.
