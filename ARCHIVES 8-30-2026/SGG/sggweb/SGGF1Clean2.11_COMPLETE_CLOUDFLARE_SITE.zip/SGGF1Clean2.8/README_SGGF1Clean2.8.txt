SPIFFY'S GIFT — CLEAN DEPLOYMENT

CURRENT VERSION: SGGF1Clean2.8

The complete Cloudflare site now includes fourteen deliberately selected playable editions, with Clean2.8 current and all thirteen previous catalogue editions retained.

Clean2.8 remodels the Castle Vault as a richly layered stone treasury using the JSON-driven Luma Draw Engine. Kelp's original Vault recipe is preserved intact as c1_bg_castle_vault_kelp_original in the asset JSON. The new central back-wall vault door uses the exact same locked_door drawing recipe and native 130x166 size as the outer vault door in Castle Hall.

The four existing treasure piles, their locations and value, the ordinary wooden Vault Exit, the Vault walkmesh, Castle Hall's vault door and wall seam, both vault connections, and every other world object, area, navigation mesh and transition remain unchanged. In particular, the platter-and-wall-seam exploit remains intact. No new Vault gameplay or interactables were introduced.

The previous thirteen playable editions remain available. Clean2.8 is the final planned area remodel before Cozmo's full end-to-end playthroughs; SGG remains a WIP.
