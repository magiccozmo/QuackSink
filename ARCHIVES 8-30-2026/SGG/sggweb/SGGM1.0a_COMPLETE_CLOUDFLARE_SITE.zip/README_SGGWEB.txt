SPIFFY'S GIFT — SGG WEB PROJECT

Current edition: SGGM1.0. This is the staged continuous-world foundation built from SGGK1.12. It uses 11 continuous 2D sheets, 20 layer portals, a 1280 × 640 (2:1) viewport, world-space movement, walkmeshes, and a dead-zone scrolling camera. The environment uses intentionally simple placeholder drawings; the prior Luma artwork is retained in the source for a later painting stage.

The complete site preserves SGGK1.12 and the eight legacy editions only. See versions.json for the active browser catalogue.
