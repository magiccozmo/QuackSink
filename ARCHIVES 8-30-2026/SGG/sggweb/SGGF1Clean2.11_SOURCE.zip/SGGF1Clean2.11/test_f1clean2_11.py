from __future__ import annotations
import ast, copy, hashlib, json, math, tarfile, zipfile
from pathlib import Path
from types import SimpleNamespace

HERE=Path(__file__).resolve().parent
PROJECT=HERE.parent if HERE.name=='SGGF1Clean2.11' else HERE
BASE=PROJECT/'SGGF1Clean2.10'
NEW=PROJECT/'SGGF1Clean2.11'
DEPLOY=PROJECT/'deploy'
assert BASE.is_dir() and NEW.is_dir() and DEPLOY.is_dir(), 'Run from the complete Clean2.11 source handoff.'
checks=0

def check(value, message):
    global checks
    assert value, message
    checks += 1

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def load(path): return json.loads(Path(path).read_text(encoding='utf-8'))
def tree(root):
    root=Path(root)
    return {p.relative_to(root).as_posix():sha(p) for p in root.rglob('*') if p.is_file()}
def cls(mod,name): return next(n for n in mod.body if isinstance(n,ast.ClassDef) and n.name==name)
def method(cnode,name): return next(n for n in cnode.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name==name)

# 1. Python syntax, mirrors and runtime identity.
main_files=(NEW/'main.py',NEW/'assets'/'main.py',PROJECT/'main.py',PROJECT/'assets'/'main.py',DEPLOY/'SGGF1Clean2.11'/'main.py')
for p in main_files:
    src=p.read_text(encoding='utf-8'); ast.parse(src); compile(src,str(p),'exec')
    check(True,f'Python syntax: {p}')
main_text=(NEW/'main.py').read_text(encoding='utf-8')
mod=ast.parse(main_text)
for p in main_files[1:]: check(p.read_bytes()==main_files[0].read_bytes(),f'Runtime mirror exact: {p}')
check('VERSION = "F1Clean2.11"' in main_text,'Runtime version string')
check('machine = F1Clean2_11StateMachine(archive, config, warning)' in main_text,'Main launches Clean2.11 state machine')
check('ui = F1Clean2_11Interface(machine)' in main_text,'Main launches Clean2.11 interface')
check(cls(mod,'F1Clean2_11Interface').bases[0].id=='F1Clean2_10Interface','Clean2.11 interface retains Clean2.10 UI')

# 2. Luma JSON mirrors and narrowly scoped world data change.
new_json=load(NEW/'luma_assets_e33.json'); old_json=load(BASE/'luma_assets_e33.json')
for p in (NEW/'assets'/'luma_assets_e33.json',PROJECT/'luma_assets_e33.json',PROJECT/'assets'/'luma_assets_e33.json',DEPLOY/'SGGF1Clean2.11'/'luma_assets_e33.json'):
    check(p.read_bytes()==(NEW/'luma_assets_e33.json').read_bytes(),f'Luma JSON mirror exact: {p}')
check(new_json['version']=='F1Clean2.11','Luma JSON current version')
old_compare=copy.deepcopy(old_json); new_compare=copy.deepcopy(new_json)
for d in (old_compare,new_compare):
    d.pop('version',None); d.pop('art_revision',None); d.pop('notes',None)
old_book=next(o for o in old_compare['world']['objects'] if o['object_id']=='shop_recipe_book')
old_book['x'],old_book['y']=200,300
check(old_compare==new_compare,'Only shop_recipe_book world coordinates changed; all other JSON data and art recipes preserved')
book=next(o for o in new_json['world']['objects'] if o['object_id']=='shop_recipe_book')
check((book['x'],book['y'],book['width'],book['height'])==(200,300,49,34),'Fresh-game recipe book is centred on tabletop')
redroot=next(o for o in new_json['world']['objects'] if o['object_id']=='shop_redroot')
old_redroot=next(o for o in old_json['world']['objects'] if o['object_id']=='shop_redroot')
check(redroot==old_redroot,'Redroot world object placement/identity/stock unchanged')
# Tabletop polygon in the existing background: centred item, same authored table.
table=next(c for c in new_json['assets']['alchemy_shop_background']['commands'] if c.get('op')=='polygon' and c.get('points')==[[129,325],[323,325],[331,337],[133,337]])
check(table['points'][0][0] < book['x']+book['width']/2 < table['points'][1][0]+8,'Recipe book centre lies over small table width')
check(book['x']+book['width']/2 < 260 and book['y']+17 <= 325+12,'Recipe book is on the small table depth, not the counter/floor')

# 3. Redroot access code: shelf-state flag is not a gate for approach, reach or hit-test.
model=cls(mod,'Clean211GameModel')
model_methods={n.name:n for n in model.body if isinstance(n,ast.FunctionDef)}
for req in ('_is_live_redroot_stock','object_access_point','close_to_object','hit_test'):
    check(req in model_methods,f'Clean2.11 Redroot model method exists: {req}')
model_src=ast.get_source_segment(main_text,model)
for hidden in ('and obj.on_shelf','and root.on_shelf'):
    check(hidden not in model_src,f'Redroot interaction no longer depends on shelf flag: {hidden}')
for phrase in ('shop_redroot','REDROOT_ACCESS_Y = 382.0','REDROOT_REACH = 230.0','REDROOT_CLICK_INFLATE = (40, 38)'):
    check(phrase in model_src,f'Redroot approach/reach/selection retained: {phrase}')
check('not obj.moved' in ast.get_source_segment(main_text,method(model,'_is_live_redroot_stock')),'Special approach applies only while Redroot remains unmoved')

# Execute the actual Clean2.11 model methods against an old-save-like object with on_shelf=False.
class TinyRect:
    def __init__(self,x,y,w,h): self.x,self.y,self.w,self.h=x,y,w,h
    def inflate(self,dx,dy): return TinyRect(self.x-dx/2,self.y-dy/2,self.w+dx,self.h+dy)
    def collidepoint(self,p): return self.x<=p[0]<=self.x+self.w and self.y<=p[1]<=self.y+self.h
class BaseModel:
    def object_access_point(self,obj): return (obj.x+obj.width/2,obj.y+obj.height/2)
    def close_to_object(self,obj): return False
    def hit_test(self,point): return 'base-hit'
class TestClean210GameModel(BaseModel): pass
namespace={'Clean210GameModel':TestClean210GameModel}
node=copy.deepcopy(model); node.decorator_list=[]
exec(compile(ast.Module(body=[node],type_ignores=[]),'<Clean211GameModel-test>','exec'),namespace)
RuntimeModel=namespace['Clean211GameModel']
inst=RuntimeModel.__new__(RuntimeModel)
inst.current_area_id='alchemy_shop'; inst.player_x=282; inst.player_y=382; inst.carried_object_id=None
root=SimpleNamespace(object_id='shop_redroot',area_id='alchemy_shop',in_inventory=False,moved=False,on_shelf=False,
                     takeable=True,x=269.0,y=293.0,width=26,height=32,rect=lambda: TinyRect(269,293,26,32))
inst.object_by_id=lambda oid: root if oid=='shop_redroot' else None
inst.close_to=lambda x,y,reach=None: math.hypot(inst.player_x-x,inst.player_y-y) <= (118 if reach is None else reach)
check(inst.object_access_point(root)==(282.0,382.0),'False on_shelf legacy object still gets Redroot front-side approach')
check(inst.close_to_object(root),'False on_shelf legacy object is within its dedicated approach reach')
check(inst.hit_test((282,309)) is root,'False on_shelf legacy object gets enlarged clickable target')
root.moved=True
check(inst.object_access_point(root)==(282.0,309.0),'Player-moved Redroot falls back to its actual position')
root.moved=False; root.in_inventory=True
check(inst.hit_test((282,309))=='base-hit','Redroot already in inventory is not re-targeted')

# 4. Save-safe shelf flag migration and recipe placement migration.
state=cls(mod,'F1Clean2_11StateMachine')
state_src=ast.get_source_segment(main_text,state)
check(state.bases[0].id=='F1Clean2_10StateMachine','Clean2.11 extends exact Clean2.10 state machine')
check('RECIPE_BOOK_TARGET = (200.0, 300.0, 49, 34)' in state_src,'Recipe book migration target matches tabletop')
parent_state=cls(mod,'F1Clean2_10StateMachine')
parent_state_src=ast.get_source_segment(main_text,parent_state)
for legacy in ('134.0, 169.0, 49, 34','134.0, 195.0, 49, 34'):
    check(legacy in parent_state_src,f'Inherited untouched legacy recipe position remains supported: {legacy}')
check('333.0, 304.0, 49, 34' in state_src,'Misplaced Clean2.10 recipe position is included in migration')
for required in ('_f1_upgrade_model','_normalize_redroot_shelf_state'):
    check(required in [n.name for n in state.body if isinstance(n,ast.FunctionDef)],f'Redroot state migration method exists: {required}')
red_migration=ast.get_source_segment(main_text,method(state,'_normalize_redroot_shelf_state'))
for phrase in ('shop_redroot','not root.in_inventory','not root.moved','self.REDROOT_DEFAULT','root.on_shelf = True'):
    check(phrase in red_migration,f'Redroot shelf migration guard: {phrase}')
# Execute shelf-flag migration method from the actual AST class.
class DummyStateBase:
    RECIPE_BOOK_LEGACY_LAYOUTS={(134.0,169.0,49,34),(134.0,195.0,49,34)}
namespace2={'F1Clean2_10StateMachine':DummyStateBase,'Clean211GameModel':object}
node2=copy.deepcopy(state); node2.decorator_list=[]
exec(compile(ast.Module(body=[node2],type_ignores=[]),'<Clean211State-test>','exec'),namespace2)
RuntimeState=namespace2['F1Clean2_11StateMachine']
inst2=RuntimeState.__new__(RuntimeState)
inst2.game=SimpleNamespace(object_by_id=lambda oid: root)
inst2._log=lambda *args,**kwargs: None
root.area_id='alchemy_shop'; root.in_inventory=False; root.moved=False; root.x=269.0; root.y=293.0; root.width=26; root.height=32; root.on_shelf=False
check(inst2._normalize_redroot_shelf_state() and root.on_shelf,'Untouched default Redroot shelf flag is restored')
root.on_shelf=False; root.moved=True
check(not inst2._normalize_redroot_shelf_state() and not root.on_shelf,'Moved Redroot flag is not reset')
root.moved=False; root.in_inventory=True; root.on_shelf=False
check(not inst2._normalize_redroot_shelf_state() and not root.on_shelf,'Inventory Redroot flag is not reset')
root.in_inventory=False; root.x=270.0
check(not inst2._normalize_redroot_shelf_state() and not root.on_shelf,'Non-default Redroot position is not reset')

recipe_method=ast.get_source_segment(main_text,method(cls(mod,'F1Clean2_10StateMachine'),'_normalize_recipe_book_layout'))
for phrase in ('shop_recipe_book','RECIPE_BOOK_LEGACY_LAYOUTS','book.in_inventory','or book.moved','RECIPE_BOOK_TARGET'):
    check(phrase in recipe_method,f'Inherited recipe migration retains guard: {phrase}')

# 5. Current edition assets and web entry.
for p in (NEW/'luma_assets_e33.json',DEPLOY/'SGGF1Clean2.11'/'luma_assets_e33.json'):
    check(json.loads(p.read_text())['version']=='F1Clean2.11',f'JSON version in {p}')
play=(NEW/'play.html').read_text()
check('F1Clean2.11' in play and 'sggf1clean2_11.tar.gz' in play and 'sggf1clean2_11.apk' in play,'Web launcher points to current runtime packages')
for p in (NEW/'sggf1clean2_11.apk',NEW/'sggf1clean2_11.tar.gz',DEPLOY/'SGGF1Clean2.11'/'sggf1clean2_11.apk',DEPLOY/'SGGF1Clean2.11'/'sggf1clean2_11.tar.gz'):
    check(p.is_file() and p.stat().st_size>10000,f'Runtime package exists and is nonempty: {p}')
with zipfile.ZipFile(NEW/'sggf1clean2_11.apk') as z:
    check(z.testzip() is None,'APK ZIP integrity')
    check(z.read('assets/main.py')==(NEW/'main.py').read_bytes(),'APK embeds exact main.py')
    check(z.read('assets/luma_assets_e33.json')==(NEW/'luma_assets_e33.json').read_bytes(),'APK embeds exact Luma JSON')
with tarfile.open(NEW/'sggf1clean2_11.tar.gz','r:gz') as t:
    check(t.extractfile('assets/main.py').read()==(NEW/'main.py').read_bytes(),'TAR embeds exact main.py')
    check(t.extractfile('assets/luma_assets_e33.json').read()==(NEW/'luma_assets_e33.json').read_bytes(),'TAR embeds exact Luma JSON')
with zipfile.ZipFile(DEPLOY/'SGGF1Clean2.11'/'sggf1clean2_11.apk') as z:
    check(z.read('assets/main.py')==(DEPLOY/'SGGF1Clean2.11'/'main.py').read_bytes(),'Deploy APK embeds exact current main.py')
with tarfile.open(DEPLOY/'SGGF1Clean2.11'/'sggf1clean2_11.tar.gz','r:gz') as t:
    check(t.extractfile('assets/main.py').read()==(DEPLOY/'SGGF1Clean2.11'/'main.py').read_bytes(),'Deploy TAR embeds exact current main.py')

# 6. Version catalogue: 17 selectable editions, only Clean2.11 current.
versions=load(DEPLOY/'versions.json')
entries=versions['versions']
check(len(entries)==17,'Version catalogue has 17 selectable editions')
check(entries[0]['version']=='SGGF1Clean2.11' and entries[0]['current'] is True,'Clean2.11 is the top/current edition')
check(sum(bool(v.get('current')) for v in entries)==1,'Exactly one current edition')
for entry in entries:
    check((DEPLOY/entry['path']).is_file(),f'Catalogue route exists: {entry["path"]}')
    if entry.get('image'):
        check((DEPLOY/entry['image']).is_file(),f'Catalogue preview exists: {entry["image"]}')
check((DEPLOY/'SGGF1Clean2.11'/'alchemy_shop_preview.png').is_file(),'New Alchemy Shop preview exists')
check((NEW/'alchemy_shop_preview.png').is_file(),'Source Alchemy Shop preview exists')

# 7. All 16 old deployed editions are byte-for-byte unchanged; only catalogue and root README change.
manifest=load(NEW/'Clean2.10_DEPLOYMENT_SHA256_MANIFEST.json')
current=tree(DEPLOY)
allowed_changed={'versions.json','README_SGGWEB.txt'}
for rel,h in manifest.items():
    check(rel in current,f'Old deployment file retained: {rel}')
    if rel not in allowed_changed:
        check(current[rel]==h,f'Old deployment file unchanged: {rel}')
for version in ('SGGE2.0','SGGE3.1','SGGE3.2','SGGF1.0','SGGF1.6','SGGF1.666','SGGF1.666Cleanup1.0','SGGF1.666f1s',
                'SGGF1Clean2.2','SGGF1Clean2.4','SGGF1Clean2.5','SGGF1Clean2.6','SGGF1Clean2.7','SGGF1Clean2.8','SGGF1Clean2.9','SGGF1Clean2.10'):
    check((DEPLOY/version).is_dir(),f'Prior version folder remains: {version}')
check(not any(p.suffix.lower()=='.mp4' for p in DEPLOY.rglob('*') if p.is_file()),'No MP4 files in deployment')

# 8. Embedded source deployment must be a byte-identical mirror of standalone deploy.
mirror=PROJECT/'deploy'
mirror_tree=tree(mirror); deploy_tree=tree(DEPLOY)
check(mirror_tree==deploy_tree,'Source-embedded deploy mirrors standalone deployment exactly')
check(tree(NEW/'assets')=={'main.py':sha(NEW/'main.py'),'luma_assets_e33.json':sha(NEW/'luma_assets_e33.json')},'New source asset directory contains exact two runtime sources')

# 9. Preserve historical Clean2.10 source edition verbatim.
check(tree(BASE)==load(NEW/'Clean2.10_SOURCE_SHA256_MANIFEST.json'),'Historical Clean2.10 source directory remains byte-for-byte unchanged')
historical_deploy={k.split('/',1)[1]:v for k,v in manifest.items() if k.startswith('SGGF1Clean2.10/')}
check(tree(DEPLOY/'SGGF1Clean2.10')==historical_deploy,'Historical Clean2.10 deployment directory remains byte-for-byte unchanged')

# 10. Release files exclude large videos and source archive includes complete embedded deployment.
check(not any(p.suffix.lower()=='.mp4' for p in PROJECT.rglob('*') if p.is_file()),'No MP4 files in complete source handoff')

result=f'''SGGF1Clean2.11 STATIC TEST RESULTS\n\nResult: PASS — {checks} focused regression and preservation assertions.\n\nPASS SUMMARY\n\n• Python syntax and bytecode compilation for the new runtime and all active source mirrors.\n• Redroot access point, reach and enlarged selection operate when a legacy saved object has on_shelf=False; the actual Clean2.11 class methods were executed against a simulated legacy item.\n• Redroot shelf-flag migration restores only untouched stock at its exact default position; moved, inventory and non-default objects are not reset.\n• Recipe book moves to the centre of the small Alchemy Shop table in fresh games; Clean2.10 misplaced position and both older known defaults are migrated only when the book is untouched and not in inventory.\n• Luma JSON comparison confirms the only world-object data change is shop_recipe_book x/y. All art recipes, room geometry, solids, navigation, other objects and connections remain unchanged.\n• Runtime APK/TAR packages contain the exact new main.py and Luma JSON; package integrity passed.\n• The deployment catalogue has 17 selectable editions with exactly one current entry. All 16 earlier editions and prior deployment files remain byte-for-byte unchanged except the intended versions.json and current root README updates.\n• The source-embedded complete deployment matches the standalone Cloudflare site file-for-file. The historical Clean2.10 source and deployment directories remain unchanged.\n• No MP4 files were added.\n\nLIMITATIONS\n\nPygame is not installed in the build environment. No live browser, WebAssembly, Cloudflare, mouse-click, keyboard pickup or save/load test was performed. Static and simulated legacy-object tests are not a substitute for Cozmo's field test.\n'''
(NEW/'SGGF1Clean2.11_TEST_RESULTS.txt').write_text(result,encoding='utf-8')
(NEW/'SGGF1Clean2.11_BUILD_META.json').write_text(json.dumps({
  **load(NEW/'SGGF1Clean2.11_BUILD_META.json'),
  'static_check_count': checks,
  'static_checks': [
    f'{checks} focused Clean2.11 regression and preservation assertions passed.',
    'The actual Clean211GameModel access methods were executed against a simulated older save with on_shelf=False; approach, reach and expanded click selection passed.',
    'The exact-default Redroot migration restores on_shelf only when the object is unmoved and not in inventory; three negative cases (moved, carried/inventory, non-default position) were tested.',
    'The only current Luma world object change is the recipe book x/y; drawing recipes, geometry, collision, navigation and connections are otherwise unchanged.',
    'APK and TAR package contents match exact main.py and Luma JSON mirrors; archive integrity passed.',
    'All sixteen previous selectable deployment editions remain byte-for-byte preserved; version catalogue has seventeen entries, one current edition, and all route/image links resolve.',
    'The source-embedded full deployment mirror equals the standalone Cloudflare site; historical Clean2.10 source and deploy directories remain byte-for-byte unchanged.'
  ]
},indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(f'PASS: {checks} focused Clean2.11 assertions')
