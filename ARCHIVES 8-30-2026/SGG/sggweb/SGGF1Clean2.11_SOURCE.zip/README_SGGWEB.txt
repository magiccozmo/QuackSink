SPIFFY'S GIFT — COMPLETE SOURCE HANDOFF

CURRENT VERSION: SGGF1Clean2.11

Clean2.11 is a focused Alchemy Shop correction built from the exact Clean2.10 source and complete Cloudflare deployment. Redroot's dedicated approach and expanded hit target now work independently of a stale legacy on_shelf flag; the shelf flag is restored only for untouched Redroot at its exact default location. The Potent Problem recipe book is placed on the small wooden side table, and an untouched Clean2.10 save at the former misplaced position is migrated safely. Previously moved or carried objects are preserved.

The grounded matching Mage Lab doors, challenge quicksave behavior, settings cleanup, Downloads-only log export, all other gameplay systems, all previous selectable editions, historical source archives and Kelp's original Vault recipe remain preserved. See SGGF1Clean2.11_BUILD_META.json and the new version folder for details.
