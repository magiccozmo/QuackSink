SPIFFY'S GIFT — CURATED CLOUDFLARE SITE

Current release: SGGF1.666Cleanup1.0, created from the verified SGGF1.666f1s baseline.

The version menu intentionally retains only these historical playable milestones:
SGGE2.0, SGGE3.1, SGGE3.2, SGGF1.0, SGGF1.6, SGGF1.666, and SGGF1.666f1s.
SGGF1.666Cleanup1.0 is the current release.

All other intermediate releases remain in the complete public GitHub repository and Cozmo's local archive. They are not repeated in this Cloudflare distribution.

Gameplay is unchanged from F1s. HELLgs Inn remains the starting scenario throughout the F1.666 line. The later normal-start / optional Challenge Mode redesign is deferred until after SGGF1.666Final.
