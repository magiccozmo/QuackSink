SPIFFY'S GIFT — SGGF1.6
Castle Hall floor-aligned walkmesh correction (built directly from F1.5)

WHAT CHANGED
- Corrected Castle Hall ground navigation so the player's foot position stays on the visible stone floor rather than walking across the back wall.
- The main Castle Hall floor is now a walkable polygon from x=24..1260 and y=418..626.
- Added one narrow, connected approach lane at x=1018..1074 and y=306..418. It preserves access to the existing off-centre vault seam and platter target without making the rest of the back wall walkable.
- No art was changed. The F1.5 Castle Hall background is retained byte-for-byte.

DOORS, VAULT, AND EXPLOIT PRESERVATION
- Left Mage Room door: unchanged object, transition trigger, connection, and arrival point.
- Middle Castle Exterior door: unchanged. The amusing enter-while-moving-and-immediately-exit loop remains.
- Right Bank Vault Door: unchanged appearance, object, interaction, dialogue, and permanent locked state.
- Special Hard Hitbox: unchanged persistent 1.0–5.0 setting, default 3.0, and off-centre target center at (1046,333).
- The existing vault_wall_seam object and castle_hall_to_vault_clip connection are unchanged.
- Both existing seam entry methods remain: the directional carried-plate clip route and the E-interaction on the seam while carrying a plate. The latter is explicitly regression-tested.
- No other game exploit, door transition, item, inventory rule, save behavior, or area navigation definition was intentionally changed.

WHAT DID NOT CHANGE
- All F1.5 Castle Hall art, vault-door art, objects, NPCs, doors, connections, collision definitions, dialogue, configuration, and gameplay code are preserved.
- All other world areas, asset recipes, quests, Kitty, Stables, carriage, comments, and Part One finale are preserved.
- Every prior Cloudflare deployment entry is retained byte-for-byte except versions.json, which now lists SGGF1.6 as current.

IMPLEMENTATION
- Runtime code: main.py
- World and Luma artwork: luma_assets_e33.json
- Browser entry page: F1_play.html (archive identifier sggf16)
- F1.5 source snapshots are included so this release can be audited against its exact base.

DEPLOYMENT
Upload the contents of SGGF1.6_CLOUDFLARE_DEPLOY.zip to the existing Cloudflare static-assets site, preserving the archive folder structure. The package contains all earlier releases plus the new SGGF1.6 browser bundle. The comments API Worker and D1 database do not need changes.

TESTING AND VERIFICATION
- Python AST parsing and py_compile pass.
- The F1.6 regression suite verifies that the only F1.5 world-data change is Castle Hall navigation; the visible floor and narrow seam approach are connected; the left and middle door approaches are reachable; non-floor back-wall positions are blocked; and the seam E-interaction still enters the vault while carrying a plate.
- The regression suite also rechecks the unchanged F1.5 door/connection identities, hidden directional clip, off-centre hitbox scaling, vault-object hit test, lock/force dialogue, item-specific responses, permanently closed door, and persistent config setting.
- Runtime APK and TAR payloads are checked against the exact F1.6 source bytes.
- Both ZIP archives are checked for CRC integrity, unique paths, valid version catalog, and byte-for-byte preservation of all previous deployment files except versions.json.
- The existing F1.5 hall preview is retained because the F1.6 change is navigation-only; no artwork was altered.
- This build was not launched in a live browser. Please field-test F1.6 for movement at the visible floor edge, access to each door, the narrow seam approach, and the existing vault entry behavior.
