The complete Cloudflare static-site distribution is in the source package's ../deploy mirror. This folder is the SGGF1.666HellFinal current playable edition.
