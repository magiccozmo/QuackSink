SPIFFY'S GIFT — SGGF2.0a

F2.0 STARTUP HOTFIX
This edition fixes a startup crash in the original F2.0 build. The existing SGGF1_666HellFinalInterface class is now defined before SGGF2Interface subclasses it. In F2.0, the child class appeared first and Python raised NameError while importing main.py, leaving the browser window blank after the loading screen.

CHOOSE YOUR PATH
• Easy: begin in the Stables; fast travel to every ordinary world area is available immediately.
• Normal: begin in the Stables; fast-travel destinations unlock as you discover new areas.
• Spiffy Challenge: begin in HELLgs Inn and retain the special locked-cell, cross-version save-escape challenge.

The three choices share the same world, quests, artwork, exploits, inventory, save system and transitions. The selected difficulty is stored with each save. Easy/Normal do not clear the shared quicksave; only a new Spiffy Challenge run performs the established HELLgs quicksave reset.

The existing HELLgs editions remain available in the version chooser. Their public descriptions intentionally avoid revealing the challenge details.

The corrected code order, package mirrors, bundle references, catalogue and archive integrity were checked statically. A live browser/WebAssembly session and gameplay field test have not yet been performed; Cozmo's launch test remains necessary.
