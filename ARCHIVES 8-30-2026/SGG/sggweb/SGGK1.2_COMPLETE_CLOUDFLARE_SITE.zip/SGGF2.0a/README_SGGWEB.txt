SGGF2.0a browser edition. Launch play.html; the page loads sggf2_0a.tar.gz (or sggf2_0a.apk on itch-hosted pages).
