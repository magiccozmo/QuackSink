SPIFFY'S GIFT — SGGF1.666

BASE
F1.6 is the direct gameplay and world baseline. F1.6 source, JSON, and browser-entry snapshots are retained in this source package.

HELLgs Inn
The game starts in a small stone cell called HELLgs Inn. Its only visible exit is a solid barred cell door drawn into the background and backed by collision geometry. It is deliberately not a world object, is not interactable, and has no ordinary door transition. Stone walls and the closed cell door are solid. The cell floor itself is walkable.

A folded paper lies on the floor. Pick it up, open Inventory, select the paper, and press E to read:

Welcome brave exploiter to version F1.666 of Spiffy's Gift.
I look forwarding to meeting you.
Signed Cozmo

END CONDITION
The fire surges through the cell door after ONE in-game day OR when the selected real-time timer expires, whichever happens first. Initial End Timer in Minutes is a new persistent settings slider, range 1–1440 minutes, default 60 minutes. Press T to advance one in-game day. The fire animates through the gate, consumes the player, and causes a final GAME OVER; R does not respawn the player.

SCOPE / PRESERVATION
No normal exit, door object, or new area connection is defined for HELLgs Inn. Existing F1.6 game systems are retained, including the ordinary fast-travel system and its existing destination list. No special escape route or solution is added. The room is authored as specified so Cozmo can test his own system exploit. All pre-existing F1.6 areas, objects, connections, artwork, Castle Hall walkmesh, vault dialogue, platter/plate behavior, and other mechanics are retained.

TESTING
Static checks cover the JSON/Luma recipes, sealed-room collision and floor navigation, spawn, note pickup/read path, day-or-minutes deadline, persistent slider normalization, no new Hellgs connections, and F1.6 historical asset/world preservation. A live browser field test remains for the user.
