SPIFFY'S GIFT — COMPLETE SOURCE AND DEPLOYMENT PACKAGE

Current edition: SGGK1.2. The archive contains the new Grella escort sequence, the Giant Camp flight route, Mudcrab River first-entrant result, Cookpot Hole-in-One award, and all previous selectable releases.

The authoritative current source is at the project root (main.py, luma_assets_e33.json and validate_luma_assets.mjs). The complete versioned runtime folder is deploy/SGGK1.2. SGGK1.1 and all earlier deployed editions remain intact as historical versions.

K1.2 preserves the existing 23-area/44-connection world and save schema. New quest/effect values use additional c1_flags fields that migrate into existing saves without resetting them. See deploy/SGGK1.2/SGGK1.2_README.txt, SGGK1.2_TEST_RESULTS.txt and SGGK1.2_LUMA_LOG_Entry038.txt.

No GitHub main push or Cloudflare static-site deployment was performed by Luma. Live browser testing remains for Cozmo's field test.
