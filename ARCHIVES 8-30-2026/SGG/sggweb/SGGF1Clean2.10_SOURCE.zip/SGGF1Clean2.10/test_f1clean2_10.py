from __future__ import annotations
import ast, copy, hashlib, json, tarfile, zipfile
from pathlib import Path

HERE=Path(__file__).resolve().parent
PROJECT=HERE.parent if HERE.name=='SGGF1Clean2.10' else HERE
BASE=PROJECT/'SGGF1Clean2.9'
NEW=PROJECT/'SGGF1Clean2.10'
DEPLOY=PROJECT/'deploy'
assert BASE.is_dir() and NEW.is_dir() and DEPLOY.is_dir(), 'Run from the complete Clean2.10 source handoff.'
checks=0

def check(value, message):
    global checks
    assert value, message
    checks += 1

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def load(path): return json.loads(Path(path).read_text(encoding='utf-8'))
def tree(root):
    root=Path(root)
    return {p.relative_to(root).as_posix():sha(p) for p in root.rglob('*') if p.is_file()}

BASE_MANIFEST=load(HERE/'Clean2.9_DEPLOYMENT_SHA256_MANIFEST.json')

def cls(tree_node, name): return next(n for n in tree_node.body if isinstance(n,ast.ClassDef) and n.name==name)
def method(cnode, name): return next(n for n in cnode.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name==name)

# Current runtime parity and Python syntax.
for path in (NEW/'main.py',NEW/'assets'/'main.py',HERE/'main.py',PROJECT/'assets'/'main.py'):
    src=path.read_text(encoding='utf-8'); ast.parse(src); compile(src,str(path),'exec')
    check(True,f'Python syntax: {path}')
check((NEW/'main.py').read_bytes()==(NEW/'assets'/'main.py').read_bytes(),'Clean2.10 current source asset mirror')
check((HERE/'main.py').read_bytes()==(NEW/'main.py').read_bytes(),'Active source root is Clean2.10')
check((PROJECT/'assets'/'main.py').read_bytes()==(NEW/'main.py').read_bytes(),'Shared source asset runtime is Clean2.10')
check('VERSION = "F1Clean2.10"' in (NEW/'main.py').read_text(),'Runtime version string')

# World geometry and Luma art definitions are preserved; only top-level release notes/version changed.
old_json=load(BASE/'luma_assets_e33.json'); new_json=load(NEW/'luma_assets_e33.json')
check(new_json['world']==old_json['world'],'All current world objects, room geometry, collision, walkmeshes and transitions unchanged')
old_asset_copy=copy.deepcopy(old_json); new_asset_copy=copy.deepcopy(new_json)
for key in ('version','art_revision','notes'):
    old_asset_copy.pop(key,None); new_asset_copy.pop(key,None)
check(new_asset_copy==old_asset_copy,'All Luma drawing recipes and non-version metadata unchanged')
check(new_json['version']=='F1Clean2.10','Luma JSON version')
for oid in ('lab_door','lab_exit'):
    b=next(o for o in old_json['world']['objects'] if o['object_id']==oid)
    n=next(o for o in new_json['world']['objects'] if o['object_id']==oid)
    check(n==b,f'{oid} object, collision and walk trigger preserved')
old_connections=[c for c in old_json['world']['connections'] if 'mages_lab' in c['from_area_id'] or 'mages_lab' in c['to_area_id']]
new_connections=[c for c in new_json['world']['connections'] if 'mages_lab' in c['from_area_id'] or 'mages_lab' in c['to_area_id']]
check(new_connections==old_connections,'Both Mage Lab reciprocal area transitions preserved')

# Redroot: only its targeted object gets its own access/reach/hitbox overrides.
text=(NEW/'main.py').read_text(encoding='utf-8'); mod=ast.parse(text)
model=cls(mod,'Clean210GameModel'); methods={n.name:n for n in model.body if isinstance(n,ast.FunctionDef)}
for required in ('object_access_point','close_to_object','hit_test'):
    check(required in methods,f'Redroot-specific model override exists: {required}')
for phrase in ('shop_redroot','REDROOT_ACCESS_Y = 382.0','REDROOT_REACH = 230.0','REDROOT_CLICK_INFLATE = (40, 38)'):
    check(phrase in ast.get_source_segment(text,model),f'Redroot reach/selection setting: {phrase}')
redroot=next(o for o in new_json['world']['objects'] if o['object_id']=='shop_redroot')
check((redroot['x'],redroot['y'],redroot['width'],redroot['height'])==(269,293,26,32),'Redroot art/object position retained; reach fix is interaction-only')

# Recipe book migration is limited to untouched known legacy defaults and the screenshot's table position.
state=cls(mod,'F1Clean2_10StateMachine'); state_methods={n.name:n for n in state.body if isinstance(n,ast.FunctionDef)}
check(state.bases[0].id=='F1Clean2_9StateMachine','Clean2.10 extends the exact Clean2.9 state machine')
for required in ('_normalize_recipe_book_layout','start_game','_read_save','_clear_challenge_quicksave','e41_export','e41_choose_folder'):
    check(required in state_methods,f'Clean2.10 state override exists: {required}')
recipe_method=ast.get_source_segment(text,state_methods['_normalize_recipe_book_layout'])
for phrase in ('shop_recipe_book','RECIPE_BOOK_LEGACY_LAYOUTS','book.in_inventory','or book.moved','RECIPE_BOOK_TARGET'):
    check(phrase in recipe_method,f'Recipe book migration guard: {phrase}')
check('333.0, 304.0, 49, 34' in ast.get_source_segment(text,state),'Reference recipe target is x333,y304,49x34')
check((next(o for o in new_json['world']['objects'] if o['object_id']=='shop_recipe_book')['x'],
       next(o for o in new_json['world']['objects'] if o['object_id']=='shop_recipe_book')['y'])==(333,304),
      'Fresh Alchemy Shop layout puts recipe book on the table shown in alchj fix reference')

# Challenge startup deletes only the shared quick slot.
start=ast.get_source_segment(text,state_methods['start_game'])
clear=ast.get_source_segment(text,state_methods['_clear_challenge_quicksave'])
check("self._clear_challenge_quicksave('challenge game start')" in start,'Every challenge game start clears its quicksave')
check("E1_STORAGE.delete(self.CHALLENGE_QUICKSAVE_KEY)" in clear,'Only named shared quicksave key is deleted')
check("CHALLENGE_QUICKSAVE_KEY = 'save-quick'" in ast.get_source_segment(text,state),'Challenge clears exact save-quick slot')
check('save-slot' not in clear and 'save-1' not in clear and 'save-2' not in clear and 'save-3' not in clear,'Numbered save slots are not deleted')
check("STORAGE_NAMESPACE = 'spiffys-gift-sgge1-v1:'" in text,'Shared cross-version storage namespace remains common')
check('self._log(\'CLEAN2.10 CHALLENGE QUICKSAVE RESET\'' in clear,'Quicksave reset is logged')

# Settings must be generic and no longer expose log-directory controls or platter/vault hints.
ui=cls(mod,'F1Clean2_10Interface'); ui_methods={n.name:n for n in ui.body if isinstance(n,ast.FunctionDef)}
settings=ast.get_source_segment(text,ui_methods['_draw_c13_game_config'])
check('Ultra Hard Hitbox' in settings,'Settings show Ultra Hard Hitbox label')
for hidden in ('platter','vault','seam','door','log_directory','log_folder_name','CHOOSE FOLDER','LOG PATH','Browser folder'):
    check(hidden.lower() not in settings.lower(),f'Settings contain no extra clue or log path UI: {hidden}')
check('DOWNLOADS FOLDER' in settings,'Settings state that log exports go to Downloads')
export=ast.get_source_segment(text,state_methods['e41_export'])
check('_downloadLog(contents, name)' in export,'Browser logs use ordinary download flow and bypass saved folder picker')
check("Path.home() / 'Downloads'" in export,'Desktop logs use Downloads folder')
for hidden in ('log_directory','log_folder_name','_getHandle','exportLog('):
    check(hidden not in export,f'Export ignores legacy folder preferences: {hidden}')
choose=ast.get_source_segment(text,state_methods['e41_choose_folder'])
check('Log exports always go to Downloads.' in choose,'Legacy folder-picker click is inert and gives neutral status')

# Door render targets increase size, align bottoms to each existing doorway, and do not mutate geometry.
check(ui_methods['DOOR_ART_SIZE'].value if isinstance(ui_methods.get('DOOR_ART_SIZE'),ast.Assign) else True,'Door rendering class has size configuration')
ui_class_text=ast.get_source_segment(text,ui)
check('DOOR_ART_SIZE = (168, 228)' in ui_class_text,'Both doors enlarged about 20 percent')
check('GAME_HEIGHT-art_h' in ui_class_text,'Mage Lab exit art bottom is anchored to screen bottom')
check('lab_door.y + lab_door.height - art_h' in ui_class_text,'Castle Hall matching arch bottom aligns with existing doorway base')
check("'mage_lab_exit_door'" in ui_class_text,'Both doors use the exact same Mage Lab arch recipe')

# Challenge help is preserved with no new escape hints.
challenge_hint=ast.get_source_segment(text,method(cls(mod,'F1Clean2_9Interface'),'_d1_hint'))
check('WASD MOVE' in challenge_hint and 'F9 LOAD' in challenge_hint,'General controls remain')
check('two-tab' not in challenge_hint.lower() and 'second tab' not in challenge_hint.lower(),'Two-tab exploit is not explained in player help')

# App starts Clean2.10 classes; old baseline runtime remains unchanged.
check('F1Clean2_10StateMachine(archive, config, warning)' in text,'Application starts Clean2.10 state machine')
check('F1Clean2_10Interface(machine)' in text,'Application starts Clean2.10 interface')
check((BASE/'main.py').read_bytes()==(BASE/'assets'/'main.py').read_bytes(),'Clean2.9 historical runtime mirror untouched')

# Verify the exact Clean2.9 deployment files against a compact, portable SHA-256 manifest.
base_tree=BASE_MANIFEST['files']; new_tree=tree(DEPLOY)
for rel,digest in base_tree.items():
    if rel=='versions.json': continue
    check(new_tree.get(rel)==digest,f'Previous deployment file preserved byte-for-byte: {rel}')
check(set(base_tree)-{'versions.json'} <= set(new_tree),'No files removed from the previous complete deployment')
for old_name in BASE_MANIFEST['playable_folders']:
    check((DEPLOY/old_name).is_dir(),f'Prior playable edition remains present: {old_name}')

versions=load(DEPLOY/'versions.json')['versions']
check(len(versions)==16,'Sixteen selectable deployment editions')
check(versions[0]['version']=='SGGF1Clean2.10' and versions[0]['current'] is True,'Clean2.10 is first and current')
check(sum(bool(v.get('current')) for v in versions)==1,'Exactly one current edition')
check('two-tab' not in versions[0]['title'].lower()+versions[0]['description'].lower() and 'quicksave' not in versions[0]['description'].lower(),'Public catalogue does not reveal challenge escape mechanic')
for v in versions:
    check((DEPLOY/v['path']).is_file(),f'Catalogue route exists: {v["version"]}')
    if v.get('image'): check((DEPLOY/v['image']).is_file(),f'Catalogue image exists: {v["version"]}')

# Version directory payloads and package integrity.
for root in (NEW,DEPLOY/'SGGF1Clean2.10'):
    check((root/'play.html').is_file(),'Clean2.10 play.html exists')
    check('F1Clean2.10' in (root/'play.html').read_text(encoding='utf-8'),'Clean2.10 play page version label')
    check('sggf1clean2_10' in (root/'play.html').read_text(encoding='utf-8'),'Clean2.10 play page bundle name')
    apk=root/'sggf1clean2_10.apk'; tgz=root/'sggf1clean2_10.tar.gz'
    check(apk.is_file() and tgz.is_file(),'Clean2.10 APK and TAR bundles exist')
    with zipfile.ZipFile(apk) as z:
        check(z.testzip() is None,'Clean2.10 APK ZIP integrity')
        check(z.read('assets/main.py')==(root/'main.py').read_bytes(),'APK carries Clean2.10 main.py')
        check(z.read('assets/luma_assets_e33.json')==(root/'luma_assets_e33.json').read_bytes(),'APK carries current Luma JSON')
    with tarfile.open(tgz,'r:gz') as t:
        payload={m.name:t.extractfile(m).read() for m in t.getmembers() if m.isfile()}
        check(payload['assets/main.py']==(root/'main.py').read_bytes(),'TAR carries Clean2.10 main.py')
        check(payload['assets/luma_assets_e33.json']==(root/'luma_assets_e33.json').read_bytes(),'TAR carries current Luma JSON')

check((NEW/'VERSION').read_text().strip()=='16','Source edition counter records 16 playable editions')
check((PROJECT/'deploy').is_dir(),'Embedded complete deployment mirror exists')
check('Clean2.10' in (NEW/'README_SGGF1Clean2.10.txt').read_text(encoding='utf-8'),'Clean2.10 handoff README exists')
check('Clean2.9' in (BASE/'README_SGGF1Clean2.9.txt').read_text(encoding='utf-8'),'Historical Clean2.9 handoff remains intact')
check(bool(BASE_MANIFEST['files']) and len(BASE_MANIFEST['playable_folders'])==15,'Portable original deployment preservation manifest is complete')

print(f'SGGF1Clean2.10 static regression self-test passed: {checks} assertions.')
