from __future__ import annotations
import ast, copy, hashlib, json, tarfile, zipfile
from pathlib import Path

HERE=Path(__file__).resolve().parent
PROJECT=HERE.parent if HERE.name=='SGGF1Clean2.9' else HERE
BASE=PROJECT/'SGGF1Clean2.8'
NEW=PROJECT/'SGGF1Clean2.9'
DEPLOY=PROJECT/'deploy'
assert BASE.is_dir() and NEW.is_dir() and DEPLOY.is_dir(), 'Run from complete SGG source handoff.'

checks=0
def check(value, message):
    global checks
    assert value, message
    checks += 1

def load(path): return json.loads(Path(path).read_text(encoding='utf-8'))
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def tree_files(root):
    root=Path(root)
    return {p.relative_to(root).as_posix():sha(p) for p in root.rglob('*') if p.is_file()}

# Runtime syntax and mirrored current sources.
for path in (NEW/'main.py',NEW/'assets'/'main.py',NEW/'package_f1clean2_9.py',HERE/'main.py',HERE/'package_f1clean2_9.py'):
    src=path.read_text(encoding='utf-8'); ast.parse(src); compile(src,str(path),'exec')
    check(True, f'Python syntax: {path.name}')
check((NEW/'main.py').read_bytes()==(NEW/'assets'/'main.py').read_bytes(), 'Current version main.py mirror')
check((NEW/'luma_assets_e33.json').read_bytes()==(NEW/'assets'/'luma_assets_e33.json').read_bytes(), 'Current version JSON mirror')
check((HERE/'main.py').read_bytes()==(NEW/'main.py').read_bytes(), 'Source root active runtime equals Clean2.9')
check((HERE/'luma_assets_e33.json').read_bytes()==(NEW/'luma_assets_e33.json').read_bytes(), 'Source root active JSON equals Clean2.9')
check('VERSION = "F1Clean2.9"' in (NEW/'main.py').read_text(encoding='utf-8'), 'Runtime version string')

# JSON and exact scope of world data changes.
base=load(BASE/'assets'/'luma_assets_e33.json'); new=load(NEW/'assets'/'luma_assets_e33.json')
check(new['version']=='F1Clean2.9', 'Luma JSON version')
expected_world=copy.deepcopy(base['world'])
shifts={
 'shop_healing_potion':231.0,'shop_spell_scroll':236.0,'shop_miracle_potion':230.0,
 'shop_gold_pouch':230.0,'shop_blue_vial':231.0,'shop_counter_sample':231.0,
}
for obj in expected_world['objects']:
    if obj['object_id'] in shifts: obj['y']=shifts[obj['object_id']]
lab=next(o for o in expected_world['objects'] if o['object_id']=='lab_exit')
lab.update({'x':570,'y':410,'width':140,'height':190,'walk_trigger':{'rect':[574,538,132,50],'approach':'south'}})
check(new['world']==expected_world, 'Only six Alchemy Shop stock y values and Mage Lab exit bounds/trigger changed in world definition')
check(new['world']['connections']==base['world']['connections'], 'All area connections unchanged')
check(new['world']['areas']==base['world']['areas'], 'All area geometry/walkmeshes unchanged')
check(new['world']['npcs']==base['world']['npcs'], 'All NPC data unchanged')
for oid in ('shop_healing_potion','shop_spell_scroll','shop_miracle_potion','shop_gold_pouch','shop_blue_vial','shop_counter_sample'):
    b=next(o for o in base['world']['objects'] if o['object_id']==oid)
    n=next(o for o in new['world']['objects'] if o['object_id']==oid)
    for k in b:
        if k!='y': check(n.get(k)==b.get(k), f'{oid} unrelated field preserved: {k}')
market_base=next(o for o in base['world']['objects'] if o['object_id']=='market_gold_pouch')
market_new=next(o for o in new['world']['objects'] if o['object_id']=='market_gold_pouch')
check(market_new==market_base, 'Market gold pouch untouched')

# Alchemy shelf placement / reach and migration guard.
main=NEW/'main.py'; text=main.read_text(encoding='utf-8')
check('ALCHEMY_SHELF_REACH = 160.0' in text, 'Alchemy Shop shelf reach increased')
check('ALCHEMY_SHELF_CLICK_INFLATE = (30, 24)' in text, 'Alchemy Shop shelf hit target enlarged')
check("return (obj.x + obj.width / 2.0, 350.0)" in text, 'Shelf approach point moves to accessible front side')
check("and not obj.in_inventory and not obj.moved" in text, 'Migration excludes carried/moved objects')
check("(obj.x, obj.y, obj.width, obj.height) == (old_x, old_y, old_w, old_h)" in text, 'Migration requires exact old default coordinates')
for oid,y in shifts.items():
    check(f"'{oid}':" in text and f"{y:.1f}" in text, f'Save migration target for {oid}')
check("obj.area_id == 'alchemy_shop'" in text, 'Migration scoped to Alchemy Shop objects')
check("self._normalize_alchemy_stock_layout('new game start')" in text and "self._normalize_alchemy_stock_layout(f'load of {slot}')" in text, 'New game/load migration entry points')

# General control help, with F-Consume Soup displayed only for actual inventory soup.
mod=ast.parse(text)
classes={n.name:n for n in mod.body if isinstance(n,ast.ClassDef)}
check('F1Clean2_9Interface' in classes, 'Clean2.9 interface class exists')
ui=classes['F1Clean2_9Interface']
hints=next(n for n in ui.body if isinstance(n,ast.FunctionDef) and n.name=='_d1_hint')
hint_src=ast.get_source_segment(text,hints)
for phrase in ('WASD MOVE','E INTERACT','I INVENTORY','B BUY','V SELL','F5 SAVE','F9 LOAD'):
    check(phrase in hint_src, f'General control help includes {phrase}')
check("g.c1_have(lambda obj: obj.kind == 'soup') is not None" in hint_src, 'Soup help requires soup in inventory')
check("F - CONSUME SOUP" in hint_src, 'Conditional soup help wording')
for clue in ('FROSTY','plate','off-centre seam','bucket','ALCHEMY: missing','Fearmonger','vault'):
    check(clue.lower() not in hint_src.lower(), f'No puzzle clue in help line: {clue}')

# Remove player-facing bucket exploit spoilers while preserving the mechanics.
for banned in ('shopkeeper cannot see you taking shop goods','Vendor cannot witness theft','He cannot see theft until the bucket comes off','watched shop items are safe to take','carried bucket can be placed on the head','BUCKET TRICK IS OPTIONAL','BUCKET EXPLOIT ACTIVE'):
    check(banned.lower() not in text.lower(), f'Bucket spoiler copy removed: {banned}')
check('bucket_on_head_vendor_id' in text and 'c1_guard_bucketed' in text, 'Bucket and guard state systems remain in source')
check("self._log(\"EXPLOIT\", \"Bucket placed on Alchemy Shop shopkeeper" in text, 'Bucket exploit event remains logged')

# Graduated Hellgs hints disabled only; real exploit cameos and tea awards preserved.
check('F1666C_HINT_EVENTS' in text, 'Original hint event IDs remain for migration filtering')
state=classes['F1Clean2_9StateMachine']
bases=[ast.unparse(x) for x in state.bases]
check(bases==['F1Clean2_7StateMachine'], 'Clean2.9 subclasses established Clean2.7 state machine')
method={n.name:n for n in state.body if isinstance(n,ast.FunctionDef)}
check('_f1666c_queue_hint' in method and 'return False' in ast.get_source_segment(text,method['_f1666c_queue_hint']), 'Hellgs puzzle hint queue is disabled')
check('_suppress_challenge_hints' in method, 'Old active/queued Hellgs hint actors are cleaned')
check('F1666C_HINT_EVENTS' in ast.get_source_segment(text,method['_suppress_challenge_hints']), 'Only hint event keys are suppressed')
check('_f1666c_award_achievement' not in ast.get_source_segment(text,method['_suppress_challenge_hints']), 'No exploit achievement code is disabled by hint cleanup')
check("F1Clean2_9StateMachine(archive, config, warning)" in text, 'Application starts the Clean2.9 state machine')
check("F1Clean2_9Interface(machine)" in text, 'Application starts the Clean2.9 interface')

# Fast travel is disabled by narrow overrides; the original implementation remains unchanged.
base_main=(BASE/'main.py').read_text(encoding='utf-8'); base_ast=ast.parse(base_main)
def find_class(tree,name): return next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name==name)
new_e33=find_class(mod,'E33StateMachine')
base_e33=find_class(base_ast,'E33StateMachine')
check(ast.dump(new_e33,include_attributes=False)==ast.dump(base_e33,include_attributes=False), 'Original E3.3 fast-travel implementation retained byte-for-byte at AST level')
for meth in ('_e33_toggle_travel','_e33_jump'):
    check(meth in method, f'Clean2.9 fast travel override exists: {meth}')
    body=ast.get_source_segment(text,method[meth])
    check('self.e33_fast_travel_open = False' in body and 'return None' in body, f'Fast travel remains inactive: {meth}')
check('FAST_TRAVEL_TEMPORARILY_DISABLED = True' in text, 'Explicit temporary disable marker')
check('M FAST TRAVEL' not in hint_src, 'Fast travel omitted from player help')

# Preserve all pre-existing game classes and mechanics apart from wording-only changes.
class StripStrings(ast.NodeTransformer):
    def visit_Constant(self,node):
        if isinstance(node.value,str): return ast.copy_location(ast.Constant(value='__STRING_LITERAL__'),node)
        return node

def normalized(n): return ast.dump(StripStrings().visit(copy.deepcopy(n)),include_attributes=False)
for cls_name,base_node in ((n.name,n) for n in base_ast.body if isinstance(n,ast.ClassDef)):
    if cls_name == 'SGGInterface':
        continue  # Its bottom status prompt is intentionally simplified to controls only.
    new_node=next(x for x in mod.body if isinstance(x,ast.ClassDef) and x.name==cls_name)
    check(normalized(new_node)==normalized(base_node), f'Existing class logic unchanged (string text may differ): {cls_name}')

# Mage Lab door art and transition preservation.
assets_base=base['assets']; assets_new=new['assets']
check('mage_lab_exit_door' not in assets_base and 'mage_lab_exit_door' in assets_new, 'New Mage Lab exit asset added')
door=assets_new['mage_lab_exit_door']
check((door['width'],door['height'],len(door['commands']))==(144,194,73), 'Mage Lab arch dimensions and 73 JSON primitives')
valid_ops={'rect','line','polygon','circle','ellipse'}
check(all(cmd['op'] in valid_ops for cmd in door['commands']), 'Mage Lab arch uses supported Draw Engine operations')
base_bg=assets_base['c1_bg_mages_lab']['commands']; new_bg=assets_new['c1_bg_mages_lab']['commands']
expected_bg=[c for i,c in enumerate(base_bg) if not 322<=i<=329]
check(len(base_bg)==362 and len(new_bg)==354 and new_bg==expected_bg, 'Only old eight-command wooden door removed from lab background')
for name,asset in assets_base.items():
    if name!='c1_bg_mages_lab': check(assets_new[name]==asset, f'Unrelated asset unchanged: {name}')
check(assets_new['locked_door']==assets_base['locked_door'], 'Castle Hall/Vault locked door asset unchanged')
check(assets_new['c1_bg_castle_vault']==assets_base['c1_bg_castle_vault'], 'Clean2.8 Vault artwork unchanged')
check(assets_new['c1_bg_castle_vault_kelp_original']==assets_base['c1_bg_castle_vault_kelp_original'], 'Kelp original Vault artwork preserved exactly')
check('original(dst, \'mage_lab_exit_door\', target_rect)' in text, 'Mage Lab renderer redirects only its door to new asset')
check("if g.current_area_id != 'mages_lab'" in ast.get_source_segment(text,next(n for n in ui.body if isinstance(n,ast.FunctionDef) and n.name=='_draw_game_scene')), 'Door renderer is scoped to Mage Lab')

# Exact Catalogue history and unchanged previous deployment editions.
base_versions=load(PROJECT/'deploy'/'versions.json') if False else load(PROJECT/'deploy'/'versions.json')
versions=load(PROJECT/'deploy'/'versions.json')
check(len(versions['versions'])==15, 'Fifteen total selectable catalogue editions')
check(versions['versions'][0]['version']=='SGGF1Clean2.9' and versions['versions'][0]['current'] is True, 'Clean2.9 is the sole current catalogue edition')
check(sum(bool(v.get('current')) for v in versions['versions'])==1, 'Exactly one current catalogue flag')
for v in versions['versions']:
    check((PROJECT/'deploy'/v['path']).is_file(), f'Catalogue page exists: {v["path"]}')
    if v.get('image'): check((PROJECT/'deploy'/v['image']).is_file(), f'Catalogue image exists: {v["image"]}')
# Embedded source mirror is compared after root source deploy/ has been synchronized.
check((DEPLOY/'index.html').read_bytes()==(PROJECT/'deploy'/'index.html').read_bytes(), 'Deployment index exists in embedded mirror')
check((DEPLOY/'versions.html').read_bytes()==(PROJECT/'deploy'/'versions.html').read_bytes(), 'Deployment versions page exists in embedded mirror')

# Runtime bundle integrity/content.
for root in (NEW,):
    apk=root/'sggf1clean2_9.apk'; tgz=root/'sggf1clean2_9.tar.gz'
    check(apk.is_file() and tgz.is_file(), 'Clean2.9 APK/TAR runtime bundles exist')
    with zipfile.ZipFile(apk) as z:
        check(z.testzip() is None, 'Clean2.9 APK ZIP integrity')
        check(z.read('assets/main.py')==(root/'main.py').read_bytes(), 'APK contains current main.py')
        check(z.read('assets/luma_assets_e33.json')==(root/'luma_assets_e33.json').read_bytes(), 'APK contains current Luma JSON')
    with tarfile.open(tgz,'r:gz') as t:
        files={m.name:t.extractfile(m).read() for m in t.getmembers() if m.isfile()}
        check(files['assets/main.py']==(root/'main.py').read_bytes(), 'TAR contains current main.py')
        check(files['assets/luma_assets_e33.json']==(root/'luma_assets_e33.json').read_bytes(), 'TAR contains current Luma JSON')

# Build and source history metadata.
check((NEW/'VERSION').read_text().strip()=='15', 'New source edition number')
check('F1Clean2.9' in (NEW/'play.html').read_text(encoding='utf-8'), 'New play page references F1Clean2.9')
check('sggf1clean2_9' in (NEW/'play.html').read_text(encoding='utf-8'), 'New play page uses Clean2.9 runtime bundle')
check('F1Clean2.8' in (BASE/'main.py').read_text(encoding='utf-8'), 'Pristine Clean2.8 source edition retained')
check((BASE/'main.py').read_bytes()==(BASE/'assets'/'main.py').read_bytes(), 'Clean2.8 historical source mirror intact')

print(f'SGGF1Clean2.9 static regression self-test passed: {checks} assertions.')
