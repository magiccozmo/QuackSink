SPIFFY'S GIFT — SGG WEB PROJECT

Current edition: SGGM1.1. Built from the exact SGGM1.0a source and complete Cloudflare deployment archives. SGGK1.12 remains the behavioral and current-UI reference.

M1.1 refines continuous-world geography and layer portals, moves Troll Cave to the previous Mudcrab River site, moves Mudcrab River to the former outdoor HELLgs location south of Giant Camp, removes the outside HELLgs entrance, protects the player from the fixed top-right minimap, sets Z to walkmesh visibility and M to new-world fast travel, and restores K1.12's current header controls including Export Log and private Player Says.

This milestone is still geography/navigation/UI only. NPC/object/Grella behavior is not wired. Placeholder artwork remains, while the Luma drawing recipes are preserved for the later area-by-area repaint stage. The complete source handoff and static Cloudflare site retain M1.0a, M1.0, K1.12, and the legacy editions. See versions.json for the browser catalogue.
