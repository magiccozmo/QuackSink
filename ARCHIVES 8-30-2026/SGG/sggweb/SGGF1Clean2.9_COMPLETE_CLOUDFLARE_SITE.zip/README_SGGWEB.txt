SPIFFY'S GIFT — COMPLETE CLOUDFLARE SITE

CURRENT VERSION: SGGF1Clean2.9

The full site contains fifteen playable editions: Clean2.9 current and all fourteen previous catalogue editions. Clean2.9 removes puzzle hints from the challenge presentation while retaining general controls; F - Consume Soup appears only while soup is in inventory. It suppresses the graduated Hellgs hint cameos but preserves exploit cameos and Tea rewards. Fast travel is temporarily disabled with its original implementation retained. Alchemy Shop stock has enlarged hover targets, a reachable front-side access point and a save-safe migration of only untouched shelf defaults. The Mage Lab exit uses a custom indigo stone-and-brass architectural arch while preserving the existing automatic door transition. No earlier selectable version has been deleted or replaced.
