from pathlib import Path
from types import MethodType, SimpleNamespace
import ast
import copy
import importlib.util
import json
import sys
import zipfile

W = Path(__file__).resolve().parent
MAIN = W / 'main.py'
ASSETS = W / 'luma_assets_e33.json'
PAGE = W / 'F1_play.html'
VERSION = 'F1.666d'

source = MAIN.read_text(encoding='utf-8')
base_source = (W / 'F1.666c_BASE_MAIN.py').read_text(encoding='utf-8')
asset_doc = json.loads(ASSETS.read_text(encoding='utf-8'))
base_asset_doc = json.loads((W / 'F1.666c_BASE_LUMA_ASSETS.json').read_text(encoding='utf-8'))
page = PAGE.read_text(encoding='utf-8')

ast.parse(source)
assert 'VERSION = "F1.666d"' in source
assert asset_doc['version'] == 'SGGF1.666d'
expected_assets = copy.deepcopy(base_asset_doc)
expected_assets['version'] = 'SGGF1.666d'
expected_assets['notes'] = asset_doc['notes']
assert asset_doc == expected_assets, 'D must preserve C world/assets exactly apart from version + release notes.'
assert 'SGGF1.666d:' in asset_doc.get('notes', '')
assert 'sggf1666d.apk' in page and 'sggf1666d.tar.gz' in page
assert 'archive:"sggf1666d"' in page and 'bundle = "sggf1666d"' in page
assert 'sggf1666c.apk' not in page and 'sggf1666c.tar.gz' not in page


def find_class(tree, name):
    return next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == name)


def class_method_dump(tree, class_name, method_name):
    cls = find_class(tree, class_name)
    method = next(n for n in cls.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == method_name)
    return ast.dump(method, include_attributes=False)


current_tree = ast.parse(source)
base_tree = ast.parse(base_source)
# The generic save migration and historical game systems are retained.
for cls, method in (
    ('C131GameModel', 'from_snapshot'),
    ('E33StateMachine', '_dispatch_game'),
    ('D11StateMachine', '_d11_update_cameo'),
    ('D11StateMachine', '_take'),
    ('F1666StateMachine', '_hellgs_due'),
    ('F1666StateMachine', '_dispatch_game'),
):
    assert class_method_dump(current_tree, cls, method) == class_method_dump(base_tree, cls, method), \
        f'Historical {cls}.{method} changed.'
assert 'merge_saved_over_defaults' in source
assert 'cozmo_tea_ledger_f1666d_migrated' in source

# The front-door description in D must match the A description byte-for-byte.
base_deploy = Path('/mnt/data/SGGF1.666c_CLOUDFLARE_DEPLOY.zip')
assert base_deploy.is_file()
with zipfile.ZipFile(base_deploy) as z:
    assert z.testzip() is None
    manifest = json.loads(z.read('versions.json'))
    a_desc = next(v['description'] for v in manifest['versions'] if v['version'] == 'SGGF1.666a')
    c_desc = next(v['description'] for v in manifest['versions'] if v['version'] == 'SGGF1.666c')
assert a_desc.endswith('woops.. now it IS possible to escape')
assert c_desc == a_desc
assert a_desc == next(v['description'] for v in manifest['versions'] if v['version'] == 'SGGF1.666a')
assert 'load while standing' not in a_desc.lower()
assert 'alternating' not in a_desc.lower()

# Import without starting the live SDL/Pygame loop.
spec = importlib.util.spec_from_file_location('sgg_f1666d_main_test', MAIN)
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)
assert module.VERSION == VERSION
assert module.F1666C_EXPLOIT_ACHIEVEMENTS == {
    'bucket': 'bucket_theft',
    'naz': 'naz_guard_death',
    'vault_clip': 'vault_clip',
    'lout_guard_death': 'lout_guard_death',
    'hellgs_escape': 'hellgs_escape',
}


def fake_machine(area='hellgs_inn', config=None):
    machine = object.__new__(module.F1666dStateMachine)
    machine.config = dict(config or {})
    machine.config.setdefault('cozmo_exploit_events', [])
    machine.config.setdefault('cozmo_pending_tea_events', [])
    machine.config.setdefault('cozmo_tea_earned', 0)
    machine.config.setdefault('cozmo_death_reload_count', 0)
    machine.config.setdefault('cozmo_hint_stage', 0)
    machine.game = SimpleNamespace(
        current_area_id=area,
        c1_elapsed=100.0,
        c1_dead=None,
        c1_dialogue=None,
        player_x=640.0,
        player_y=480.0,
        c1_vault_entered=False,
        c1_npcs={},
        c1_flags={
            'd11_cameo_events': [],
            'd11_cameo_queue': [],
            'd11_cameo_active': None,
        },
    )
    machine.d11_context_ref = None
    machine.logs = []
    machine.statuses = []
    machine.speeches = []
    machine.dialogues = []
    machine._log = MethodType(lambda self, a, b: self.logs.append((a, b)), machine)
    machine._set_status = MethodType(lambda self, value: self.statuses.append(value), machine)
    machine._f1666c_save_config = MethodType(
        lambda self, **changes: (self.config.update(changes) or True), machine)
    machine._speech = MethodType(lambda self, value, seconds=6.0: self.speeches.append(value), machine)

    def dialogue(self, speaker, text, options):
        self.dialogues.append((speaker, text, options))
        self.game.c1_dialogue = {'speaker': speaker, 'text': text, 'options': options}

    machine._dialogue = MethodType(dialogue, machine)
    return machine


# C's startup-only legacy counter credit is removed once, with real discoveries
# retained as pending. A version update itself never earns a Tea point.
legacy = fake_machine(config={
    'cozmo_exploiter_appearances': 2,
    'cozmo_exploit_events': ['hellgs_escape', 'bucket_theft', 'vault_clip'],
    'cozmo_pending_tea_events': [],
    'cozmo_tea_earned': 3,
    'cozmo_tea_ledger_f1666d_migrated': False,
})
assert legacy._f1666d_migrate_legacy_tea_credit() is True
assert legacy.config['cozmo_exploit_events'] == ['bucket_theft', 'vault_clip']
assert legacy.config['cozmo_pending_tea_events'] == ['bucket_theft', 'vault_clip']
assert legacy.config['cozmo_tea_earned'] == 0
assert legacy.config['cozmo_tea_ledger_f1666d_migrated'] is True
assert legacy._f1666d_migrate_legacy_tea_credit() is False
assert legacy.config['cozmo_tea_earned'] == 0
assert legacy._f1666c_award_achievement('hellgs_escape') is True
assert legacy.config['cozmo_tea_earned'] == 3  # escape point + two real pending discoveries
assert legacy.config['cozmo_pending_tea_events'] == []
assert legacy._f1666c_award_achievement('hellgs_escape') is False

# A legacy appearance counter by itself never grants Tea or marks escape.
old_counter_only = fake_machine(config={
    'cozmo_exploiter_appearances': 9,
    'cozmo_exploit_events': [],
    'cozmo_pending_tea_events': [],
    'cozmo_tea_earned': 0,
    'cozmo_tea_ledger_f1666d_migrated': False,
})
old_counter_only._f1666d_migrate_legacy_tea_credit()
assert old_counter_only.config['cozmo_exploit_events'] == []
assert old_counter_only.config['cozmo_tea_earned'] == 0

# If the escape score was genuinely earned with no C legacy startup counter,
# the once-only gameplay record and score survive D.
legit = fake_machine(config={
    'cozmo_exploiter_appearances': 0,
    'cozmo_exploit_events': ['hellgs_escape'],
    'cozmo_pending_tea_events': [],
    'cozmo_tea_earned': 1,
    'cozmo_tea_ledger_f1666d_migrated': False,
})
legit._f1666d_migrate_legacy_tea_credit()
assert legit.config['cozmo_exploit_events'] == ['hellgs_escape']
assert legit.config['cozmo_tea_earned'] == 1

# Test the real successful-load trigger: the pre-load area is HELLgs and the
# incoming save restores the player outside. This is the only Tea #1 trigger.
old_parent_read = module.F1666bStateMachine._read_save
try:
    def swap_to_outside(self, slot):
        self.game = SimpleNamespace(
            current_area_id='castle_hall', c1_elapsed=120.0, c1_dead=None,
            c1_dialogue=None, player_x=640.0, player_y=490.0,
            c1_vault_entered=False, c1_npcs={},
            c1_flags={'d11_cameo_events': [], 'd11_cameo_queue': [], 'd11_cameo_active': None},
        )
    module.F1666bStateMachine._read_save = swap_to_outside
    escape = fake_machine('hellgs_inn')
    escape._read_save('slot1')
    assert escape.game.current_area_id == 'castle_hall'
    assert escape.game.c1_flags['d11_cameo_active']['event'] == 'hellgs_escape'
    assert escape.config['cozmo_exploit_events'] == ['hellgs_escape']
    assert escape.config['cozmo_tea_earned'] == 1
finally:
    module.F1666bStateMachine._read_save = old_parent_read

# A load not initiated from the cell does not grant the escape cameo/Tea.
old_parent_read = module.F1666bStateMachine._read_save
try:
    def swap_area(self, slot):
        self.game = SimpleNamespace(
            current_area_id='castle_exterior', c1_elapsed=120.0, c1_dead=None,
            c1_dialogue=None, player_x=640.0, player_y=490.0,
            c1_vault_entered=False, c1_npcs={},
            c1_flags={'d11_cameo_events': [], 'd11_cameo_queue': [], 'd11_cameo_active': None},
        )
    module.F1666bStateMachine._read_save = swap_area
    not_escape = fake_machine('castle_hall')
    not_escape._read_save('slot1')
    assert not_escape.game.c1_flags['d11_cameo_active'] is None
    assert not_escape.config['cozmo_tea_earned'] == 0
finally:
    module.F1666bStateMachine._read_save = old_parent_read

# The four non-escape achievements are once-only and remain pending until
# the actual escape is performed.
ledger = fake_machine(config={'cozmo_exploit_events': [], 'cozmo_pending_tea_events': [], 'cozmo_tea_earned': 0})
for event in ('bucket_theft', 'vault_clip', 'naz_guard_death', 'lout_guard_death'):
    assert ledger._f1666c_award_achievement(event) is True
assert ledger.config['cozmo_tea_earned'] == 0
assert len(ledger.config['cozmo_pending_tea_events']) == 4
assert ledger._f1666c_award_achievement('hellgs_escape') is True
assert ledger.config['cozmo_tea_earned'] == 5
for event in ('bucket_theft', 'vault_clip', 'naz_guard_death', 'lout_guard_death', 'hellgs_escape'):
    assert ledger._f1666c_award_achievement(event) is False
assert ledger.config['cozmo_tea_earned'] == 5

# 10-death interaction now uses the requested wording irrespective of whether
# the player accepted the earlier hint.
hint10 = fake_machine(config={'cozmo_hint_stage': 2})
hint10.game.c1_flags['d11_cameo_active'] = {
    'event': 'hint_10', 'area': 'hellgs_inn', 'x': 785.0, 'y': 474.0,
    'talked': False, 'leave_at': None,
}
hint10._f1666c_hint_talk('hint_10')
assert hint10.dialogues[-1][1] == "I'm willing to give you an even better hint than last time"
assert hint10.dialogues[-1][2][0]['text'] == "Yah, i'm still stumped"

# The twentieth-death cameo is not completed by appearing. It stays stage 2,
# can be queued again if the player ignores it/leaves, and awards no Tea.
final_hint = fake_machine('hellgs_inn', {'cozmo_hint_stage': 2, 'cozmo_tea_earned': 0})
assert final_hint._f1666c_queue_hint(20) is True
final_hint.game.c1_elapsed += 2.0
final_hint._d11_update_cameo()
assert final_hint.game.c1_flags['d11_cameo_active']['event'] == 'hint_20'
assert final_hint.config['cozmo_hint_stage'] == 2
assert final_hint.config['cozmo_tea_earned'] == 0
assert any('total spoiler' in speech for speech in final_hint.speeches)
final_hint.game.c1_flags['d11_cameo_active'] = None  # simulate leaving before interacting
assert final_hint._f1666c_queue_hint(20) is True
assert final_hint.game.c1_flags['d11_cameo_queue'][-1]['event'] == 'hint_20'

# Only selecting the final-spoiler option consumes the stage and makes Cozmo
# vanish. Simply appearing, interacting, or closing a dialogue does not.
accepted = fake_machine('hellgs_inn', {'cozmo_hint_stage': 2, 'cozmo_tea_earned': 0})
accepted.game.c1_flags['d11_cameo_active'] = {
    'event': 'hint_20', 'area': 'hellgs_inn', 'x': 785.0, 'y': 474.0,
    'talked': True, 'leave_at': None,
}
accepted.game.c1_dialogue = {'options': [{'text': 'admit defeat', 'action': 'f1666c_hint20_admit'}]}
accepted._choose_dialogue(0)
assert accepted.config['cozmo_hint_stage'] == 3
assert accepted.game.c1_flags['d11_cameo_active'] is None
assert accepted.game.c1_dialogue['text'] == module.F1666C_HINT_SOLUTION

# Re-checking an eligible Hellgs load queues the pending 20-death offer even
# when that load was not itself a post-death Quickload.
old_parent_read = module.F1666bStateMachine._read_save
try:
    def swap_to_cell(self, slot):
        self.game = SimpleNamespace(
            current_area_id='hellgs_inn', c1_elapsed=140.0, c1_dead=None,
            c1_dialogue=None, player_x=640.0, player_y=480.0,
            c1_vault_entered=False, c1_npcs={},
            c1_flags={'d11_cameo_events': [], 'd11_cameo_queue': [], 'd11_cameo_active': None},
        )
    module.F1666bStateMachine._read_save = swap_to_cell
    retry = fake_machine('castle_hall', {'cozmo_death_reload_count': 20, 'cozmo_hint_stage': 2})
    retry._read_save('slot1')
    assert retry.game.current_area_id == 'hellgs_inn'
    assert retry.game.c1_flags['d11_cameo_queue'][-1]['event'] == 'hint_20'
finally:
    module.F1666bStateMachine._read_save = old_parent_read

# No Tea inventory creation, no alternating reward, and Quickload button/key
# remain as in C.
d_cls = find_class(current_tree, 'F1666dStateMachine')
d_methods = {n.name: ast.get_source_segment(source, n) for n in d_cls.body if isinstance(n, ast.FunctionDef)}
assert 'cozmo_tea_earned=0' in d_methods['_f1666d_migrate_legacy_tea_credit']
assert 'tea_due' not in source[source.index('class F1666cStateMachine'):]
assert 'c1_make_item' not in source[source.index('class F1666cStateMachine'):source.index('class F1666cInterface')]
assert 'TEA EARNED:' in source[source.index('class F1666cInterface'):]
assert 'F1666dStateMachine(archive, config, warning)' in source
assert 'F1666dInterface(machine)' in source
assert "if g and g.c1_dead:" in d_methods['_dispatch_game'] if '_dispatch_game' in d_methods else True

# No new cell exit, world mechanics, or art changes.
assert asset_doc['world'] == base_asset_doc['world']
assert asset_doc['assets'] == base_asset_doc['assets']

print('PASS F1.666d AST parse, import and immutable C world/assets checks.')
print('PASS C false startup credit is corrected once; legacy counter alone never grants Tea.')
print('PASS only the actual HELLgs-cell-to-outside save-load transition awards Tea #1.')
print('PASS prior real exploit discoveries remain pending until the genuine escape; all five achievements remain once-only.')
print('PASS 10-death interaction uses the improved wording regardless of the earlier hint response.')
print('PASS 20-death spoiler stays pending after appearance/ignored interaction and is consumed only by the explicit final choice.')
print('PASS an uncompleted hint milestone is queued again on a later successful load into HELLgs.')
print('PASS no Tea inventory item or version-start award; visible Tea score and Game Over Quickload are retained.')
print('PASS C forward-compatible save migration, F1.6 fast travel, bucket, vault, NPC/guard and world mechanics remain unchanged.')
print('PASS F1.666a front-door description copied verbatim without exploit spoilers.')
