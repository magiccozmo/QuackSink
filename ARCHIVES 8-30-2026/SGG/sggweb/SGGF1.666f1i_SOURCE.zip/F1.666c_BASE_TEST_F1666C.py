from pathlib import Path
from types import MethodType, SimpleNamespace
import ast
import copy
import importlib.util
import json
import sys
import zipfile

W = Path(__file__).resolve().parent
MAIN = W / 'main.py'
ASSETS = W / 'luma_assets_e33.json'
PAGE = W / 'F1_play.html'
VERSION = 'F1.666c'

source = MAIN.read_text(encoding='utf-8')
base_source = (W / 'F1.666b_BASE_MAIN.py').read_text(encoding='utf-8')
asset_doc = json.loads(ASSETS.read_text(encoding='utf-8'))
base_asset_doc = json.loads((W / 'F1.666b_BASE_LUMA_ASSETS.json').read_text(encoding='utf-8'))
page = PAGE.read_text(encoding='utf-8')

ast.parse(source)
assert 'VERSION = "F1.666c"' in source
assert asset_doc['version'] == 'SGGF1.666c'
expected_assets = copy.deepcopy(base_asset_doc)
expected_assets['version'] = 'SGGF1.666c'
expected_assets['notes'] = asset_doc['notes']
assert asset_doc == expected_assets, 'F1.666c must preserve F1.666b world/assets exactly apart from version + release notes.'
assert 'SGGF1.666c:' in asset_doc.get('notes', '')
assert 'sggf1666c.apk' in page and 'sggf1666c.tar.gz' in page
assert 'archive:"sggf1666c"' in page and 'bundle = "sggf1666c"' in page
assert 'sggf1666b.apk' not in page and 'sggf1666b.tar.gz' not in page

# Verify the permanent generic save migration and the F1.6 world/fast-travel
# machinery are identical to the pushed F1.666b baseline.
def find_class(tree, name):
    return next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == name)

def class_method_dump(tree, class_name, method_name):
    cls = find_class(tree, class_name)
    method = next(n for n in cls.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == method_name)
    return ast.dump(method, include_attributes=False)

current_tree = ast.parse(source)
base_tree = ast.parse(base_source)
for cls, method in (
    ('C131GameModel', 'from_snapshot'),
    ('E33StateMachine', '_dispatch_game'),
    ('D11StateMachine', '_d11_update_cameo'),
    ('D11StateMachine', '_take'),
    ('F1666StateMachine', '_hellgs_due'),
    ('F1666StateMachine', '_dispatch_game'),
):
    assert class_method_dump(current_tree, cls, method) == class_method_dump(base_tree, cls, method), \
        f'Historical {cls}.{method} changed.'
assert 'merge_saved_over_defaults' in source
assert 'cozmo_exploit_events' in source and 'cozmo_death_reload_count' in source

# The front-door description must be copied byte-for-byte from F1.666a,
# not inherited from F1.666b's spoiler-expanded description.
base_deploy = Path('/mnt/data/SGGF1.666b_CLOUDFLARE_DEPLOY.zip')
assert base_deploy.is_file()
with zipfile.ZipFile(base_deploy) as z:
    manifest = json.loads(z.read('versions.json'))
    a_desc = next(v['description'] for v in manifest['versions'] if v['version'] == 'SGGF1.666a')
    b_desc = next(v['description'] for v in manifest['versions'] if v['version'] == 'SGGF1.666b')
assert a_desc.endswith('woops.. now it IS possible to escape')
assert 'alternating Yorkshire Tea rewards' in b_desc

# Load the module without starting SDL/Pygame, then exercise the score ledger.
spec = importlib.util.spec_from_file_location('sgg_f1666c_main_test', MAIN)
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)
assert module.VERSION == 'F1.666c'
assert module.F1666C_EXPLOIT_ACHIEVEMENTS == {
    'bucket': 'bucket_theft',
    'naz': 'naz_guard_death',
    'vault_clip': 'vault_clip',
    'lout_guard_death': 'lout_guard_death',
    'hellgs_escape': 'hellgs_escape',
}
assert set(module.F1666C_EXPLOIT_ACHIEVEMENTS.values()) == {
    'bucket_theft', 'naz_guard_death', 'vault_clip', 'lout_guard_death', 'hellgs_escape'
}

m = object.__new__(module.F1666cStateMachine)
m.config = {
    'cozmo_exploit_events': [],
    'cozmo_pending_tea_events': [],
    'cozmo_tea_earned': 0,
}
logs = []
statuses = []
m._log = MethodType(lambda self, category, message: logs.append((category, message)), m)
m._set_status = MethodType(lambda self, message: statuses.append(message), m)
m._f1666c_save_config = MethodType(
    lambda self, **changes: (self.config.update(changes) or True), m)

# A non-escape exploit discovered first is held pending. The HELLgs escape
# receives Tea #1, then releases the pending once-only point.
assert m._f1666c_award_achievement('bucket_theft') is True
assert m.config['cozmo_tea_earned'] == 0
assert m.config['cozmo_pending_tea_events'] == ['bucket_theft']
assert m._f1666c_award_achievement('bucket_theft') is False
assert m._f1666c_award_achievement('hellgs_escape') is True
assert m.config['cozmo_tea_earned'] == 2
assert m.config['cozmo_pending_tea_events'] == []
assert 'first Tea awarded for escaping HELLgs Inn' in logs[-1][1]
for achievement in ('vault_clip', 'naz_guard_death', 'lout_guard_death'):
    assert m._f1666c_award_achievement(achievement) is True
assert m.config['cozmo_tea_earned'] == 5
for achievement in ('hellgs_escape', 'bucket_theft', 'vault_clip', 'naz_guard_death', 'lout_guard_death'):
    assert m._f1666c_award_achievement(achievement) is False
assert m.config['cozmo_tea_earned'] == 5

# The old alternating item reward is completely bypassed. F1.666c displays a
# persistent score and never creates inventory tea in its cameo/reward code.
c_cls = find_class(current_tree, 'F1666cStateMachine')
method_sources = {
    n.name: ast.get_source_segment(source, n)
    for n in c_cls.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))
}
assert 'cozmo_exploiter_appearances' not in method_sources.get('_d11_talk', '')
assert 'c1_make_item' not in method_sources.get('_d11_talk', '')
assert 'tea_due' not in source[source.index('class F1666cStateMachine'):]
assert 'TEA EARNED:' in source[source.index('class F1666cInterface'):]
assert 'c1_make_item' not in source[source.index('class F1666cStateMachine'):source.index('class F1666cInterface')]

# Exact hint progression, text, options and thresholds.
for text in (
    'If you REALLY REALLY want, I can gave you a hint',
    'yah, help me out here',
    'Are you REALLY SURE?',
    "Yes I'm damn sure! I'm NOT the Spiffing Brit after all",
    'Have you considered loading a DIFFERENT save?',
    'Still trying? I can offer ONE final hint',
    'You really want another hint?',
    "Yah, i'm still stumped",
    'I told Luma to make sure that save games are as forward compatable as possible',
    '<raises eyebrow like a certain alien>',
    "I'm impressed by your stubborn tenacity, but I am willing to give you a total spoiler if you are willing to admit defeat",
    'Ok, if you truly admit defeat I will tell you how to get out of here.',
    "Cozmo, i'm truly stumped but want to see more of this game than these four walls and fire. Please help me out.",
 ):
    assert text in source, f'Missing dialogue text: {text}'
assert module.F1666C_HINT_SOLUTION == (
    "Load into a version where the starting location is NOT Hellgs Inn. Do a quicksave.  open THIS version (or later O_o) and then quickload.  I'll see ya on the other side"
)
assert "if reload_count >= 4" in method_sources['_f1666c_queue_hint']
assert "elif reload_count >= 10" in method_sources['_f1666c_queue_hint']
assert "elif reload_count >= 20" in method_sources['_f1666c_queue_hint']
assert 'cozmo_hint_stage=desired' not in method_sources['_f1666c_queue_hint']
assert 'cozmo_death_reload_count=reload_count' in method_sources['_read_save']
assert "slot == 'quick' and died_before_load" in method_sources['_read_save']

# The Quickload button is present for any death and handles both button and
# configured keyboard quickload. The legacy HELLgs game-over gate is preserved.
assert module.F1666C_QUICKLOAD_RECT[1] >= 445
assert "if g and g.c1_dead:" in method_sources['_dispatch_game']
assert "self._read_save('quick')" in method_sources['_dispatch_game']
interface_cls = find_class(current_tree, 'F1666cInterface')
ui_draw = next(n for n in interface_cls.body if isinstance(n, ast.FunctionDef) and n.name == '_draw_game_scene')
ui_draw_source = ast.get_source_segment(source, ui_draw)
assert "if not g.c1_dead:" in ui_draw_source
assert "'QUICKLOAD'" in ui_draw_source
assert 'TEA EARNED:' in ui_draw_source

# No changed world mechanics, assets or Luma recipes, no door/exit changes.
assert asset_doc['world'] == base_asset_doc['world']
assert asset_doc['assets'] == base_asset_doc['assets']
assert 'hellgs_inn' not in str(module.F1666C_EXPLOIT_ACHIEVEMENTS) or 'hellgs_escape' in module.F1666C_EXPLOIT_ACHIEVEMENTS


# Exercise the actual inherited cameo queue with lightweight game objects, not
# just source-string checks. This verifies the five events use the D1.1 actor.
def fake_machine(area):
    machine = object.__new__(module.F1666cStateMachine)
    machine.config = {
        'cozmo_exploit_events': [],
        'cozmo_pending_tea_events': [],
        'cozmo_tea_earned': 0,
        'cozmo_hint_stage': 0,
        'cozmo_death_reload_count': 0,
    }
    machine.game = SimpleNamespace(
        current_area_id=area,
        c1_elapsed=100.0,
        c1_dead=None,
        c1_dialogue=None,
        player_x=640.0,
        player_y=480.0,
        c1_flags={
            'd11_cameo_events': [],
            'd11_cameo_queue': [],
            'd11_cameo_active': None,
        },
    )
    machine.d11_context_ref = None
    machine.logs, machine.statuses, machine.speeches, machine.dialogues = [], [], [], []
    machine._log = MethodType(lambda self, a, b: self.logs.append((a, b)), machine)
    machine._set_status = MethodType(lambda self, value: self.statuses.append(value), machine)
    machine._f1666c_save_config = MethodType(
        lambda self, **changes: (self.config.update(changes) or True), machine)
    machine._speech = MethodType(lambda self, value, seconds=6.0: self.speeches.append(value), machine)
    machine._dialogue = MethodType(lambda self, *args, **kwargs: self.dialogues.append((args, kwargs)), machine)
    return machine

# The existing D1.1 bucket/Naz scheduling and the new vault/lout events each
# create one visible cameo in the appropriate area and award one ledger entry.
bucket_test = fake_machine('alchemy_shop')
bucket_test._d11_schedule('bucket')
assert len(bucket_test.game.c1_flags['d11_cameo_queue']) == 1
bucket_test.game.c1_elapsed += 6.0
bucket_test._d11_update_cameo()
assert bucket_test.game.c1_flags['d11_cameo_active']['event'] == 'bucket'
assert bucket_test.config['cozmo_pending_tea_events'] == ['bucket_theft']
bucket_test._d11_schedule('bucket')
assert len(bucket_test.game.c1_flags['d11_cameo_queue']) == 0

naz_test = fake_machine('castle_hall')
naz_test._d11_schedule('naz')
naz_test.game.c1_elapsed += 6.0
naz_test._d11_update_cameo()
assert naz_test.game.c1_flags['d11_cameo_active'] is None
naz_test.game.current_area_id = 'britrun_market'
naz_test._d11_update_cameo()
assert naz_test.game.c1_flags['d11_cameo_active']['event'] == 'naz'

for event, area in (('vault_clip', 'castle_vault'), ('lout_guard_death', 'inn_outside')):
    event_test = fake_machine(area)
    event_test._d11_schedule(event)
    event_test.game.c1_elapsed += 6.0
    event_test._d11_update_cameo()
    assert event_test.game.c1_flags['d11_cameo_active']['event'] == event
    assert event_test.config['cozmo_pending_tea_events'] == [module.F1666C_EXPLOIT_ACHIEVEMENTS[event]]

escape_test = fake_machine('castle_hall')
assert escape_test._f1666c_spawn_cameo('hellgs_escape') is True
assert escape_test.game.c1_flags['d11_cameo_active']['event'] == 'hellgs_escape'
assert escape_test.config['cozmo_exploit_events'] == ['hellgs_escape']
assert escape_test.config['cozmo_tea_earned'] == 1

# The three death/reload hints are distinct, ordered, no-tea cameos. The
# tenth and twentieth milestones speak before the player interacts.
for count, event, stage, has_auto_speech in (
    (4, 'hint_4', 1, False),
    (10, 'hint_10', 2, True),
    (20, 'hint_20', 3, True),
):
    hint_test = fake_machine('hellgs_inn')
    hint_test.config['cozmo_hint_stage'] = stage - 1
    hint_test._f1666c_queue_hint(count)
    hint_test.game.c1_elapsed += 2.0
    hint_test._d11_update_cameo()
    active = hint_test.game.c1_flags['d11_cameo_active']
    assert active and active['event'] == event
    assert hint_test.config['cozmo_hint_stage'] == stage
    assert bool(hint_test.speeches) is has_auto_speech
    assert hint_test.config['cozmo_tea_earned'] == 0

print('PASS F1.666c AST parse and import.')
print('PASS runtime cameo queue for bucket theft, Naz, vault clip, Lout guard death and HELLgs escape.')
print('PASS runtime fourth/tenth/twentieth reload hints; no hint awards Tea.')
print('PASS F1.666b save migration, D11 core cameo mechanics, F1.6 fast-travel/game-over paths remain unchanged.')
print('PASS exactly five distinct, globally once-only exploit achievements; HELLgs escape receives Tea #1.')
print('PASS old B appearance counter migrates to the HELLgs escape achievement in shared config.')
print('PASS no alternating reward and no Yorkshire Tea inventory item; visible TEA EARNED score.')
print('PASS Quickload button/key path and successful-death-quickload counting.')
print('PASS ordered fourth/tenth/twentieth death-reload hint sequence and exact dialogue.')
print('PASS F1.666a front-door description is the C release description; B spoiler copy excluded.')
print('PASS F1.666b world geometry, world objects and Luma assets unchanged.')
