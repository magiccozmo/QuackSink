from pathlib import Path
import json
import shutil

W = Path(__file__).resolve().parent

# Preserve the exact F1.666b repository source before making the next release.
for src_name, base_name in (
    ('main.py', 'F1.666b_BASE_MAIN.py'),
    ('luma_assets_e33.json', 'F1.666b_BASE_LUMA_ASSETS.json'),
    ('F1_play.html', 'F1.666b_BASE_F1_play.html'),
    ('README_SGGF1666b.txt', 'F1.666b_BASE_README.txt'),
    ('package_f1666b.py', 'F1.666b_BASE_PACKAGE_F1666B.py'),
    ('prepare_f1666b.py', 'F1.666b_BASE_PREPARE_F1666B.py'),
    ('test_f1666b.py', 'F1.666b_BASE_TEST_F1666B.py'),
):
    src = W / src_name
    dst = W / base_name
    if src.is_file() and not dst.exists():
        shutil.copy2(src, dst)

main_path = W / 'main.py'
src = main_path.read_text(encoding='utf-8')
assert 'VERSION = "F1.666b"' in src
assert 'class F1666bStateMachine(F1666StateMachine)' in src
assert 'class F1666bInterface(F1666Interface)' in src
assert 'machine = F1666bStateMachine(archive, config, warning)' in src

# Keep the retired counter key readable for old sgg.config files, but add the
# event achievements, tea total, and per-run hint counter as separate fields.
src = src.replace(
    '    "cozmo_exploiter_appearances": 0,\n',
    '    "cozmo_exploiter_appearances": 0,  # retained only for older config files\n'
    '    "cozmo_exploit_events": [],\n'
    '    "cozmo_pending_tea_events": [],\n'
    '    "cozmo_tea_earned": 0,\n'
    '    "cozmo_death_reload_count": 0,\n'
    '    "cozmo_hint_stage": 0,\n', 1)
needle = '    result["cozmo_exploiter_appearances"] = min(1000000000, max(0, cozmo_appearances))\n'
assert src.count(needle) == 1
src = src.replace(needle, needle + '''    for field in ("cozmo_exploit_events", "cozmo_pending_tea_events"):
        values = result.get(field, [])
        if not isinstance(values, list):
            values = []
        clean = []
        for value in values:
            if isinstance(value, str) and value and value not in clean:
                clean.append(value[:80])
        result[field] = clean
    for field, fallback in (("cozmo_tea_earned", 0),
                            ("cozmo_death_reload_count", 0),
                            ("cozmo_hint_stage", 0)):
        try:
            number = int(result.get(field, fallback))
        except (TypeError, ValueError, OverflowError):
            number = fallback
        maximum = 3 if field == "cozmo_hint_stage" else 1000000000
        result[field] = min(maximum, max(0, number))
''', 1)

# Release-specific code is appended as a new subclass. All F1.666b classes,
# save migration routines, world objects, area links, and F1.6 systems remain.
insert = r'''

# ===========================================================================
# SGGF1.666c — exploit-specific Cozmo achievements and graduated HELLgs hints.
# This is an additive layer over F1.666b. Do not rewrite the shared save loader.
# ===========================================================================

F1666C_EXPLOIT_ACHIEVEMENTS = {
    'bucket': 'bucket_theft',
    'naz': 'naz_guard_death',
    'vault_clip': 'vault_clip',
    'lout_guard_death': 'lout_guard_death',
    'hellgs_escape': 'hellgs_escape',
}
F1666C_HINT_EVENTS = {'hint_4': 1, 'hint_10': 2, 'hint_20': 3}
F1666C_HINT_AUTO_LINES = {
    'hint_10': 'Still trying? I can offer ONE final hint',
    'hint_20': "I'm impressed by your stubborn tenacity, but I am willing to give you a total spoiler if you are willing to admit defeat",
}
F1666C_HINT_SOLUTION = (
    'Load into a version where the starting location is NOT Hellgs Inn. '
    'Do a quicksave.  open THIS version (or later O_o) and then quickload.  '
    "I'll see ya on the other side"
)
F1666C_QUICKLOAD_RECT = (510, 420, 260, 48)


class F1666cStateMachine(F1666bStateMachine):
    """F1.666b plus five once-only exploit recognitions and no-tea hint tiers."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._f1666c_run_initialized = False
        self.config.setdefault('cozmo_exploit_events', [])
        self.config.setdefault('cozmo_pending_tea_events', [])
        self.config.setdefault('cozmo_tea_earned', 0)
        self.config.setdefault('cozmo_death_reload_count', 0)
        self.config.setdefault('cozmo_hint_stage', 0)
        self._log('F1.666c CONFIG',
                  f"exploit_events={self.config.get('cozmo_exploit_events', [])}; "
                  f"tea_earned={self.config.get('cozmo_tea_earned', 0)}; "
                  f"death_reload_count={self.config.get('cozmo_death_reload_count', 0)}; "
                  f"hint_stage={self.config.get('cozmo_hint_stage', 0)}")

    def _f1666b_spawn_cozmo(self):
        # F1.666c replaces F1.666b's alternating visit counter entirely.
        # The inherited loader still calls this hook, but all successful-load
        # recognition is handled below using the pre-load and post-load areas.
        return None

    def _f1666c_save_config(self, **changes):
        self.config.update(changes)
        try:
            save_main_config(self.config)
        except Exception as exc:
            self._log('F1.666c CONFIG ERROR',
                      f'{type(exc).__name__}: {exc}; keys={sorted(changes)}')
            return False
        self._log('CONFIG', 'Saved Cozmo achievement/hint state: ' + ', '.join(sorted(changes)))
        return True

    def _f1666c_achievement_ids(self):
        values = self.config.get('cozmo_exploit_events', [])
        return set(values) if isinstance(values, list) else set()

    def _f1666c_award_achievement(self, achievement):
        """Record one distinct exploit and update the visible Tea score once.

        Non-HELLgs achievements discovered first are held pending so the first
        actual Tea point is always the successful escape from HELLgs Inn.
        """
        if achievement not in set(F1666C_EXPLOIT_ACHIEVEMENTS.values()):
            return False
        seen = list(self.config.get('cozmo_exploit_events', []))
        if achievement in seen:
            return False
        seen.append(achievement)
        pending = list(self.config.get('cozmo_pending_tea_events', []))
        try:
            tea_total = int(self.config.get('cozmo_tea_earned', 0))
        except (TypeError, ValueError, OverflowError):
            tea_total = 0

        released = []
        if achievement == 'hellgs_escape':
            tea_total += 1  # This is always Yorkshire Tea number one.
            released = list(pending)
            tea_total += len(released)
            pending = []
        elif 'hellgs_escape' not in seen:
            if achievement not in pending:
                pending.append(achievement)
        else:
            tea_total += 1

        self._f1666c_save_config(
            cozmo_exploit_events=seen,
            cozmo_pending_tea_events=pending,
            cozmo_tea_earned=tea_total,
        )
        if achievement == 'hellgs_escape':
            detail = 'first Tea awarded for escaping HELLgs Inn'
            if released:
                detail += '; released pending achievements=' + ','.join(released)
        elif 'hellgs_escape' not in seen:
            detail = 'achievement recorded; Tea held until HELLgs escape so escape remains Tea #1'
        else:
            detail = 'one Yorkshire Tea added to the Tea Earned total'
        self._log('COZMO TEA ACHIEVEMENT',
                  f'{achievement}; tea_earned={tea_total}; {detail}')
        self._set_status(f'TEA EARNED: {tea_total}')
        return True

    def _f1666c_spawn_cameo(self, event):
        g = self.game
        if g is None:
            return False
        flags = self._d11_flags()
        if event in F1666C_EXPLOIT_ACHIEVEMENTS:
            achievement = F1666C_EXPLOIT_ACHIEVEMENTS[event]
            if achievement in self._f1666c_achievement_ids():
                return False
        px, py = g.player_x, g.player_y
        x = max(120.0, min(1120.0, px + (145 if px < 880 else -145)))
        y = max(190.0, min(535.0, py + (8 if py < 420 else -16)))
        flags['d11_cameo_active'] = {
            'event': event,
            'area': g.current_area_id,
            'x': x,
            'y': y,
            'talked': False,
            'leave_at': None,
        }
        if event in F1666C_EXPLOIT_ACHIEVEMENTS:
            self._f1666c_award_achievement(F1666C_EXPLOIT_ACHIEVEMENTS[event])
        self._log('COZMO CAMEO',
                  f'Appeared event={event}; area={g.current_area_id}; '
                  f'position=({x:.0f},{y:.0f})')
        return True

    def start_game(self):
        new_run = self.game is None and not self._f1666c_run_initialized
        super().start_game()
        if new_run:
            # This counter belongs to the current actual run, not to an
            # individual save slot. Exploit achievements and Tea remain global.
            self._f1666c_save_config(cozmo_death_reload_count=0, cozmo_hint_stage=0)
            self._f1666c_run_initialized = True
            self._log('COZMO HINTS', 'New actual run: death/reload count=0; hint stage=0.')

    def _d11_schedule(self, event):
        achievement = F1666C_EXPLOIT_ACHIEVEMENTS.get(event)
        if achievement is None:
            return super()._d11_schedule(event)
        g = self.game
        if g is None or achievement in self._f1666c_achievement_ids():
            return
        flags = self._d11_flags()
        active = flags.get('d11_cameo_active')
        if isinstance(active, dict) and active.get('event') == event:
            return
        queue = flags.get('d11_cameo_queue', [])
        if any(isinstance(item, dict) and item.get('event') == event for item in queue):
            return
        # If an old save says the D1.1 bucket/Naz cameo already appeared and
        # neither an active actor nor a pending queue entry remains, credit
        # that legacy discovery once rather than replaying the same cameo.
        if event in flags.get('d11_cameo_events', []):
            self._f1666c_award_achievement(achievement)
            self._log('COZMO CAMEO', f'Legacy save already recorded {event}; recognition migrated without replay.')
            return
        if event not in flags['d11_cameo_events']:
            flags['d11_cameo_events'].append(event)
        flags['d11_cameo_queue'].append({
            'event': event,
            'at': float(g.c1_elapsed) + 5.0,
            'area': g.current_area_id,
        })
        self._log('COZMO CAMEO',
                  f'Queued first-time exploit event={event} area={g.current_area_id} '
                  f'at={g.c1_elapsed + 5.0:.2f}')

    def _d11_update_cameo(self):
        g = self.game
        if g is None:
            return
        flags = self._d11_flags()
        previous = flags.get('d11_cameo_active')
        if previous is None and flags.get('d11_cameo_queue'):
            next_event = flags['d11_cameo_queue'][0]
            required_area = next_event.get('area') if isinstance(next_event, dict) else None
            if required_area and g.current_area_id != required_area:
                return
            if next_event.get('event') in ('vault_clip', 'lout_guard_death') and required_area:
                if g.current_area_id != required_area:
                    return
        super()._d11_update_cameo()
        active = flags.get('d11_cameo_active')
        if previous is None and isinstance(active, dict):
            event = active.get('event')
            achievement = F1666C_EXPLOIT_ACHIEVEMENTS.get(event)
            if achievement:
                self._f1666c_award_achievement(achievement)
            auto_line = F1666C_HINT_AUTO_LINES.get(event)
            if auto_line:
                self._f1666c_speech_as_cozmo(auto_line, 7.0)

    def _f1666c_speech_as_cozmo(self, message, seconds=6.0):
        previous = self.d11_context_ref
        self.d11_context_ref = {'kind': 'cozmo'}
        try:
            self._speech(message, seconds)
        finally:
            self.d11_context_ref = previous

    def _f1666c_queue_hint(self, reload_count):
        desired = 0
        if reload_count >= 4:
            desired = 1
        if reload_count >= 10:
            desired = 2
        if reload_count >= 20:
            desired = 3
        try:
            current_stage = int(self.config.get('cozmo_hint_stage', 0))
        except (TypeError, ValueError, OverflowError):
            current_stage = 0
        if desired <= current_stage:
            return False
        event = {1: 'hint_4', 2: 'hint_10', 3: 'hint_20'}[desired]
        flags = self._d11_flags()
        active = flags.get('d11_cameo_active')
        if isinstance(active, dict) and active.get('event') == event:
            return False
        if any(isinstance(item, dict) and item.get('event') == event
               for item in flags['d11_cameo_queue']):
            return False
        self._f1666c_save_config(cozmo_hint_stage=desired)
        if event not in flags['d11_cameo_events']:
            flags['d11_cameo_events'].append(event)
        flags['d11_cameo_queue'].append({
            'event': event,
            'at': float(self.game.c1_elapsed) + 1.0,
            'area': 'hellgs_inn',
        })
        self._log('COZMO HINT',
                  f'Queued {event} after successful death quickload #{reload_count} into HELLgs Inn.')
        return True

    def _f1666c_clean_loaded_cameos(self):
        """Prevent old snapshots from replaying a globally completed cameo."""
        g = self.game
        if g is None:
            return
        flags = self._d11_flags()
        seen = self._f1666c_achievement_ids()
        active = flags.get('d11_cameo_active')
        if isinstance(active, dict):
            achievement = F1666C_EXPLOIT_ACHIEVEMENTS.get(active.get('event'))
            hint_stage = F1666C_HINT_EVENTS.get(active.get('event'))
            if achievement and achievement in seen:
                flags['d11_cameo_active'] = None
            elif hint_stage and int(self.config.get('cozmo_hint_stage', 0)) >= hint_stage:
                flags['d11_cameo_active'] = None
            elif achievement:
                # The save captured Cozmo already present. Count that event,
                # but do not manufacture a second appearance on loading it.
                self._f1666c_award_achievement(achievement)
                flags['d11_cameo_active'] = None
        cleaned_queue = []
        for item in flags.get('d11_cameo_queue', []):
            if not isinstance(item, dict):
                continue
            achievement = F1666C_EXPLOIT_ACHIEVEMENTS.get(item.get('event'))
            hint_stage = F1666C_HINT_EVENTS.get(item.get('event'))
            if achievement and achievement in self._f1666c_achievement_ids():
                continue
            if hint_stage and int(self.config.get('cozmo_hint_stage', 0)) >= hint_stage:
                continue
            cleaned_queue.append(item)
        flags['d11_cameo_queue'] = cleaned_queue

    def _f1666c_migrate_legacy_achievements(self):
        """Recognize exploit states already present in pre-F1.666c saves."""
        g = self.game
        if g is None:
            return
        flags = self._d11_flags()
        active = flags.get('d11_cameo_active')
        queued = {item.get('event') for item in flags.get('d11_cameo_queue', [])
                  if isinstance(item, dict)}
        legacy = set(flags.get('d11_cameo_events', []))

        for old_name, achievement in (('bucket', 'bucket_theft'), ('naz', 'naz_guard_death')):
            if old_name not in legacy or achievement in self._f1666c_achievement_ids():
                continue
            if (isinstance(active, dict) and active.get('event') == old_name) or old_name in queued:
                continue
            # D1.1 already displayed this cameo in an older release. Do not
            # replay it, but convert the old recognition to the new Tea score.
            self._f1666c_award_achievement(achievement)

        if g.c1_vault_entered and 'vault_clip' not in self._f1666c_achievement_ids():
            self._d11_schedule('vault_clip')
        naz = g.c1_npcs.get('naz')
        if naz and not naz.get('alive', True) and 'naz_guard_death' not in self._f1666c_achievement_ids():
            self._d11_schedule('naz')
        lout = g.c1_npcs.get('inn_lout')
        if lout and not lout.get('alive', True) and 'lout_guard_death' not in self._f1666c_achievement_ids():
            self._d11_schedule('lout_guard_death')

    def _read_save(self, slot):
        # Capture the source location and death state BEFORE attempting load.
        previous_game = self.game
        previous_area = getattr(previous_game, 'current_area_id', None)
        previous_flags = getattr(previous_game, 'c1_flags', {}) if previous_game else {}
        died_before_load = bool(previous_game and (
            getattr(previous_game, 'c1_dead', None) or previous_flags.get('hellgs_game_over')))
        super()._read_save(slot)
        if self.game is previous_game or self.game is None:
            return  # A failed/missing load cannot count or trigger a cameo.

        self._f1666c_clean_loaded_cameos()
        loaded_area = self.game.current_area_id

        if previous_area == 'hellgs_inn' and loaded_area != 'hellgs_inn':
            # This is the actual escape achievement, and always earns Tea #1.
            self._f1666c_spawn_cameo('hellgs_escape')

        if slot == 'quick' and died_before_load:
            try:
                reload_count = int(self.config.get('cozmo_death_reload_count', 0)) + 1
            except (TypeError, ValueError, OverflowError):
                reload_count = 1
            self._f1666c_save_config(cozmo_death_reload_count=reload_count)
            self._log('COZMO DEATH RELOAD',
                      f'successful quickload after death #{reload_count}; '
                      f'loaded_area={loaded_area}; previous_area={previous_area}')
            if loaded_area == 'hellgs_inn':
                self._f1666c_queue_hint(reload_count)

        self._f1666c_migrate_legacy_achievements()

    def _area_enter(self, conn):
        result = super()._area_enter(conn)
        if (conn and getattr(conn, 'trigger', None) == 'clip'
                and getattr(conn, 'from_area_id', None) == 'castle_hall'
                and getattr(conn, 'to_area_id', None) == 'castle_vault'):
            self._d11_schedule('vault_clip')
            self._log('COZMO EXPLOIT', 'First-time castle vault seam clip detected.')
        return result

    def _npc_tick(self, dt):
        g = self.game
        previous_lout_alive = bool(g and g.c1_npcs.get('inn_lout', {}).get('alive', True))
        super()._npc_tick(dt)
        if g and previous_lout_alive and not g.c1_npcs.get('inn_lout', {}).get('alive', True):
            self._d11_schedule('lout_guard_death')
            self._log('COZMO EXPLOIT', 'First-time inn lout guard death detected.')

    def _f1666c_hint_talk(self, event):
        info = self._d11_flags().get('d11_cameo_active')
        if not isinstance(info, dict):
            return
        info['talked'] = True
        if event == 'hint_4':
            self._dialogue('Cozmo',
                'If you REALLY REALLY want, I can gave you a hint',
                [{'text': 'yah, help me out here', 'action': 'f1666c_hint4_yes'}])
        elif event == 'hint_10':
            self._dialogue('Cozmo', 'You really want another hint?',
                [{'text': "Yah, i'm still stumped", 'action': 'f1666c_hint10_yes'}])
        elif event == 'hint_20':
            self._dialogue('Cozmo',
                'Ok, if you truly admit defeat I will tell you how to get out of here.',
                [{'text': "Cozmo, i'm truly stumped but want to see more of this game than these four walls and fire. Please help me out.",
                  'action': 'f1666c_hint20_admit'}])

    def _d11_talk(self):
        flags = self._d11_flags()
        info = flags.get('d11_cameo_active') if flags else None
        if not isinstance(info, dict):
            return super()._d11_talk()
        event = info.get('event')
        if event in F1666C_HINT_EVENTS:
            return self._f1666c_hint_talk(event)
        if event in ('hellgs_escape', 'vault_clip', 'lout_guard_death'):
            if not info.get('talked'):
                info['talked'] = True
                info['leave_at'] = self.game.c1_elapsed + 30.0
            self._dialogue('Cozmo', F1666B_COZMO_TEXT,
                           [{'text': 'Thank you, Cozmo!', 'action': 'close'}])
            return
        # Keep the original D1.1 bucket and Naz dialogue exactly as it was.
        return super()._d11_talk()

    def _choose_dialogue(self, index):
        g = self.game
        if g and g.c1_dialogue:
            options = g.c1_dialogue.get('options', [])
            if 0 <= index < len(options):
                action = options[index].get('action')
                if action == 'f1666c_hint4_yes':
                    g.c1_dialogue = None
                    self._dialogue('Cozmo', 'Are you REALLY SURE?',
                        [{'text': "Yes I'm damn sure! I'm NOT the Spiffing Brit after all",
                          'action': 'f1666c_hint4_yes2'}])
                    return
                if action == 'f1666c_hint4_yes2':
                    g.c1_dialogue = None
                    self._dialogue('Cozmo', 'Have you considered loading a DIFFERENT save?',
                        [{'text': 'Thanks, Cozmo.', 'action': 'f1666c_hint_close'}])
                    return
                if action == 'f1666c_hint10_yes':
                    g.c1_dialogue = None
                    self._dialogue('Cozmo',
                        'I told Luma to make sure that save games are as forward compatable as possible.\n\n(Cozmo raises one eyebrow.)',
                        [{'text': 'I will remember that.', 'action': 'f1666c_hint_close'}])
                    return
                if action == 'f1666c_hint20_admit':
                    g.c1_dialogue = None
                    flags = self._d11_flags()
                    flags['d11_cameo_active'] = None  # Cozmo vanishes as the spoiler begins.
                    self._dialogue('Cozmo', F1666C_HINT_SOLUTION,
                        [{'text': 'Thank you, Cozmo.', 'action': 'f1666c_hint_close'}])
                    self._log('COZMO HINT', 'Player explicitly admitted defeat; final escape spoiler delivered.')
                    return
                if action == 'f1666c_hint_close':
                    g.c1_dialogue = None
                    self._d11_flags()['d11_cameo_active'] = None
                    self._log('COZMO HINT', 'Hint conversation closed; Cozmo departed.')
                    return
        return super()._choose_dialogue(index)

    def _dispatch_game(self, event, ui):
        g = self.game
        if g and g.c1_dead:
            if event.type == pygame.KEYDOWN and c12_binding_matches(event, self.c1_keys['quickload']):
                self._read_save('quick')
                return
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                point = ui.screen_to_game(event.pos)
                if point is not None and pygame.Rect(F1666C_QUICKLOAD_RECT).collidepoint(point):
                    self._read_save('quick')
                    return
        return super()._dispatch_game(event, ui)


class F1666cInterface(F1666bInterface):
    """F1.666c adds a visible Tea Earned score and a Quickload death button."""

    def _draw_header(self):
        super()._draw_header()
        if self.machine.state is AppState.PLAY_GAME:
            try:
                tea_total = int(self.machine.config.get('cozmo_tea_earned', 0))
            except (TypeError, ValueError, OverflowError):
                tea_total = 0
            panel = pygame.Rect(365, 5, 190, 30)
            pygame.draw.rect(self.screen, (42, 35, 43), panel, border_radius=5)
            pygame.draw.rect(self.screen, (220, 175, 106), panel, 1, border_radius=5)
            label = self.game_small_font.render(f'TEA EARNED: {tea_total}', True, (250, 221, 153))
            self.screen.blit(label, label.get_rect(center=panel.center))

    def _draw_game_scene(self, surface, g):
        super()._draw_game_scene(surface, g)
        if not g.c1_dead:
            return
        x, y, w, h = F1666C_QUICKLOAD_RECT
        button = pygame.Rect(x, y, w, h)
        pygame.draw.rect(surface, (37, 58, 55), button, border_radius=8)
        pygame.draw.rect(surface, (233, 190, 113), button, 3, border_radius=8)
        label = self.game_font.render('QUICKLOAD', True, (255, 239, 205))
        surface.blit(label, label.get_rect(center=button.center))


'''

assert 'async def main():' in src
src = src.replace('\n\nasync def main():', insert + '\nasync def main():', 1)
src = src.replace('VERSION = "F1.666b"', 'VERSION = "F1.666c"', 1)
src = src.replace('machine = F1666bStateMachine(archive, config, warning)',
                  'machine = F1666cStateMachine(archive, config, warning)', 1)
src = src.replace('ui = F1666bInterface(machine)', 'ui = F1666cInterface(machine)', 1)
main_path.write_text(src, encoding='utf-8')

# The Luma world is unchanged except for its version identifier and a note
# recording that this release adds code-only Cozmo cameo / hint behaviour.
asset_path = W / 'luma_assets_e33.json'
asset_doc = json.loads(asset_path.read_text(encoding='utf-8'))
assert asset_doc['version'] == 'SGGF1.666b'
asset_doc['version'] = 'SGGF1.666c'
asset_doc['notes'] = str(asset_doc.get('notes', '')) + (
    '\nSGGF1.666c: adds once-only Cozmo recognition for the HELLgs save-load escape, '
    'the first bucket theft, first vault seam clip, and the first guard deaths of Naz '
    'and the inn lout. Each distinct exploit earns one Tea, with the HELLgs escape '
    'always counted first. The visible TEA EARNED counter is global and save-slot independent. '
    'Adds a Quickload button after any death and independent no-tea hints on the fourth, '
    'tenth and twentieth successful death quickloads back into HELLgs Inn.'
)
asset_path.write_text(json.dumps(asset_doc, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

# Unique web runtime archive / bundle names; F1.666b's page is preserved as snapshot.
page_path = W / 'F1_play.html'
page = page_path.read_text(encoding='utf-8')
assert 'SGGF1.666b' in page and 'sggf1666b' in page
page = page.replace('SGGF1.666b', 'SGGF1.666c').replace('sggf1666b', 'sggf1666c')
page_path.write_text(page, encoding='utf-8')

print('Prepared F1.666c from the exact F1.666b source archive.')
