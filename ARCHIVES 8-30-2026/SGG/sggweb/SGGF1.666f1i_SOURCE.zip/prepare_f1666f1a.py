from pathlib import Path
import ast, json
W=Path(__file__).resolve().parent
ast.parse((W/'main.py').read_text(encoding='utf-8'))
a=json.loads((W/'luma_assets_e33.json').read_text(encoding='utf-8'))
assert a['version']=='SGGF1.666f1a'
assert '.card.no-art{grid-template-columns:minmax(0,1fr)}' in (W/'deploy'/'index.html').read_text(encoding='utf-8')
print('F1.666f1a source validates.')
