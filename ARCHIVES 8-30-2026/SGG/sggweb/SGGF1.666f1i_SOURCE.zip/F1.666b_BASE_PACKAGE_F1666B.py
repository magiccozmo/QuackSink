"""Package SGGF1.666b as a new immutable release on top of F1.666a."""
from pathlib import Path
import ast
import copy
import gzip
import hashlib
import io
import json
import subprocess
import sys
import tarfile
import zipfile

ROOT = Path('/mnt/data')
WORK = Path(__file__).resolve().parent
BASE_DEPLOY = ROOT / 'SGGF1.666a_CLOUDFLARE_DEPLOY.zip'
BASE_SOURCE = ROOT / 'SGGF1.666a_SOURCE.zip'
MAIN = WORK / 'main.py'
ASSETS = WORK / 'luma_assets_e33.json'
PLAY = WORK / 'F1_play.html'
README = WORK / 'README_SGGF1666b.txt'
TEST = WORK / 'test_f1666b.py'
DEPLOY = ROOT / 'SGGF1.666b_CLOUDFLARE_DEPLOY.zip'
SOURCE = ROOT / 'SGGF1.666b_SOURCE.zip'
META_PATH = WORK / 'F1.666b_BUILD_META.json'
VERSION = 'SGGF1.666b'
BUNDLE = 'sggf1666b'

for p in (BASE_DEPLOY, BASE_SOURCE, MAIN, ASSETS, PLAY, README, TEST,
          WORK / 'F1.666a_BASE_MAIN.py', WORK / 'F1.666a_BASE_LUMA_ASSETS.json'):
    assert p.is_file(), f'Missing build input: {p}'
# Immutable archive rule: never replace a previously built release.
assert not DEPLOY.exists(), 'Refusing to replace an existing F1.666b deploy archive.'
assert not SOURCE.exists(), 'Refusing to replace an existing F1.666b source archive.'

code = MAIN.read_bytes()
assets_bytes = ASSETS.read_bytes()
assets_doc = json.loads(assets_bytes)
page = PLAY.read_text(encoding='utf-8')
assert assets_doc['version'] == VERSION
assert b'VERSION = "F1.666b"' in code
assert all(token in page for token in (
    'SGGF1.666b', 'sggf1666b.apk', 'sggf1666b.tar.gz',
    'archive:"sggf1666b"', 'bundle = "sggf1666b"'))
assert "Welcome brave exploiter to version F1.666 of Spiffy's Gift." in code.decode('utf-8')
assert "I look forwarding to meeting you." in code.decode('utf-8')
assert "Well dayum! I guess you are exploiter after all." in code.decode('utf-8')
assert 'hellgs_note' not in code.decode('utf-8').split('class C13GameModel', 1)[-1].split('class C13StateMachine', 1)[0], \
    'C13 must not contain the old per-object migration allowlist.'
assert 'merge_saved_over_defaults' in code.decode('utf-8')
assert 'class F1666bStateMachine(F1666StateMachine)' in code.decode('utf-8')
assert 'class F1666bInterface(F1666Interface)' in code.decode('utf-8')

ast.parse(code.decode('utf-8'))
subprocess.run([sys.executable, '-m', 'py_compile', str(MAIN)], cwd=WORK, check=True)
subprocess.run([sys.executable, str(TEST)], cwd=WORK, check=True)

# The F1.666a world remains byte-for-byte the same except the release id and
# one additional inventory artwork recipe for Yorkshire Tea.
base_doc = json.loads((WORK / 'F1.666a_BASE_LUMA_ASSETS.json').read_text(encoding='utf-8'))
expected_doc = copy.deepcopy(base_doc)
expected_doc['version'] = VERSION
expected_doc.setdefault('assets', {})['tea'] = copy.deepcopy(assets_doc['assets']['tea'])
assert assets_doc == expected_doc, 'Unexpected world/asset change beyond version id and tea sprite.'
assert 'tea' in assets_doc['assets']

# Runtime APK/TAR contain the exact tested source and Luma world bytes.
apkb = io.BytesIO()
with zipfile.ZipFile(apkb, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as apk:
    apk.writestr('assets/main.py', code)
    apk.writestr('assets/luma_assets_e33.json', assets_bytes)

tarb = io.BytesIO()
with gzip.GzipFile(fileobj=tarb, mode='wb', compresslevel=9, mtime=0) as gz:
    with tarfile.open(fileobj=gz, mode='w') as tf:
        for name, payload in (('assets/main.py', code), ('assets/luma_assets_e33.json', assets_bytes)):
            info = tarfile.TarInfo(name)
            info.size = len(payload)
            info.mode = 0o644
            info.mtime = 0
            tf.addfile(info, io.BytesIO(payload))

with zipfile.ZipFile(BASE_DEPLOY, 'r') as old:
    assert old.testzip() is None
    old_names = old.namelist()
    assert len(old_names) == 180 and len(old_names) == len(set(old_names))
    for required in (
        'index.html', 'versions.html', 'versions.json', '_headers',
        'SGGF1.666a/play.html', 'SGGF1.666a/favicon.png',
        'SGGF1.666a/sggf1666a.apk', 'SGGF1.666a/sggf1666a.tar.gz',
        'SGGF1.666a/README_SGGF1666a.txt'):
        assert required in old_names, required

    manifest = json.loads(old.read('versions.json'))
    assert len(manifest['versions']) == 35
    previous_release = next(v for v in manifest['versions'] if v['version'] == 'SGGF1.666a')
    assert previous_release['current'] is True
    new_description = previous_release['description'] + (
        ' Backward-compatible loading preserves earlier saved locations and game state. '
        'Load while standing in HELLgs Inn and Cozmo appears at the loaded save location, '
        'with alternating Yorkshire Tea rewards.')
    for entry in manifest['versions']:
        entry['current'] = False
    manifest['versions'].insert(0, {
        'version': VERSION,
        'title': 'SGGF1.666b — Save Compatibility & Cozmo’s Tea',
        'path': VERSION + '/play.html',
        'description': new_description,
        'current': True,
    })
    manifest_bytes = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode('utf-8')

    index_html = old.read('index.html').decode('utf-8')
    versions_html = old.read('versions.html').decode('utf-8')
    # F1.666a introduced the alphabetic suffix guard; confirm F1.666b is allowed.
    for label, html in (('index.html', index_html), ('versions.html', versions_html)):
        assert '[a-z]?' in html, f'{label} does not support alphabetic release suffixes.'
        assert 'navigator.userAgentData?.mobile' in html

    favicon = old.read('SGGF1.666a/favicon.png')
    additions = [
        (VERSION + '/play.html', page.encode('utf-8')),
        (VERSION + '/favicon.png', favicon),
        (VERSION + '/' + BUNDLE + '.apk', apkb.getvalue()),
        (VERSION + '/' + BUNDLE + '.tar.gz', tarb.getvalue()),
        (VERSION + '/README_SGGF1666b.txt', README.read_bytes()),
    ]

    deploy_dir = WORK / 'deploy'
    deploy_dir.mkdir(exist_ok=True)
    (deploy_dir / 'index.html').write_text(index_html, encoding='utf-8')
    (deploy_dir / 'versions.html').write_text(versions_html, encoding='utf-8')
    (deploy_dir / 'versions.json').write_bytes(manifest_bytes)
    (deploy_dir / '_headers').write_bytes(old.read('_headers'))

    with zipfile.ZipFile(DEPLOY, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=8) as out:
        for member in old.infolist():
            name = member.filename
            if name == 'versions.json':
                payload = manifest_bytes
            else:
                payload = old.read(name)
            out.writestr(copy.copy(member), payload)
        for name, payload in additions:
            assert name not in old_names, f'New release path collides with historical deployment: {name}'
            out.writestr(name, payload)

# Validate the deployment as a self-contained and history-preserving publish.
with zipfile.ZipFile(DEPLOY, 'r') as z, zipfile.ZipFile(BASE_DEPLOY, 'r') as old:
    assert z.testzip() is None
    names = z.namelist()
    assert len(names) == len(old_names) + len(additions) == 185
    assert len(names) == len(set(names))
    for name in old_names:
        if name == 'versions.json':
            continue
        assert z.read(name) == old.read(name), f'Historical deployment member changed: {name}'
    final_manifest = json.loads(z.read('versions.json'))
    assert len(final_manifest['versions']) == 36
    assert final_manifest['versions'][0]['version'] == VERSION
    assert final_manifest['versions'][0]['current'] is True
    assert final_manifest['versions'][1]['version'] == 'SGGF1.666a'
    assert final_manifest['versions'][1]['current'] is False
    assert sum(1 for v in final_manifest['versions'] if v.get('current')) == 1
    assert final_manifest['versions'][0]['description'] == new_description
    assert final_manifest['versions'][1]['description'] == previous_release['description']
    with zipfile.ZipFile(io.BytesIO(z.read(VERSION + '/' + BUNDLE + '.apk'))) as runtime:
        assert runtime.testzip() is None
        assert runtime.namelist() == ['assets/main.py', 'assets/luma_assets_e33.json']
        assert runtime.read('assets/main.py') == code
        assert runtime.read('assets/luma_assets_e33.json') == assets_bytes
    with tarfile.open(fileobj=io.BytesIO(z.read(VERSION + '/' + BUNDLE + '.tar.gz')), mode='r:gz') as runtime:
        assert runtime.extractfile('assets/main.py').read() == code
        assert runtime.extractfile('assets/luma_assets_e33.json').read() == assets_bytes
    final_page = z.read(VERSION + '/play.html').decode('utf-8')
    assert 'archive:"' + BUNDLE + '"' in final_page
    assert BUNDLE + '.apk' in final_page and BUNDLE + '.tar.gz' in final_page

# Build metadata records the compatibility contract and test evidence.
meta = {
    'version': VERSION,
    'based_on': 'SGGF1.666a',
    'previous_release_preserved': True,
    'repository': 'magiccozmo/QuackSink',
    'source_folder': 'ARCHIVES 8-30-2026/SGG/sggweb',
    'scope': 'Permanent additive, backward-compatible save migration plus the HELLgs return Cozmo cameo and alternating Yorkshire Tea score reward. No new escape or anti-exploit mechanics.',
    'save_compatibility_contract': {
        'schema': 'spiffys-gift-save-v1',
        'policy': 'Keep existing area IDs and shared save schema stable. Load older saves into current defaults; preserve saved gameplay values and saved location.',
        'world_objects': 'Add every current-world object absent from the older save once, using current object defaults. Preserve all existing saved object records and custom/dropped objects. No per-object allowlist.',
        'npcs': 'Merge current NPC definitions/defaults with saved NPC state recursively. Preserve existing saved values and add only missing defaults.',
        'save_fields': 'New top-level and nested dictionary keys default from the current model only when missing; existing values take priority.',
        'set_fields': 'New saved set fields receive current defaults when absent.',
        'object_dataclass': 'New GameObject dataclass fields must have defaults/default factories so older object snapshots can be upgraded.',
        'area_ids': 'Do not silently move a player when a saved area is unknown. Keep old area IDs valid or add a deliberate alias/migration.',
    },
    'cozmo_return_cameo': {
        'trigger': 'A successful save load whose pre-load player location was hellgs_inn.',
        'placement': 'Existing Cozmo cameo artwork and interaction at the current player location in the newly loaded save area.',
        'dialogue': "Well dayum! I guess you are exploiter after all. This 'game' was truly designed and created for folks like you. Here is some Tea.",
        'tea_awards': 'Appearances 1,3,5,... grant one Yorkshire Tea; appearances 2,4,6,... grant none.',
        'once_per_appearance': True,
        'counter_storage': 'Persistent sgg.config preference outside individual save slots.',
        'non_reward_appearances': 'The one-time interaction opportunity is consumed for that appearance; repeated dialogue does not produce a delayed duplicate award.',
    },
    'preserved': [
        'SGGF1.666a archive and all historical release archives are not replaced.',
        'F1.666a world geometry, objects, connections, HELLgs clock, paper text and F1.6 systems remain unchanged except the new tea inventory artwork asset and dynamic version labels.',
        'Existing save location, coordinates, inventory, object records, item metadata, NPC state, quest flags, day, elapsed time and other save state remain authoritative.',
        'No custom exit, escape path, cooldown, anti-exploit mechanic or other restriction was introduced.',
        'All 180 previous deployment members are byte-for-byte unchanged; five distinct F1.666b entries were added. The version catalogue alone was extended.',
    ],
    'tests': [
        'PASS AST parse and py_compile.',
        'PASS in-memory synthetic F1.6 save into SGGF1.666b preserving area, player coordinates, inventory, gold, day, elapsed time, quest flags, NPC state, old object records and item metadata.',
        'PASS generic future-release simulation: new world object, NPC, save field, set field and nested NPC default merge without per-ID allowlists.',
        'PASS current-world objects added once when absent; present/moved paper object remains unchanged; unknown/dropped dynamic object survives.',
        'PASS pre-load hellgs_inn trigger only on successful load; Cozmo placed in loaded area; failed/no-op load does not trigger.',
        'PASS alternating Yorkshire Tea reward 1,0,1 and repeat interaction cannot double-claim within one appearance.',
        'PASS new tea art asset accepted by LumaDrawEngine.',
        'PASS all 180 historical deployment members retained byte-for-byte; 5 new version assets added; runtime APK and TAR contain exact tested source and JSON.',
    ],
    'runtime_note': 'Static and in-memory model tests passed. No live browser/Pygame launch was run in this environment; field testing by Cozmo remains necessary.',
    'hashes': {
        'main_sha256': hashlib.sha256(code).hexdigest(),
        'assets_sha256': hashlib.sha256(assets_bytes).hexdigest(),
        'base_deploy_sha256': hashlib.sha256(BASE_DEPLOY.read_bytes()).hexdigest(),
        'deploy_sha256': hashlib.sha256(DEPLOY.read_bytes()).hexdigest(),
        'base_source_sha256': hashlib.sha256(BASE_SOURCE.read_bytes()).hexdigest(),
    },
    'bytes': {'deploy': DEPLOY.stat().st_size},
    'deployment_entries': {
        'previous_entries': len(old_names),
        'new_entries': len(additions),
        'final_entries': len(old_names) + len(additions),
        'catalog_versions': 36,
    },
}
META_PATH.write_text(json.dumps(meta, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

# Build a complete source archive, retaining all release-history snapshots.
source_files = []
for path in sorted(WORK.iterdir()):
    if not path.is_file() or path.suffix.lower() in ('.zip', '.pyc') or path.name.startswith('.'):
        continue
    source_files.append((path.name, path))
for name in ('index.html', 'versions.html', 'versions.json', '_headers'):
    path = WORK / 'deploy' / name
    assert path.is_file()
    source_files.append(('deploy/' + name, path))
assert len({name for name, _ in source_files}) == len(source_files)
with zipfile.ZipFile(SOURCE, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as out:
    for arcname, path in source_files:
        out.write(path, arcname)
with zipfile.ZipFile(SOURCE, 'r') as z:
    assert z.testzip() is None
    assert z.read('main.py') == code
    assert z.read('luma_assets_e33.json') == assets_bytes
    assert z.read('F1_play.html') == page.encode('utf-8')
    assert z.read('README_SGGF1666b.txt') == README.read_bytes()
    assert z.read('F1.666b_BUILD_META.json') == META_PATH.read_bytes()
    assert z.read('F1.666a_BASE_MAIN.py') == (WORK / 'F1.666a_BASE_MAIN.py').read_bytes()
    assert len(z.namelist()) == len(source_files)
    assert len(z.namelist()) == len(set(z.namelist()))

print(f'PASS deployment: {len(old_names)} prior entries retained; {len(additions)} distinct F1.666b entries added.')
print(f'PASS source ZIP: {len(source_files)} source/build/history components.')
print('DEPLOY:', DEPLOY, DEPLOY.stat().st_size, 'bytes')
print('DEPLOY SHA256:', hashlib.sha256(DEPLOY.read_bytes()).hexdigest())
print('SOURCE:', SOURCE, SOURCE.stat().st_size, 'bytes')
print('SOURCE SHA256:', hashlib.sha256(SOURCE.read_bytes()).hexdigest())
print('MAIN SHA256:', meta['hashes']['main_sha256'])
print('ASSETS SHA256:', meta['hashes']['assets_sha256'])
