"""F1.666f1 is generated from the immutable F1.666f runtime baseline.
See build_f1666f1.py in the release work notes for the deterministic package builder.
"""
from pathlib import Path
import ast, json
W=Path(__file__).resolve().parent
source=(W/'main.py').read_text(encoding='utf-8')
ast.parse(source)
assets=json.loads((W/'luma_assets_e33.json').read_text(encoding='utf-8'))
assert 'VERSION = "F1.666f1"' in source
assert assets['version']=='SGGF1.666f1'
print('F1.666f1 source validates; use package_f1666f1.py to rebuild archives.')
