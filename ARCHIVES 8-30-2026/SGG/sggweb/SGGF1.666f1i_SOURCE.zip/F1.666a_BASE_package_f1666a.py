"""Package SGGF1.666a as a distinct release, preserving F1.666 unchanged."""
from pathlib import Path
import ast
import copy
import gzip
import hashlib
import io
import json
import re
import subprocess
import sys
import tarfile
import zipfile

ROOT = Path('/mnt/data')
WORK = Path(__file__).resolve().parent
BASE_DEPLOY = ROOT / 'SGGF1.666_CLOUDFLARE_DEPLOY.zip'
BASE_SOURCE = ROOT / 'SGGF1.666_SOURCE.zip'
MAIN = WORK / 'main.py'
ASSETS = WORK / 'luma_assets_e33.json'
PLAY = WORK / 'F1_play.html'
README = WORK / 'README_SGGF1666a.txt'
TEST = WORK / 'test_f1666a.py'
DEPLOY = ROOT / 'SGGF1.666a_CLOUDFLARE_DEPLOY.zip'
SOURCE = ROOT / 'SGGF1.666a_SOURCE.zip'
META_PATH = WORK / 'F1.666a_BUILD_META.json'
VERSION = 'SGGF1.666a'
BUNDLE = 'sggf1666a'

for p in (BASE_DEPLOY, BASE_SOURCE, MAIN, ASSETS, PLAY, README, TEST):
    assert p.is_file(), f'Missing build input: {p}'
assert not DEPLOY.exists(), 'Refusing to replace an existing F1.666a deploy archive.'
assert not SOURCE.exists(), 'Refusing to replace an existing F1.666a source archive.'

code = MAIN.read_bytes()
assets_bytes = ASSETS.read_bytes()
assets_doc = json.loads(assets_bytes)
page = PLAY.read_text(encoding='utf-8')
assert assets_doc['version'] == VERSION
assert b'VERSION = "F1.666a"' in code
assert all(s in page for s in ('SGGF1.666a', 'sggf1666a.apk', 'sggf1666a.tar.gz', 'archive:"sggf1666a"'))
assert "Welcome brave exploiter to version F1.666 of Spiffy's Gift." in code.decode('utf-8')

# Source/runtime checks, including a real snapshot construction/load test.
ast.parse(code.decode('utf-8'))
subprocess.run([sys.executable, '-m', 'py_compile', str(MAIN)], cwd=WORK, check=True)

# Whole-world lock: the F1.666 world and artwork remain identical except the release id.
base_doc = json.loads((WORK / 'F1.666_BASE_LUMA_ASSETS.json').read_text(encoding='utf-8'))
expected = copy.deepcopy(base_doc)
expected['version'] = VERSION
assert assets_doc == expected, 'F1.666 world/assets changed beyond the version identifier.'

# Build exact runtime archives from the exact source bytes.
apkb = io.BytesIO()
with zipfile.ZipFile(apkb, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as apk:
    apk.writestr('assets/main.py', code)
    apk.writestr('assets/luma_assets_e33.json', assets_bytes)

tarb = io.BytesIO()
with gzip.GzipFile(fileobj=tarb, mode='wb', compresslevel=9, mtime=0) as gz:
    with tarfile.open(fileobj=gz, mode='w') as tf:
        for name, payload in (('assets/main.py', code), ('assets/luma_assets_e33.json', assets_bytes)):
            info = tarfile.TarInfo(name)
            info.size = len(payload)
            info.mode = 0o644
            info.mtime = 0
            tf.addfile(info, io.BytesIO(payload))

# Start from F1.666's full deployment, never from a mutable live folder.
with zipfile.ZipFile(BASE_DEPLOY, 'r') as old:
    assert old.testzip() is None
    old_names = old.namelist()
    assert len(old_names) == 175
    assert len(old_names) == len(set(old_names))
    for required in ('index.html', 'versions.html', 'versions.json', '_headers',
                     'SGGF1.666/play.html', 'SGGF1.666/favicon.png',
                     'SGGF1.666/sggf1666.apk', 'SGGF1.666/sggf1666.tar.gz',
                     'SGGF1.666/README_SGGF1666.txt'):
        assert required in old_names, required

    manifest = json.loads(old.read('versions.json'))
    assert len(manifest['versions']) == 34
    old_release = next(v for v in manifest['versions'] if v['version'] == 'SGGF1.666')
    old_description = old_release['description']
    new_description = old_description + ' woops.. now it IS possible to escape'
    for entry in manifest['versions']:
        entry['current'] = False
    manifest['versions'].insert(0, {
        'version': VERSION,
        'title': 'SGGF1.666a — HELLgs Inn',
        'path': VERSION + '/play.html',
        'description': new_description,
        'current': True,
    })
    manifest_bytes = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode('utf-8')

    # The front-door JavaScript needs to accept the single alphabetic suffix "a".
    index_html = old.read('index.html').decode('utf-8')
    versions_html = old.read('versions.html').decode('utf-8')
    old_regex = r"!\s*/\^SGG\[A-Z\]\\d\+\(\?:\\\.\(\?:\\d\+\)\*\)\*\$/"
    # Use direct literal replacement to keep all unrelated homepage markup untouched.
    original_guard = "if(!/^SGG[A-Z]\\d+(?:\\.\\d+)*$/.test(entry.version) || !/^SGG[A-Z]\\d+(?:\\.\\d+)*\\/(?:play|index)\\.html$/.test(entry.path)) continue;"
    new_guard = "if(!/^SGG[A-Z]\\d+(?:\\.\\d+)*[a-z]?$/.test(entry.version) || !/^SGG[A-Z]\\d+(?:\\.\\d+)*[a-z]?\\/(?:play|index)\\.html$/.test(entry.path)) continue;"
    for label, html in (('index.html', index_html), ('versions.html', versions_html)):
        assert html.count(original_guard) == 1, f'Could not uniquely locate version guard in {label}'
        updated = html.replace(original_guard, new_guard, 1)
        if label == 'index.html':
            index_html = updated
        else:
            versions_html = updated

    favicon = old.read('SGGF1.666/favicon.png')

    additions = [
        (VERSION + '/play.html', page.encode('utf-8')),
        (VERSION + '/favicon.png', favicon),
        (VERSION + '/' + BUNDLE + '.apk', apkb.getvalue()),
        (VERSION + '/' + BUNDLE + '.tar.gz', tarb.getvalue()),
        (VERSION + '/README_SGGF1666a.txt', README.read_bytes()),
    ]

    # Save the exact front-door source files alongside the source package.
    (WORK / 'deploy' / 'index.html').write_text(index_html, encoding='utf-8')
    (WORK / 'deploy' / 'versions.html').write_text(versions_html, encoding='utf-8')
    (WORK / 'deploy' / 'versions.json').write_bytes(manifest_bytes)

    subprocess.run([sys.executable, str(TEST)], cwd=WORK, check=True)

    with zipfile.ZipFile(DEPLOY, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=8) as out:
        for member in old.infolist():
            name = member.filename
            if name == 'versions.json':
                payload = manifest_bytes
            elif name == 'index.html':
                payload = index_html.encode('utf-8')
            elif name == 'versions.html':
                payload = versions_html.encode('utf-8')
            else:
                payload = old.read(name)
            out.writestr(copy.copy(member), payload)
        for name, payload in additions:
            assert name not in old_names, f'New release path collides with prior deployment: {name}'
            out.writestr(name, payload)

# Inspect deployment and verify byte preservation of every historical release file.
with zipfile.ZipFile(DEPLOY, 'r') as z, zipfile.ZipFile(BASE_DEPLOY, 'r') as old:
    assert z.testzip() is None
    names = z.namelist()
    assert len(names) == len(old_names) + len(additions) == 180
    assert len(names) == len(set(names))
    for name in old_names:
        if name in ('versions.json', 'index.html', 'versions.html'):
            continue
        assert z.read(name) == old.read(name), f'Historical deployment member changed: {name}'
    final_manifest = json.loads(z.read('versions.json'))
    assert len(final_manifest['versions']) == 35
    assert final_manifest['versions'][0]['version'] == VERSION
    assert final_manifest['versions'][0]['current'] is True
    assert final_manifest['versions'][1]['version'] == 'SGGF1.666'
    assert sum(1 for v in final_manifest['versions'] if v.get('current')) == 1
    expected_front_door = old_description + ' woops.. now it IS possible to escape'
    assert final_manifest['versions'][0]['description'] == expected_front_door
    assert all(re.fullmatch(r'SGG[A-Z]\d+(?:\.\d+)*[a-z]?', v['version']) for v in final_manifest['versions'])
    assert all(re.fullmatch(r'SGG[A-Z]\d+(?:\.\d+)*[a-z]?/(?:play|index)\.html', v['path'])
               for v in final_manifest['versions'])
    for root in ('index.html', 'versions.html'):
        html = z.read(root).decode('utf-8')
        assert '[a-z]?' in html and 'navigator.userAgentData?.mobile' in html
    with zipfile.ZipFile(io.BytesIO(z.read(VERSION + '/' + BUNDLE + '.apk'))) as runtime:
        assert runtime.testzip() is None
        assert runtime.namelist() == ['assets/main.py', 'assets/luma_assets_e33.json']
        assert runtime.read('assets/main.py') == code
        assert runtime.read('assets/luma_assets_e33.json') == assets_bytes
    with tarfile.open(fileobj=io.BytesIO(z.read(VERSION + '/' + BUNDLE + '.tar.gz')), mode='r:gz') as runtime:
        assert runtime.extractfile('assets/main.py').read() == code
        assert runtime.extractfile('assets/luma_assets_e33.json').read() == assets_bytes
    final_page = z.read(VERSION + '/play.html').decode('utf-8')
    assert 'archive:"' + BUNDLE + '"' in final_page
    assert BUNDLE + '.apk' in final_page and BUNDLE + '.tar.gz' in final_page

# Metadata captures precisely what changed and what was tested.
meta = {
    'version': VERSION,
    'based_on': 'SGGF1.666',
    'previous_release_preserved': True,
    'repository': 'magiccozmo/QuackSink',
    'source_folder': 'ARCHIVES 8-30-2026/SGG/sggweb',
    'scope': 'Backward-compatible save migration: insert only the missing hellgs_note object and its item metadata when loading F1.6 saves into F1.666a. Preserve every field and existing object in the saved game. No new exits, areas, connections, or gameplay escape route are introduced.',
    'migration': {
        'load_path': 'F1666StateMachine._read_save -> inherited C131StateMachine._read_save -> C12StateMachine._read_save -> C131GameModel.from_snapshot -> C13GameModel.from_snapshot -> C12GameModel.from_snapshot',
        'missing_object': 'hellgs_note',
        'injected_only_when_absent': True,
        'item_metadata_added_only_when_absent': True,
        'preserved': ['saved area id', 'player x/y', 'player size', 'inventory', 'existing object records',
                      'existing item metadata', 'quest flags', 'day', 'elapsed time', 'NPC state', 'all saved fields'],
        'duplicate_prevention': 'Existing hellgs_note object and item metadata are not overwritten.',
    },
    'front_door_description': {
        'base': 'SGGF1.666 description unchanged',
        'appended_exact_text': 'woops.. now it IS possible to escape',
    },
    'preserved': [
        'F1.666 world JSON and artwork are unchanged except release id.',
        'F1.666 note wording and typo remain unchanged.',
        'F1.6 F1StateMachine, F1Interface and E33StateMachine code remains unchanged.',
        'F1.666 interface and gameplay layer remain unchanged apart from release labels.',
        'F1.666 existing archive, source ZIP and Cloudflare deployment are not overwritten.',
        'All 175 historical deployment entries remain byte-for-byte unchanged except front-door index.html, versions.html, and versions.json; five F1.666a entries are appended.',
    ],
    'tests': [
        'PASS py_compile and AST parse.',
        'PASS actual in-memory load of a synthetic F1.6 snapshot into the F1.666a world through C131GameModel.from_snapshot.',
        'PASS saved area, coordinates, inventory, all 55 existing world objects, object states, item metadata, flags, gold, day, and elapsed time preserved.',
        'PASS exactly one default hellgs_note object and its item metadata supplied when absent.',
        'PASS an already-present hellgs_note is not duplicated or reset.',
        'PASS F1.666 world/assets equality except version id.',
        'PASS the front-door description is the F1.666 description plus the exact requested phrase.',
        'PASS all historical deployment members are retained; prior F1.666 release files remain byte-for-byte identical.',
        'PASS the new browser page, APK/TAR names, runtime payloads, version catalog, and new archive paths match F1.666a.',
    ],
    'runtime_note': 'Static and direct model-level save migration tests passed. The browser game was not launched live in this environment; Cozmo should field-test F1.6 quickload from his intended old area in F1.666a.',
    'hashes': {
        'main_sha256': hashlib.sha256(code).hexdigest(),
        'assets_sha256': hashlib.sha256(assets_bytes).hexdigest(),
        'base_deploy_sha256': hashlib.sha256(BASE_DEPLOY.read_bytes()).hexdigest(),
        'deploy_sha256': hashlib.sha256(DEPLOY.read_bytes()).hexdigest(),
        'base_source_sha256': hashlib.sha256(BASE_SOURCE.read_bytes()).hexdigest(),
    },
    'bytes': {'deploy': DEPLOY.stat().st_size},
    'deployment_entries': {
        'previous_entries': len(old_names),
        'new_entries': len(additions),
        'final_entries': len(old_names) + len(additions),
        'catalog_versions': 35,
    },
}
META_PATH.write_text(json.dumps(meta, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

# Build a complete source archive with exact F1.666 base snapshots and new release files.
source_files = []
for path in sorted(WORK.iterdir()):
    if not path.is_file():
        continue
    if path.suffix.lower() in ('.zip', '.pyc') or path.name.startswith('.'):
        continue
    source_files.append((path.name, path))
for name in ('index.html', 'versions.html', 'versions.json', '_headers'):
    path = WORK / 'deploy' / name
    assert path.is_file()
    source_files.append(('deploy/' + name, path))
assert len({name for name, _ in source_files}) == len(source_files)
with zipfile.ZipFile(SOURCE, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as out:
    for arcname, path in source_files:
        out.write(path, arcname)
with zipfile.ZipFile(SOURCE, 'r') as z:
    assert z.testzip() is None
    assert z.read('main.py') == code
    assert z.read('luma_assets_e33.json') == assets_bytes
    assert z.read('F1_play.html') == page.encode('utf-8')
    assert z.read('README_SGGF1666a.txt') == README.read_bytes()
    assert z.read('F1.666a_BUILD_META.json') == META_PATH.read_bytes()
    assert z.read('F1.666_BASE_MAIN.py') == (WORK / 'F1.666_BASE_MAIN.py').read_bytes()
    assert len(z.namelist()) == len(source_files)
    assert len(z.namelist()) == len(set(z.namelist()))

print(f'PASS deploy: {len(old_names)} historical entries retained (3 front-door files updated); {len(additions)} new F1.666a entries added.')
print(f'PASS source ZIP: {len(source_files)} source/build components.')
print('DEPLOY:', DEPLOY, DEPLOY.stat().st_size, 'bytes')
print('DEPLOY SHA256:', hashlib.sha256(DEPLOY.read_bytes()).hexdigest())
print('SOURCE:', SOURCE, SOURCE.stat().st_size, 'bytes')
print('SOURCE SHA256:', hashlib.sha256(SOURCE.read_bytes()).hexdigest())
print('MAIN SHA256:', meta['hashes']['main_sha256'])
print('ASSETS SHA256:', meta['hashes']['assets_sha256'])
