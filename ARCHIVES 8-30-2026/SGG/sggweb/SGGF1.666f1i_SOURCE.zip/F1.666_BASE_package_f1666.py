"""Package SGGF1.666 directly from the F1.6 baseline and preserve deployed history."""
from pathlib import Path
import ast
import copy
import gzip
import hashlib
import io
import json
import re
import subprocess
import sys
import tarfile
import zipfile

ROOT = Path('/mnt/data')
WORK = Path(__file__).resolve().parent
BASE_DEPLOY = ROOT / 'SGGF1.6_CLOUDFLARE_DEPLOY.zip'
BASE_SOURCE = ROOT / 'SGGF1.6_SOURCE.zip'
MAIN = WORK / 'main.py'
ASSETS = WORK / 'luma_assets_e33.json'
PLAY = WORK / 'F1_play.html'
README = WORK / 'README_SGGF1666.txt'
PREVIEW = WORK / 'F1.666_HELLGS_INN_PREVIEW.png'
TEST = WORK / 'test_f1666.py'
DEPLOY = ROOT / 'SGGF1.666_CLOUDFLARE_DEPLOY.zip'
SOURCE = ROOT / 'SGGF1.666_SOURCE.zip'
META_PATH = WORK / 'F1.666_BUILD_META.json'

for path in (BASE_DEPLOY, BASE_SOURCE, MAIN, ASSETS, PLAY, README, PREVIEW, TEST):
    assert path.is_file(), f'Missing required build input: {path}'
code = MAIN.read_bytes()
assets_bytes = ASSETS.read_bytes()
assets_doc = json.loads(assets_bytes)
page = PLAY.read_text(encoding='utf-8')
assert assets_doc['version'] == 'SGGF1.666'
assert b'VERSION = "F1.666"' in code
assert all(x in page for x in ('SGGF1.666', 'sggf1666.apk', 'sggf1666.tar.gz', 'archive:"sggf1666"'))
assert "Welcome brave exploiter to version F1.666 of Spiffy's Gift." in code.decode('utf-8')

# Repeatable source and gameplay checks.
ast.parse(code.decode('utf-8'))
subprocess.run([sys.executable, '-m', 'py_compile', str(MAIN)], cwd=WORK, check=True)
subprocess.run([sys.executable, str(TEST)], cwd=WORK, check=True)

# Exact F1.6 baseline scope lock: the only world changes are release metadata,
# initial area/start point, and one new room, one paper object and two art assets.
base_assets = json.loads((WORK / 'F1.6_BASE_LUMA_ASSETS.json').read_text(encoding='utf-8'))
expected = copy.deepcopy(base_assets)
expected['version'] = assets_doc['version']
expected['notes'] = assets_doc['notes']
expected['world']['initial_area'] = assets_doc['world']['initial_area']
expected['world']['player_start'] = assets_doc['world']['player_start']
hell = next(a for a in assets_doc['world']['areas'] if a['area_id'] == 'hellgs_inn')
note = next(o for o in assets_doc['world']['objects'] if o['object_id'] == 'hellgs_note')
expected['world']['areas'].append(copy.deepcopy(hell))
expected['world']['objects'].append(copy.deepcopy(note))
for name in ('c1_bg_hellgs_inn', 'paper'):
    expected['assets'][name] = copy.deepcopy(assets_doc['assets'][name])
assert assets_doc == expected, 'F1.6 world/assets changed outside the HELLgs Inn addition and start/release metadata.'
assert hell['display_name'] == 'HELLgs Inn'
assert hell['vendors'] == [] and hell['sight_blockers'] == [] and hell['conceal_zones'] == []
assert not any('hellgs' in str(c).lower() for c in assets_doc['world']['connections'])
assert not any(o.get('object_id') == 'hellgs_cell_door' for o in assets_doc['world']['objects'])
assert any(rect == [545, 160, 190, 114] for rect in hell['solid_rects'])
assert hell['navigation']['regions'] == [[[207, 306], [1073, 306], [1073, 542], [207, 542]]]
assert note['kind'] == 'paper' and note['takeable'] and note['area_id'] == 'hellgs_inn'
assert all(assets_doc['assets'][n]['width'] > 0 for n in ('c1_bg_hellgs_inn', 'paper'))
assert all(c.get('op') in {'rect', 'line', 'polygon', 'circle', 'ellipse'}
           for n in ('c1_bg_hellgs_inn', 'paper') for c in assets_doc['assets'][n]['commands'])

# Build the exact web runtime archives from these exact F1.666 source bytes.
apkb = io.BytesIO()
with zipfile.ZipFile(apkb, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as apk:
    apk.writestr('assets/main.py', code)
    apk.writestr('assets/luma_assets_e33.json', assets_bytes)

tarb = io.BytesIO()
with gzip.GzipFile(fileobj=tarb, mode='wb', compresslevel=9, mtime=0) as gz:
    with tarfile.open(fileobj=gz, mode='w') as tf:
        for name, payload in (('assets/main.py', code), ('assets/luma_assets_e33.json', assets_bytes)):
            info = tarfile.TarInfo(name)
            info.size = len(payload)
            info.mode = 0o644
            info.mtime = 0
            tf.addfile(info, io.BytesIO(payload))

# Extend the F1.6 full deployment archive. Preserve every historical member
# byte-for-byte except versions.json, then append the five new F1.666 members.
with zipfile.ZipFile(BASE_DEPLOY, 'r') as old:
    assert old.testzip() is None
    old_names = old.namelist()
    assert len(old_names) == 170
    assert all(x in old_names for x in (
        'index.html', 'versions.html', 'versions.json', '_headers',
        'SGGF1.6/play.html', 'SGGF1.6/favicon.png',
        'SGGF1.6/sggf16.apk', 'SGGF1.6/sggf16.tar.gz', 'SGGF1.6/README_SGGF16.txt'))
    favicon = old.read('SGGF1.6/favicon.png')
    manifest = json.loads(old.read('versions.json'))
    assert len(manifest['versions']) == 33
    assert manifest['versions'][0]['version'] == 'SGGF1.6'
    assert manifest['versions'][0]['current'] is True
    for entry in manifest['versions']:
        entry['current'] = False
    manifest['versions'].insert(0, {
        'version': 'SGGF1.666',
        'title': 'SGGF1.666 — HELLgs Inn',
        'path': 'SGGF1.666/play.html',
        'description': 'Halloween locked-cell challenge. Start in HELLgs Inn, a small stone cell with a solid barred door and fire beyond it. Pick up and read Cozmo’s note. After one in-game day OR the persistent Initial End Timer in Minutes, the flames surge through and end the run. No normal exit or special escape route is added; existing F1.6 systems remain available for Cozmo’s exploit test.',
        'current': True,
    })
    manifest_bytes = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    (WORK / 'deploy' / 'versions.json').write_bytes(manifest_bytes)
    additions = [
        ('SGGF1.666/play.html', page.encode('utf-8')),
        ('SGGF1.666/favicon.png', favicon),
        ('SGGF1.666/sggf1666.apk', apkb.getvalue()),
        ('SGGF1.666/sggf1666.tar.gz', tarb.getvalue()),
        ('SGGF1.666/README_SGGF1666.txt', README.read_bytes()),
    ]
    with zipfile.ZipFile(DEPLOY, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=8) as out:
        for member in old.infolist():
            payload = manifest_bytes if member.filename == 'versions.json' else old.read(member.filename)
            out.writestr(copy.copy(member), payload)
        for name, payload in additions:
            out.writestr(name, payload)

# Validate package structure, historic byte preservation, runtime parity, and catalog.
with zipfile.ZipFile(DEPLOY, 'r') as z:
    assert z.testzip() is None
    names = z.namelist()
    assert len(names) == len(old_names) + len(additions) == 175
    assert len(set(names)) == len(names)
    with zipfile.ZipFile(BASE_DEPLOY, 'r') as old:
        for name in old_names:
            if name == 'versions.json':
                continue
            assert z.read(name) == old.read(name), f'Historic deploy member changed: {name}'
    final_manifest = json.loads(z.read('versions.json'))
    assert len(final_manifest['versions']) == 34
    assert final_manifest['versions'][0]['version'] == 'SGGF1.666'
    assert final_manifest['versions'][0]['current'] is True
    assert final_manifest['versions'][1]['version'] == 'SGGF1.6'
    assert final_manifest['versions'][1]['current'] is False
    assert sum(1 for v in final_manifest['versions'] if v.get('current')) == 1
    for v in final_manifest['versions']:
        assert re.fullmatch(r'SGG[A-Z]\d+(?:\.\d+)*', v['version'])
        assert re.fullmatch(r'SGG[A-Z]\d+(?:\.\d+)*\/(?:play|index)\.html', v['path'])
    with zipfile.ZipFile(io.BytesIO(z.read('SGGF1.666/sggf1666.apk'))) as runtime:
        assert runtime.testzip() is None
        assert runtime.namelist() == ['assets/main.py', 'assets/luma_assets_e33.json']
        assert runtime.read('assets/main.py') == code
        assert runtime.read('assets/luma_assets_e33.json') == assets_bytes
    with tarfile.open(fileobj=io.BytesIO(z.read('SGGF1.666/sggf1666.tar.gz')), mode='r:gz') as runtime:
        assert runtime.extractfile('assets/main.py').read() == code
        assert runtime.extractfile('assets/luma_assets_e33.json').read() == assets_bytes
    final_page = z.read('SGGF1.666/play.html').decode('utf-8')
    assert 'archive:"sggf1666"' in final_page
    assert 'sggf1666.apk' in final_page and 'sggf1666.tar.gz' in final_page
    for name in ('index.html', 'versions.html'):
        html = z.read(name).decode('utf-8')
        assert 'isPhoneOrTablet' in html and 'navigator.userAgentData?.mobile' in html

# Build repeatable build metadata before adding it to the source archive.
meta = {
    'version': 'SGGF1.666',
    'based_on': 'SGGF1.6',
    'repository': 'magiccozmo/QuackSink',
    'source_folder': 'ARCHIVES 8-30-2026/SGG/sggweb',
    'scope': 'Add only a new HELLgs Inn room and its initial spawn, note, real-time/in-game-day end timer, flame sequence and final Game Over presentation. No ordinary exit or special escape route. Existing F1.6 game systems remain intact for Cozmo’s exploit test.',
    'hellgs_inn': {
        'area_id': 'hellgs_inn',
        'display_name': 'HELLgs Inn',
        'initial_area': True,
        'player_start': assets_doc['world']['player_start'],
        'cell_door': 'Background art plus solid collision rectangle; no world object, interaction, or exit connection.',
        'note': 'Takeable folded paper. Read from inventory with E. Exact wording is stored in main.py.',
        'end_condition': 'one in-game day OR Initial End Timer in Minutes, whichever occurs first',
        'initial_end_timer_minutes_default': 60,
        'initial_end_timer_minutes_range': [1, 1440],
        'fire_sequence_seconds': 3.4,
        'game_over': 'Final; R does not respawn. Escape leaves the run to the main menu.',
    },
    'preserved': [
        'F1.6 state-machine and interface classes remain unchanged; F1666StateMachine and F1666Interface add a final version layer.',
        'F1.6 E33 fast-travel system and destination list are retained unchanged; no special exit route is defined.',
        'All F1.6 areas, world connections, objects, NPCs, recipes, artwork, Castle Hall walkmesh, vault, platter and settings remain unchanged byte-for-byte in JSON/code baseline checks.',
        'All previous 170 deployment entries are byte-for-byte preserved except versions.json; five SGGF1.666 runtime files are appended.',
    ],
    'tests': [
        'PASS Python AST parse and py_compile.',
        'PASS whole-document F1.6 baseline equality except version/notes, initial area/start and the HELLgs Inn area, note object and two art assets.',
        'PASS all new Luma commands use supported draw operations.',
        'PASS sealed room has solid walls and cell door, an interior walkable floor, no cell-door object, and no Hellgs connections.',
        'PASS paper object is takeable and inventory E opens the exact requested text.',
        'PASS one-day OR minute-timer due logic and persistent slider normalization bounds.',
        'PASS F1StateMachine, F1Interface and E33StateMachine source remains byte-for-byte unchanged from F1.6.',
        'PASS browser bootstrap names, archive id, APK and TAR names match F1.666.',
        'PASS APK/TAR payload equals the exact main.py and Luma JSON source bytes.',
        'PASS deployment ZIP CRC, unique paths, 34-entry version catalog, and byte-for-byte preservation of all 170 prior deployment entries except versions.json.',
    ],
    'runtime_note': 'Static and packaging checks passed. The game was not launched in a live browser during this build; Cozmo must field-test the starting room, pickup/read, timer, fire sequence, game-over state and his intended exploit.',
    'hashes': {
        'main_sha256': hashlib.sha256(code).hexdigest(),
        'assets_sha256': hashlib.sha256(assets_bytes).hexdigest(),
        'base_deploy_sha256': hashlib.sha256(BASE_DEPLOY.read_bytes()).hexdigest(),
        'deploy_sha256': hashlib.sha256(DEPLOY.read_bytes()).hexdigest(),
        'base_source_sha256': hashlib.sha256(BASE_SOURCE.read_bytes()).hexdigest(),
    },
    'bytes': {'deploy': DEPLOY.stat().st_size},
    'source_archive_digest_note': 'Not embedded because the source archive contains this metadata file; compute SHA-256 externally after packaging.',
    'deploy_entries': {
        'previous_entries_preserved': len(old_names),
        'catalog_versions': 34,
        'new_files': [name for name, _ in additions],
    },
}
META_PATH.write_text(json.dumps(meta, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

# Keep all source/build snapshots and the exact deploy index/catalog in the source ZIP.
source_files = []
for path in sorted(WORK.iterdir()):
    if not path.is_file():
        continue
    if path.suffix.lower() in ('.zip', '.pyc') or path.name.startswith('.'):
        continue
    source_files.append((path.name, path))
for name in ('index.html', 'versions.html', 'versions.json', '_headers'):
    path = WORK / 'deploy' / name
    assert path.is_file()
    source_files.append((f'deploy/{name}', path))
assert len({name for name, _ in source_files}) == len(source_files)
with zipfile.ZipFile(SOURCE, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as out:
    for arcname, path in source_files:
        out.write(path, arcname)
with zipfile.ZipFile(SOURCE, 'r') as z:
    assert z.testzip() is None
    assert z.read('main.py') == code
    assert z.read('luma_assets_e33.json') == assets_bytes
    assert z.read('F1_play.html') == page.encode('utf-8')
    assert z.read('README_SGGF1666.txt') == README.read_bytes()
    assert z.read('F1.666_BUILD_META.json') == META_PATH.read_bytes()
    assert z.read('F1.6_BASE_MAIN.py') == (WORK / 'F1.6_BASE_MAIN.py').read_bytes()
    assert len(z.namelist()) == len(source_files)
    assert len(set(z.namelist())) == len(z.namelist())

print(f'PASS deploy: {len(old_names)} previous entries preserved except versions.json; {len(additions)} F1.666 entries added.')
print(f'PASS source ZIP: {len(source_files)} source/build components.')
print('DEPLOY:', DEPLOY, DEPLOY.stat().st_size, 'bytes')
print('DEPLOY SHA256:', hashlib.sha256(DEPLOY.read_bytes()).hexdigest())
print('SOURCE:', SOURCE, SOURCE.stat().st_size, 'bytes')
print('SOURCE SHA256:', hashlib.sha256(SOURCE.read_bytes()).hexdigest())
print('MAIN SHA256:', meta['hashes']['main_sha256'])
print('ASSETS SHA256:', meta['hashes']['assets_sha256'])
