from pathlib import Path
import json, math, tarfile, zipfile
ROOT=Path(__file__).resolve().parent
VER="SGGF1.666f1e"
FOLDER=ROOT/VER
main=(FOLDER/"assets"/"main.py").read_text(encoding="utf-8")
compile(main, str(FOLDER/"assets"/"main.py"), "exec")
assert 'VERSION = "F1.666f1e"' in main
data=json.loads((FOLDER/"assets"/"luma_assets_e33.json").read_text(encoding="utf-8"))
assert data["version"]==VER
areas={a["area_id"]:a for a in data["world"]["areas"]}
regions=areas["front_gate"]["navigation"]["regions"]
assert len(regions)==2 and regions[0]==[[20,408],[500,408],[480,460],[20,460]]
assert regions[1]==[[480,442],[800,442],[896,640],[384,640]]
conns={c["connection_id"]:c for c in data["world"]["connections"]}
assert "front_gate_top_britrun_market" not in conns
assert conns["front_gate_bottom_britrun_market"]["edge"]=="bottom"
assert conns["britrun_market_bottom_front_gate"]["arrival_y"]==520
assert conns["front_gate_bottom_britrun_market"]["arrival_y"]==520
assert "front_gate_to_outside_gate" in conns and "front_gate_left_gold_district" in conns
with zipfile.ZipFile(FOLDER/("sggf1666f1e.apk")) as z: assert z.testzip() is None
with tarfile.open(FOLDER/("sggf1666f1e.tar.gz"),"r:gz") as t: assert set(t.getnames())=={"assets/main.py","assets/luma_assets_e33.json"}
print("F1.666f1e Front Gate/Market navigation and package checks passed.")
