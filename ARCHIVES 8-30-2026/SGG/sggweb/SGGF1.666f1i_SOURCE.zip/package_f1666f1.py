"""F1.666f1 packaging contract / simple runtime packager.
Run from the extracted source package.
"""
from pathlib import Path
from io import BytesIO
import tarfile, zipfile
W=Path(__file__).resolve().parent
code=(W/'main.py').read_bytes(); assets=(W/'luma_assets_e33.json').read_bytes()
bundle='sggf1666f1'
with zipfile.ZipFile(W/(bundle+'.apk'),'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
 z.writestr('assets/main.py',code); z.writestr('assets/luma_assets_e33.json',assets)
with tarfile.open(W/(bundle+'.tar.gz'),'w:gz') as t:
 for name,data in [('assets/main.py',code),('assets/luma_assets_e33.json',assets)]:
  import io; info=tarfile.TarInfo(name); info.size=len(data); info.mtime=0; t.addfile(info,io.BytesIO(data))
print('Built F1.666f1 runtime packages.')
