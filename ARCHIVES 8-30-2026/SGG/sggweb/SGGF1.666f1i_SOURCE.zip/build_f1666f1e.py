from __future__ import annotations

import copy
import hashlib
import io
import json
import math
import shutil
import tarfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BASE_NAME = "SGGF1.666f1c"
NEW_NAME = "SGGF1.666f1e"
VERSION = "F1.666f1e"
BUNDLE = "sggf1666f1e"
NEW = ROOT / NEW_NAME
OUT = Path("/mnt/data")

# Create a new, immutable release from the F1.666f1c source folder.
if NEW.exists():
    raise SystemExit(f"Refusing to overwrite existing release folder: {NEW}")
BASE = ROOT / BASE_NAME
shutil.copytree(BASE, NEW)

main_path = NEW / "assets" / "main.py"
main_text = main_path.read_text(encoding="utf-8")
old_version_line = 'VERSION = "F1.666f1c"  # Front Gate art rebuild; all other areas and gameplay retained.'
new_version_line = 'VERSION = "F1.666f1e"  # Front Gate grounded Market transition and walkmesh correction.'
if main_text.count(old_version_line) != 1:
    raise SystemExit("Expected F1.666f1c version declaration not found exactly once.")
main_text = main_text.replace(old_version_line, new_version_line, 1)
main_path.write_text(main_text, encoding="utf-8", newline="\n")

asset_path = NEW / "assets" / "luma_assets_e33.json"
world_data = json.loads(asset_path.read_text(encoding="utf-8"))
if world_data.get("version") != BASE_NAME:
    raise SystemExit(f"Unexpected source asset version: {world_data.get('version')}")

areas = {area["area_id"]: area for area in world_data["world"]["areas"]}
front_gate = areas["front_gate"]
old_front_gate_regions = front_gate.get("navigation", {}).get("regions", [])
expected_old_regions = [
    [[20, 415], [1260, 415], [1260, 621], [20, 621]],
    [[540, 44], [741, 44], [741, 560], [540, 560]],
]
if old_front_gate_regions != expected_old_regions:
    raise SystemExit("Front Gate walkmesh differs from the known F1.666f1c baseline; stopping.")

# Front Gate navigation uses foot anchors (body-centre y + 14).
# 1) paved left-side courtyard lane: keeps the Gold District exit reachable.
# 2) central stone stair: a trapezoid matching the visible steps down to the foreground.
# The previous vertical rectangle from y=44 to y=560 is deliberately removed; it
# allowed the player to climb through the gate facade and into the sky.
front_gate["navigation"]["regions"] = [
    [[20, 408], [500, 408], [480, 460], [20, 460]],
    [[480, 442], [800, 442], [896, 640], [384, 640]],
]

connections = world_data["world"]["connections"]
by_id = {connection["connection_id"]: connection for connection in connections}
market_to_gate = by_id.get("britrun_market_bottom_front_gate")
if not market_to_gate or market_to_gate.get("edge") != "bottom":
    raise SystemExit("Expected Market bottom exit to Front Gate not found.")
# Market's bottom road now lands on the lower, visible stone staircase in Front Gate.
market_to_gate["arrival_x"] = 640
market_to_gate["arrival_y"] = 520

front_gate_to_market = by_id.get("front_gate_top_britrun_market")
if not front_gate_to_market or front_gate_to_market.get("edge") != "top":
    raise SystemExit("Expected Front Gate top exit to Market not found.")
# The old exit required reaching y<=46, which put the player into the sky.
# Put the reciprocal exit at the bottom of the stone staircase instead.
front_gate_to_market.clear()
front_gate_to_market.update({
    "connection_id": "front_gate_bottom_britrun_market",
    "from_area_id": "front_gate",
    "to_area_id": "britrun_market",
    "trigger": "edge",
    "edge": "bottom",
    "arrival_x": 640,
    "arrival_y": 520,
    "label": "Return to BritRun Market",
})

world_data["version"] = NEW_NAME
asset_path.write_text(json.dumps(world_data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")

# Keep project-root working copies aligned with the new release.
shutil.copy2(main_path, ROOT / "main.py")
shutil.copy2(asset_path, ROOT / "luma_assets_e33.json")

# Update the version-specific browser page without changing its controls or styling.
play_path = NEW / "play.html"
play = play_path.read_text(encoding="utf-8")
play = play.replace("F1.666f1c", VERSION).replace("sggf1666f1c", BUNDLE)
if "F1.666f1c" in play or "sggf1666f1c" in play:
    raise SystemExit("Old release identifiers remain in new play.html")
play_path.write_text(play, encoding="utf-8", newline="\n")

# Runtime bundles consumed by the browser launch page.
code_bytes = main_path.read_bytes()
assets_bytes = asset_path.read_bytes()
with zipfile.ZipFile(NEW / f"{BUNDLE}.apk", "w", zipfile.ZIP_DEFLATED, compresslevel=8) as archive:
    archive.writestr("assets/main.py", code_bytes)
    archive.writestr("assets/luma_assets_e33.json", assets_bytes)
with tarfile.open(NEW / f"{BUNDLE}.tar.gz", "w:gz") as archive:
    for name, data in (("assets/main.py", code_bytes), ("assets/luma_assets_e33.json", assets_bytes)):
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mtime = 0
        archive.addfile(info, io.BytesIO(data))

readme = f'''SPIFFY'S GIFT — {NEW_NAME}

BASE
This release is based directly on the immutable {BASE_NAME} package. It is a
focused correction to the Front Gate / BritRun Market connection and Front Gate
walkmesh. The earlier {"SGGF1.666f1d"} archive remains untouched.

FRONT GATE WALKMESH
The old Front Gate walkmesh included a vertical rectangle running from y=44 to
y=560. It let the player walk through the gate facade and into the sky. That
rectangle has been removed. The replacement walkmesh follows the visible paved
left-side approach lane and the central stone staircase down to the foreground.
Navigation continues to use the engine's foot anchor (player body y + 14).

FRONT GATE ↔ MARKET TRANSITION
The old Front Gate → Market transition was attached to the top screen edge,
forcing the player to walk upward into the sky to activate it. The exit now sits
at the bottom of the stone staircase, where the player is on visible ground.
The reciprocal Market → Front Gate arrival was moved from y=115 (sky) to y=520
(on the staircase). Both areas keep their exit arrows, now marking the grounded
bottom-edge connection. The Front Gate → Outside Gate door and the left exit to
Gold District remain separate and unchanged.

PRESERVED
All other area artwork, objects, doors, arrows, save compatibility, HELLgs Inn,
Cozmo exploit events and Tea rewards, hint progression, dialogue, tip behaviour,
and earlier release folders are inherited unchanged from {BASE_NAME}.

RELEASE RULE
{NEW_NAME} is a separate immutable release. No existing archive version is overwritten.
'''
(NEW / f"README_{NEW_NAME}.txt").write_text(readme, encoding="utf-8", newline="\n")
(ROOT / f"README_{NEW_NAME}.txt").write_text(readme, encoding="utf-8", newline="\n")

meta = {
    "version": NEW_NAME,
    "based_on": BASE_NAME,
    "purpose": "Move the Front Gate ↔ BritRun Market edge transition onto the stone staircase and prevent walking into the sky.",
    "gameplay_changes": True,
    "gameplay_change_scope": "Front Gate walkmesh and reciprocal Front Gate / BritRun Market transition only.",
    "prior_releases_untouched": True,
    "front_gate_walkmesh": {
        "navigation_anchor": "player foot point (body-centre y + 14 px)",
        "regions": [
            [[20, 408], [500, 408], [480, 460], [20, 460]],
            [[480, 442], [800, 442], [896, 640], [384, 640]],
        ],
        "sky_rectangle_removed": [[540, 44], [741, 44], [741, 560], [540, 560]],
        "ground_path": "paved left-side approach lane plus central stone staircase",
    },
    "front_gate_market_transition": {
        "old_front_gate_exit": "top edge; required entering sky at y <= 46",
        "new_front_gate_exit": "bottom edge; stone stair landing",
        "market_to_front_gate_arrival": [640, 520],
        "front_gate_to_market_arrival": [640, 520],
        "exit_arrows_preserved": True,
    },
    "preserved": [
        "Front Gate → Outside Gate walk-in door",
        "Front Gate → Gold District left exit",
        "Market shops, stalls, objects and NPCs",
        "All other areas and their transition arrows",
        "backward-compatible save/load behaviour",
        "HELLgs Inn challenge, timer and escape",
        "Cozmo exploit events and Yorkshire Tea rewards",
        "Cozmo hint progression",
        "Ko-fi / Please Tip, Thank You behaviour",
        "all previous immutable release folders",
    ],
}
(ROOT / f"{NEW_NAME}_BUILD_META.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")

# Create a visible walkmesh preview from the actual F1.666f1c artwork recipe.
# This is a diagnostic image only; the game art is not changed.
try:
    from PIL import Image, ImageDraw
    source_image = Image.open(ROOT / "front_gate_preview_render.png").convert("RGBA")
except Exception:
    source_image = None
if source_image is not None:
    overlay = Image.new("RGBA", source_image.size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(overlay)
    draw.polygon([(20,408),(500,408),(480,460),(20,460)], fill=(30,160,255,72), outline=(60,205,255,240), width=3)
    draw.polygon([(480,442),(800,442),(896,640),(384,640)], fill=(30,160,255,92), outline=(60,205,255,255), width=4)
    draw.text((640,615), "MARKET EXIT — GROUNDED", fill=(255,242,165,255), anchor="mm", stroke_width=2, stroke_fill=(25,25,30,255))
    source_image.alpha_composite(overlay)
    source_image.convert("RGB").save(ROOT / f"{NEW_NAME}_FRONT_GATE_WALKMESH_PREVIEW.png", quality=94)

# Update the public site version index. Keep every prior entry and asset path.
versions_path = ROOT / "deploy" / "versions.json"
versions_data = json.loads(versions_path.read_text(encoding="utf-8"))
for entry in versions_data["versions"]:
    entry["current"] = False
new_entry = {
    "version": NEW_NAME,
    "title": f"{NEW_NAME} — Front Gate Grounded Transition",
    "path": f"{NEW_NAME}/play.html",
    "description": "Moves the Front Gate ↔ BritRun Market transition onto the stone staircase, replaces the sky-reaching Front Gate walkmesh with a grounded courtyard/stair path, and preserves the other exits and save compatibility.",
    "image": "https://raw.githubusercontent.com/magiccozmo/QuackSink/main/ARCHIVES%208-30-2026/SGG/sggweb/new%20path.png",
    "current": True,
}
versions_data["versions"].insert(0, new_entry)
versions_path.write_text(json.dumps(versions_data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")
if (ROOT / "deploy" / "index.html").read_bytes() != (ROOT / "deploy" / "versions.html").read_bytes():
    raise SystemExit("Base deploy index.html and versions.html differ unexpectedly.")

# Focused regression test: verify geometry, real edge direction, both arrivals,
# and that unrelated areas / connections / art data are unchanged from F1.666f1c.
base_data = json.loads((BASE / "assets" / "luma_assets_e33.json").read_text(encoding="utf-8"))
base_areas = {a["area_id"]: a for a in base_data["world"]["areas"]}
for area_id, area in areas.items():
    if area_id != "front_gate":
        assert area == base_areas[area_id], f"Unexpected area change: {area_id}"

def segment_distance(px, py, a, b):
    ax, ay = a; bx, by = b
    dx, dy = bx-ax, by-ay
    den = dx*dx + dy*dy
    t = 0.0 if den == 0 else max(0.0, min(1.0, ((px-ax)*dx+(py-ay)*dy)/den))
    return math.hypot(px-(ax+t*dx), py-(ay+t*dy))

def polygon_distance(px, py, polygon):
    def inside(x, y, poly):
        hit = False
        j = len(poly)-1
        for i in range(len(poly)):
            xi, yi = poly[i]; xj, yj = poly[j]
            if ((yi > y) != (yj > y)) and x < (xj-xi)*(y-yi)/(yj-yi)+xi:
                hit = not hit
            j = i
        return hit
    if inside(px, py, polygon):
        return 0.0
    return min(segment_distance(px,py,a,b) for a,b in zip(polygon, polygon[1:]+polygon[:1]))

def nav_error_for_body(x, body_y):
    foot = (x, body_y + 14.0)
    return min(polygon_distance(*foot, p) for p in front_gate["navigation"]["regions"])

# The player can traverse the centre of the staircase from its lower landing to
# the city-gate door approach without leaving walkable ground.
for body_y in range(600, 427, -2):
    assert nav_error_for_body(640, body_y) <= 1.0, (640, body_y, nav_error_for_body(640, body_y))
# Required arrival and exit points, plus the left Gold District marker, are grounded.
for x, body_y in ((640,520),(640,600),(640,460),(20,440)):
    assert nav_error_for_body(x, body_y) <= 1.0, (x,body_y,nav_error_for_body(x,body_y))
# Sky positions that were previously accepted by the tall vertical rectangle are rejected.
for x, body_y in ((640,115),(640,200),(640,300),(700,115)):
    assert nav_error_for_body(x, body_y) > 1.0, ("sky should be blocked",x,body_y)

new_by_id = {c["connection_id"]: c for c in world_data["world"]["connections"]}
assert "front_gate_top_britrun_market" not in new_by_id
fgm = new_by_id["front_gate_bottom_britrun_market"]
mtg = new_by_id["britrun_market_bottom_front_gate"]
assert fgm["trigger"] == mtg["trigger"] == "edge"
assert fgm["edge"] == mtg["edge"] == "bottom"
assert (fgm["arrival_x"], fgm["arrival_y"]) == (640,520)
assert (mtg["arrival_x"], mtg["arrival_y"]) == (640,520)
assert "front_gate_to_outside_gate" in new_by_id
assert "front_gate_left_gold_district" in new_by_id
# All other links stay unchanged.
base_conn = {c["connection_id"]: c for c in base_data["world"]["connections"]}
for cid, conn in new_by_id.items():
    if cid in ("front_gate_bottom_britrun_market", "britrun_market_bottom_front_gate"):
        continue
    assert conn == base_conn[cid], f"Unexpected connection change: {cid}"
assert sum(1 for c in world_data["world"]["connections"] if c["from_area_id"] == "front_gate" and c["trigger"] == "edge" and c["edge"] == "bottom") == 1
assert not any(c["from_area_id"] == "front_gate" and c["trigger"] == "edge" and c["edge"] == "top" for c in world_data["world"]["connections"])

# Runtime syntax, archive structure, and version history.
compile(main_text, str(main_path), "exec")
assert 'VERSION = "F1.666f1e"' in main_text
assert world_data["version"] == NEW_NAME
assert "F1.666f1e" in play_path.read_text(encoding="utf-8")
assert BUNDLE in play_path.read_text(encoding="utf-8")
assert "F1.666f1c" not in play_path.read_text(encoding="utf-8")
versions = json.loads(versions_path.read_text(encoding="utf-8"))
assert versions["versions"][0]["version"] == NEW_NAME
assert sum(bool(v.get("current")) for v in versions["versions"]) == 1
assert any(v["version"] == "SGGF1.666f1d" and not v.get("current") for v in versions["versions"])

# Run source test against the newly produced release folder.
test = f'''from pathlib import Path\nimport json, math, tarfile, zipfile\nROOT=Path(__file__).resolve().parent\nVER="{NEW_NAME}"\nFOLDER=ROOT/VER\nmain=(FOLDER/"assets"/"main.py").read_text(encoding="utf-8")\ncompile(main, str(FOLDER/"assets"/"main.py"), "exec")\nassert 'VERSION = "{VERSION}"' in main\ndata=json.loads((FOLDER/"assets"/"luma_assets_e33.json").read_text(encoding="utf-8"))\nassert data["version"]==VER\nareas={{a["area_id"]:a for a in data["world"]["areas"]}}\nregions=areas["front_gate"]["navigation"]["regions"]\nassert len(regions)==2 and regions[0]==[[20,408],[500,408],[480,460],[20,460]]\nassert regions[1]==[[480,442],[800,442],[896,640],[384,640]]\nconns={{c["connection_id"]:c for c in data["world"]["connections"]}}\nassert "front_gate_top_britrun_market" not in conns\nassert conns["front_gate_bottom_britrun_market"]["edge"]=="bottom"\nassert conns["britrun_market_bottom_front_gate"]["arrival_y"]==520\nassert conns["front_gate_bottom_britrun_market"]["arrival_y"]==520\nassert "front_gate_to_outside_gate" in conns and "front_gate_left_gold_district" in conns\nwith zipfile.ZipFile(FOLDER/("{BUNDLE}.apk")) as z: assert z.testzip() is None\nwith tarfile.open(FOLDER/("{BUNDLE}.tar.gz"),"r:gz") as t: assert set(t.getnames())=={{"assets/main.py","assets/luma_assets_e33.json"}}\nprint("F1.666f1e Front Gate/Market navigation and package checks passed.")\n'''
(ROOT / "test_f1666f1e.py").write_text(test, encoding="utf-8", newline="\n")

# A small helper for rebuilding only the two runtime payloads from source files.
package_script = f'''from pathlib import Path\nfrom io import BytesIO\nimport tarfile, zipfile\nW=Path(__file__).resolve().parent\ncode=(W/"main.py").read_bytes()\nassets=(W/"luma_assets_e33.json").read_bytes()\nwith zipfile.ZipFile(W/"{BUNDLE}.apk","w",zipfile.ZIP_DEFLATED,compresslevel=8) as z:\n z.writestr("assets/main.py",code); z.writestr("assets/luma_assets_e33.json",assets)\nwith tarfile.open(W/"{BUNDLE}.tar.gz","w:gz") as t:\n for name,data in (("assets/main.py",code),("assets/luma_assets_e33.json",assets)):\n  i=tarfile.TarInfo(name); i.size=len(data); i.mtime=0; t.addfile(i,BytesIO(data))\nprint("Built {NEW_NAME} runtime packages.")\n'''
(ROOT / "package_f1666f1e.py").write_text(package_script, encoding="utf-8", newline="\n")

overlay_note = f'''{NEW_NAME} CLOUDFLARE DEPLOY OVERLAY

This is an incremental overlay for the existing Spiffy's Gift Cloudflare site.
Extract these files into the existing site root. Keep every previously deployed
version folder, including SGGF1.666f1d and earlier versions. Do not replace the
site with only this ZIP. The overlay updates the site version index and adds
only SGGF1.666f1e/. Its player page is SGGF1.666f1e/play.html.
'''
(ROOT / f"DEPLOY_OVERLAY_{NEW_NAME}.txt").write_text(overlay_note, encoding="utf-8", newline="\n")

# Save the new source archive, retaining F1.666f1d and all earlier release folders.
source_zip = OUT / f"{NEW_NAME}_SOURCE.zip"
if source_zip.exists(): source_zip.unlink()
with zipfile.ZipFile(source_zip, "w", zipfile.ZIP_DEFLATED, compresslevel=8) as archive:
    for path in sorted(ROOT.rglob("*")):
        if not path.is_file():
            continue
        rel = path.relative_to(ROOT)
        if "__pycache__" in rel.parts or path.suffix == ".pyc":
            continue
        if path.name.endswith("_SOURCE.zip") or path.name.endswith("_CLOUDFLARE_DEPLOY.zip"):
            continue
        archive.write(path, rel.as_posix())

# Cloudflare ZIP is an incremental overlay: keep all older deployed version folders.
deploy_zip = OUT / f"{NEW_NAME}_CLOUDFLARE_DEPLOY.zip"
if deploy_zip.exists(): deploy_zip.unlink()
with zipfile.ZipFile(deploy_zip, "w", zipfile.ZIP_DEFLATED, compresslevel=8) as archive:
    deploy_root = ROOT / "deploy"
    for path in sorted(deploy_root.iterdir()):
        if path.is_file():
            archive.write(path, path.name)
    for path in sorted(NEW.rglob("*")):
        if path.is_file():
            archive.write(path, (Path(NEW_NAME) / path.relative_to(NEW)).as_posix())
    archive.write(ROOT / f"DEPLOY_OVERLAY_{NEW_NAME}.txt", f"DEPLOY_OVERLAY_{NEW_NAME}.txt")

# Structural checks of delivered ZIPs.
for archive_path in (source_zip, deploy_zip):
    with zipfile.ZipFile(archive_path) as archive:
        assert archive.testzip() is None
        names = set(archive.namelist())
        assert f"{NEW_NAME}/play.html" in names
        assert f"{NEW_NAME}/{BUNDLE}.tar.gz" in names
        assert f"{NEW_NAME}/assets/main.py" in names
with zipfile.ZipFile(source_zip) as archive:
    names = set(archive.namelist())
    for prior in ("SGGF1.666f1a/", "SGGF1.666f1b/", "SGGF1.666f1c/", "SGGF1.666f1d/"):
        assert any(name.startswith(prior) for name in names), f"Missing previous archive: {prior}"
    assert "test_f1666f1e.py" in names
    assert f"{NEW_NAME}/README_{NEW_NAME}.txt" in names

for archive_path in (source_zip, deploy_zip):
    digest = hashlib.sha256(archive_path.read_bytes()).hexdigest()
    print(f"{archive_path.name}\t{archive_path.stat().st_size:,} bytes\tsha256={digest}")
print("F1.666f1e source and Cloudflare overlay archives passed integrity checks.")
