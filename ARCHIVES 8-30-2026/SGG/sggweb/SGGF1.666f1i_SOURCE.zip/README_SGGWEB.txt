SPIFFY'S GIFT — SGG WEB SOURCE ARCHIVE

This archive preserves the prior versioned source and adds SGGF1.666f1c. The new release changes only the Front Gate background artwork and adds a matching Outside Gate transition arrow for the existing door trigger. The Market and Gold District edge arrows remain the existing standard exits. All other areas, save data compatibility, achievements, hints, narration, site UI, and prior archives remain unchanged.

The Cloudflare deployment archive contains the current site root, the complete version catalogue, and every game version directory. The source archive contains the current source snapshots and the deploy-root files.
