from pathlib import Path
import ast
import copy
import gzip
import hashlib
import io
import json
import subprocess
import sys
import tarfile
import zipfile

WORK = Path(__file__).resolve().parent
ROOT = Path('/mnt/data')
MAIN = WORK / 'main.py'
ASSETS = WORK / 'luma_assets_e33.json'
PLAY = WORK / 'F1_play.html'
README = WORK / 'README_SGGF1666e.txt'
TEST = WORK / 'test_f1666e.py'
PREPARE = WORK / 'prepare_f1666e.py'
BASE_DEPLOY = ROOT / 'SGGF1.666d_CLOUDFLARE_DEPLOY.zip'
BASE_SOURCE = ROOT / 'SGGF1.666d_SOURCE.zip'
DEPLOY = ROOT / 'SGGF1.666e_CLOUDFLARE_DEPLOY.zip'
SOURCE = ROOT / 'SGGF1.666e_SOURCE.zip'
META_PATH = WORK / 'F1.666e_BUILD_META.json'
VERSION = 'SGGF1.666e'
BUNDLE = 'sggf1666e'

for path in (MAIN, ASSETS, PLAY, README, TEST, PREPARE, BASE_DEPLOY, BASE_SOURCE,
             WORK / 'F1.666d_BASE_MAIN.py', WORK / 'F1.666d_BASE_LUMA_ASSETS.json',
             WORK / 'F1.666d_BASE_F1_play.html'):
    assert path.is_file(), f'Missing build input: {path}'
# Immutable archives: never overwrite an existing release.
assert not DEPLOY.exists(), f'Refusing to replace existing archive: {DEPLOY}'
assert not SOURCE.exists(), f'Refusing to replace existing archive: {SOURCE}'

code = MAIN.read_bytes()
assets_bytes = ASSETS.read_bytes()
assets_doc = json.loads(assets_bytes)
page = PLAY.read_text(encoding='utf-8')
readme_bytes = README.read_bytes()
assert assets_doc['version'] == VERSION
assert b'VERSION = "F1.666e"' in code
assert all(token in page for token in (
    'SGGF1.666e', 'sggf1666e.apk', 'sggf1666e.tar.gz',
    'archive:"sggf1666e"', 'bundle = "sggf1666e"'))
assert 'sggf1666d.apk' not in page and 'sggf1666d.tar.gz' not in page
ast.parse(code.decode('utf-8'))
subprocess.run([sys.executable, '-m', 'py_compile', str(MAIN), str(TEST)], cwd=WORK, check=True)
subprocess.run([sys.executable, str(TEST)], cwd=WORK, check=True)

# Exact world/asset preservation from D, aside from version and release notes.
with zipfile.ZipFile(BASE_SOURCE, 'r') as base_src:
    assert base_src.testzip() is None
    base_assets = json.loads(base_src.read('luma_assets_e33.json'))
    expected_assets = copy.deepcopy(base_assets)
    expected_assets['version'] = VERSION
    expected_assets['notes'] = assets_doc['notes']
    assert assets_doc == expected_assets
    base_main = base_src.read('main.py')
    assert base_main == (WORK / 'F1.666d_BASE_MAIN.py').read_bytes()

# Keep every existing deployment member byte-for-byte except the version catalogue.
with zipfile.ZipFile(BASE_DEPLOY, 'r') as old:
    assert old.testzip() is None
    old_names = old.namelist()
    assert len(old_names) == 195 and len(old_names) == len(set(old_names))
    required_old = (
        'index.html', 'versions.html', 'versions.json', '_headers',
        'SGGF1.666d/play.html', 'SGGF1.666d/favicon.png',
        'SGGF1.666d/sggf1666d.apk', 'SGGF1.666d/sggf1666d.tar.gz',
        'SGGF1.666d/README_SGGF1666d.txt',
        'SGGF1.666c/play.html', 'SGGF1.666c/README_SGGF1666c.txt',
        'SGGF1.666a/play.html', 'SGGF1.666a/README_SGGF1666a.txt',
        'SGGF1.666b/play.html', 'SGGF1.666b/README_SGGF1666b.txt',
    )
    for name in required_old:
        assert name in old_names, f'Missing historical member: {name}'

    base_manifest = json.loads(old.read('versions.json'))
    assert len(base_manifest['versions']) == 38
    a_release = next(v for v in base_manifest['versions'] if v['version'] == 'SGGF1.666a')
    b_release = next(v for v in base_manifest['versions'] if v['version'] == 'SGGF1.666b')
    c_release = next(v for v in base_manifest['versions'] if v['version'] == 'SGGF1.666c')
    d_release = next(v for v in base_manifest['versions'] if v['version'] == 'SGGF1.666d')
    a_description = a_release['description']
    assert a_description.endswith('woops.. now it IS possible to escape')
    assert c_release['description'] == a_description
    assert d_release['description'] == a_description

    # Build matching Pygbag APK and TAR.GZ runtime payloads from tested files.
    apkb = io.BytesIO()
    with zipfile.ZipFile(apkb, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as apk:
        apk.writestr('assets/main.py', code)
        apk.writestr('assets/luma_assets_e33.json', assets_bytes)

    tarb = io.BytesIO()
    with gzip.GzipFile(fileobj=tarb, mode='wb', compresslevel=9, mtime=0) as gz:
        with tarfile.open(fileobj=gz, mode='w') as tf:
            for name, payload in (
                ('assets/main.py', code),
                ('assets/luma_assets_e33.json', assets_bytes),
            ):
                info = tarfile.TarInfo(name)
                info.size = len(payload)
                info.mode = 0o644
                info.mtime = 0
                tf.addfile(info, io.BytesIO(payload))

    manifest = copy.deepcopy(base_manifest)
    for entry in manifest['versions']:
        entry['current'] = False
        # From A onward, every release that begins in the HELLgs cell must
        # display the exact A description. This edits only the current catalogue;
        # the historic release ZIPs and their contents remain immutable.
        if entry.get('version') in {
            'SGGF1.666a', 'SGGF1.666b', 'SGGF1.666c', 'SGGF1.666d'
        }:
            entry['description'] = a_description
    manifest['versions'].insert(0, {
        'version': VERSION,
        'title': 'SGGF1.666e — Fresh Exploiter Runs',
        'path': VERSION + '/play.html',
        'description': a_description,
        'current': True,
    })
    manifest_bytes = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode('utf-8')

    index_html = old.read('index.html').decode('utf-8')
    versions_html = old.read('versions.html').decode('utf-8')
    for label, html in (('index.html', index_html), ('versions.html', versions_html)):
        assert '[a-z]?' in html, f'{label} does not support alphabetic version suffixes.'
        assert 'navigator.userAgentData?.mobile' in html
    favicon = old.read('SGGF1.666d/favicon.png')
    additions = [
        (VERSION + '/play.html', page.encode('utf-8')),
        (VERSION + '/favicon.png', favicon),
        (VERSION + '/' + BUNDLE + '.apk', apkb.getvalue()),
        (VERSION + '/' + BUNDLE + '.tar.gz', tarb.getvalue()),
        (VERSION + '/README_SGGF1666e.txt', readme_bytes),
    ]

    deploy_dir = WORK / 'deploy'
    deploy_dir.mkdir(exist_ok=True)
    (deploy_dir / 'index.html').write_text(index_html, encoding='utf-8')
    (deploy_dir / 'versions.html').write_text(versions_html, encoding='utf-8')
    (deploy_dir / 'versions.json').write_bytes(manifest_bytes)
    (deploy_dir / '_headers').write_bytes(old.read('_headers'))

    with zipfile.ZipFile(DEPLOY, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=8) as out:
        for member in old.infolist():
            payload = manifest_bytes if member.filename == 'versions.json' else old.read(member.filename)
            out.writestr(copy.copy(member), payload)
        for name, payload in additions:
            assert name not in old_names, f'Historical deployment path collision: {name}'
            out.writestr(name, payload)

# Verify the complete immutable deployment extension.
with zipfile.ZipFile(DEPLOY, 'r') as built, zipfile.ZipFile(BASE_DEPLOY, 'r') as old:
    assert built.testzip() is None
    names = built.namelist()
    assert len(names) == len(old_names) + len(additions) == 200
    assert len(names) == len(set(names))
    for name in old_names:
        if name != 'versions.json':
            assert built.read(name) == old.read(name), f'Historical deployment member changed: {name}'
    final_manifest = json.loads(built.read('versions.json'))
    assert len(final_manifest['versions']) == 39
    assert final_manifest['versions'][0]['version'] == VERSION
    assert final_manifest['versions'][0]['current'] is True
    assert final_manifest['versions'][0]['description'] == a_description
    assert final_manifest['versions'][1]['version'] == 'SGGF1.666d'
    assert final_manifest['versions'][1]['current'] is False
    for cell_version in ('SGGF1.666a', 'SGGF1.666b', 'SGGF1.666c', 'SGGF1.666d', 'SGGF1.666e'):
        assert next(v for v in final_manifest['versions'] if v['version'] == cell_version)['description'] == a_description, cell_version
    assert sum(1 for v in final_manifest['versions'] if v.get('current')) == 1
    with zipfile.ZipFile(io.BytesIO(built.read(VERSION + '/' + BUNDLE + '.apk'))) as runtime:
        assert runtime.testzip() is None
        assert runtime.namelist() == ['assets/main.py', 'assets/luma_assets_e33.json']
        assert runtime.read('assets/main.py') == code
        assert runtime.read('assets/luma_assets_e33.json') == assets_bytes
    with tarfile.open(fileobj=io.BytesIO(built.read(VERSION + '/' + BUNDLE + '.tar.gz')), mode='r:gz') as runtime:
        assert runtime.extractfile('assets/main.py').read() == code
        assert runtime.extractfile('assets/luma_assets_e33.json').read() == assets_bytes

# Preserve the exact E baseline inside E's source package for future releases.
for source_name, snapshot_name in (
    ('main.py', 'F1.666e_BASE_MAIN.py'),
    ('luma_assets_e33.json', 'F1.666e_BASE_LUMA_ASSETS.json'),
    ('F1_play.html', 'F1.666e_BASE_F1_play.html'),
    ('README_SGGF1666e.txt', 'F1.666e_BASE_README.txt'),
    ('test_f1666e.py', 'F1.666e_BASE_TEST_F1666E.py'),
    ('prepare_f1666e.py', 'F1.666e_BASE_PREPARE_F1666E.py'),
):
    snapshot = WORK / snapshot_name
    assert not snapshot.exists(), f'Refusing to replace source snapshot: {snapshot_name}'
    snapshot.write_bytes((WORK / source_name).read_bytes())

meta = {
    'version': VERSION,
    'based_on': 'SGGF1.666d',
    'base_source_sha256': hashlib.sha256(BASE_SOURCE.read_bytes()).hexdigest(),
    'base_deploy_sha256': hashlib.sha256(BASE_DEPLOY.read_bytes()).hexdigest(),
    'previous_release_preserved': True,
    'repository': 'magiccozmo/QuackSink',
    'source_folder': 'ARCHIVES 8-30-2026/SGG/sggweb',
    'scope': 'Run-scoped Cozmo/Tea/death/hint ledger reset only on actual E run start; same-tab run marker for save snapshots; cross-version shared save slots remain intact.',
    'front_door_description_source': 'SGGF1.666a; copied verbatim; no save-load exploit spoilers.',
    'tea_achievements': {
        'events': ['hellgs_escape', 'bucket_theft', 'vault_clip', 'naz_guard_death', 'lout_guard_death'],
        'once_only': True,
        'first_award': 'hellgs_escape',
        'trigger': 'Only the successful in-game load initiated while the current area is HELLgs Inn and restored to an area outside HELLgs Inn.',
        'pending_rule': 'Other actual exploit discoveries are held pending until HELLgs escape, so the escape is Tea #1.',
        'display': 'Visible TEA EARNED score; no Yorkshire Tea inventory object.',
        'storage': 'In-memory per live E tab/run; not written to shared config. Top-level _f1666e_run_id marker on E-created saves preserves same-run cameo queues; older/different-run save flags are cleared on load.',
        'legacy_correction': 'All historical appearance/achievement counters are ignored at a new E run start. Only current-run gameplay triggers award Tea.',
    },
    'death_reload_hints': {
        'counter_start': 0,
        'increment': 'Only after a successful quickload made while the previous game was dead.',
        'quickload_access': 'Game Over button and existing configured quickload key.',
        'milestones': {
            '4': 'First interactive hint sequence; no Tea; Escape does not change the later hint wording.',
            '10': 'Automatic speech; on interaction says: I am willing to give you an even better hint than last time; choice leads to the Luma save compatibility line.',
            '20': 'Automatic spoiler offer; remains pending until the explicit admission-of-defeat choice is selected; then Cozmo vanishes after delivering the solution.',
        },
        'tea_awarded': False,
        'storage': 'In-memory current-run ledger; hint stages and reload counter reset at start of a new actual run.',
    },
    'save_compatibility': {
        'schema': 'spiffys-gift-save-v1',
        'policy': 'Preserve C central additive migration; saved area/coordinates/state remain authoritative and missing new definitions/defaults are merged.',
        'area_ids': 'Keep existing IDs valid; renamed/retired areas require explicit alias migration.',
    },
    'preserved': [
        'F1.666, F1.666a, F1.666b, F1.666c and F1.666d source and deployment archives are not replaced.',
        'D world geometry, objects, Luma recipes, fast travel, bucket/theft, vault clipping and NPC/guard mechanics are unchanged.',
        'No gameplay event is credited merely because E is installed or launched.',
        'F1.666a front-door description is reused exactly; no exploit spoiler is copied.',
        'All 195 previous deployment entries are byte-for-byte unchanged except versions.json; five E entries are added. The catalogue normalizes F1.666a through F1.666e cell-start descriptions to A verbatim, without modifying old release ZIPs.',
    ],
    'tests': [
        'PASS AST parse, module import and py_compile.',
        'PASS historical config/appearance counters never award Tea; every new E run starts with a blank gameplay ledger.',
        'PASS only actual HELLgs-cell-to-outside save load awards Tea #1.',
        'PASS five global once-only gameplay achievements; other actual discoveries remain pending until escape.',
        'PASS improved tenth-death interaction wording.',
        'PASS twentieth-death hint remains pending until explicit final-spoiler choice; re-queues on later HELLgs loads.',
        'PASS no inventory tea and no version-start Tea award; visible Tea score and Game Over Quickload retained.',
        'PASS C forward-compatible save migration, F1.6 fast travel, and existing exploit/NPC/world mechanics preserved.',
        'PASS F1.666a front-door description copied verbatim to E and normalized for all A-through-D cell-start catalogue entries.',
        'PASS 195 prior deployment entries unchanged except versions.json; five E assets added; APK/TAR match tested files.',
    ],
    'runtime_note': 'Static and in-memory behavior tests passed. A live browser/Pygame launch was not run; Cozmo field testing remains necessary.',
    'hashes': {
        'main_sha256': hashlib.sha256(code).hexdigest(),
        'assets_sha256': hashlib.sha256(assets_bytes).hexdigest(),
        'base_source_sha256': hashlib.sha256(BASE_SOURCE.read_bytes()).hexdigest(),
        'base_deploy_sha256': hashlib.sha256(BASE_DEPLOY.read_bytes()).hexdigest(),
        'deploy_sha256': hashlib.sha256(DEPLOY.read_bytes()).hexdigest(),
    },
    'bytes': {'source': None, 'deploy': DEPLOY.stat().st_size},
    'deployment_entries': {
        'previous_entries': len(old_names),
        'new_entries': len(additions),
        'final_entries': len(old_names) + len(additions),
        'catalog_versions': 39,
    },
}
META_PATH.write_text(json.dumps(meta, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

# Package complete source, tests, release tooling, historical snapshots and
# the generated deploy catalogue. Never include the ZIP outputs recursively.
source_files = []
for path in sorted(WORK.iterdir()):
    if not path.is_file() or path.suffix.lower() in ('.zip', '.pyc') or path.name.startswith('.'):
        continue
    source_files.append((path.name, path))
for name in ('index.html', 'versions.html', 'versions.json', '_headers'):
    path = WORK / 'deploy' / name
    assert path.is_file()
    source_files.append(('deploy/' + name, path))
assert len({name for name, _ in source_files}) == len(source_files)
with zipfile.ZipFile(SOURCE, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as out:
    for arcname, path in source_files:
        out.write(path, arcname)
with zipfile.ZipFile(SOURCE, 'r') as z:
    assert z.testzip() is None
    assert z.read('main.py') == code
    assert z.read('luma_assets_e33.json') == assets_bytes
    assert z.read('F1_play.html') == page.encode('utf-8')
    assert z.read('README_SGGF1666e.txt') == readme_bytes
    assert z.read('F1.666e_BUILD_META.json') == META_PATH.read_bytes()
    assert len(z.namelist()) == len(source_files) == len(set(z.namelist()))

# Record exact final source archive byte count and re-save metadata (the metadata
# itself is included in the source archive, so its byte-count field is omitted).
meta['bytes']['source'] = SOURCE.stat().st_size
META_PATH.write_text(json.dumps(meta, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
# Keep packaged metadata and the build-meta file in sync by rebuilding the
# source ZIP once, still as a new archive only.
with zipfile.ZipFile(SOURCE, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as out:
    for arcname, path in source_files:
        out.write(path, arcname)
with zipfile.ZipFile(SOURCE, 'r') as z:
    assert z.testzip() is None
    assert z.read('F1.666e_BUILD_META.json') == META_PATH.read_bytes()
    assert z.read('main.py') == code

print(f'PASS deployment: {len(old_names)} prior entries retained; {len(additions)} F1.666e entries added.')
print(f'PASS source ZIP: {len(source_files)} source/build/history components.')
print('DEPLOY:', DEPLOY, DEPLOY.stat().st_size, 'bytes')
print('DEPLOY SHA256:', hashlib.sha256(DEPLOY.read_bytes()).hexdigest())
print('SOURCE:', SOURCE, SOURCE.stat().st_size, 'bytes')
print('SOURCE SHA256:', hashlib.sha256(SOURCE.read_bytes()).hexdigest())
print('MAIN SHA256:', meta['hashes']['main_sha256'])
print('ASSETS SHA256:', meta['hashes']['assets_sha256'])
