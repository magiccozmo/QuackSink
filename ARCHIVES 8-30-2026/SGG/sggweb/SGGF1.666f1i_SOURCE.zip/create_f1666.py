from __future__ import annotations
import copy, json, re
from pathlib import Path

W = Path('/mnt/data/sgg_f1666')

# Preserve the exact F1.6 inputs before making the F1.666 changes.
for src, dst in [
    ('main.py', 'F1.6_BASE_MAIN.py'),
    ('luma_assets_e33.json', 'F1.6_BASE_LUMA_ASSETS.json'),
    ('F1_play.html', 'F1.6_BASE_F1_play.html'),
    ('README_SGGF16.txt', 'F1.6_BASE_README.txt'),
    ('package_f16.py', 'F1.6_BASE_package_f16.py'),
    ('test_f16.py', 'F1.6_BASE_test_f16.py'),
]:
    p = W / src
    q = W / dst
    if p.exists() and not q.exists():
        q.write_bytes(p.read_bytes())

# ------------------------------------------------------------------
# Luma JSON: add one sealed cell, one note, and two small art recipes.
# No connections are added. Existing areas, connections and objects
# are kept intact; only the initial spawn and the new room content change.
# ------------------------------------------------------------------
assets_path = W / 'luma_assets_e33.json'
doc = json.loads(assets_path.read_text(encoding='utf-8'))
assert doc.get('version') == 'SGGF1.6'
assert not any(a.get('area_id') == 'hellgs_inn' for a in doc['world']['areas'])
assert not any(o.get('object_id') == 'hellgs_note' for o in doc['world']['objects'])

doc['version'] = 'SGGF1.666'
doc['notes'] += (
    '\nSGGF1.666: added the sealed HELLgs Inn cell as the starting area, '
    'with solid stone walls and a non-interactable solid cell door, a takeable '
    'paper note, and a persistent Initial End Timer in Minutes setting. '
    'After one in-game day or the configured real-time minutes elapse, whichever '
    'comes first, fire surges through the cell door and ends the run. All prior '
    'F1.6 areas, objects, connections, art, vault behavior and fast-travel rules remain.'
)
doc['world']['initial_area'] = 'hellgs_inn'
doc['world']['player_start'] = {'x': 640, 'y': 480}

# All geometry is in the new room only. The only visible door is drawn into
# the background and represented as a solid rectangle, never as an object.
hell_area = {
    'area_id': 'hellgs_inn',
    'display_name': 'HELLgs Inn',
    'background_asset': 'c1_bg_hellgs_inn',
    'vendors': [],
    'solid_rects': [
        [142, 160, 52, 440],      # left stone wall
        [1086, 160, 52, 440],    # right stone wall
        [194, 160, 351, 114],    # rear wall, left of cell door
        [735, 160, 351, 114],    # rear wall, right of cell door
        [545, 160, 190, 114],    # SOLID, non-interactable cell door
        [142, 546, 996, 52],     # front stone wall / closed end of cell
    ],
    'sight_blockers': [],
    'conceal_zones': [],
    # E3 navigation uses the player's foot point (centre + 14 px).
    # This rectangle is only the interior floor; no door, wall top or outside
    # region is a normal walking surface.
    'navigation': {
        'regions': [[[207, 306], [1073, 306], [1073, 542], [207, 542]]]
    },
}
doc['world']['areas'].append(hell_area)

doc['world']['objects'].append({
    'object_id': 'hellgs_note',
    'name': 'A folded piece of paper',
    'kind': 'paper',
    'area_id': 'hellgs_inn',
    'x': 602,
    'y': 502,
    'width': 76,
    'height': 44,
    'takeable': True,
    'stealable': False,
    'on_shelf': False,
    'value': 0,
})

# 1280x640 hand-authored recipe. Limited to Luma's supported primitives.
cmd = []
def rect(box, color, radius=0, border=0):
    cmd.append({'op':'rect','rect':list(box),'color':list(color),'radius':radius,'border':border})
def line(points, color, width=1):
    cmd.append({'op':'line','points':[list(p) for p in points],'color':list(color),'width':width})
def poly(points, color, border=0):
    cmd.append({'op':'polygon','points':[list(p) for p in points],'color':list(color),'border':border})
def circle(center, radius, color, border=0):
    cmd.append({'op':'circle','center':list(center),'radius':radius,'color':list(color),'border':border})
def ellipse(box, color, border=0):
    cmd.append({'op':'ellipse','rect':list(box),'color':list(color),'border':border})

# Outer darkness, cut-stone rear wall and side returns.
rect((0,0,1280,640),(20,19,23))
rect((0,44,1280,234),(66,67,67))
rect((0,44,1280,17),(43,42,43))
# Masonry blocks on the back wall.
for y in range(66,260,38):
    line([(0,y),(1280,y)],(91,92,90),2)
    offset = 0 if ((y//38)%2)==0 else 38
    for x in range(-offset,1280,76):
        line([(x,y),(x,y+38)],(48,49,49),2)
# Side wall piers and lower wall.
rect((0,252,160,355),(49,51,52))
rect((1120,252,160,355),(49,51,52))
for x in (24,78,132,1148,1202,1256):
    line([(x,262),(x,604)],(86,87,85),2)
for y in range(302,600,46):
    line([(0,y),(160,y)],(78,79,77),2)
    line([(1120,y),(1280,y)],(78,79,77),2)
# Deep stone flag floor.
rect((160,262,960,304),(55,57,57))
for y in range(286,560,44):
    line([(160,y),(1120,y)],(81,83,82),2)
    offset = 0 if ((y//44)%2)==0 else 42
    for x in range(160+offset,1120,84):
        line([(x,y),(x,y+44)],(39,42,43),2)
# Lower foreground coping and joints.
rect((142,546,996,52),(47,47,48))
line([(142,547),(1138,547)],(111,108,101),3)
for x in range(160,1140,74):
    line([(x,550),(x,598)],(73,72,70),2)
# Cell alcove / deep black space beyond the barred door.
rect((512,84,256,190),(12,10,13),radius=9)
rect((529,100,222,158),(25,17,15),radius=6)
# Deep red/orange fire light behind the gate.
ellipse((550,145,180,112),(106,38,17))
ellipse((566,164,148,86),(168,57,14))
# The static fire beyond the bars.
poly([(556,258),(558,220),(574,187),(582,229),(603,165),(618,231),(634,184),(646,247),(669,170),(684,228),(704,189),(713,245),(728,213),(738,258)],(218,78,20))
poly([(573,258),(582,225),(595,206),(602,249),(619,191),(630,248),(651,203),(662,256),(681,211),(692,250),(710,218),(721,258)],(245,137,30))
poly([(592,258),(600,235),(614,221),(623,255),(639,218),(648,254),(664,224),(674,258),(693,230),(700,257)],(255,204,84))
# Arch surround, stone voussoirs and heavy iron frame.
rect((493,89,294,184),(95,92,88),border=9,radius=12)
rect((510,105,260,157),(29,27,29),border=5,radius=8)
# Arch voussoir cuts.
for i in range(9):
    x = 520 + i*27
    line([(x,104),(x+4,121)],(137,133,119),3)
for i in range(7):
    x = 500 + i*44
    line([(x,252),(x+36,252)],(130,122,106),3)
# Solid barred door, hinged on both sides and closed across the opening.
rect((535,118,210,145),(19,22,25),border=7,radius=5)
for x in (548,578,608,638,668,698,728):
    line([(x,125),(x,255)],(105,111,112),8)
    line([(x-2,125),(x-2,255)],(37,40,42),2)
for y in (137,171,206,240):
    line([(538,y),(742,y)],(125,126,121),7)
    line([(538,y+4),(742,y+4)],(38,40,42),2)
# Hinges, latch and locking plate. (Decorative only; no interactive object.)
rect((528,150,17,35),(74,73,68),border=2,radius=3)
rect((735,150,17,35),(74,73,68),border=2,radius=3)
rect((621,182,38,46),(63,65,66),border=3,radius=5)
rect((633,192,14,26),(30,31,33),border=2,radius=3)
circle((640,205),5,(157,147,117))
# Heavy lintel and wall-side sconces.
rect((482,75,316,22),(81,79,75),border=3,radius=4)
for x in (402,878):
    rect((x,142,18,50),(38,34,31),radius=4)
    line([(x+9,148),(x+9,184)],(157,111,56),4)
    poly([(x+2,163),(x+9,145),(x+16,163),(x+13,181),(x+5,181)],(237,125,35))
    poly([(x+6,165),(x+9,154),(x+12,165),(x+10,176)],(255,211,108))
# A narrow drain/channel before the bars; no path through it.
rect((518,267,244,9),(27,26,27))
line([(520,271),(760,271)],(114,67,42),2)
# Small scattered scorch marks beyond the threshold.
for x,y,w,h in [(555,250,16,5),(581,245,20,4),(700,247,21,5),(728,251,12,4)]:
    ellipse((x,y,w,h),(63,37,28))

hell_bg = {'width':1280,'height':640,'commands':cmd}
doc['assets']['c1_bg_hellgs_inn'] = hell_bg

# The note is a true takeable inventory object, with a simple folded-paper recipe.
paper_cmd = [
    {'op':'polygon','points':[[3,3],[66,1],[75,8],[73,40],[8,43],[2,36]],'color':[219,210,181]},
    {'op':'polygon','points':[[66,1],[66,10],[75,8]],'color':[245,237,210]},
    {'op':'line','points':[[9,14],[62,12]],'color':[112,100,81],'width':2},
    {'op':'line','points':[[9,22],[60,20]],'color':[122,108,88],'width':2},
    {'op':'line','points':[[9,30],[54,28]],'color':[122,108,88],'width':2},
    {'op':'line','points':[[9,37],[39,36]],'color':[122,108,88],'width':2},
    {'op':'line','points':[[3,3],[66,1],[75,8],[73,40]],'color':[250,242,218],'width':1},
]
doc['assets']['paper'] = {'width':78,'height':46,'commands':paper_cmd}

# Preserve JSON readability and deterministic key/array order.
assets_path.write_text(json.dumps(doc, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

# ------------------------------------------------------------------
# Python runtime: only config normalization and appended F1.666 layer.
# ------------------------------------------------------------------
main_path = W / 'main.py'
s = main_path.read_text(encoding='utf-8')
assert 'VERSION = "F1.6"' in s
assert 'async def main()' in s
s = s.replace('VERSION = "F1.6"  # Castle Hall floor-aligned walkmesh; F1.5 vault behavior retained.',
              'VERSION = "F1.666"  # HELLgs Inn Halloween locked-cell challenge; F1.6 world retained.')
s = s.replace('    "special_hard_hitbox": 3.0,\n',
              '    "special_hard_hitbox": 3.0,\n    "initial_end_timer_minutes": 60,\n', 1)
needle = '    result["special_hard_hitbox"] = round(min(5.0, max(1.0, special_hitbox)), 1)\n'
assert needle in s
s = s.replace(needle, needle +
'''    try:\n        end_timer_minutes = int(result.get("initial_end_timer_minutes", 60))\n    except (TypeError, ValueError, OverflowError):\n        end_timer_minutes = 60\n    result["initial_end_timer_minutes"] = min(1440, max(1, end_timer_minutes))\n''', 1)

# Add the new release layer after F1Interface and before main().
marker = '\n\n\nasync def main():\n'
assert marker in s
addition = r'''

# ===========================================================================
# SGGF1.666 — HELLgs Inn: sealed-cell Halloween challenge.
# This layer deliberately adds no exit, door object, transition, or special
# escape route. Existing F1.6 game systems (including their fast-travel and
# collision behavior) are otherwise left available for the player's own test.
# ===========================================================================

F1666_SLIDER_TRACKS = (
    (445, 157, 390, 15),
    (445, 218, 390, 15),
    (445, 279, 390, 15),
    (445, 340, 390, 15),
    (445, 401, 390, 15),
    (445, 462, 390, 15),
)
F1666_SLIDER_RANGES = (
    (1.0, 4.0), (5.0, 90.0), (1.0, 5.0),
    (1.0, 10.0), (1.0, 5.0), (1.0, 1440.0),
)
F1666_NOTE_TEXT = (
    "Welcome brave exploiter to version F1.666 of Spiffy's Gift.\n\n"
    "I look forwarding to meeting you.\n\n"
    "Signed Cozmo"
)


class F1666StateMachine(F1StateMachine):
    """F1.6 plus the deliberately sealed HELLgs Inn room and its timer."""

    HELLGS_FIRE_DURATION = 3.4

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.initial_end_timer_minutes = int(self.config.get('initial_end_timer_minutes', 60))
        self.hellgs_fire_active = False
        self.hellgs_fire_seconds = 0.0
        self._log('F1.666 CONFIG',
                  f'initial_end_timer_minutes={self.initial_end_timer_minutes}; '
                  'HELLgs Inn is the starting area; no ordinary exit or cell-door interaction.')

    def _hellgs_prepare_clock(self):
        g = self.game
        if not g:
            return
        flags = g.c1_flags
        if not flags.get('hellgs_started'):
            flags['hellgs_started'] = True
            flags['hellgs_start_day'] = int(g.c1_day)
            flags['hellgs_start_elapsed'] = float(g.c1_elapsed)
            flags['hellgs_end_triggered'] = False
            flags['hellgs_game_over'] = False
            flags['hellgs_fire_active'] = False
            flags['hellgs_fire_remaining'] = self.HELLGS_FIRE_DURATION
            self._log('HELLGS CLOCK',
                      f'started area={g.current_area_id} day={g.c1_day} elapsed={g.c1_elapsed:.2f}s '
                      f'limit={self.initial_end_timer_minutes} minutes')
        self.hellgs_fire_active = bool(flags.get('hellgs_fire_active', False))
        self.hellgs_fire_seconds = float(flags.get('hellgs_fire_remaining', self.HELLGS_FIRE_DURATION))

    def _hellgs_due(self, g):
        flags = g.c1_flags
        start_day = int(flags.get('hellgs_start_day', g.c1_day))
        start_elapsed = float(flags.get('hellgs_start_elapsed', g.c1_elapsed))
        day_due = int(g.c1_day) >= start_day + 1
        timer_due = (float(g.c1_elapsed) - start_elapsed) >= self.initial_end_timer_minutes * 60.0
        return day_due or timer_due, day_due, timer_due

    def _hellgs_set_end_timer(self, value):
        try:
            value = int(round(float(value)))
        except (TypeError, ValueError, OverflowError):
            value = self.initial_end_timer_minutes
        value = max(1, min(1440, value))
        if value == self.initial_end_timer_minutes:
            return
        error = self.persist_preference('initial_end_timer_minutes', value)
        if error:
            self._log('GAME CONFIG ERROR', f'Initial End Timer in Minutes: {error}')
            return
        self.initial_end_timer_minutes = value
        self._log('GAME CONFIG',
                  f'initial_end_timer_minutes={value}; end condition is one in-game day OR {value} real-time minutes')

    def _d1_adjust_slider(self, slot, value):
        if slot == 5:
            self._hellgs_set_end_timer(value)
            return
        return super()._d1_adjust_slider(slot, value)

    def _d1_slider_pointer(self, pos, ui):
        point = ui.screen_to_game(pos)
        if point is None:
            return
        g = self.game
        slot = max(0, min(5, int(g.c13_slider_selected)))
        x, y, w, h = F1666_SLIDER_TRACKS[slot]
        lo, hi = F1666_SLIDER_RANGES[slot]
        ratio = max(0.0, min(1.0, (point[0] - x) / w))
        value = lo + ratio * (hi - lo)
        if slot in (1, 5):
            value = round(value)
        else:
            value = round(value, 1)
        self._d1_adjust_slider(slot, value)

    def _dispatch_game(self, event, ui):
        # Preserve the existing comment overlay's ownership of its controls.
        if getattr(self, 'e57_comment_open', False):
            return super()._dispatch_game(event, ui)
        g = self.game
        if g is None:
            return super()._dispatch_game(event, ui)

        # The end is final. Escape returns to the tool; R cannot respawn the player.
        if g.c1_flags.get('hellgs_game_over'):
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                self.transition(AppState.MAIN, 'Left after HELLgs Inn game over')
                self._set_status('HELLgs Inn run ended. GAME OVER.')
            return

        # During the brief flame surge, movement and item interaction are locked.
        if self.hellgs_fire_active:
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                self.transition(AppState.MAIN, 'Left during HELLgs Inn fire sequence')
            return

        # Six-slider F1.666 settings panel. Slots 0–4 retain the F1.6 settings;
        # the sixth is the new Initial End Timer in Minutes control.
        if g.c13_game_config_open:
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if ui.d11_tip_button().collidepoint(event.pos):
                    self._d11_open_tip(); return
                if ui.e41_export_button().collidepoint(event.pos):
                    self.e41_export(); return
                if ui.e57_comment_button().collidepoint(event.pos):
                    self._e57_open_comment(ui); return
                if ui.layout.menu_button.collidepoint(event.pos):
                    self._d1_menu(); return
                point = ui.screen_to_game(event.pos)
                if point is not None and pygame.Rect(E41_FOLDER_RECT).collidepoint(point):
                    self.e41_choose_folder(); return
                if point is not None and pygame.Rect(C13_GAME_CLOSE).collidepoint(point):
                    self._d1_menu(); return
                if point is not None:
                    for i, (x, y, w, h) in enumerate(F1666_SLIDER_TRACKS):
                        if pygame.Rect(x-18, y-22, w+36, 55).collidepoint(point):
                            g.c13_slider_selected = i
                            g.c13_slider_dragging = True
                            self._d1_slider_pointer(event.pos, ui)
                            return
                return
            if event.type == pygame.MOUSEMOTION and g.c13_slider_dragging:
                self._d1_slider_pointer(event.pos, ui)
                return
            if event.type == pygame.MOUSEBUTTONUP and event.button == 1:
                g.c13_slider_dragging = False
                return
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE or c12_binding_matches(event, self.c1_keys['game_config']):
                    self._d1_menu()
                elif event.key in (pygame.K_UP, pygame.K_DOWN):
                    g.c13_slider_selected = (g.c13_slider_selected + (-1 if event.key == pygame.K_UP else 1)) % 6
                elif event.key in (pygame.K_LEFT, pygame.K_RIGHT):
                    slot = max(0, min(5, int(g.c13_slider_selected)))
                    values = (self.soup_speed_multiplier, self.soup_effect_seconds,
                              self.hidden_chest_hitbox_scale, self.bubble_duration_seconds,
                              self.special_hard_hitbox, self.initial_end_timer_minutes)
                    step = 1 if slot in (1, 5) else 0.1
                    self._d1_adjust_slider(slot, values[slot] + (step if event.key == pygame.K_RIGHT else -step))
                return
            return

        # Reading is a separate action after the paper has been picked up.
        if (event.type == pygame.KEYDOWN and c12_binding_matches(event, self.c1_keys['use'])
                and g.inventory_open and not g.c1_dialogue):
            selected = g.object_by_id(g.inventory_selected_id)
            if selected is not None and selected.kind == 'paper' and 'hellgs_note' == selected.object_id:
                g.c1_flags['hellgs_note_read'] = True
                self._log('HELLGS NOTE', 'Player opened and read the folded paper in inventory.')
                self._dialogue('A FOLDED PIECE OF PAPER', F1666_NOTE_TEXT,
                               [{'text': 'Fold the paper and put it away.', 'action': 'close'}])
                return

        return super()._dispatch_game(event, ui)

    def start_game(self):
        super().start_game()
        self._hellgs_prepare_clock()
        self._set_status('SGGF1.666: HELLgs Inn. Find the paper. The cell is sealed; time is not on your side.')

    def _read_save(self, slot):
        super()._read_save(slot)
        self._hellgs_prepare_clock()

    def update(self, elapsed_seconds, ui):
        g = self.game
        if not g or self.state is not AppState.PLAY_GAME:
            return super().update(elapsed_seconds, ui)

        dt = max(0.0, min(0.1, float(elapsed_seconds)))
        if self.hellgs_fire_active:
            # Freeze the player while the flames visibly surge through the gate.
            super().update(0.0, ui)
            self.hellgs_fire_seconds = max(0.0, self.hellgs_fire_seconds - dt)
            g.c1_flags['hellgs_fire_remaining'] = self.hellgs_fire_seconds
            if self.hellgs_fire_seconds <= 0.0 and not g.c1_flags.get('hellgs_game_over'):
                g.c1_flags['hellgs_fire_active'] = False
                g.c1_flags['hellgs_game_over'] = True
                g.c1_dead = 'The fire poured through the cell door and consumed you.'
                g.c1_launch_seconds = 0.0
                self.hellgs_fire_active = False
                self._speech('The flames consume you. GAME OVER.', 8)
                self._log('HELLGS GAME OVER',
                          f'fire reached player in {g.current_area_id}; day={g.c1_day}; '
                          f'elapsed={g.c1_elapsed:.2f}s; configured_minutes={self.initial_end_timer_minutes}')
            return

        result = super().update(elapsed_seconds, ui)
        g = self.game
        if (g is None or self.state is not AppState.PLAY_GAME
                or g.current_area_id != 'hellgs_inn' or g.c1_dead
                or g.c1_flags.get('hellgs_end_triggered')
                or g.c1_flags.get('hellgs_game_over')):
            return result
        due, day_due, timer_due = self._hellgs_due(g)
        if due:
            g.c1_flags['hellgs_end_triggered'] = True
            g.c1_flags['hellgs_fire_active'] = True
            g.c1_flags['hellgs_fire_remaining'] = self.HELLGS_FIRE_DURATION
            self.hellgs_fire_active = True
            self.hellgs_fire_seconds = self.HELLGS_FIRE_DURATION
            source = 'one in-game day' if day_due else 'Initial End Timer in Minutes'
            if day_due and timer_due:
                source = 'one in-game day and the configured minute timer'
            self._speech('A terrible roar rises beyond the cell door. The fire is coming through!', 4)
            self._log('HELLGS FIRE',
                      f'trigger={source}; day={g.c1_day}; '
                      f'elapsed={g.c1_elapsed:.2f}s; timer={self.initial_end_timer_minutes} minutes')
        return result


class F1666Interface(F1Interface):
    """F1.666 interface: six settings sliders plus the HELLgs fire/game-over presentation."""

    def _draw_c13_game_config(self, surface, g):
        shade = pygame.Surface((GAME_WIDTH, GAME_HEIGHT), pygame.SRCALPHA)
        shade.fill((0, 0, 0, 153))
        surface.blit(shade, (0, 0))
        panel = pygame.Rect(305, 52, 670, 558)
        pygame.draw.rect(surface, (25, 24, 33), panel, border_radius=13)
        pygame.draw.rect(surface, (231, 181, 117), panel, 3, border_radius=13)
        self._c1_text(surface, 'GAME CONFIGURATION', 345, 71, (255, 226, 166), self.game_font, 490)
        close = pygame.Rect(C13_GAME_CLOSE)
        pygame.draw.rect(surface, (100, 58, 58), close, border_radius=6)
        self._c1_text(surface, 'CLOSE', close.x+6, close.y+11, (255, 232, 213), self.game_small_font, 54)

        values = (self.machine.soup_speed_multiplier, self.machine.soup_effect_seconds,
                  self.machine.hidden_chest_hitbox_scale, self.machine.bubble_duration_seconds,
                  self.machine.special_hard_hitbox, self.machine.initial_end_timer_minutes)
        labels = ('Soup speed multiplier', 'Soup effect duration',
                  'Hidden chest hitbox size ONLY', 'Speech bubble duration',
                  'Special Hard Hitbox — platter / vault seam',
                  'Initial End Timer in Minutes')
        displays = (f'{values[0]:.1f}x normal speed', f'{values[1]} seconds',
                    f'{values[2]:.2f}x chest width and height', f'{values[3]:.1f} seconds',
                    f'{values[4]:.1f} / 5.0  (higher = smaller, harder target)',
                    f'{values[5]} minutes  (ends at one in-game day OR this timer)')
        for i, (x, y, w, h) in enumerate(F1666_SLIDER_TRACKS):
            self._c1_text(surface, labels[i], x, y-39, (248, 228, 191), self.game_font, 390)
            self._c1_text(surface, displays[i], x, y-20, (162, 244, 183), self.game_small_font, 390)
            pygame.draw.rect(surface, (73, 67, 78), (x, y, w, h), border_radius=6)
            lo, hi = F1666_SLIDER_RANGES[i]
            ratio = max(0.0, min(1.0, (values[i]-lo)/(hi-lo)))
            pygame.draw.rect(surface, (148, 206, 132), (x, y, max(5, round(w*ratio)), h), border_radius=6)
            knob = pygame.Rect(round(x+w*ratio)-10, y-7, 20, 29)
            pygame.draw.rect(surface, (247, 213, 146), knob, border_radius=5)
            if g.c13_slider_selected == i:
                pygame.draw.rect(surface, (255, 255, 242), knob, 2, border_radius=5)

        self._c1_text(surface,
                      'The HELLgs fire arrives at whichever comes first: one full in-game day or the selected minutes.',
                      345, 502, (225, 216, 204), self.game_small_font, 600)
        pygame.draw.rect(surface, (25, 24, 33), (332, 553, 619, 66), border_radius=5)
        pygame.draw.line(surface, (120, 103, 83), (339, 552), (935, 552))
        preferred = self.machine.config.get('log_directory', '')
        pretty = 'LOG PATH: ' + preferred
        font = self.game_small_font
        while font.size(pretty)[0] > 573 and len(pretty) > 14:
            pretty = pretty[:-2] + '…'
        self._c1_text(surface, pretty, 344, 557, (220, 217, 196), font, 582)
        folder = self.machine.config.get('log_folder_name', '')
        self._c1_text(surface, 'Browser folder: ' + (folder or 'not authorized (uses Downloads)'),
                      344, 589, (176, 213, 196), font, 398)
        button = pygame.Rect(E41_FOLDER_RECT)
        pygame.draw.rect(surface, (57, 82, 76), button, border_radius=5)
        pygame.draw.rect(surface, (204, 193, 141), button, 2, border_radius=5)
        self._c1_text(surface, 'CHOOSE FOLDER', button.x+8, button.y+6,
                      (247, 235, 184), font, button.width-16)

    def _draw_header(self):
        super()._draw_header()
        if self.machine.state is AppState.PLAY_GAME:
            smaller, _ = self.e21_font_buttons()
            clear_right = max(0, smaller.x - 9)
            pygame.draw.rect(self.screen, (22, 18, 31), (0, 0, clear_right, 40))
            label = "SPIFFY'S GIFT  |  F1.666  |  " + ('BROWSER' if BROWSER else 'DESKTOP')
            self._draw_text(label, self.game_small_font, (239, 225, 195),
                            14, 12, max_width=max(0, clear_right - 24))
            self._draw_e21_font_buttons()
        # Preserve the E5.7 comment button over the repainted version strip.
        button = self.e57_comment_button()
        hovering = button.collidepoint(pygame.mouse.get_pos())
        fill = (77, 104, 88) if hovering else (57, 82, 76)
        pygame.draw.rect(self.screen, fill, button, border_radius=5)
        pygame.draw.rect(self.screen, (204, 193, 141), button, 2, border_radius=5)
        label_font = pygame.font.SysFont("consolas", 15, bold=True)
        label = label_font.render("LEAVE A COMMENT", True, (245, 238, 193))
        self.screen.blit(label, label.get_rect(center=button.center))

    def _draw_game_scene(self, surface, g):
        super()._draw_game_scene(surface, g)
        if g.current_area_id != 'hellgs_inn':
            if g.c1_flags.get('hellgs_game_over'):
                shade = pygame.Surface((GAME_WIDTH, GAME_HEIGHT), pygame.SRCALPHA)
                shade.fill((0, 0, 0, 225))
                surface.blit(shade, (0, 0))
                self._c1_text(surface, 'GAME OVER', 420, 212, (255, 92, 65), self.game_font, 440)
                self._c1_wrapped(surface, 'The fire poured through the cell door and consumed you.',
                                  360, 282, 560, (255, 224, 198))
            return

        if self.machine.hellgs_fire_active:
            progress = 1.0 - max(0.0, min(1.0,
                self.machine.hellgs_fire_seconds / self.machine.HELLGS_FIRE_DURATION))
            tick = pygame.time.get_ticks() / 1000.0
            layer = pygame.Surface((GAME_WIDTH, GAME_HEIGHT), pygame.SRCALPHA)
            # A growing orange glow comes through the barred opening.
            front_y = round(267 + progress * 285)
            pygame.draw.ellipse(layer, (255, 73, 20, 86), (520, 225, 240, max(70, front_y-218)))
            pygame.draw.polygon(layer, (215, 52, 13, 160),
                               [(536, 253), (548, 222), (568, 258), (586, 209),
                                (607, 253), (628, 215), (646, 254), (668, 208),
                                (690, 255), (712, 218), (739, 255), (front_y+12, front_y),
                                (522, front_y)])
            # Jagged tongues ripple forward; they remain decoration, not exits.
            for i in range(9):
                x = 545 + i * 22
                wobble = math.sin(tick * 8.0 + i * 1.7) * (5 + progress * 8)
                tip_y = 242 + int((i % 3) * 11 + wobble - progress * 20)
                base_y = min(front_y, 300 + int(progress * 255))
                pygame.draw.polygon(layer, (255, 125 + (i % 2) * 35, 28, 190),
                                    [(x, base_y), (x+10, tip_y), (x+23, base_y)])
                pygame.draw.polygon(layer, (255, 218, 94, 210),
                                    [(x+6, base_y), (x+11, tip_y+15), (x+18, base_y)])
            surface.blit(layer, (0, 0))
            self._c1_text(surface, 'THE FIRE IS COMING THROUGH THE CELL DOOR!',
                          305, 575, (255, 218, 151), self.game_font, 690)

        if g.c1_flags.get('hellgs_game_over'):
            shade = pygame.Surface((GAME_WIDTH, GAME_HEIGHT), pygame.SRCALPHA)
            shade.fill((0, 0, 0, 225))
            surface.blit(shade, (0, 0))
            pygame.draw.rect(surface, (65, 23, 18), (280, 177, 720, 268), border_radius=15)
            pygame.draw.rect(surface, (222, 88, 47), (280, 177, 720, 268), 3, border_radius=15)
            self._c1_text(surface, 'GAME OVER', 442, 226, (255, 92, 65), self.game_font, 420)
            self._c1_wrapped(surface, 'The fire poured through the cell door and consumed you.',
                              360, 298, 560, (255, 224, 198))
            self._c1_text(surface, 'HELLgs Inn', 554, 381, (228, 192, 150), self.game_small_font, 190)
'''
s = s.replace(marker, '\n' + addition + marker, 1)

# Point the browser entry page at its unique F1.666 bundle/local-storage key.
s = s.replace('machine = F1StateMachine(archive, config, warning)',
              'machine = F1666StateMachine(archive, config, warning)')
s = s.replace('ui = F1Interface(machine)', 'ui = F1666Interface(machine)')
main_path.write_text(s, encoding='utf-8')

# Browser bootstrap: unique bundle, APK/TAR names and archive identifier.
play = (W / 'F1_play.html').read_text(encoding='utf-8')
play = play.replace('SGGF1.6', 'SGGF1.666').replace('F1.6', 'F1.666')
play = play.replace('sggf16', 'sggf1666')
(W / 'F1_play.html').write_text(play, encoding='utf-8')

# Release notes / source documentation.
readme = """SPIFFY'S GIFT — SGGF1.666

BASE
F1.6 is the direct gameplay and world baseline. F1.6 source, JSON, and browser-entry snapshots are retained in this source package.

HELLgs Inn
The game starts in a small stone cell called HELLgs Inn. Its only visible exit is a solid barred cell door drawn into the background and backed by collision geometry. It is deliberately not a world object, is not interactable, and has no ordinary door transition. Stone walls and the closed cell door are solid. The cell floor itself is walkable.

A folded paper lies on the floor. Pick it up, open Inventory, select the paper, and press E to read:

Welcome brave exploiter to version F1.666 of Spiffy's Gift.
I look forwarding to meeting you.
Signed Cozmo

END CONDITION
The fire surges through the cell door after ONE in-game day OR when the selected real-time timer expires, whichever happens first. Initial End Timer in Minutes is a new persistent settings slider, range 1–1440 minutes, default 60 minutes. Press T to advance one in-game day. The fire animates through the gate, consumes the player, and causes a final GAME OVER; R does not respawn the player.

SCOPE / PRESERVATION
No normal exit, door object, or new area connection is defined for HELLgs Inn. Existing F1.6 game systems are retained, including the ordinary fast-travel system and its existing destination list. No special escape route or solution is added. The room is authored as specified so Cozmo can test his own system exploit. All pre-existing F1.6 areas, objects, connections, artwork, Castle Hall walkmesh, vault dialogue, platter/plate behavior, and other mechanics are retained.

TESTING
Static checks cover the JSON/Luma recipes, sealed-room collision and floor navigation, spawn, note pickup/read path, day-or-minutes deadline, persistent slider normalization, no new Hellgs connections, and F1.6 historical asset/world preservation. A live browser field test remains for the user.
"""
(W / 'README_SGGF1666.txt').write_text(readme, encoding='utf-8')

print('Created HELLgs Inn JSON/runtime/page changes.')
