from __future__ import annotations

import copy
import json
import shutil
import zipfile
import tarfile
import io
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BASE = ROOT / "SGGF1.666f1c"
NEW_NAME = "SGGF1.666f1d"
NEW = ROOT / NEW_NAME
VERSION = "F1.666f1d"
BUNDLE = "sggf1666f1d"

# The F1.666f1c folder is the authoritative base. Keep it immutable.
if NEW.exists():
    raise SystemExit(f"Refusing to overwrite existing release folder: {NEW}")
shutil.copytree(BASE, NEW)

# Keep byte-for-byte baselines for the release diff.
shutil.copy2(BASE / "assets" / "main.py", ROOT / "F1.666f1d_BASE_MAIN.py")
shutil.copy2(BASE / "assets" / "luma_assets_e33.json", ROOT / "F1.666f1d_BASE_LUMA_ASSETS.json")
shutil.copy2(BASE / "play.html", ROOT / "F1.666f1d_BASE_F1_play.html")

# --- Runtime source: version bump plus a body-centre-aligned entry threshold.
main_path = NEW / "assets" / "main.py"
main_text = main_path.read_text(encoding="utf-8")
old_version = 'VERSION = "F1.666f1c"  # Front Gate art rebuild; all other areas and gameplay retained.'
new_version = 'VERSION = "F1.666f1d"  # Castle Path upper walkmesh and aligned approach transition.'
if old_version not in main_text:
    raise SystemExit("Expected F1.666f1c VERSION line was not found; stopping safely.")
main_text = main_text.replace(old_version, new_version, 1)
old_approach = '''class E56StateMachine(E53StateMachine):
    """SGGE5.6 perspective Castle Path with a mid-approach castle transition."""
    CASTLE_APPROACH = (791.2, 371.2)
    CASTLE_FORWARD = (-0.8303, -0.5573)
    CASTLE_LATERAL = (0.5573, -0.8303)'''
new_approach = '''class E56StateMachine(E53StateMachine):
    """Perspective Castle Path with a player-aligned mid-approach transition.

    The walkmesh uses the character's foot point (body y + 14). The approach
    threshold uses the body-centre coordinate, so its y value is 14 px above
    the corresponding walkmesh centreline point.
    """
    CASTLE_APPROACH = (795.0, 360.0)  # foot anchor on the road: (795, 374)
    CASTLE_FORWARD = (-0.8303, -0.5573)
    CASTLE_LATERAL = (0.5573, -0.8303)'''
if old_approach not in main_text:
    raise SystemExit("Expected E56StateMachine approach block was not found; stopping safely.")
main_text = main_text.replace(old_approach, new_approach, 1)
main_path.write_text(main_text, encoding="utf-8", newline="\n")

# --- World data: continue the foot-point walkmesh up the full visible road.
asset_path = NEW / "assets" / "luma_assets_e33.json"
world_data = json.loads(asset_path.read_text(encoding="utf-8"))
if world_data.get("version") != "SGGF1.666f1c":
    raise SystemExit(f"Unexpected asset base version: {world_data.get('version')}")
castle_path = next(a for a in world_data["world"]["areas"] if a["area_id"] == "castle_path")
old_corridors = castle_path.get("navigation", {}).get("corridors", [])
if len(old_corridors) != 1:
    raise SystemExit("Expected exactly one existing Castle Path corridor; stopping safely.")
old_polyline, old_width = old_corridors[0]
if old_polyline[0] != [791, 371] or old_width != 104:
    raise SystemExit("Castle Path base corridor differs from the expected F1.666f1c geometry.")

# Centerline landmarks follow the cobbled roadway from beneath the castle arch,
# around the first bend, and into the already-mapped upper bend. The last point
# joins the original lower-S corridor exactly at its original first coordinate.
upper_road = [
    [640, 180],
    [640, 198],
    [641, 216],
    [644, 234],
    [650, 251],
    [659, 267],
    [671, 283],
    [686, 297],
    [704, 310],
    [724, 322],
    [746, 334],
    [767, 346],
    [785, 359],
    [791, 371],
]
full_centerline = upper_road + old_polyline[1:]
# This corridor is slightly widened from 104 to 112 world px. The engine's
# foot-anchor clearance allowance still keeps the player well inside the stone
# road and rejects nearby grass/hills.
castle_path["navigation"]["corridors"] = [[full_centerline, 112]]
world_data["version"] = NEW_NAME
asset_path.write_text(json.dumps(world_data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")

# Keep the project-root working copies aligned with the new authoritative build.
shutil.copy2(main_path, ROOT / "main.py")
shutil.copy2(asset_path, ROOT / "luma_assets_e33.json")

# --- Version-specific browser launcher.
play_path = NEW / "play.html"
play = play_path.read_text(encoding="utf-8")
play = play.replace("F1.666f1c", VERSION).replace("sggf1666f1c", BUNDLE)
if "F1.666f1c" in play or "sggf1666f1c" in play:
    raise SystemExit("Old release identifiers remain in the new play.html")
play_path.write_text(play, encoding="utf-8", newline="\n")

# --- Runtime packages: .apk (ZIP) for itch-style hosting and .tar.gz for Cloudflare.
code_bytes = main_path.read_bytes()
assets_bytes = asset_path.read_bytes()
with zipfile.ZipFile(NEW / f"{BUNDLE}.apk", "w", zipfile.ZIP_DEFLATED, compresslevel=8) as z:
    z.writestr("assets/main.py", code_bytes)
    z.writestr("assets/luma_assets_e33.json", assets_bytes)
with tarfile.open(NEW / f"{BUNDLE}.tar.gz", "w:gz") as t:
    for name, data in (("assets/main.py", code_bytes), ("assets/luma_assets_e33.json", assets_bytes)):
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mtime = 0
        t.addfile(info, io.BytesIO(data))

# --- Release notes and build record.
readme = f'''SPIFFY'S GIFT — {NEW_NAME}

BASE
This release is based directly on the immutable SGGF1.666f1c package. It is a
focused Castle Path navigation correction. Prior releases remain untouched.

CASTLE PATH WALKMESH
The walkmesh now follows the paved route continuously from the castle arch,
through the upper bend, and into the existing lower S-curve. The previous
F1.666f1c mesh began at the upper bend and left the paved stretch between the
gate and that bend unmapped. The new corridor uses foot-point coordinates and
keeps the player on the visible stone road instead of allowing movement over
the surrounding grass and hillside.

CASTLE ENTRY TRANSITION
The invisible Castle Exterior threshold is aligned with the player's position
shown in the original new-path reference. Its coordinates are body-centre
coordinates; the matching walkmesh point is 14 px lower at the character's
feet. The direction of approach and the visible transition arrow are retained.

PRESERVED
All other areas, art, doors, exit arrows, collision rules, save compatibility,
HELLgs Inn challenge, Cozmo exploit/Tea rewards, hint progression, narration,
YouTube link, and Ko-fi/tip behaviour are inherited unchanged from F1.666f1c.

RELEASE RULE
{NEW_NAME} is a separate release. {"SGGF1.666f1c"} and all earlier archives are left untouched.
'''
(NEW / f"README_{NEW_NAME}.txt").write_text(readme, encoding="utf-8", newline="\n")
(ROOT / f"README_{NEW_NAME}.txt").write_text(readme, encoding="utf-8", newline="\n")

meta = {
    "version": NEW_NAME,
    "based_on": "SGGF1.666f1c",
    "purpose": "Complete the Castle Path walkmesh from the arch to the lower S-curve and align the castle-entry threshold with the player reference position.",
    "gameplay_changes": True,
    "gameplay_change_scope": "Castle Path only: continuous ground-navigation corridor; Castle Exterior approach threshold aligned to the player's body-centre coordinate.",
    "preserved": [
        "All previous releases and archive folders",
        "All areas and area artwork other than Castle Path navigation metadata",
        "All area exit arrows and existing edge transitions",
        "Gold District and Castle Path return transition",
        "Castle Exterior and Castle Hall door transition",
        "backward-compatible save/load behavior",
        "HELLgs Inn challenge and timer",
        "Cozmo exploit events, Yorkshire Tea rewards and earned-tea ledger",
        "Cozmo death/reload hint progression",
        "fast-travel refusal",
        "in-game YouTube button",
        "front door narration and controls",
        "gallery and Ko-fi link"
    ],
    "prior_releases_untouched": True,
    "walkmesh": {
        "area_id": "castle_path",
        "foot_anchor_offset_px": 14,
        "corridor_width_world_px": 112,
        "continuous_from": [640, 180],
        "continuous_through_transition_foot_anchor": [795, 374],
        "joins_existing_lower_route_at": [791, 371]
    },
    "castle_entry": {
        "approach_body_center": [795.0, 360.0],
        "approach_foot_anchor": [795.0, 374.0],
        "forward": [-0.8303, -0.5573],
        "lateral": [0.5573, -0.8303],
        "lateral_tolerance_px": 43.0
    }
}
(ROOT / f"{NEW_NAME}_BUILD_META.json").write_text(json.dumps(meta, indent=2) + "\n", encoding="utf-8", newline="\n")

# Build helper included in the source release.
package_script = '''"""Build the F1.666f1d browser runtime archives from the current project root."""
from pathlib import Path
from io import BytesIO
import tarfile, zipfile
W=Path(__file__).resolve().parent
code=(W/"main.py").read_bytes()
assets=(W/"luma_assets_e33.json").read_bytes()
bundle="sggf1666f1d"
with zipfile.ZipFile(W/(bundle+".apk"),"w",zipfile.ZIP_DEFLATED,compresslevel=8) as z:
    z.writestr("assets/main.py",code)
    z.writestr("assets/luma_assets_e33.json",assets)
with tarfile.open(W/(bundle+".tar.gz"),"w:gz") as t:
    for name,data in (("assets/main.py",code),("assets/luma_assets_e33.json",assets)):
        info=tarfile.TarInfo(name); info.size=len(data); info.mtime=0
        t.addfile(info,BytesIO(data))
print("Built SGGF1.666f1d runtime packages.")
'''
(ROOT / "package_f1666f1d.py").write_text(package_script, encoding="utf-8", newline="\n")

# --- Site version index: promote F1.666f1d without removing legacy entries.
versions_path = ROOT / "deploy" / "versions.json"
versions_data = json.loads(versions_path.read_text(encoding="utf-8"))
for entry in versions_data["versions"]:
    entry["current"] = False
new_entry = {
    "version": NEW_NAME,
    "title": f"{NEW_NAME} — Castle Path Grounding",
    "path": f"{NEW_NAME}/play.html",
    "description": "Completes the Castle Path walkmesh from the castle arch through the upper bend, keeping Spiffy on the cobbled road; aligns the Castle Exterior transition with the player reference. Existing areas, exits and backward-compatible saves are retained.",
    "image": "https://raw.githubusercontent.com/magiccozmo/QuackSink/main/ARCHIVES%208-30-2026/SGG/sggweb/new%20path.png",
    "current": True
}
versions_data["versions"].insert(0, new_entry)
versions_path.write_text(json.dumps(versions_data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")

# The site uses identical landing/versions HTML documents; keep that invariant.
site_index = ROOT / "deploy" / "index.html"
site_versions = ROOT / "deploy" / "versions.html"
if site_index.read_bytes() != site_versions.read_bytes():
    raise SystemExit("The base index.html and versions.html were not identical.")

# --- Focused regression test for the corrected ground path and transition.
test_script = r'''from __future__ import annotations
import json, math, re, tarfile, zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
VER="SGGF1.666f1d"
FOLDER=ROOT/VER
MAIN=FOLDER/"assets"/"main.py"
ASSETS=FOLDER/"assets"/"luma_assets_e33.json"
assert MAIN.is_file() and ASSETS.is_file()
source=MAIN.read_text(encoding="utf-8")
compile(source, str(MAIN), "exec")
assert 'VERSION = "F1.666f1d"' in source
assert "CASTLE_APPROACH = (795.0, 360.0)" in source
assert "foot point (body y + 14)" in source
world=json.loads(ASSETS.read_text(encoding="utf-8"))
assert world["version"]==VER
area=next(a for a in world["world"]["areas"] if a["area_id"]=="castle_path")
corridors=area["navigation"]["corridors"]
assert len(corridors)==1
points,width=corridors[0]
assert width==112
assert points[0]==[640,180]
assert [795,374] in points
assert points[-1]==[640,640]

def segment_distance(px,py,a,b):
    ax,ay=a; bx,by=b
    dx,dy=bx-ax,by-ay
    den=dx*dx+dy*dy
    t=0.0 if den==0 else max(0.0,min(1.0,((px-ax)*dx+(py-ay)*dy)/den))
    return math.hypot(px-(ax+t*dx),py-(ay+t*dy))
def nav_error_foot(px,py):
    return min(segment_distance(px,py,a,b) for a,b in zip(points,points[1:]))
# Every point on the road centreline is a valid foot anchor. Sample each segment.
for a,b in zip(points,points[1:]):
    steps=max(1,int(math.dist(a,b)*2))
    for i in range(steps+1):
        t=i/steps
        x=a[0]+(b[0]-a[0])*t
        y=a[1]+(b[1]-a[1])*t
        assert nav_error_foot(x,y)<=0.75, (x,y,nav_error_foot(x,y))
# The player body centre sits 14px above the foot point; transition and mesh agree.
body=(795.0,360.0)
foot=(body[0],body[1]+14.0)
assert nav_error_foot(*foot)<=0.75
# The map must reject movement well off the stone road, not grant the hillside.
assert max(0.0,nav_error_foot(795.0+70.0,374.0)-width/2+9)>1.0
# A lower-to-upper crossing of the approach threshold has the expected sign.
fx,fy=(-0.8303,-0.5573)
prev=(body[0]-fx*16,body[1]-fy*16)
after=(body[0]+fx*16,body[1]+fy*16)
def progress(p): return (p[0]-body[0])*fx+(p[1]-body[1])*fy
assert progress(prev)<0<=progress(after)
play=(FOLDER/"play.html").read_text(encoding="utf-8")
assert "F1.666f1d" in play and "sggf1666f1d.tar.gz" in play
assert "sggf1666f1c" not in play
with zipfile.ZipFile(FOLDER/"sggf1666f1d.apk") as z:
    assert set(z.namelist())=={"assets/main.py","assets/luma_assets_e33.json"}
    assert z.testzip() is None
with tarfile.open(FOLDER/"sggf1666f1d.tar.gz","r:gz") as t:
    assert set(t.getnames())=={"assets/main.py","assets/luma_assets_e33.json"}
site=json.loads((ROOT/"deploy"/"versions.json").read_text(encoding="utf-8"))
assert site["versions"][0]["version"]==VER and site["versions"][0]["current"] is True
assert sum(1 for e in site["versions"] if e.get("current"))==1
assert (ROOT/"deploy"/"index.html").read_bytes()==(ROOT/"deploy"/"versions.html").read_bytes()
print("F1.666f1d checks passed: continuous Castle Path mesh, grounded threshold, runtime archives, and version index.")
'''
(ROOT / "test_f1666f1d.py").write_text(test_script, encoding="utf-8", newline="\n")

# Provide a deployment overlay note so the Cloudflare ZIP cannot be mistaken
# for a destructive replacement of the existing 44-version archive site.
overlay_note = f'''SGGF1.666f1d CLOUDFLARE DEPLOY OVERLAY

This ZIP is an incremental overlay for the existing Spiffy's Gift Cloudflare
site, not a clean replacement of the whole historical site.

Copy/extract these files into the existing Cloudflare site's web root and keep
all existing legacy version folders in place. It updates the landing/version
index and adds only the new {NEW_NAME} folder. Do not delete the existing
SGGF/SGGE version directories: the 44-entry version history still links to them.

The new browser page is {NEW_NAME}/play.html and loads {BUNDLE}.tar.gz.
'''
(ROOT / f"DEPLOY_OVERLAY_{NEW_NAME}.txt").write_text(overlay_note, encoding="utf-8", newline="\n")

print(f"Prepared {NEW_NAME} from immutable {BASE.name}.")
