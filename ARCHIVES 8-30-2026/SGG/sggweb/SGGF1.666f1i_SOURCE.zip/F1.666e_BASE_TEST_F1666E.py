from pathlib import Path
from types import MethodType, SimpleNamespace
import ast
import copy
import importlib.util
import json
import sys
import zipfile

W = Path(__file__).resolve().parent
MAIN = W / 'main.py'
ASSETS = W / 'luma_assets_e33.json'
PAGE = W / 'F1_play.html'
VERSION = 'F1.666e'
BASE_SOURCE = Path('/mnt/data/SGGF1.666d_SOURCE.zip')
BASE_DEPLOY = Path('/mnt/data/SGGF1.666d_CLOUDFLARE_DEPLOY.zip')

source = MAIN.read_text(encoding='utf-8')
base_source = (W / 'F1.666d_BASE_MAIN.py').read_text(encoding='utf-8')
asset_doc = json.loads(ASSETS.read_text(encoding='utf-8'))
base_asset_doc = json.loads((W / 'F1.666d_BASE_LUMA_ASSETS.json').read_text(encoding='utf-8'))
page = PAGE.read_text(encoding='utf-8')

ast.parse(source)
assert 'VERSION = "F1.666e"' in source
assert asset_doc['version'] == 'SGGF1.666e'
expected_assets = copy.deepcopy(base_asset_doc)
expected_assets['version'] = 'SGGF1.666e'
expected_assets['notes'] = asset_doc['notes']
assert asset_doc == expected_assets, 'E must preserve D world/assets exactly apart from version + release notes.'
assert 'sggf1666e.apk' in page and 'sggf1666e.tar.gz' in page
assert 'archive:"sggf1666e"' in page and 'bundle = "sggf1666e"' in page
assert 'sggf1666d.apk' not in page and 'sggf1666d.tar.gz' not in page
assert BASE_SOURCE.is_file() and BASE_DEPLOY.is_file()


def find_class(tree, name):
    return next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == name)


def class_dump(tree, name):
    return ast.dump(find_class(tree, name), include_attributes=False)


def class_method_dump(tree, class_name, method_name):
    cls = find_class(tree, class_name)
    method = next(n for n in cls.body
                  if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == method_name)
    return ast.dump(method, include_attributes=False)


current_tree = ast.parse(source)
base_tree = ast.parse(base_source)
# Every D game/UI class remains intact. E adds only an outer run-lifecycle layer.
for cls in (
    'StateMachine', 'E1Storage', 'E1StateMachine', 'E33StateMachine',
    'F1StateMachine', 'F1666StateMachine', 'F1666bStateMachine',
    'F1666cStateMachine', 'F1666cInterface', 'F1666dStateMachine',
    'F1666dInterface', 'C131GameModel',
):
    assert class_dump(current_tree, cls) == class_dump(base_tree, cls), f'Historical class changed: {cls}'
for cls, method in (
    ('C131GameModel', 'from_snapshot'),
    ('E1StateMachine', '_write_save'),
    ('E1StateMachine', '_read_save'),
    ('E33StateMachine', '_dispatch_game'),
    ('D11StateMachine', '_d11_update_cameo'),
    ('D11StateMachine', '_take'),
    ('F1666StateMachine', '_hellgs_due'),
    ('F1666StateMachine', '_dispatch_game'),
    ('F1666cStateMachine', '_read_save'),
    ('F1666dStateMachine', '_read_save'),
):
    assert class_method_dump(current_tree, cls, method) == class_method_dump(base_tree, cls, method), \
        f'Historical method changed: {cls}.{method}'
assert 'merge_saved_over_defaults' in source
assert "STORAGE_NAMESPACE = 'spiffys-gift-sgge1-v1:'" in source

# F1.3 and E use the same save namespace; the old tab writes the exact slots E reads.
f13 = (W / 'F1.3_BASE_MAIN.py').read_text(encoding='utf-8')
assert "STORAGE_NAMESPACE = 'spiffys-gift-sgge1-v1:'" in f13
assert "STORAGE_NAMESPACE = 'spiffys-gift-sgge1-v1:'" in source

# The previous D deployment catalogue supplies the canonical A description.
with zipfile.ZipFile(BASE_DEPLOY, 'r') as z:
    assert z.testzip() is None
    old_manifest = json.loads(z.read('versions.json'))
    a_description = next(v['description'] for v in old_manifest['versions'] if v['version'] == 'SGGF1.666a')
assert a_description.endswith('woops.. now it IS possible to escape')
assert 'load while standing' not in a_description.lower()
assert 'alternating' not in a_description.lower()

# Import without launching SDL/Pygame.
spec = importlib.util.spec_from_file_location('sgg_f1666e_main_test', MAIN)
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)
assert module.VERSION == VERSION
assert module.F1666C_EXPLOIT_ACHIEVEMENTS == {
    'bucket': 'bucket_theft',
    'naz': 'naz_guard_death',
    'vault_clip': 'vault_clip',
    'lout_guard_death': 'lout_guard_death',
    'hellgs_escape': 'hellgs_escape',
}


class FakeStorage:
    """Models shared localStorage slots visible to all SGG versions/tabs."""
    def __init__(self):
        self.data = {}
        self.deleted = []

    def get(self, kind):
        return self.data.get(kind)

    def put(self, kind, value):
        self.data[kind] = value

    def delete(self, kind):
        self.deleted.append(kind)
        self.data.pop(kind, None)

    def has(self, kind):
        return kind in self.data


def fake_game(area='hellgs_inn', *, stale_cameos=False):
    events = ['bucket', 'naz'] if stale_cameos else []
    queue = [{'event': 'vault_clip', 'at': 10, 'area': 'castle_hall'}] if stale_cameos else []
    active = ({'event': 'lout_guard_death', 'area': area, 'x': 800, 'y': 400,
               'talked': False, 'leave_at': None} if stale_cameos else None)
    return SimpleNamespace(
        current_area_id=area,
        c1_elapsed=100.0,
        c1_dead=None,
        c1_dialogue=None,
        player_x=640.0,
        player_y=480.0,
        c1_vault_entered=False,
        c1_npcs={},
        c1_flags={
            'd11_cameo_events': events,
            'd11_cameo_queue': queue,
            'd11_cameo_active': active,
            'cozmo_finale_seen': bool(stale_cameos),
        },
    )


def make_machine(config=None, area='hellgs_inn'):
    m = object.__new__(module.F1666eStateMachine)
    m.config = dict(config or {})
    m.game = fake_game(area)
    m._f1666c_run_initialized = False
    m._f1666e_run_id = None
    m._f1666e_incoming_run_id = None
    m._f1666e_loaded_legacy_save = False
    m.d11_context_ref = None
    m.logs = []
    m.statuses = []
    m.speeches = []
    m.dialogues = []
    m._log = MethodType(lambda self, a, b: self.logs.append((a, b)), m)
    m._set_status = MethodType(lambda self, value: self.statuses.append(value), m)
    m._speech = MethodType(lambda self, value, seconds=6.0: self.speeches.append(value), m)

    def dialogue(self, speaker, text, options):
        self.dialogues.append((speaker, text, options))
        self.game.c1_dialogue = {'speaker': speaker, 'text': text, 'options': options}

    m._dialogue = MethodType(dialogue, m)
    return m


# D's historical config migration is bypassed; no stale D ledger is imported.
stale_before_start = {
    'cozmo_exploiter_appearances': 7,
    'cozmo_exploit_events': ['hellgs_escape', 'bucket_theft'],
    'cozmo_pending_tea_events': ['vault_clip'],
    'cozmo_tea_earned': 4,
    'cozmo_tea_ledger_f1666d_migrated': False,
    'cozmo_death_reload_count': 17,
    'cozmo_hint_stage': 2,
}
migration_probe = make_machine(stale_before_start)
assert migration_probe._f1666d_migrate_legacy_tea_credit() is False
assert migration_probe.config == stale_before_start

# A real new run clears the entire in-memory Cozmo ledger and fresh-world
# cameo records, but leaves ALL shared save slots byte-for-byte untouched.
store = FakeStorage()
store.put('save-quick', json.dumps({'area': 'castle_hall', 'x': 930, 'y': 488}))
store.put('save-1', json.dumps({'area': 'britrun_market', 'x': 660, 'y': 470}))
save_snapshot_before = dict(store.data)
old_storage = module.E1_STORAGE
old_save_config = module.save_main_config
old_parent_start = module.F1666dStateMachine.start_game
old_parent_read = module.F1666bStateMachine._read_save
module.E1_STORAGE = store
module.save_main_config = lambda *_args, **_kwargs: (_ for _ in ()).throw(AssertionError('E ledger must not write shared config'))

try:
    def fake_parent_start(self):
        # The historical parent creates a fresh HELLgs game at runtime start.
        if self.game is None:
            self.game = fake_game('hellgs_inn', stale_cameos=True)
        self._f1666c_run_initialized = True
        return 'started'

    module.F1666dStateMachine.start_game = fake_parent_start
    fresh = make_machine(stale_before_start)
    fresh.game = None  # true new E runtime
    assert fresh.start_game() == 'started'
    for key, expected in module.F1666eStateMachine.RUN_LEDGER_DEFAULTS.items():
        assert fresh.config[key] == expected, (key, fresh.config[key], expected)
    assert fresh.game.current_area_id == 'hellgs_inn'
    assert isinstance(fresh._f1666e_run_id, str) and len(fresh._f1666e_run_id) == 32
    assert fresh.game.c1_flags['d11_cameo_events'] == []
    assert fresh.game.c1_flags['d11_cameo_queue'] == []
    assert fresh.game.c1_flags['d11_cameo_active'] is None
    assert fresh.game.c1_flags['cozmo_finale_seen'] is False
    assert store.data == save_snapshot_before, 'Starting a new run must not touch save slots.'
    assert store.deleted == []

    # Returning to MAIN and pressing Play Game again resumes the same game;
    # it is not a new actual run and does not clear run counters. Keep the Tea
    # ledger clean so the upcoming cross-version escape can earn Tea #1.
    fresh.config['cozmo_death_reload_count'] = 6
    fresh.config['cozmo_hint_stage'] = 1
    assert fresh.start_game() == 'started'
    assert fresh.config['cozmo_tea_earned'] == 0
    assert fresh.config['cozmo_exploit_events'] == []
    assert fresh.config['cozmo_death_reload_count'] == 6
    assert fresh.config['cozmo_hint_stage'] == 1

    # Simulate the old F1.3 tab writing its shared quicksave after E is already
    # running. This does not trigger E.start_game or alter its current ledger.
    store.put('save-quick', json.dumps({'area': 'britrun_market', 'x': 777, 'y': 464,
                                        'writer': 'F1.3 second tab'}))
    assert fresh.game.current_area_id == 'hellgs_inn'
    assert fresh.config['cozmo_tea_earned'] == 0
    assert fresh.config['cozmo_exploit_events'] == []

    def old_version_quickload_reader(self, slot):
        assert slot == 'quick'
        payload = json.loads(module.E1_STORAGE.get('save-' + slot))
        if payload.get('same_run_queue'):
            loaded = fake_game(payload['area'])
            loaded.c1_flags['d11_cameo_events'] = ['bucket']
            loaded.c1_flags['d11_cameo_queue'] = [
                {'event': 'bucket', 'at': 105.0, 'area': 'alchemy_shop'}
            ]
        else:
            # A legacy F1.3/D save can contain historic cameo flags and completed
            # world conditions. These must not earn Tea in the new E run.
            loaded = fake_game(payload['area'], stale_cameos=True)
            loaded.c1_vault_entered = True
            loaded.c1_npcs = {
                'naz': {'alive': False},
                'inn_lout': {'alive': False},
            }
        self.game = loaded
        self.game.player_x = float(payload.get('x', 640))
        self.game.player_y = float(payload.get('y', 480))

    module.F1666bStateMachine._read_save = old_version_quickload_reader
    fresh._read_save('quick')
    assert fresh.game.current_area_id == 'britrun_market'
    assert fresh.game.player_x == 777.0
    assert fresh.game.c1_flags['d11_cameo_active']['event'] == 'hellgs_escape'
    assert fresh.game.c1_flags['d11_cameo_events'] == []
    assert fresh.game.c1_flags['d11_cameo_queue'] == []
    assert fresh.config['cozmo_exploit_events'] == ['hellgs_escape']
    assert fresh.config['cozmo_tea_earned'] == 1
    assert fresh.config['cozmo_death_reload_count'] == 6
    assert fresh.config['cozmo_hint_stage'] == 1
    assert 'save-quick' in store.data and 'save-1' in store.data

    # A save from this exact running E tab carries a top-level run marker.
    # Its pending cameo queue survives a same-run quickload.
    store.put('save-quick', json.dumps({
        'area': 'castle_hall', 'x': 640, 'y': 490,
        '_f1666e_run_id': fresh._f1666e_run_id,
        'same_run_queue': True,
    }))
    fresh._read_save('quick')
    assert fresh.game.current_area_id == 'castle_hall'
    assert fresh.game.c1_flags['d11_cameo_events'] == ['bucket']
    assert fresh.game.c1_flags['d11_cameo_queue'][0]['event'] == 'bucket'
    assert fresh.config['cozmo_tea_earned'] == 1
    assert fresh.config['cozmo_exploit_events'] == ['hellgs_escape']

    # E writes the marker only into the top-level snapshot, not the shared
    # config or game flags; old versions drop it when they re-save.
    fresh.game.current_area = SimpleNamespace(display_name='Castle Hall')
    fresh.game.snapshot = lambda: {'schema': 'spiffys-gift-save-v1', 'state': {}}
    fresh._e1_notice = MethodType(lambda self, value: None, fresh)
    fresh._write_save('quick')
    written = json.loads(store.data['save-quick'])
    assert written['_f1666e_run_id'] == fresh._f1666e_run_id
    assert 'f1666e_run_id' not in written.get('state', {})

    # An F1.3 tab overwrites the quicksave using its older schema, so it has no
    # E marker. E clears only the stale Cozmo cameo fields and preserves Tea.
    store.put('save-quick', json.dumps({
        'area': 'castle_hall', 'x': 640, 'y': 490, 'writer': 'F1.3 second tab'
    }))
    fresh._read_save('quick')
    assert fresh.game.c1_flags['d11_cameo_events'] == []
    assert fresh.game.c1_flags['d11_cameo_queue'] == []
    assert fresh.config['cozmo_tea_earned'] == 1
    assert fresh.config['cozmo_exploit_events'] == ['hellgs_escape']

    # An old-version tab can write the shared general config too. The active E
    # instance's ledger is in memory and cannot be overwritten by that write.
    store.put('config', json.dumps({
        'cozmo_tea_earned': 0,
        'cozmo_exploit_events': [],
        'cozmo_death_reload_count': 0,
        'cozmo_hint_stage': 0,
        'writer': 'older SGG tab',
    }))
    assert fresh.config['cozmo_tea_earned'] == 1
    assert fresh.config['cozmo_exploit_events'] == ['hellgs_escape']

    # Repeating a load after the player is already outside does not award the
    # same escape twice during this run.
    store.put('save-quick', json.dumps({'area': 'castle_hall', 'x': 640, 'y': 490}))
    fresh._read_save('quick')
    assert fresh.game.current_area_id == 'castle_hall'
    assert fresh.config['cozmo_tea_earned'] == 1
    assert fresh.config['cozmo_exploit_events'] == ['hellgs_escape']

    # A genuinely new E instance/run starts from zero even if the shared config
    # contains old achievement data. Existing save slots remain available.
    next_run_config = {
        'cozmo_exploiter_appearances': 3,
        'cozmo_exploit_events': ['hellgs_escape', 'bucket_theft'],
        'cozmo_pending_tea_events': ['vault_clip'],
        'cozmo_tea_earned': 5,
        'cozmo_tea_ledger_f1666d_migrated': True,
        'cozmo_death_reload_count': 25,
        'cozmo_hint_stage': 3,
    }
    next_run = make_machine(next_run_config)
    next_run.game = None
    assert next_run.start_game() == 'started'
    assert next_run._f1666e_run_id != fresh._f1666e_run_id
    assert next_run.config['cozmo_tea_earned'] == 0
    assert next_run.config['cozmo_exploit_events'] == []
    assert next_run.config['cozmo_pending_tea_events'] == []
    assert next_run.config['cozmo_death_reload_count'] == 0
    assert next_run.config['cozmo_hint_stage'] == 0
    assert store.data['save-quick'] == json.dumps({'area': 'castle_hall', 'x': 640, 'y': 490})
    assert store.data['save-1'] == save_snapshot_before['save-1']
finally:
    module.E1_STORAGE = old_storage
    module.save_main_config = old_save_config
    module.F1666dStateMachine.start_game = old_parent_start
    module.F1666bStateMachine._read_save = old_parent_read

# Confirm D's migration bypass also happens through the inherited constructor.
# In particular, constructing E does not silently write/credit a stale ledger.
probe_config = dict(stale_before_start)
probe = module.F1666eStateMachine(module.RunArchive(), probe_config, None)
assert probe.config['cozmo_tea_earned'] == 4
assert probe.config['cozmo_exploit_events'] == ['hellgs_escape', 'bucket_theft']

# New E run start logic is the only reset call site; no automatic save-slot
# erasure, storage clear, or direct localStorage removal exists in the E layer.
e_cls = find_class(current_tree, 'F1666eStateMachine')
e_methods = {n.name: ast.get_source_segment(source, n) for n in e_cls.body if isinstance(n, ast.FunctionDef)}
assert "self.game is None" in e_methods['start_game']
assert 'self._f1666e_reset_run_ledger()' in e_methods['start_game']
assert 'save-' not in e_methods['_f1666e_reset_run_ledger'] or 'No save-* browser storage keys' in e_methods['_f1666e_reset_run_ledger']
assert 'E1_STORAGE.delete' not in source[source.index('class F1666eStateMachine'):]
assert 'save_main_config(' not in e_methods['_f1666c_save_config']
assert 'STORAGE_NAMESPACE = \'spiffys-gift-sgge1-v1:\'' in source

print('PASS F1.666e AST parse/import/compile and unchanged D class/world checks.')
print('PASS D legacy Tea migration is bypassed; old config values are ignored at E construction and reset only at a genuine new run.')
print('PASS a new run clears Tea, all five exploit recognitions, pending recognitions, death/reload and hints, plus Cozmo encounter flags.')
print('PASS same-run resume does not clear the live ledger a second time.')
print('PASS an F1.3 second-tab quicksave is visible to the still-open E tab through the unchanged shared save namespace.')
print('PASS HELLgs-to-old-save quickload creates the escape cameo and awards Tea #1 once.')
print('PASS a second quickload outside HELLgs cannot repeat the escape reward.')
print('PASS another tab config write cannot alter the active E instance ledger.')
print('PASS starting E never deletes quick or named save slots.')
