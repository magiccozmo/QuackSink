from __future__ import annotations
import json, math, re, tarfile, zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
VER="SGGF1.666f1d"
FOLDER=ROOT/VER
MAIN=FOLDER/"assets"/"main.py"
ASSETS=FOLDER/"assets"/"luma_assets_e33.json"
assert MAIN.is_file() and ASSETS.is_file()
source=MAIN.read_text(encoding="utf-8")
compile(source, str(MAIN), "exec")
assert 'VERSION = "F1.666f1d"' in source
assert "CASTLE_APPROACH = (795.0, 360.0)" in source
assert "foot point (body y + 14)" in source
world=json.loads(ASSETS.read_text(encoding="utf-8"))
assert world["version"]==VER
area=next(a for a in world["world"]["areas"] if a["area_id"]=="castle_path")
corridors=area["navigation"]["corridors"]
assert len(corridors)==1
points,width=corridors[0]
assert width==112
assert points[0]==[640,180]
assert [795,374] in points
assert points[-1]==[640,640]

def segment_distance(px,py,a,b):
    ax,ay=a; bx,by=b
    dx,dy=bx-ax,by-ay
    den=dx*dx+dy*dy
    t=0.0 if den==0 else max(0.0,min(1.0,((px-ax)*dx+(py-ay)*dy)/den))
    return math.hypot(px-(ax+t*dx),py-(ay+t*dy))
def nav_error_foot(px,py):
    return min(segment_distance(px,py,a,b) for a,b in zip(points,points[1:]))
# Every point on the road centreline is a valid foot anchor. Sample each segment.
for a,b in zip(points,points[1:]):
    steps=max(1,int(math.dist(a,b)*2))
    for i in range(steps+1):
        t=i/steps
        x=a[0]+(b[0]-a[0])*t
        y=a[1]+(b[1]-a[1])*t
        assert nav_error_foot(x,y)<=0.75, (x,y,nav_error_foot(x,y))
# The player body centre sits 14px above the foot point; transition and mesh agree.
body=(795.0,360.0)
foot=(body[0],body[1]+14.0)
assert nav_error_foot(*foot)<=0.75
# The map must reject movement well off the stone road, not grant the hillside.
assert max(0.0,nav_error_foot(795.0+70.0,374.0)-width/2+9)>1.0
# A lower-to-upper crossing of the approach threshold has the expected sign.
fx,fy=(-0.8303,-0.5573)
prev=(body[0]-fx*16,body[1]-fy*16)
after=(body[0]+fx*16,body[1]+fy*16)
def progress(p): return (p[0]-body[0])*fx+(p[1]-body[1])*fy
assert progress(prev)<0<=progress(after)
play=(FOLDER/"play.html").read_text(encoding="utf-8")
assert "F1.666f1d" in play and "sggf1666f1d.tar.gz" in play
assert "sggf1666f1c" not in play
with zipfile.ZipFile(FOLDER/"sggf1666f1d.apk") as z:
    assert set(z.namelist())=={"assets/main.py","assets/luma_assets_e33.json"}
    assert z.testzip() is None
with tarfile.open(FOLDER/"sggf1666f1d.tar.gz","r:gz") as t:
    assert set(t.getnames())=={"assets/main.py","assets/luma_assets_e33.json"}
site=json.loads((ROOT/"deploy"/"versions.json").read_text(encoding="utf-8"))
assert site["versions"][0]["version"]==VER and site["versions"][0]["current"] is True
assert sum(1 for e in site["versions"] if e.get("current"))==1
assert (ROOT/"deploy"/"index.html").read_bytes()==(ROOT/"deploy"/"versions.html").read_bytes()
print("F1.666f1d checks passed: continuous Castle Path mesh, grounded threshold, runtime archives, and version index.")
