from __future__ import annotations
import ast,json,zipfile,tarfile,io
from pathlib import Path
ROOT=Path(__file__).resolve().parent
VERSION="SGGF1.666f1i"; PACKAGE="sggf1666f1i"
current=json.loads((ROOT/"luma_assets_e33.json").read_text(encoding="utf-8"))
base=json.loads((ROOT/"SGGF1.666f1h"/"assets"/"luma_assets_e33.json").read_text(encoding="utf-8"))
assert current["version"]==VERSION
assert len(current["world"]["connections"])==len(base["world"]["connections"])
base_areas={a["area_id"]:a for a in base["world"]["areas"]}
cur_areas={a["area_id"]:a for a in current["world"]["areas"]}
assert cur_areas==base_areas
base_con={c["connection_id"]:c for c in base["world"]["connections"]}
cur_con={c["connection_id"]:c for c in current["world"]["connections"]}
for cid,c in base_con.items():
    if cid=="giant_camp_bottom_plains":
        expected=dict(c); expected["arrival_y"]=330
        assert cur_con[cid]==expected
    else: assert cur_con[cid]==c, cid
assert cur_con["plains_top_giant_camp"]==base_con["plains_top_giant_camp"]
assert cur_con["giant_camp_bottom_plains"]["arrival_x"]==640
assert cur_con["giant_camp_bottom_plains"]["arrival_y"]==330
# All world objects remain byte-for-byte equivalent as parsed JSON.
assert current["world"]["objects"]==base["world"]["objects"]
# Only the Plains background differs among the assets.
for key,value in base["assets"].items():
    if key!="c1_bg_plains": assert current["assets"][key]==value, key
# Crossroads + every other Plains backdrop command remain unchanged; the inserted
# replacement is confined to the old road block (253..287).
old=base["assets"]["c1_bg_plains"]["commands"]
new=current["assets"]["c1_bg_plains"]["commands"]
assert new[:253]==old[:253]
assert new[253+29:]==old[288:]
main=(ROOT/"main.py").read_text(encoding="utf-8"); ast.parse(main)
assert 'VERSION = "F1.666f1i"' in main
assert 'class F1666f1iInterface(F1666f1hInterface):' in main
assert 'ui = F1666f1iInterface(machine)' in main
assert 'previous_y > 300 >= game.player_y' in main
update_body=main.split('def update(self, elapsed_seconds: float, ui: "SGGInterface") -> None:',1)[1].split('def _dispatch_game',1)[0]
assert update_body.index('game = self.game') < update_body.index('previous_y = game.player_y')
assert "conn.connection_id == 'plains_top_giant_camp'" in main
v=ROOT/VERSION
assert (v/"play.html").is_file()
assert (v/"assets"/"main.py").read_bytes()==(ROOT/"main.py").read_bytes()
assert (v/"assets"/"luma_assets_e33.json").read_bytes()==(ROOT/"luma_assets_e33.json").read_bytes()
with zipfile.ZipFile(v/(PACKAGE+".apk")) as z:
    assert z.testzip() is None and set(z.namelist())=={"assets/main.py","assets/luma_assets_e33.json"}
    pkg=json.load(z.open("assets/luma_assets_e33.json")); assert pkg["version"]==VERSION
with tarfile.open(v/(PACKAGE+".tar.gz"),"r:gz") as t:
    assert set(t.getnames())=={"assets/main.py","assets/luma_assets_e33.json"}
    pkg=json.load(t.extractfile("assets/luma_assets_e33.json")); assert pkg["version"]==VERSION
manifest=json.loads((ROOT/"deploy"/"versions.json").read_text(encoding="utf-8"))["versions"]
assert len(manifest)==51 and manifest[0]["version"]==VERSION
assert sum(bool(x.get("current")) for x in manifest)==1
print("F1.666f1i regression checks PASS")
