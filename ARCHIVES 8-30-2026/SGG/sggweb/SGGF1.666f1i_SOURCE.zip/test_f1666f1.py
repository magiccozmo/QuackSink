from pathlib import Path
import ast, json, zipfile, tarfile, io, re, hashlib
W=Path(__file__).resolve().parent
MAIN=W/'main.py'; ASSETS=W/'luma_assets_e33.json'; PAGE=W/'F1_play.html'
BASE=W/'F1.666f1_BASE_MAIN.py'
source=MAIN.read_text(encoding='utf-8'); tree=ast.parse(source)
base_tree=ast.parse(BASE.read_text(encoding='utf-8'))
classes=lambda t:{n.name:n for n in t.body if isinstance(n,ast.ClassDef)}
cur=classes(tree); old=classes(base_tree)
for name,node in old.items():
 assert name in cur and ast.dump(cur[name],include_attributes=False)==ast.dump(node,include_attributes=False), name
assert 'VERSION = "F1.666f1"' in source
assert cur['F1666f1StateMachine'].bases[0].id=='F1666fStateMachine'
assert cur['F1666f1Interface'].bases[0].id=='F1666fInterface'
assert 'F1666f1StateMachine(archive, config, warning)' in source
assert 'F1666f1Interface(machine)' in source
assert 'https://www.youtube.com/watch?v=XZ2GjHXn-kA&list=PLdhINWyYlsB4' in source
assert "STORAGE_NAMESPACE = 'spiffys-gift-sgge1-v1:'" in source
assets=json.loads(ASSETS.read_text(encoding='utf-8')); assert assets['version']=='SGGF1.666f1'
page=PAGE.read_text(encoding='utf-8'); assert 'sggf1666f1.apk' in page and 'sggf1666f1.tar.gz' in page
assert 'archive:"sggf1666f1"' in page and 'bundle = "sggf1666f1"' in page
# The source archive carries its deploy-facing catalogue and front-door files.
idx=(W/'deploy'/'index.html').read_text(encoding='utf-8')
vers=(W/'deploy'/'versions.html').read_text(encoding='utf-8')
cat=json.loads((W/'deploy'/'versions.json').read_text(encoding='utf-8'))
assert idx==vers
assert 'device-blocked' not in idx and 'isPhoneOrTablet' not in idx
assert 'id="open-gallery"' in idx and 'id="gallery-dialog"' in idx
assert 'https://ko-fi.com/cozmothemagician' in idx
assert 'https://www.youtube.com/watch?v=XZ2GjHXn-kA&amp;list=PLdhINWyYlsB4' in idx
entry=cat['versions'][0]
assert entry['version']=='SGGF1.666f1' and entry['current'] is True
assert entry['image'].endswith('/hell.png')
assert sum(bool(x.get('current')) for x in cat['versions'])==1
assert len(re.findall(r'raw\.githubusercontent\.com/[^" ]+\.png',idx))==17
print('PASS portable F1.666f1 source tests')
