from __future__ import annotations
import ast
import copy
import importlib.util
import json
from pathlib import Path
import sys
from types import SimpleNamespace

W = Path(__file__).resolve().parent
MAIN = W / 'main.py'
ASSETS = W / 'luma_assets_e33.json'
PAGE = W / 'F1_play.html'
BASE_MAIN = W / 'F1.666_BASE_MAIN.py'
BASE_ASSETS = W / 'F1.666_BASE_LUMA_ASSETS.json'
BASE_PAGE = W / 'F1.666_BASE_F1_play.html'
BASE_README = W / 'F1.666_BASE_README.txt'

src = MAIN.read_text(encoding='utf-8')
ast.parse(src)
compile(src, str(MAIN), 'exec')
assert 'VERSION = "F1.666a"' in src
assert 'Welcome brave exploiter to version F1.666 of Spiffy\'s Gift.' in src
assert 'I look forwarding to meeting you.' in src
assert "'stable_carriage', 'stable_draft_horse', 'stables_foreground_fence', 'hellgs_note')" in src
assert src.count("'stable_carriage', 'stable_draft_horse', 'stables_foreground_fence', 'hellgs_note')") == 2
assert 'class F1666StateMachine(F1StateMachine)' in src
assert 'self._hellgs_prepare_clock()' in src


def class_segment(text, class_name):
    tree = ast.parse(text)
    node = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == class_name)
    return ast.get_source_segment(text, node)

base_source = BASE_MAIN.read_text(encoding='utf-8')
# The original F1.6 gameplay, fast-travel, interface and collision systems remain untouched.
for class_name in ('F1StateMachine', 'F1Interface', 'E33StateMachine', 'F1666Interface'):
    assert class_segment(src, class_name) == class_segment(base_source, class_name), class_name

# The C13 migration may differ only by admitting the new default paper object.
base_c13 = class_segment(base_source, 'C13GameModel')
new_c13 = class_segment(src, 'C13GameModel')
assert new_c13.count("'hellgs_note'") == 2
assert new_c13.replace(", 'hellgs_note'", '') == base_c13

# Only the release version identifier changes in the world data.
base_doc = json.loads(BASE_ASSETS.read_text(encoding='utf-8'))
doc = json.loads(ASSETS.read_text(encoding='utf-8'))
expected = copy.deepcopy(base_doc)
expected['version'] = 'SGGF1.666a'
assert doc == expected, 'World/art JSON must be byte-for-byte equivalent to F1.666 apart from release version.'

# In-world paper text remains exactly the same as F1.666.
assert 'F1666_NOTE_TEXT' in src
note_start = src.index('F1666_NOTE_TEXT')
note_segment = src[note_start:src.index('\n\n', note_start)]
assert "Welcome brave exploiter to version F1.666 of Spiffy's Gift." in note_segment

# Verify the actual F1.6 -> F1.666a save migration through the same classmethod
# used by the live quickload chain (C131GameModel.from_snapshot).
spec = importlib.util.spec_from_file_location('sgg_f1666a_main', MAIN)
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)
old_doc = json.loads((W / 'F1.6_BASE_LUMA_ASSETS.json').read_text(encoding='utf-8'))
old_engine = SimpleNamespace(world=old_doc['world'])
new_engine = SimpleNamespace(world=doc['world'])
old_game = module.C131GameModel(old_engine)
old_game.current_area_id = 'castle_hall'
old_game.player_x = 987.25
old_game.player_y = 322.75
old_game.c1_day = 17
old_game.c1_gold = 12345
old_game.c1_elapsed = 8765.5
old_game.c1_flags.update({'quest_done': True, 'f1666a_migration_probe': 'preserve-me'})
old_item = old_game.objects[0]
old_item.in_inventory = True
old_game.inventory = [old_item.object_id]
old_snapshot = old_game.snapshot()
old_snapshot['source_version'] = 'F1.6'
old_ids = {o['object_id'] for o in old_snapshot['objects']}
assert 'hellgs_note' not in old_ids

loaded = module.C131GameModel.from_snapshot(new_engine, copy.deepcopy(old_snapshot))
assert loaded.current_area_id == 'castle_hall'
assert (loaded.player_x, loaded.player_y) == (987.25, 322.75)
assert loaded.c1_day == 17 and loaded.c1_gold == 12345 and loaded.c1_elapsed == 8765.5
assert loaded.inventory == [old_item.object_id]
assert loaded.object_by_id(old_item.object_id).in_inventory is True
assert loaded.c1_flags['quest_done'] is True
assert loaded.c1_flags['f1666a_migration_probe'] == 'preserve-me'
assert len(loaded.objects) == len(old_snapshot['objects']) + 1
paper = loaded.object_by_id('hellgs_note')
assert paper is not None and paper.kind == 'paper' and paper.area_id == 'hellgs_inn'
assert paper.in_inventory is False and paper.moved is False
assert loaded.item_meta['hellgs_note']['object_id'] == 'hellgs_note'
for raw in old_snapshot['objects']:
    obj = loaded.object_by_id(raw['object_id'])
    assert obj is not None
    assert {k: getattr(obj, k) for k in raw} == raw, raw['object_id']
for key, value in old_snapshot['item_meta'].items():
    assert loaded.item_meta[key] == value, key

# A later save that already contains the paper is not duplicated or reset.
loaded_paper = loaded.object_by_id('hellgs_note')
loaded_paper.x, loaded_paper.y = 611.5, 493.5
loaded_paper.area_id = 'castle_hall'
loaded_paper.moved = True
second = module.C131GameModel.from_snapshot(new_engine, loaded.snapshot())
assert sum(1 for o in second.objects if o.object_id == 'hellgs_note') == 1
assert (second.object_by_id('hellgs_note').x, second.object_by_id('hellgs_note').y) == (611.5, 493.5)
assert second.object_by_id('hellgs_note').area_id == 'castle_hall'
assert second.object_by_id('hellgs_note').moved is True

# Browser bundle names are unique to the new release.
page = PAGE.read_text(encoding='utf-8')
assert 'SGGF1.666a' in page and 'F1.666a' in page
assert 'sggf1666a.apk' in page and 'sggf1666a.tar.gz' in page
assert 'archive:"sggf1666a"' in page and 'bundle = "sggf1666a"' in page
assert 'sggf1666.tar.gz' not in page

# Front-door text is a verbatim carry-forward from F1.666, with the requested addition.
with __import__('zipfile').ZipFile('/mnt/data/SGGF1.666_CLOUDFLARE_DEPLOY.zip') as old_zip:
    manifest = json.loads(old_zip.read('versions.json'))
old_entry = next(v for v in manifest['versions'] if v['version'] == 'SGGF1.666')
expected_description = old_entry['description'] + ' woops.. now it IS possible to escape'
new_manifest = json.loads((W / 'deploy' / 'versions.json').read_text(encoding='utf-8'))
new_entry = new_manifest['versions'][0]
assert new_entry['version'] == 'SGGF1.666a'
assert new_entry['description'] == expected_description

print('PASS F1.666a: synthetic F1.6 quicksave loads into its saved area/coordinates; all old objects, inventory, item metadata and flags survive; only missing hellgs_note is migrated; existing paper saves do not duplicate/reset it; base mechanics and world data stay unchanged.')
