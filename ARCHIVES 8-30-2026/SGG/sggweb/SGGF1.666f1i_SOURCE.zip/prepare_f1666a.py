from pathlib import Path
import json, shutil

W = Path(__file__).resolve().parent

# Freeze the complete F1.666 release inputs inside the new archive directory.
for src, dst in [
    ('main.py', 'F1.666_BASE_MAIN.py'),
    ('luma_assets_e33.json', 'F1.666_BASE_LUMA_ASSETS.json'),
    ('F1_play.html', 'F1.666_BASE_F1_play.html'),
    ('README_SGGF1666.txt', 'F1.666_BASE_README.txt'),
    ('test_f1666.py', 'F1.666_BASE_test_f1666.py'),
    ('package_f1666.py', 'F1.666_BASE_package_f1666.py'),
    ('F1.666_BUILD_META.json', 'F1.666_BASE_BUILD_META.json'),
]:
    shutil.copy2(W / src, W / dst)

main_path = W / 'main.py'
src = main_path.read_text(encoding='utf-8')
assert 'VERSION = "F1.666"' in src
src = src.replace('VERSION = "F1.666"', 'VERSION = "F1.666a"', 1)
src = src.replace("_log('F1.666 CONFIG'", "_log('F1.666a CONFIG'", 1)
src = src.replace("'SGGF1.666: HELLgs Inn.", "'SGGF1.666a: HELLgs Inn.", 1)
src = src.replace('Six-slider F1.666 settings panel', 'Six-slider F1.666a settings panel', 1)
src = src.replace('SGGF1.666 — HELLgs Inn: sealed-cell Halloween challenge.',
                  'SGGF1.666a — HELLgs Inn: backward-save-compatible sealed-cell Halloween challenge.', 1)
old_tuple = "'stable_carriage', 'stable_draft_horse', 'stables_foreground_fence')"
migration_start = src.index('class C13GameModel')
head, migration = src[:migration_start], src[migration_start:]
assert migration.count(old_tuple) == 2, migration.count(old_tuple)
migration = migration.replace(old_tuple,
                  "'stable_carriage', 'stable_draft_horse', 'stables_foreground_fence', 'hellgs_note')")
src = head + migration
assert "VERSION = \"F1.666a\"" in src
assert src.count("'hellgs_note')") == 2
assert "Welcome brave exploiter to version F1.666 of Spiffy's Gift." in src
main_path.write_text(src, encoding='utf-8')

assets_path = W / 'luma_assets_e33.json'
doc = json.loads(assets_path.read_text(encoding='utf-8'))
assert doc['version'] == 'SGGF1.666'
doc['version'] = 'SGGF1.666a'
assets_path.write_text(json.dumps(doc, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

page_path = W / 'F1_play.html'
page = page_path.read_text(encoding='utf-8')
assert 'SGGF1.666' in page and 'sggf1666' in page
page = page.replace('SGGF1.666', 'SGGF1.666a')
page = page.replace('sggf1666', 'sggf1666a')
page_path.write_text(page, encoding='utf-8')

readme = '''SPIFFY'S GIFT — SGGF1.666a

BASE
F1.666 is the direct gameplay and world baseline. The prior F1.666 release remains preserved as-is in its own archive. This new release is a separate additive version; it does not replace or edit F1.666.

HELLgs INN
The game still starts in the same small stone cell called HELLgs Inn. Its only visible exit is the same solid barred cell door drawn into the background and backed by collision geometry. It is not a world object, is not interactable, and has no ordinary door transition. Stone walls and the closed cell door remain solid. The cell floor remains walkable.

A folded paper lies on the floor. Pick it up, open Inventory, select the paper, and press E to read. The paper text is intentionally unchanged from F1.666:

Welcome brave exploiter to version F1.666 of Spiffy's Gift.
I look forwarding to meeting you.
Signed Cozmo

BACKWARD SAVE COMPATIBILITY — THE F1.666a FIX
F1.6 quicksaves can now load in F1.666a. F1.6 saves do not contain the HELLgs paper object because that object did not exist when they were made. During the normal save-load migration, F1.666a adds only the missing default hellgs_note object and its item metadata before the existing world-object validation runs.

The migration does not replace the saved world state. It preserves the saved area, player coordinates, inventory, existing object records, quest flags, day, elapsed time, and other saved fields. The old saved area and coordinates therefore take precedence over the new HELLgs Inn starting location. The loader does not create a new exit or a special escape mechanic; it simply restores compatibility with the cross-version quickload path that Cozmo is testing.

END CONDITION
The existing HELLgs Inn fire end condition remains one in-game day OR the selected real-time timer, whichever comes first. Initial End Timer in Minutes remains a persistent settings slider, range 1–1440 minutes, default 60 minutes. Press T to advance one in-game day. The fire still surges through the gate, consumes the player, and causes a final GAME OVER; R does not respawn the player.

SCOPE / PRESERVATION
No new area, normal exit, door object, or Hellgs area connection has been added. Existing F1.666 gameplay systems, including the ordinary fast-travel system and its existing destination list, are retained. The only gameplay code change is the backward-save migration for hellgs_note. The existing version F1.666 archive and Cloudflare deployment are not modified or replaced.

FRONT-DOOR VERSION DESCRIPTION
The F1.666 front-door description is carried forward unchanged, with this addition appended: "woops.. now it IS possible to escape".

TESTING
Static checks include an actual in-memory load of a synthetic F1.6-format save through the same C131GameModel.from_snapshot migration path used by quickload. The test verifies that the old area, player coordinates, inventory, quest flags, and existing objects survive while exactly one default hellgs_note object is supplied. A second pass verifies an already-present paper object is not duplicated. Packaging checks verify that F1.666 historical deployment files remain preserved and that F1.666a is added as a distinct new release. A live browser launch remains for Cozmo's field test.
'''
(W / 'README_SGGF1666a.txt').write_text(readme, encoding='utf-8')

print('Prepared F1.666a source: version id, browser bundle, asset metadata, one-object save migration, and README.')
