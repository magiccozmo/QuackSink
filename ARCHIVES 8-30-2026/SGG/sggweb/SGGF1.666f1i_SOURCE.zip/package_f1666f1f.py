from pathlib import Path
from io import BytesIO
import tarfile, zipfile
W=Path(__file__).resolve().parent
code=(W/"main.py").read_bytes()
assets=(W/"luma_assets_e33.json").read_bytes()
with zipfile.ZipFile(W/"sggf1666f1f.apk","w",zipfile.ZIP_DEFLATED,compresslevel=8) as z:
    z.writestr("assets/main.py",code); z.writestr("assets/luma_assets_e33.json",assets)
with tarfile.open(W/"sggf1666f1f.tar.gz","w:gz") as t:
    for name,data in (("assets/main.py",code),("assets/luma_assets_e33.json",assets)):
        i=tarfile.TarInfo(name); i.size=len(data); i.mtime=0; t.addfile(i,BytesIO(data))
print("Built SGGF1.666f1f runtime packages.")
