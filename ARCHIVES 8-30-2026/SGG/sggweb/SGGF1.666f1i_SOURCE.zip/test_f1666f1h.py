from __future__ import annotations
import ast, json, zipfile, tarfile, io
from pathlib import Path
ROOT=Path(__file__).resolve().parent
VERSION="SGGF1.666f1h"
PACKAGE="sggf1666f1h"
RECT=(540,316,200,128)
current=json.loads((ROOT/"luma_assets_e33.json").read_text(encoding="utf-8"))
base=json.loads((ROOT/"SGGF1.666f1g"/"assets"/"luma_assets_e33.json").read_text(encoding="utf-8"))
assert current["version"]==VERSION
assert current["world"]["areas"]==base["world"]["areas"]
assert current["world"]["connections"]==base["world"]["connections"]
for key,value in base["assets"].items(): assert current["assets"][key]==value, key
old={o["object_id"]:o for o in base["world"]["objects"]}
new={o["object_id"]:o for o in current["world"]["objects"]}
for oid,o in old.items():
    assert new[oid]==o, ("World objects/defaults must remain unchanged",oid)
ret=new["city_gate_return"]
assert ret["walk_trigger"]=={"rect":[590,383,104,21],"approach":"north"}
assert (ret["x"],ret["y"],ret["width"],ret["height"])==(540,316,200,128)
# A legacy save retains the original object box; the runtime renderer must ignore
# that stale box for visuals and always supply the current canonical rectangle.
legacy_saved_rect=(597,248,90,122)
assert legacy_saved_rect != RECT
main=(ROOT/"main.py").read_text(encoding="utf-8")
ast.parse(main)
assert 'VERSION = "F1.666f1h"' in main
assert 'OUTSIDE_GATE_DOOR_VISUAL_RECT = (540, 316, 200, 128)' in main
assert 'target_rect = pygame.Rect(*OUTSIDE_GATE_DOOR_VISUAL_RECT)' in main
assert 'class F1666f1hInterface(F1666f1fInterface):' in main
assert 'ui = F1666f1hInterface(machine)' in main
assert 'if g.current_area_id != \'outside_gate\':' in main
assert 'name = \'city_gate_double_leaf\'' in main
assert 'walk_trigger' in main
v=ROOT/VERSION
assert (v/"play.html").is_file()
assert (v/"outside_gate_preview.png").is_file()
assert (v/"assets"/"main.py").read_bytes()==(ROOT/"main.py").read_bytes()
assert (v/"assets"/"luma_assets_e33.json").read_bytes()==(ROOT/"luma_assets_e33.json").read_bytes()
with zipfile.ZipFile(v/(PACKAGE+".apk")) as z:
    assert z.testzip() is None
    assert set(z.namelist())=={"assets/main.py","assets/luma_assets_e33.json"}
with tarfile.open(v/(PACKAGE+".tar.gz"),"r:gz") as t:
    assert set(t.getnames())=={"assets/main.py","assets/luma_assets_e33.json"}
    embedded=json.load(t.extractfile("assets/luma_assets_e33.json"))
    assert embedded["version"]==VERSION
with (ROOT/"deploy"/"versions.json").open(encoding="utf-8") as f: versions=json.load(f)["versions"]
assert versions[0]["version"]==VERSION
assert sum(bool(x.get("current")) for x in versions)==1
print("F1.666f1h legacy-save gate-render regression checks PASS")
