from pathlib import Path
p = Path('/mnt/data/sgg_f1666c/main.py')
s = p.read_text(encoding='utf-8')

# Keep the death/Game Over quickload control clear of both the generic and
# HELLgs-specific overlay text.
s = s.replace("F1666C_QUICKLOAD_RECT = (510, 420, 260, 48)",
              "F1666C_QUICKLOAD_RECT = (510, 470, 260, 48)", 1)

# C must treat F1.666b's already-fired HELLgs cameo counter as proof the player
# has previously completed the HELLgs save-load escape. The shared E1 config
# namespace spans version bundles, so this prevents replaying the same event.
needle = """        self.config.setdefault('cozmo_hint_stage', 0)\n        self._log('F1.666c CONFIG',\n"""
replacement = """        self.config.setdefault('cozmo_hint_stage', 0)\n        try:\n            legacy_hellgs_appearances = int(self.config.get(self.COZMO_APPEARANCE_CONFIG_KEY, 0))\n        except (TypeError, ValueError, OverflowError):\n            legacy_hellgs_appearances = 0\n        if legacy_hellgs_appearances > 0 and 'hellgs_escape' not in self._f1666c_achievement_ids():\n            # F1.666b counted a cameo at every successful load from HELLgs.\n            # One or more such appearances prove the once-only escape event\n            # was already discovered. Credit that legacy event exactly once.\n            self._f1666c_award_achievement('hellgs_escape')\n            self._log('COZMO ACHIEVEMENT MIGRATION',\n                      f'Converted {legacy_hellgs_appearances} legacy HELLgs cameo(s) into the single hellgs_escape achievement.')\n        self._log('F1.666c CONFIG',\n"""
assert s.count(needle) == 1
s = s.replace(needle, replacement, 1)

# For Naz, the D1.1 cameo deliberately waits for the market; it must not be
# tied to the area in which the guard actually killed him.
needle = """        flags['d11_cameo_queue'].append({\n            'event': event,\n            'at': float(g.c1_elapsed) + 5.0,\n            'area': g.current_area_id,\n        })\n"""
replacement = """        flags['d11_cameo_queue'].append({\n            'event': event,\n            'at': float(g.c1_elapsed) + 5.0,\n            'area': None if event == 'naz' else g.current_area_id,\n        })\n"""
assert s.count(needle) == 1
s = s.replace(needle, replacement, 1)

# Do not mark a hint tier as completed when it is merely queued. It becomes
# complete only once Cozmo has actually appeared, so loading an older save
# before his appearance cannot discard the promised hint.
needle = """        self._f1666c_save_config(cozmo_hint_stage=desired)\n        if event not in flags['d11_cameo_events']:\n"""
replacement = """        if event not in flags['d11_cameo_events']:\n"""
assert s.count(needle) == 1
s = s.replace(needle, replacement, 1)

# On appearance, persist the hint stage; autospell the tenth and twentieth
# milestone lines from Cozmo's existing world anchor.
needle = """            auto_line = F1666C_HINT_AUTO_LINES.get(event)\n            if auto_line:\n                self._f1666c_speech_as_cozmo(auto_line, 7.0)\n"""
replacement = """            hint_stage = F1666C_HINT_EVENTS.get(event)\n            if hint_stage:\n                current_stage = int(self.config.get('cozmo_hint_stage', 0))\n                if hint_stage > current_stage:\n                    self._f1666c_save_config(cozmo_hint_stage=hint_stage)\n            auto_line = F1666C_HINT_AUTO_LINES.get(event)\n            if auto_line:\n                self._f1666c_speech_as_cozmo(auto_line, 7.0)\n"""
assert s.count(needle) == 1
s = s.replace(needle, replacement, 1)

# Make the eyebrow stage direction explicit and preserve the user's exact
# unusual spelling of "forward compatable".
s = s.replace(
    "'I told Luma to make sure that save games are as forward compatable as possible.\\n\\n(Cozmo raises one eyebrow.)',",
    "'I told Luma to make sure that save games are as forward compatable as possible\\n\\n<raises eyebrow like a certain alien>',",
    1)

# Lout earns the guard-death cameo only for the guard resolution outcome.
needle = """        if g and previous_lout_alive and not g.c1_npcs.get('inn_lout', {}).get('alive', True):\n            self._d11_schedule('lout_guard_death')\n            self._log('COZMO EXPLOIT', 'First-time inn lout guard death detected.')\n"""
replacement = """        if (g and previous_lout_alive\n                and not g.c1_npcs.get('inn_lout', {}).get('alive', True)\n                and g.c1_flags.get('lout_resolved') == 'dead'):\n            self._d11_schedule('lout_guard_death')\n            self._log('COZMO EXPLOIT', 'First-time inn lout guard death detected.')\n"""
assert s.count(needle) == 1
s = s.replace(needle, replacement, 1)

# When a save captured the old F1.666b special-return cameo, convert it to the
# new one-time exploit recognition without ever calling the old alternating
# inventory-tea handler. This is deliberately cleared by the B compatibility
# hook so D1.1 cannot index a missing event string.
needle = """        flags = self._d11_flags()\n        seen = self._f1666c_achievement_ids()\n        active = flags.get('d11_cameo_active')\n        if isinstance(active, dict):\n            achievement = F1666C_EXPLOIT_ACHIEVEMENTS.get(active.get('event'))\n"""
replacement = """        flags = self._d11_flags()\n        seen = self._f1666c_achievement_ids()\n        active = flags.get('d11_cameo_active')\n        if isinstance(active, dict) and active.get('event') == self.COZMO_RETURN_EVENT:\n            flags['d11_cameo_active'] = None\n            active = None\n        if isinstance(active, dict):\n            achievement = F1666C_EXPLOIT_ACHIEVEMENTS.get(active.get('event'))\n"""
assert s.count(needle) == 1
s = s.replace(needle, replacement, 1)

# Draw the visible Tea score in the game surface, away from the top HUD bar.
# No Yorkshire Tea inventory object is ever created by F1.666c.
needle = """    def _draw_header(self):\n        super()._draw_header()\n        if self.machine.state is AppState.PLAY_GAME:\n            try:\n                tea_total = int(self.machine.config.get('cozmo_tea_earned', 0))\n            except (TypeError, ValueError, OverflowError):\n                tea_total = 0\n            panel = pygame.Rect(365, 5, 190, 30)\n            pygame.draw.rect(self.screen, (42, 35, 43), panel, border_radius=5)\n            pygame.draw.rect(self.screen, (220, 175, 106), panel, 1, border_radius=5)\n            label = self.game_small_font.render(f'TEA EARNED: {tea_total}', True, (250, 221, 153))\n            self.screen.blit(label, label.get_rect(center=panel.center))\n\n    def _draw_game_scene(self, surface, g):\n        super()._draw_game_scene(surface, g)\n        if not g.c1_dead:\n            return\n        x, y, w, h = F1666C_QUICKLOAD_RECT\n        button = pygame.Rect(x, y, w, h)\n        pygame.draw.rect(surface, (37, 58, 55), button, border_radius=8)\n        pygame.draw.rect(surface, (233, 190, 113), button, 3, border_radius=8)\n        label = self.game_font.render('QUICKLOAD', True, (255, 239, 205))\n        surface.blit(label, label.get_rect(center=button.center))\n"""
replacement = """    def _draw_header(self):\n        super()._draw_header()\n\n    def _draw_game_scene(self, surface, g):\n        super()._draw_game_scene(surface, g)\n        # Visible, persistent score only: F1.666c does not create inventory tea.\n        try:\n            tea_total = int(self.machine.config.get('cozmo_tea_earned', 0))\n        except (TypeError, ValueError, OverflowError):\n            tea_total = 0\n        panel = pygame.Rect(1015, 49, 245, 34)\n        pygame.draw.rect(surface, (42, 35, 43), panel, border_radius=5)\n        pygame.draw.rect(surface, (220, 175, 106), panel, 1, border_radius=5)\n        score_label = self.game_small_font.render(f'TEA EARNED: {tea_total}', True, (250, 221, 153))\n        surface.blit(score_label, score_label.get_rect(center=panel.center))\n\n        if not g.c1_dead:\n            return\n        x, y, w, h = F1666C_QUICKLOAD_RECT\n        button = pygame.Rect(x, y, w, h)\n        pygame.draw.rect(surface, (37, 58, 55), button, border_radius=8)\n        pygame.draw.rect(surface, (233, 190, 113), button, 3, border_radius=8)\n        label = self.game_font.render('QUICKLOAD', True, (255, 239, 205))\n        surface.blit(label, label.get_rect(center=button.center))\n"""
assert s.count(needle) == 1
s = s.replace(needle, replacement, 1)

# Correct comments to describe the no-item Tea score.
s = s.replace('five once-only exploit recognitions and no-tea hint tiers.',
              'five once-only exploit recognitions, a visible Tea score, and no-tea hint tiers.', 1)
p.write_text(s, encoding='utf-8')
print('Revised F1.666c state-machine and UI details.')
