from pathlib import Path
import copy, json, shutil

ROOT = Path(__file__).resolve().parent

# Capture the exact, unmodified F1.5 source before making any F1.6 edits.
for src, dst in [
    ('main.py', 'F1.5_BASE_MAIN.py'),
    ('luma_assets_e33.json', 'F1.5_BASE_LUMA_ASSETS.json'),
    ('F1_play.html', 'F1.5_BASE_F1_play.html'),
    ('README_SGGF15.txt', 'F1.5_BASE_README.txt'),
    ('F1.5_BUILD_META.json', 'F1.5_BASE_BUILD_META.json'),
    ('test_f15.py', 'F1.5_BASE_test_f15.py'),
    ('package_f15.py', 'F1.5_BASE_package_f15.py'),
]:
    shutil.copy2(ROOT / src, ROOT / dst)

# F1.6 is deliberately a narrow successor to F1.5: align Castle Hall's ground
# navigation to the visible floor, with a single narrow connected approach lane
# to the existing off-centre vault seam. No collision, door, seam, or dialogue
# data is changed.
assets_path = ROOT / 'luma_assets_e33.json'
doc = json.loads(assets_path.read_text(encoding='utf-8'))
assert doc['version'] == 'SGGF1.5'
hall = next(a for a in doc['world']['areas'] if a['area_id'] == 'castle_hall')
assert hall['navigation']['regions'] == [[[24, 220], [1260, 220], [1260, 626], [24, 626]]]
hall['navigation']['regions'] = [
    # Main walkable floor, aligned to the top edge of the visible stone floor.
    [[24, 418], [1260, 418], [1260, 626], [24, 626]],
    # Narrow route up to the existing right-hand wall seam / plate target.
    # This remains joined to the main floor at y=418.
    [[1018, 306], [1074, 306], [1074, 418], [1018, 418]],
]
doc['version'] = 'SGGF1.6'
doc['notes'] = str(doc['notes']).rstrip() + (
    '\nSGGF1.6: corrected only Castle Hall ground navigation to match the visible floor. '
    'The main floor begins at y=418, and a narrow connected lane at x=1018..1074 '
    'preserves access to the existing off-centre vault seam and plate target. '
    'All F1.5 vault interactions, seam actions, door transitions, collision data, '
    'and other world content remain unchanged.'
)
assets_path.write_text(json.dumps(doc, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

# Keep runtime behavior untouched; update version labels and release status only.
main_path = ROOT / 'main.py'
source = main_path.read_text(encoding='utf-8')
replacements = {
    'VERSION = "F1.5"  # Castle Hall vault door, interactions and configurable platter hitbox.':
        'VERSION = "F1.6"  # Castle Hall floor-aligned walkmesh; F1.5 vault behavior retained.',
    "self._log('F1.5 CONFIG', f'special_hard_hitbox={self.special_hard_hitbox:.1f}')":
        "self._log('F1.6 CONFIG', f'special_hard_hitbox={self.special_hard_hitbox:.1f}')",
    "self._set_status('SGGF1.5: Castle Hall vault redesign, item dialogue and adjustable off-centre platter hitbox; F1.4 world retained.')":
        "self._set_status('SGGF1.6: Castle Hall floor walkmesh aligned; all F1.5 vault, plate and door behavior retained.')",
    '"""F1.5 retains Part One while adding the bank-vault puzzle and hitbox tuning."""':
        '"""F1.6 retains the F1.5 bank-vault puzzle and aligns Castle Hall ground navigation."""',
    '"""F1.5 display: five persistent game sliders; Kitty route and E5.7 comments retained."""':
        '"""F1.6 display: F1.5 persistent sliders and gameplay retained with corrected hall navigation."""',
    '"SPIFFY\'S GIFT  |  F1.5  |  "':
        '"SPIFFY\'S GIFT  |  F1.6  |  "',
}
for old, new in replacements.items():
    if old not in source:
        raise SystemExit(f'Missing expected F1.5 source marker: {old!r}')
    source = source.replace(old, new, 1)
main_path.write_text(source, encoding='utf-8')

# Versioned browser loader.
page_path = ROOT / 'F1_play.html'
page = page_path.read_text(encoding='utf-8')
for old, new in [('SGGF1.5', 'SGGF1.6'), ('sggf15', 'sggf16')]:
    assert old in page
    page = page.replace(old, new)
page_path.write_text(page, encoding='utf-8')

print('Created F1.6 working source from the exact F1.5 baseline.')
print('Castle Hall navigation:', hall['navigation']['regions'])
