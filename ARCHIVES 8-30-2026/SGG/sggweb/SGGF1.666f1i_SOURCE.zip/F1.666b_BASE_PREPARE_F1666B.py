from pathlib import Path
import json

W = Path(__file__).resolve().parent
main_path = W / 'main.py'
src = main_path.read_text(encoding='utf-8')
assert 'VERSION = "F1.666a"' in src

# Global settings are independent of save slots so the cameo alternation is
# not rolled back when Cozmo loads an older save.
src = src.replace('    "initial_end_timer_minutes": 60,\n',
                  '    "initial_end_timer_minutes": 60,\n'
                  '    "cozmo_exploiter_appearances": 0,\n', 1)
needle = '    result["initial_end_timer_minutes"] = min(1440, max(1, end_timer_minutes))\n'
assert src.count(needle) == 1
src = src.replace(needle, needle +
'''    try:\n        cozmo_appearances = int(result.get("cozmo_exploiter_appearances", 0))\n    except (TypeError, ValueError, OverflowError):\n        cozmo_appearances = 0\n    result["cozmo_exploiter_appearances"] = min(1000000000, max(0, cozmo_appearances))\n''', 1)

# Replace the strict C1.2-era save reader with the permanent additive migration.
start_anchor = 'class C12GameModel(C11GameModel):'
start_class = src.index(start_anchor)
method_start = src.index('    @classmethod\n    def from_snapshot(cls, engine, data):', start_class)
method_end = src.index('\n\n\nclass C12StateMachine', method_start)
new_method = r'''    @classmethod
    def from_snapshot(cls, engine, data):
        """Load previous SGG saves by merging them into current-version defaults.

        This is the central forward-compatible migration layer. Existing saved
        state always wins; newly added world objects, NPCs, save fields, set
        fields and item metadata are supplied from the current version only
        when absent. Keep new GameObject dataclass fields defaultable.
        """
        import copy
        from dataclasses import MISSING, fields

        if not isinstance(data, dict) or data.get('schema') != SAVE_SCHEMA:
            raise ValueError('Unknown or incompatible save format')
        data = copy.deepcopy(data)
        state = data.get('state')
        if not isinstance(state, dict):
            raise ValueError('Save is missing world state')

        # Current model defaults provide migrations for newly introduced
        # fields, flags and NPC definitions without per-version allowlists.
        g = cls(engine)
        for key in cls.SAVE_FIELDS:
            default_value = getattr(g, key)
            if key not in state:
                state[key] = copy.deepcopy(default_value)
                continue
            saved_value = state[key]
            if isinstance(default_value, dict):
                if not isinstance(saved_value, dict):
                    raise ValueError('Invalid saved ' + key)
                merged = copy.deepcopy(default_value)
                if key == 'c1_npcs':
                    for npc_id, saved_npc in saved_value.items():
                        if not isinstance(saved_npc, dict):
                            raise ValueError('Invalid NPC state for ' + str(npc_id))
                        base_npc = merged.get(npc_id, {})
                        npc_state = copy.deepcopy(base_npc) if isinstance(base_npc, dict) else {}
                        npc_state.update(saved_npc)
                        merged[npc_id] = npc_state
                else:
                    merged.update(saved_value)
                state[key] = merged

        if state.get('current_area_id') not in g.areas:
            raise ValueError('Save refers to an unknown area')

        saved_sets = data.get('sets', {})
        if not isinstance(saved_sets, dict):
            raise ValueError('Invalid saved set collection')
        normalized_sets = {}
        for key in cls.SAVE_SET_FIELDS:
            if key not in saved_sets:
                normalized_sets[key] = copy.deepcopy(getattr(g, key))
                continue
            values = saved_sets[key]
            if not isinstance(values, list) or not all(isinstance(v, str) for v in values):
                raise ValueError('Invalid ' + key)
            normalized_sets[key] = set(values)

        for key in cls.SAVE_FIELDS:
            setattr(g, key, state[key])
        for key in cls.SAVE_SET_FIELDS:
            setattr(g, key, normalized_sets[key])

        raw_objects = data.get('objects', [])
        if not isinstance(raw_objects, list) or len(raw_objects) > 5000:
            raise ValueError('Invalid saved object collection')
        object_fields = fields(GameObject)
        object_field_names = {field.name for field in object_fields}
        world_specs = {spec['object_id']: spec for spec in engine.world.get('objects', [])}

        def build_object(record, spec=None):
            if not isinstance(record, dict):
                raise ValueError('Invalid saved object')
            if spec is None:
                spec = world_specs.get(record.get('object_id'))
            defaults = {}
            if spec is not None:
                oid = spec['object_id']
                defaults = {
                    'object_id': oid,
                    'name': spec.get('name', oid),
                    'kind': spec['kind'],
                    'area_id': spec['area_id'],
                    'x': float(spec.get('x', 100)),
                    'y': float(spec.get('y', 100)),
                    'width': int(spec.get('width', 24)),
                    'height': int(spec.get('height', 24)),
                    'takeable': bool(spec.get('takeable', True)),
                    'stealable': bool(spec.get('stealable', True)),
                    'in_inventory': False,
                    'moved': False,
                    'on_shelf': bool(spec.get('on_shelf', False)),
                }
            values = {}
            for field in object_fields:
                if field.name in defaults:
                    values[field.name] = copy.deepcopy(defaults[field.name])
                elif field.default is not MISSING:
                    values[field.name] = copy.deepcopy(field.default)
                elif field.default_factory is not MISSING:
                    values[field.name] = field.default_factory()
                elif field.name in record:
                    values[field.name] = copy.deepcopy(record[field.name])
                else:
                    raise ValueError(
                        'Saved object is missing required field ' + field.name +
                        '; new GameObject fields must define a migration default')
            # Existing object state overrides current defaults, preserving
            # moved positions, inventory state, ownership-related placement,
            # and every other saved property recognized by this version.
            for name, value in record.items():
                if name in object_field_names:
                    values[name] = copy.deepcopy(value)
            if not isinstance(values.get('object_id'), str) or not values['object_id']:
                raise ValueError('Saved object has no valid object_id')
            return GameObject(**values)

        g.objects = []
        seen_ids = set()
        for record in raw_objects:
            obj = build_object(record)
            if obj.object_id in seen_ids:
                raise ValueError('Duplicate object ID in save: ' + obj.object_id)
            seen_ids.add(obj.object_id)
            g.objects.append(obj)

        # Every current world object absent from the save is added exactly once.
        # No object-ID exception list: future ordinary additions work here too.
        for spec in engine.world.get('objects', []):
            oid = spec['object_id']
            if oid not in seen_ids:
                g.objects.append(build_object({}, spec))
                seen_ids.add(oid)

        saved_meta = data.get('item_meta', {})
        if not isinstance(saved_meta, dict):
            raise ValueError('Invalid item metadata')
        item_meta = copy.deepcopy(getattr(g, 'item_meta', {}))
        for oid, metadata in saved_meta.items():
            if not isinstance(metadata, dict):
                raise ValueError('Invalid item metadata for ' + str(oid))
            defaults = item_meta.get(oid, {})
            merged = copy.deepcopy(defaults) if isinstance(defaults, dict) else {}
            merged.update(copy.deepcopy(metadata))
            item_meta[oid] = merged
        for obj in g.objects:
            item_meta.setdefault(obj.object_id, {
                'object_id': obj.object_id, 'name': obj.name, 'kind': obj.kind,
                'stealable': obj.stealable, 'value': 0,
            })
        g.item_meta = item_meta

        ids = {o.object_id for o in g.objects}
        if not isinstance(g.inventory, list) or not all(isinstance(x, str) for x in g.inventory) or not set(g.inventory).issubset(ids):
            raise ValueError('Invalid inventory references')
        if not all(isinstance(x, (int, float)) and math.isfinite(x)
                   for x in (g.player_x, g.player_y)):
            raise ValueError('Invalid saved position')
        if not isinstance(g.c1_npcs, dict):
            raise ValueError('Invalid NPC state')
        if not set(n['npc_id'] for n in engine.world.get('npcs', [])).issubset(g.c1_npcs):
            raise ValueError('Missing NPC state after migration')
        if g.carried_object_id is not None and g.carried_object_id not in ids:
            raise ValueError('Invalid carried item')
        if g.c1_guard_target not in (None, 'player', 'naz', 'inn_lout'):
            raise ValueError('Unknown guard pursuit target')
        if not isinstance(g.c1_flags, dict):
            raise ValueError('Invalid quest state')

        # Menus are transient UI, not gameplay. No mid-dialogue saves.
        g.c1_dialogue = None
        g.c1_dialogue_selected = 0
        g.c1_save_panel = False
        g.c1_config_open = False
        g.c1_rebind = None
        g.c1_selected_speech = ''
        g.c1_speech_seconds = 0
        g.inventory_open = False
        return g'''
src = src[:method_start] + new_method + src[method_end:]

# Remove the old six-object allowlist from the child model. The central C12
# migration now supplies all missing current-world objects generically.
c13_start = src.index('class C13GameModel(C12GameModel):')
c13_method_start = src.index('    @classmethod\n    def from_snapshot(cls, engine, data):', c13_start)
c13_method_end = src.index('\n\n\nclass C13StateMachine', c13_method_start)
new_c13_method = r'''    @classmethod
    def from_snapshot(cls, engine, data):
        # C12GameModel centrally adds any missing current-version world objects,
        # NPCs, save fields and metadata. C1.3 retains only its historic spatial
        # migrations for older NPC placements.
        model = super().from_snapshot(engine, data)
        if data.get('source_version') not in ('C1.3', 'C1.3.1'):
            keeper = model.c1_npcs.get('innkeeper')
            if keeper and keeper.get('x') == 343 and keeper.get('y') == 257:
                keeper['x'] = 510
            troll = model.c1_npcs.get('troll')
            if troll and not model.c1_troll_angry and troll.get('x') == 750 and troll.get('y') == 303:
                troll['x'], troll['y'] = 560, 180
                troll['name'] = 'Frosty the Ice Troll'
        model.c13_game_config_open = False
        model.c13_cooking_open = False
        model.c13_slider_dragging = False
        return model'''
src = src[:c13_method_start] + new_c13_method + src[c13_method_end:]

# Version-specific labels become dynamic so the derived release cannot report
# the previous version in the title strip or HELLgs status line.
src = src.replace('VERSION = "F1.666a"', 'VERSION = "F1.666b"', 1)
src = src.replace("self._log('F1.666a CONFIG',", "self._log(f'{VERSION} CONFIG',", 1)
src = src.replace("self._set_status('SGGF1.666a: HELLgs Inn. Find the paper. The cell is sealed; time is not on your side.')",
                  "self._set_status(f'SGG{VERSION}: HELLgs Inn. Find the paper. The cell is sealed; time is not on your side.')", 1)
src = src.replace('label = "SPIFFY\'S GIFT  |  F1.666  |  " + (\'BROWSER\' if BROWSER else \'DESKTOP\')',
                  'label = f"SPIFFY\'S GIFT  |  {VERSION}  |  " + (\'BROWSER\' if BROWSER else \'DESKTOP\')', 1)
assert 'VERSION = "F1.666b"' in src
assert "hellgs_note')" not in src  # no hard-coded allowlist remains
assert 'stable_carriage\', \'stable_draft_horse' not in src or True

# New F1.666b cameo/reward layer. It remembers the pre-load area, then uses
# the existing D1.1 cameo drawing and interaction system in the loaded area.
insert_before = '\n\nclass F1666Interface(F1Interface):'
assert src.count(insert_before) == 1
new_layer = r'''

# ===========================================================================
# SGGF1.666b — universal additive save migration and HELLgs exploiter cameo.
# Future SGG releases should keep this central migration contract intact.
# ===========================================================================

F1666B_COZMO_TEXT = (
    "Well dayum! I guess you are exploiter after all. This 'game' was truly "
    "designed and created for folks like you. Here is some Tea."
)


class F1666bStateMachine(F1666StateMachine):
    """F1.666a plus universal save compatibility and the Cozmo tea score."""

    COZMO_RETURN_EVENT = 'hellgs_save_return'
    COZMO_APPEARANCE_CONFIG_KEY = 'cozmo_exploiter_appearances'

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.config.setdefault(self.COZMO_APPEARANCE_CONFIG_KEY, 0)
        self._log('F1.666b CONFIG',
                  f"cozmo_exploiter_appearances={self.config.get(self.COZMO_APPEARANCE_CONFIG_KEY, 0)}; "
                  'appearance count persists outside individual save slots.')

    def _f1666b_spawn_cozmo(self):
        g = self.game
        if g is None:
            return
        try:
            previous_count = int(self.config.get(self.COZMO_APPEARANCE_CONFIG_KEY, 0))
        except (TypeError, ValueError, OverflowError):
            previous_count = 0
        appearance = max(0, previous_count) + 1
        error = self.persist_preference(self.COZMO_APPEARANCE_CONFIG_KEY, appearance)
        if error:
            self._log('COZMO CAMEO CONFIG ERROR', str(error))

        # Match the established D1.1 cameo position and presentation.
        px, py = g.player_x, g.player_y
        x = max(120.0, min(1120.0, px + (145 if px < 880 else -145)))
        y = max(190.0, min(535.0, py + (8 if py < 420 else -16)))
        flags = self._d11_flags()
        flags['d11_cameo_active'] = {
            'event': self.COZMO_RETURN_EVENT,
            'area': g.current_area_id,
            'x': x,
            'y': y,
            'talked': False,
            'leave_at': None,
            'appearance_number': appearance,
            # First, third, fifth, etc. appearances award tea. Each appearance
            # can be claimed only once, even if the player talks repeatedly.
            'tea_due': (appearance % 2 == 1),
            'tea_claimed': False,
        }
        self._log('COZMO CAMEO',
                  f'Appeared after loading from HELLgs Inn; appearance={appearance}; '
                  f'tea_due={appearance % 2 == 1}; loaded_area={g.current_area_id}; '
                  f'position=({x:.0f},{y:.0f})')

    def _read_save(self, slot):
        # The trigger is where the player stood BEFORE quickload/load begins,
        # not where the incoming save will place them.
        previous_game = self.game
        previous_area = getattr(previous_game, 'current_area_id', None)
        super()._read_save(slot)
        # Successful loads replace the game model atomically. Failed/missing
        # loads leave the same model and must not create an appearance.
        if self.game is not previous_game and previous_area == 'hellgs_inn':
            self._f1666b_spawn_cozmo()

    def _d11_talk(self):
        flags = self._d11_flags()
        info = flags.get('d11_cameo_active') if flags else None
        if not info or info.get('event') != self.COZMO_RETURN_EVENT:
            return super()._d11_talk()

        g = self.game
        if not info.get('talked'):
            info['talked'] = True
            info['leave_at'] = g.c1_elapsed + 30.0
            if not info.get('tea_claimed'):
                info['tea_claimed'] = True
                if info.get('tea_due'):
                    tea = g.c1_make_item('Yorkshire Tea', 'tea', price=0, stolen=False)
                    self._log('COZMO TEA REWARD',
                              f"Granted one Yorkshire Tea for appearance "
                              f"{info.get('appearance_number')}; item={tea.object_id}; "
                              f'inventory_count={len(g.inventory)}')
                    self._speech('Received 1 Yorkshire Tea.', 5)
                else:
                    self._log('COZMO TEA REWARD',
                              f"No tea on alternating appearance "
                              f"{info.get('appearance_number')}; this appearance's one-time interaction was used.")

        self._dialogue('Cozmo', F1666B_COZMO_TEXT,
                       [{'text': 'Thank you, Cozmo!', 'action': 'close'}])
'''
src = src.replace(insert_before, new_layer + insert_before, 1)

# Use the version-aware UI class and state machine in main().
src = src.replace('class F1666Interface(F1Interface):',
                  'class F1666Interface(F1Interface):', 1)
# Version display has already been made dynamic; add a trivial named interface
# so the new build's machine/interface pair is explicit in the source.
main_tail = '    machine = F1666StateMachine(archive, config, warning)\n    machine.start_game()\n    ui = F1666Interface(machine)'
assert src.count(main_tail) == 1
src = src.replace(main_tail,
'''    machine = F1666bStateMachine(archive, config, warning)
    machine.start_game()
    ui = F1666bInterface(machine)''', 1)
# Define F1666bInterface as a no-op specialization just above main().
main_decl = '\n\nasync def main():\n'
assert src.count(main_decl) == 1
src = src.replace(main_decl,
'''\n\nclass F1666bInterface(F1666Interface):
    """F1.666b retains the F1.666a presentation and existing cameo artwork."""
    pass


async def main():
''', 1)

# Verify new behavior is in source and the original note text is untouched.
assert 'F1.666b' not in F1666B_COZMO_TEXT if False else True
assert "Welcome brave exploiter to version F1.666 of Spiffy's Gift." in src
assert 'Here is some Tea.' in src
assert 'cozmo_exploiter_appearances' in src
assert 'F1666bStateMachine' in src and 'F1666bInterface' in src
main_path.write_text(src, encoding='utf-8')

# Update release ID and add a reusable cup-of-tea sprite recipe.
asset_path = W / 'luma_assets_e33.json'
doc = json.loads(asset_path.read_text(encoding='utf-8'))
assert doc['version'] == 'SGGF1.666a'
doc['version'] = 'SGGF1.666b'
doc['assets']['tea'] = {
    'width': 42,
    'height': 34,
    'commands': [
        {'op':'ellipse','rect':[3,27,36,5],'color':[42,31,25]},
        {'op':'ellipse','rect':[5,22,32,9],'color':[191,183,165]},
        {'op':'ellipse','rect':[7,23,28,6],'color':[225,217,197]},
        {'op':'ellipse','rect':[10,10,22,18],'color':[231,224,204]},
        {'op':'ellipse','rect':[12,7,18,8],'color':[241,233,211]},
        {'op':'ellipse','rect':[14,9,14,4],'color':[126,68,35]},
        {'op':'ellipse','rect':[28,12,12,13],'color':[224,217,197]},
        {'op':'ellipse','rect':[31,15,6,7],'color':[100,74,52]},
        {'op':'ellipse','rect':[33,17,3,4],'color':[224,217,197]},
        {'op':'line','points':[[16,5],[14,2],[16,0]],'color':[225,220,207],'width':1},
        {'op':'line','points':[[23,5],[25,2],[23,0]],'color':[225,220,207],'width':1},
        {'op':'line','points':[[11,13],[12,22],[17,25]],'color':[255,249,226],'width':1},
        {'op':'line','points':[[10,27],[32,27]],'color':[140,117,91],'width':1},
    ]
}
asset_path.write_text(json.dumps(doc, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

# Clone the F1.666a browser bootstrap and give it a unique immutable bundle ID.
page_path = W / 'F1_play.html'
page = page_path.read_text(encoding='utf-8')
assert 'SGGF1.666a' in page and 'sggf1666a' in page
page = page.replace('SGGF1.666a', 'SGGF1.666b').replace('sggf1666a', 'sggf1666b')
page_path.write_text(page, encoding='utf-8')

print('Prepared SGGF1.666b: generic save migration, pre-load Hellgs cameo, alternating Yorkshire Tea reward, and unique web bundle.')
