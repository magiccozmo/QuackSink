from pathlib import Path
import ast
import copy
import gzip
import hashlib
import io
import json
import subprocess
import sys
import tarfile
import zipfile

WORK = Path(__file__).resolve().parent
ROOT = Path('/mnt/data')
MAIN = WORK / 'main.py'
ASSETS = WORK / 'luma_assets_e33.json'
PLAY = WORK / 'F1_play.html'
README = WORK / 'README_SGGF1666f.txt'
TEST = WORK / 'test_f1666f.py'
PREPARE = WORK / 'prepare_f1666f.py'
BASE_DEPLOY = ROOT / 'SGGF1.666e_CLOUDFLARE_DEPLOY.zip'
BASE_SOURCE = ROOT / 'SGGF1.666e_SOURCE.zip'
DEPLOY = ROOT / 'SGGF1.666f_CLOUDFLARE_DEPLOY.zip'
SOURCE = ROOT / 'SGGF1.666f_SOURCE.zip'
META_PATH = WORK / 'F1.666f_BUILD_META.json'
VERSION = 'SGGF1.666f'
BUNDLE = 'sggf1666f'

EXPECTED_BASE_SOURCE_SHA256 = '765bc037b13dfaf709b7c7dce7ec4823e422b1ac4aea2feafdefb3df4af32700'
EXPECTED_BASE_DEPLOY_SHA256 = '4f679687063fac3790735bf3a42d567d922272ea2f51d854eb6ccaaea8094292'
EXPECTED_BASE_MAIN_SHA256 = '5347c0a1236abf48423dd0b58fa191025800b86d2bde34335aef2095f3807140'
EXPECTED_BASE_ASSETS_SHA256 = 'd7c689a8c4cae6cc710b52c38a554a4bafba86ab5d62f006ab92f68f00cc6e1b'
EXPECTED_BASE_PAGE_SHA256 = '234e7f495329f32e1e0a90ca81951e08d331694ebf75c40eff728feb66c0772b'

required = (
    MAIN, ASSETS, PLAY, README, TEST, PREPARE, BASE_DEPLOY, BASE_SOURCE,
    WORK / 'F1.666e_BASE_MAIN.py',
    WORK / 'F1.666e_BASE_LUMA_ASSETS.json',
    WORK / 'F1.666e_BASE_F1_play.html',
)
for path in required:
    assert path.is_file(), f'Missing build input: {path}'
# Immutable archive rule: a rerun must never overwrite an existing release ZIP.
assert not DEPLOY.exists(), f'Refusing to replace existing archive: {DEPLOY}'
assert not SOURCE.exists(), f'Refusing to replace existing archive: {SOURCE}'

base_hashes = {
    'source_zip_sha256': hashlib.sha256(BASE_SOURCE.read_bytes()).hexdigest(),
    'deploy_zip_sha256': hashlib.sha256(BASE_DEPLOY.read_bytes()).hexdigest(),
    'main_sha256': hashlib.sha256((WORK / 'F1.666e_BASE_MAIN.py').read_bytes()).hexdigest(),
    'assets_sha256': hashlib.sha256((WORK / 'F1.666e_BASE_LUMA_ASSETS.json').read_bytes()).hexdigest(),
    'page_sha256': hashlib.sha256((WORK / 'F1.666e_BASE_F1_play.html').read_bytes()).hexdigest(),
}
assert base_hashes['source_zip_sha256'] == EXPECTED_BASE_SOURCE_SHA256
assert base_hashes['deploy_zip_sha256'] == EXPECTED_BASE_DEPLOY_SHA256
assert base_hashes['main_sha256'] == EXPECTED_BASE_MAIN_SHA256
assert base_hashes['assets_sha256'] == EXPECTED_BASE_ASSETS_SHA256
assert base_hashes['page_sha256'] == EXPECTED_BASE_PAGE_SHA256

code = MAIN.read_bytes()
assets_bytes = ASSETS.read_bytes()
assets_doc = json.loads(assets_bytes)
page = PLAY.read_text(encoding='utf-8')
readme_bytes = README.read_bytes()
assert assets_doc['version'] == VERSION
assert b'VERSION = "F1.666f"' in code
assert all(token in page for token in (
    'SGGF1.666f', 'sggf1666f.apk', 'sggf1666f.tar.gz',
    'archive:"sggf1666f"', 'bundle = "sggf1666f"'))
assert 'sggf1666e.apk' not in page and 'sggf1666e.tar.gz' not in page
assert assets_doc['notes'].endswith('F1.666e saves, run ledger, Tea, hints, world and cross-version compatibility are retained.')
ast.parse(code.decode('utf-8'))
subprocess.run([sys.executable, '-m', 'py_compile', str(MAIN), str(TEST), str(PREPARE)], cwd=WORK, check=True)
subprocess.run([sys.executable, str(TEST)], cwd=WORK, check=True)

# Check that the E snapshots used by the F preparation and tests are byte exact.
with zipfile.ZipFile(BASE_SOURCE, 'r') as base_src:
    assert base_src.testzip() is None
    assert base_src.read('main.py') == (WORK / 'F1.666e_BASE_MAIN.py').read_bytes()
    assert base_src.read('luma_assets_e33.json') == (WORK / 'F1.666e_BASE_LUMA_ASSETS.json').read_bytes()
    assert base_src.read('F1_play.html') == (WORK / 'F1.666e_BASE_F1_play.html').read_bytes()
    assert base_src.read('README_SGGF1666e.txt') == (WORK / 'F1.666e_BASE_README.txt').read_bytes()
    assert base_src.read('test_f1666e.py') == (WORK / 'F1.666e_BASE_TEST_F1666E.py').read_bytes()
    assert base_src.read('prepare_f1666e.py') == (WORK / 'F1.666e_BASE_PREPARE_F1666E.py').read_bytes()
    assert base_src.read('package_f1666e.py') == (WORK / 'package_f1666e.py').read_bytes()

# Save immutable F runtime snapshots for the next release's baseline.
# These are newly named files; no F1.666e snapshot is changed.
new_snapshots = {
    'F1.666f_BASE_MAIN.py': code,
    'F1.666f_BASE_LUMA_ASSETS.json': assets_bytes,
    'F1.666f_BASE_F1_play.html': page.encode('utf-8'),
    'F1.666f_BASE_README.txt': readme_bytes,
    'F1.666f_BASE_TEST_F1666F.py': TEST.read_bytes(),
    'F1.666f_BASE_PREPARE_F1666F.py': PREPARE.read_bytes(),
    'F1.666f_BASE_PACKAGE_F1666F.py': Path(__file__).read_bytes(),
}
for name, payload in new_snapshots.items():
    target = WORK / name
    assert not target.exists(), f'Refusing to replace snapshot: {target}'
    target.write_bytes(payload)

# Build matching WebAssembly runtime payloads from the same main/assets bytes.
apkb = io.BytesIO()
with zipfile.ZipFile(apkb, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as apk:
    apk.writestr('assets/main.py', code)
    apk.writestr('assets/luma_assets_e33.json', assets_bytes)

tarb = io.BytesIO()
with gzip.GzipFile(fileobj=tarb, mode='wb', compresslevel=9, mtime=0) as gz:
    with tarfile.open(fileobj=gz, mode='w') as tf:
        for name, payload in (
            ('assets/main.py', code),
            ('assets/luma_assets_e33.json', assets_bytes),
        ):
            info = tarfile.TarInfo(name)
            info.size = len(payload)
            info.mode = 0o644
            info.mtime = 0
            tf.addfile(info, io.BytesIO(payload))

with zipfile.ZipFile(BASE_DEPLOY, 'r') as old:
    assert old.testzip() is None
    old_names = old.namelist()
    assert len(old_names) == 200 and len(old_names) == len(set(old_names))
    required_old = (
        'index.html', 'versions.html', 'versions.json', '_headers',
        'SGGF1.666e/play.html', 'SGGF1.666e/favicon.png',
        'SGGF1.666e/sggf1666e.apk', 'SGGF1.666e/sggf1666e.tar.gz',
        'SGGF1.666e/README_SGGF1666e.txt',
        'SGGF1.666d/play.html', 'SGGF1.666d/README_SGGF1666d.txt',
        'SGGF1.666c/play.html', 'SGGF1.666c/README_SGGF1666c.txt',
        'SGGF1.666a/play.html', 'SGGF1.666a/README_SGGF1666a.txt',
        'SGGF1.666b/play.html', 'SGGF1.666b/README_SGGF1666b.txt',
    )
    for name in required_old:
        assert name in old_names, f'Missing historical member: {name}'

    base_manifest = json.loads(old.read('versions.json'))
    assert len(base_manifest['versions']) == 39
    a_release = next(v for v in base_manifest['versions'] if v['version'] == 'SGGF1.666a')
    a_description = a_release['description']
    assert a_description.endswith('woops.. now it IS possible to escape')
    for cell_version in ('SGGF1.666a', 'SGGF1.666b', 'SGGF1.666c', 'SGGF1.666d', 'SGGF1.666e'):
        entry = next(v for v in base_manifest['versions'] if v['version'] == cell_version)
        assert entry['description'] == a_description, f'F1.666a-safe description drifted for {cell_version}'

    manifest = copy.deepcopy(base_manifest)
    for entry in manifest['versions']:
        entry['current'] = False
        if entry.get('version') in {
            'SGGF1.666a', 'SGGF1.666b', 'SGGF1.666c', 'SGGF1.666d', 'SGGF1.666e'
        }:
            entry['description'] = a_description
    manifest['versions'].insert(0, {
        'version': VERSION,
        'title': 'SGGF1.666f — HELLgs Fire Update',
        'path': VERSION + '/play.html',
        'description': a_description,
        'current': True,
    })
    manifest_bytes = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode('utf-8')

    index_html = old.read('index.html').decode('utf-8')
    versions_html = old.read('versions.html').decode('utf-8')
    for label, html in (('index.html', index_html), ('versions.html', versions_html)):
        assert '[a-z]?' in html, f'{label} does not support alphabetic version suffixes.'
        assert 'navigator.userAgentData?.mobile' in html
    favicon = old.read('SGGF1.666e/favicon.png')
    additions = [
        (VERSION + '/play.html', page.encode('utf-8')),
        (VERSION + '/favicon.png', favicon),
        (VERSION + '/' + BUNDLE + '.apk', apkb.getvalue()),
        (VERSION + '/' + BUNDLE + '.tar.gz', tarb.getvalue()),
        (VERSION + '/README_SGGF1666f.txt', readme_bytes),
    ]

    deploy_dir = WORK / 'deploy'
    deploy_dir.mkdir(exist_ok=True)
    (deploy_dir / 'index.html').write_text(index_html, encoding='utf-8')
    (deploy_dir / 'versions.html').write_text(versions_html, encoding='utf-8')
    (deploy_dir / 'versions.json').write_bytes(manifest_bytes)
    (deploy_dir / '_headers').write_bytes(old.read('_headers'))

    with zipfile.ZipFile(DEPLOY, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=8) as out:
        for member in old.infolist():
            payload = manifest_bytes if member.filename == 'versions.json' else old.read(member.filename)
            out.writestr(copy.copy(member), payload)
        for name, payload in additions:
            assert name not in old_names, f'Historical deployment path collision: {name}'
            out.writestr(name, payload)

# Verify deploy extension and all runtime bundles.
with zipfile.ZipFile(DEPLOY, 'r') as built, zipfile.ZipFile(BASE_DEPLOY, 'r') as old:
    assert built.testzip() is None
    deploy_names = built.namelist()
    assert len(deploy_names) == len(old_names) + 5 == 205
    assert len(deploy_names) == len(set(deploy_names))
    for name in old_names:
        if name != 'versions.json':
            assert built.read(name) == old.read(name), f'Historical deployment member changed: {name}'
    final_manifest = json.loads(built.read('versions.json'))
    assert len(final_manifest['versions']) == 40
    assert final_manifest['versions'][0]['version'] == VERSION
    assert final_manifest['versions'][0]['current'] is True
    assert final_manifest['versions'][0]['description'] == a_description
    assert final_manifest['versions'][1]['version'] == 'SGGF1.666e'
    assert final_manifest['versions'][1]['current'] is False
    for cell_version in ('SGGF1.666a', 'SGGF1.666b', 'SGGF1.666c', 'SGGF1.666d', 'SGGF1.666e', 'SGGF1.666f'):
        assert next(v for v in final_manifest['versions'] if v['version'] == cell_version)['description'] == a_description
    assert sum(1 for v in final_manifest['versions'] if v.get('current')) == 1
    with zipfile.ZipFile(io.BytesIO(built.read(VERSION + '/' + BUNDLE + '.apk'))) as runtime:
        assert runtime.testzip() is None
        assert runtime.namelist() == ['assets/main.py', 'assets/luma_assets_e33.json']
        assert runtime.read('assets/main.py') == code
        assert runtime.read('assets/luma_assets_e33.json') == assets_bytes
    with tarfile.open(fileobj=io.BytesIO(built.read(VERSION + '/' + BUNDLE + '.tar.gz')), mode='r:gz') as runtime:
        assert runtime.extractfile('assets/main.py').read() == code
        assert runtime.extractfile('assets/luma_assets_e33.json').read() == assets_bytes

# Build metadata describes only the intended F changes and records the exact E base.
meta = {
    'version': VERSION,
    'based_on': 'SGGF1.666e',
    'base_hashes': base_hashes,
    'previous_release_preserved': True,
    'repository': 'magiccozmo/QuackSink',
    'source_folder': 'ARCHIVES 8-30-2026/SGG/sggweb',
    'scope': [
        'Replace the HELLgs one-dimensional vertical fire wall with a two-dimensional staggered room-filling spread and a separate pursuing flame.',
        'End the run only when spreading fire or the pursuing flame physically contacts the player collision bounds.',
        'Reject M-key fast travel inside HELLgs Inn with the exact requested Cozmo message.',
        'Preserve F1.666e saves, run ledger, Tea, hints, world data, and cross-version save compatibility.',
    ],
    'fire_behavior': {
        'room_grid': '36 columns by 11 rows across the HELLgs cell interior.',
        'spread': 'Staggered doorway-origin wave spreads across the width and depth of the cell.',
        'chaser': 'A separate flame tongue pursues the player after the initial spread delay.',
        'game_over_condition': 'Only a detected overlap with an active fire tile or the pursuing flame collision radius.',
        'legacy_timer': 'Retained for compatibility/progress fields, but it no longer independently triggers Game Over.',
        'movement': 'Normal directional movement continues during the fire sequence so the player can attempt to evade it; non-movement interactions remain locked.',
    },
    'fast_travel': {
        'key': 'M',
        'cell_behavior': 'Refuse travel and do not open the travel map.',
        'message': 'no fast travel allowed here, didja really think it would be THAT easy?',
        'outside_cell': 'Existing fast travel handler is inherited unchanged.',
    },
    'preserved': [
        'F1.666e source and Cloudflare deployment archives were not modified.',
        'All inherited F1.666e classes are AST-identical to the immutable F1.666e baseline; only new F1666f classes and app wiring are added.',
        'F1.666e save compatibility, shared storage namespace, world and save slots remain intact.',
        'F1.666e run ledger, five Tea achievements, Cozmo cameo/hint progression and Game Over Quickload remain inherited.',
        'F1.666a front-door description is reused verbatim for F and remains non-spoiler.',
        'All 200 previous Cloudflare deployment entries are byte-for-byte unchanged except versions.json; five new F entries are added.',
    ],
    'tests': [
        'PASS Python AST parsing, module py_compile, and preparation script py_compile.',
        'PASS all inherited F1.666e class definitions preserved exactly by AST comparison.',
        'PASS exact HELLgs fast-travel refusal; existing outside-cell fast travel remains functional.',
        'PASS 36x11 room fire spreads completely and the normal spawn collision bounds are physically contacted.',
        'PASS separate pursuing flame advances faster than maximum configured player movement.',
        'PASS fire start closes modal UI and fast-travel overlay while preserving directional movement.',
        'PASS zero legacy countdown does not cause Game Over without actual fire/player contact.',
        'PASS actual fire/player contact triggers Game Over and inherited Quickload remains available.',
        'PASS Cloudflare deployment extension: 200 old entries retained byte-for-byte except versions.json; five F entries added.',
        'PASS packaged APK/TAR main.py and asset JSON match tested working files exactly.',
        'PASS catalogue retains the exact non-spoiler F1.666a description for all HELLgs cell-start releases A through F.',
    ],
    'runtime_note': 'Static and in-memory tests passed. A live browser/Pygame launch was not run because Pygame is not installed in this build environment; Cozmo field testing remains necessary.',
    'hashes': {
        'main_sha256': hashlib.sha256(code).hexdigest(),
        'assets_sha256': hashlib.sha256(assets_bytes).hexdigest(),
        'play_page_sha256': hashlib.sha256(page.encode('utf-8')).hexdigest(),
        'readme_sha256': hashlib.sha256(readme_bytes).hexdigest(),
        'deploy_zip_sha256': hashlib.sha256(DEPLOY.read_bytes()).hexdigest(),
    },
    'bytes': {'deploy': DEPLOY.stat().st_size},
    'deployment_entries': {
        'previous_entries': len(old_names),
        'new_entries': 5,
        'final_entries': len(old_names) + 5,
        'catalog_versions': 40,
    },
}
META_PATH.write_text(json.dumps(meta, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

# New source release starts as a full byte-for-byte copy of E's source archive,
# with only current F runtime/build/catalogue files replaced and new F files added.
with zipfile.ZipFile(BASE_SOURCE, 'r') as old:
    old_names_source = old.namelist()
    assert len(old_names_source) == 151 and len(old_names_source) == len(set(old_names_source))
    replacements = {
        'main.py': code,
        'luma_assets_e33.json': assets_bytes,
        'F1_play.html': page.encode('utf-8'),
        'test_f1666f.py': TEST.read_bytes(),
        'prepare_f1666f.py': PREPARE.read_bytes(),
        'package_f1666f.py': Path(__file__).read_bytes(),
        'README_SGGF1666f.txt': readme_bytes,
        'F1.666f_BUILD_META.json': META_PATH.read_bytes(),
        'deploy/versions.json': manifest_bytes,
    }
    for name in replacements:
        if name not in old_names_source:
            assert name not in old_names_source, f'Unexpected replacement path collision: {name}'
    additions_source = {}
    additions_source.update(new_snapshots)
    additions_source.update({
        'test_f1666f.py': TEST.read_bytes(),
        'prepare_f1666f.py': PREPARE.read_bytes(),
        'package_f1666f.py': Path(__file__).read_bytes(),
        'README_SGGF1666f.txt': readme_bytes,
        'F1.666f_BUILD_META.json': META_PATH.read_bytes(),
    })
    # New build scripts and README are not historical entries in E's source ZIP.
    for name in additions_source:
        assert name not in old_names_source, f'Historical source path collision: {name}'

    with zipfile.ZipFile(SOURCE, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as out:
        for member in old.infolist():
            payload = replacements.get(member.filename, old.read(member.filename))
            out.writestr(copy.copy(member), payload)
        for name, payload in additions_source.items():
            out.writestr(name, payload)

# Verify old E source payloads are untouched except explicitly replaced current files.
with zipfile.ZipFile(SOURCE, 'r') as built, zipfile.ZipFile(BASE_SOURCE, 'r') as old:
    assert built.testzip() is None
    built_names = built.namelist()
    assert len(built_names) == len(old_names_source) + len(additions_source)
    assert len(built_names) == len(set(built_names))
    for name in old_names_source:
        if name not in replacements:
            assert built.read(name) == old.read(name), f'Historical E source member changed: {name}'
    assert built.read('main.py') == code
    assert built.read('luma_assets_e33.json') == assets_bytes
    assert built.read('F1_play.html') == page.encode('utf-8')
    assert built.read('README_SGGF1666f.txt') == readme_bytes
    assert built.read('F1.666f_BUILD_META.json') == META_PATH.read_bytes()
    assert built.read('deploy/versions.json') == manifest_bytes
    for name, payload in new_snapshots.items():
        assert built.read(name) == payload

# Verify the finished source archive. Its own hash is reported externally rather
# than embedded inside itself (which would make the metadata self-referential).
with zipfile.ZipFile(SOURCE, 'r') as built:
    assert built.testzip() is None
    assert built.read('F1.666f_BUILD_META.json') == META_PATH.read_bytes()
    assert built.read('main.py') == code
    assert built.read('deploy/versions.json') == manifest_bytes

# Ensure E archives have the exact same hash after building F.
assert hashlib.sha256(BASE_SOURCE.read_bytes()).hexdigest() == EXPECTED_BASE_SOURCE_SHA256
assert hashlib.sha256(BASE_DEPLOY.read_bytes()).hexdigest() == EXPECTED_BASE_DEPLOY_SHA256

print('PASS F1.666f build/test/package checks.')
print(f'PASS deploy: {len(old_names)} prior entries retained except versions.json; 5 F entries added.')
print(f'PASS source: {len(old_names_source)} E entries retained/updated, {len(additions_source)} F build/snapshot files added.')
print('DEPLOY:', DEPLOY, DEPLOY.stat().st_size, 'bytes')
print('DEPLOY SHA256:', hashlib.sha256(DEPLOY.read_bytes()).hexdigest())
print('SOURCE:', SOURCE, SOURCE.stat().st_size, 'bytes')
print('SOURCE SHA256:', hashlib.sha256(SOURCE.read_bytes()).hexdigest())
print('MAIN SHA256:', hashlib.sha256(code).hexdigest())
print('ASSETS SHA256:', hashlib.sha256(assets_bytes).hexdigest())
