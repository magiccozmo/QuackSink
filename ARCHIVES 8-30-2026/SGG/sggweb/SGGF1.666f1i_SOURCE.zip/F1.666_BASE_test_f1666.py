from __future__ import annotations
import ast
import copy
import importlib.util
import json
from pathlib import Path
import re
import sys

W = Path(__file__).resolve().parent
MAIN = W / 'main.py'
ASSETS = W / 'luma_assets_e33.json'
PAGE = W / 'F1_play.html'
BASE_MAIN = W / 'F1.6_BASE_MAIN.py'
BASE_ASSETS = W / 'F1.6_BASE_LUMA_ASSETS.json'
BASE_PAGE = W / 'F1.6_BASE_F1_play.html'

src = MAIN.read_text(encoding='utf-8')
ast.parse(src)
compile(src, str(MAIN), 'exec')
assert 'VERSION = "F1.666"' in src
assert 'machine = F1666StateMachine(archive, config, warning)' in src
assert 'ui = F1666Interface(machine)' in src
assert 'class F1666StateMachine(F1StateMachine)' in src
assert 'class F1666Interface(F1Interface)' in src
assert 'Initial End Timer in Minutes' in src
assert "g.c1_day >=" not in src  # day check is numeric and integer-based
assert "start_day + 1" in src and "initial_end_timer_minutes * 60.0" in src
assert "g.current_area_id != 'hellgs_inn'" in src
assert "g.c1_flags.get('hellgs_game_over')" in src
assert "selected.kind == 'paper'" in src
assert 'PRESS R TO RESPAWN' not in src[src.index('class F1666Interface'):]

# The existing F1.6 feature classes are byte-for-byte unchanged.
def class_segment(text, class_name):
    tree = ast.parse(text)
    node = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == class_name)
    return ast.get_source_segment(text, node)
base_source = BASE_MAIN.read_text(encoding='utf-8')
assert class_segment(src, 'F1StateMachine') == class_segment(base_source, 'F1StateMachine')
assert class_segment(src, 'F1Interface') == class_segment(base_source, 'F1Interface')

# JSON changes are strictly additive plus initial area/player spawn and release notes.
base = json.loads(BASE_ASSETS.read_text(encoding='utf-8'))
doc = json.loads(ASSETS.read_text(encoding='utf-8'))
assert doc['version'] == 'SGGF1.666'
assert doc['world']['initial_area'] == 'hellgs_inn'
assert doc['world']['player_start'] == {'x': 640, 'y': 480}
assert len(doc['world']['areas']) == len(base['world']['areas']) + 1
assert len(doc['world']['objects']) == len(base['world']['objects']) + 1
assert set(doc['assets']) == set(base['assets']) | {'c1_bg_hellgs_inn', 'paper'}
for key, value in base['assets'].items():
    assert doc['assets'][key] == value, f'Existing asset changed: {key}'
for key in ('areas', 'connections', 'objects', 'npcs', 'player', 'market_title'):
    existing = doc['world'][key][:len(base['world'][key])] if isinstance(base['world'][key], list) else doc['world'][key]
    assert existing == base['world'][key], f'Existing world data changed: {key}'
hell = next(a for a in doc['world']['areas'] if a['area_id'] == 'hellgs_inn')
assert hell['display_name'] == 'HELLgs Inn'
assert hell['vendors'] == [] and hell['sight_blockers'] == [] and hell['conceal_zones'] == []
assert hell['navigation']['regions'] == [[[207, 306], [1073, 306], [1073, 542], [207, 542]]]
assert any(rect == [545, 160, 190, 114] for rect in hell['solid_rects'])
assert all(not ('hellgs' in str(c).lower()) for c in doc['world']['connections'])
assert all(o.get('object_id') != 'hellgs_cell_door' for o in doc['world']['objects'])
note = next(o for o in doc['world']['objects'] if o['object_id'] == 'hellgs_note')
assert note['kind'] == 'paper' and note['takeable'] is True and note['area_id'] == 'hellgs_inn'
# Whole-document scope lock: exact F1.6 baseline plus the HELLgs Inn additions.
expected = copy.deepcopy(base)
expected['version'] = doc['version']
expected['notes'] = doc['notes']
expected['world']['initial_area'] = doc['world']['initial_area']
expected['world']['player_start'] = doc['world']['player_start']
expected['world']['areas'].append(copy.deepcopy(hell))
expected['world']['objects'].append(copy.deepcopy(note))
for key in ('c1_bg_hellgs_inn', 'paper'):
    expected['assets'][key] = copy.deepcopy(doc['assets'][key])
assert doc == expected, 'F1.6 baseline changed outside the HELLgs Inn addition and new start/release metadata.'
allowed = {'rect', 'line', 'polygon', 'circle', 'ellipse'}
for asset_name in ('c1_bg_hellgs_inn', 'paper'):
    recipe = doc['assets'][asset_name]
    assert recipe['width'] > 0 and recipe['height'] > 0
    assert all(command.get('op') in allowed for command in recipe['commands'])

# Geometric checks use the same foot anchor offset as E3GameModel.
def point_in_polygon(x, y, polygon):
    inside = False
    last_x, last_y = polygon[-1]
    for px, py in polygon:
        if ((py > y) != (last_y > y)):
            ix = px + (last_x - px) * (y - py) / (last_y - py)
            if x < ix:
                inside = not inside
        last_x, last_y = px, py
    return inside
poly = hell['navigation']['regions'][0]
assert point_in_polygon(640, 494, poly)  # starting player's foot is on the cell floor
assert point_in_polygon(400, 400, poly)  # room can be walked around
assert not point_in_polygon(640, 274, poly)  # cell door / wall is not walkable
assert not point_in_polygon(640, 580, poly)  # beyond the front wall is not walkable
assert not point_in_polygon(160, 420, poly)  # outside the left wall is not walkable
# Player body (26x36) touches, but never overlaps, the solid cell door at the nav boundary.
player_center_y = 292
player_top = player_center_y - 18
assert player_top >= 274

# Verify normal fast-travel code has not been altered.
assert class_segment(src, 'E33StateMachine') == class_segment(base_source, 'E33StateMachine')

# Config normalization is a small pure helper, safe to import without starting SDL.
spec = importlib.util.spec_from_file_location('sgg_f1666_main', MAIN)
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)
assert module._normalized_config({})['initial_end_timer_minutes'] == 60
assert module._normalized_config({'initial_end_timer_minutes': 0})['initial_end_timer_minutes'] == 1
assert module._normalized_config({'initial_end_timer_minutes': 2000})['initial_end_timer_minutes'] == 1440
assert module._normalized_config({'initial_end_timer_minutes': '123'})['initial_end_timer_minutes'] == 123

# Verify deadline logic directly with small stand-ins.
class Fake:
    initial_end_timer_minutes = 60
fake = Fake()
class Flags(dict): pass
class Game:
    c1_flags = Flags({'hellgs_start_day': 1, 'hellgs_start_elapsed': 100.0})
    c1_day = 1
    c1_elapsed = 100.0
game = Game()
assert module.F1666StateMachine._hellgs_due(fake, game) == (False, False, False)
game.c1_day = 2
assert module.F1666StateMachine._hellgs_due(fake, game) == (True, True, False)
game.c1_day = 1
game.c1_elapsed = 3700.0
assert module.F1666StateMachine._hellgs_due(fake, game) == (True, False, True)

# Browser bundle must be unique to F1.666 and reference matching runtime files.
page = PAGE.read_text(encoding='utf-8')
assert 'SGGF1.666' in page and 'F1.666' in page
assert 'sggf1666.apk' in page and 'sggf1666.tar.gz' in page
assert 'archive:"sggf1666"' in page and 'bundle = "sggf1666"' in page
assert 'F1.66666' not in page

print('PASS F1.666 static runtime, timer, note, sealed-room geometry, baseline preservation, fast-travel preservation, and browser bootstrap checks.')
