from __future__ import annotations
import ast, json, zipfile, tarfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
VERSION = "SGGF1.666f1f"
PACKAGE = "sggf1666f1f"

current = json.loads((ROOT / "luma_assets_e33.json").read_text(encoding="utf-8"))
base = json.loads((ROOT / "SGGF1.666f1e" / "assets" / "luma_assets_e33.json").read_text(encoding="utf-8"))
gate = current["assets"]["city_gate_double_leaf"]
obj = next(o for o in current["world"]["objects"] if o["object_id"] == "city_gate_door")
old_obj = next(o for o in base["world"]["objects"] if o["object_id"] == "city_gate_door")

assert gate["width"] == 200 and gate["height"] == 128
assert len(gate["commands"]) >= 50
assert all(c["op"] in {"rect", "line", "polygon", "circle", "ellipse"} for c in gate["commands"])
assert obj["kind"] == "door" and obj["area_id"] == "front_gate"
assert (obj["x"], obj["y"], obj["width"], obj["height"]) == (540, 316, 200, 128)
assert obj["walk_trigger"] == old_obj["walk_trigger"]
for key in ("object_id", "name", "kind", "area_id", "takeable", "stealable", "on_shelf", "walk_trigger"):
    assert obj.get(key) == old_obj.get(key), key
assert current["world"]["connections"] == base["world"]["connections"]
assert current["world"]["areas"] == base["world"]["areas"]
for key, value in base["assets"].items():
    assert current["assets"][key] == value, f"Existing asset changed: {key}"

main = (ROOT / "main.py").read_text(encoding="utf-8")
ast.parse(main)
assert 'VERSION = "F1.666f1f"' in main
assert "class F1666f1fInterface(F1666f1Interface):" in main
assert "ui = F1666f1fInterface(machine)" in main
assert "name = 'city_gate_double_leaf'" in main

version_dir = ROOT / VERSION
assert (version_dir / "play.html").is_file()
assert (version_dir / "assets" / "main.py").read_bytes() == (ROOT / "main.py").read_bytes()
assert (version_dir / "assets" / "luma_assets_e33.json").read_bytes() == (ROOT / "luma_assets_e33.json").read_bytes()
with zipfile.ZipFile(version_dir / f"{PACKAGE}.apk") as z:
    assert z.testzip() is None
    assert set(z.namelist()) == {"assets/main.py", "assets/luma_assets_e33.json"}
with tarfile.open(version_dir / f"{PACKAGE}.tar.gz", "r:gz") as t:
    assert set(t.getnames()) == {"assets/main.py", "assets/luma_assets_e33.json"}

print("F1.666f1f regression checks PASS")
