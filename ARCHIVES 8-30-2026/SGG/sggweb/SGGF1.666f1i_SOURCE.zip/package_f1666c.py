from pathlib import Path
import ast
import copy
import gzip
import hashlib
import io
import json
import subprocess
import sys
import tarfile
import zipfile

WORK = Path(__file__).resolve().parent
ROOT = Path('/mnt/data')
MAIN = WORK / 'main.py'
ASSETS = WORK / 'luma_assets_e33.json'
PLAY = WORK / 'F1_play.html'
README = WORK / 'README_SGGF1666c.txt'
TEST = WORK / 'test_f1666c.py'
PREPARE = WORK / 'prepare_f1666c.py'
REVISE = WORK / 'revise_f1666c.py'
BASE_DEPLOY = ROOT / 'SGGF1.666b_CLOUDFLARE_DEPLOY.zip'
BASE_SOURCE = ROOT / 'SGGF1.666b_SOURCE.zip'
DEPLOY = ROOT / 'SGGF1.666c_CLOUDFLARE_DEPLOY.zip'
SOURCE = ROOT / 'SGGF1.666c_SOURCE.zip'
META_PATH = WORK / 'F1.666c_BUILD_META.json'
VERSION = 'SGGF1.666c'
BUNDLE = 'sggf1666c'

for path in (MAIN, ASSETS, PLAY, README, TEST, PREPARE, REVISE, BASE_DEPLOY, BASE_SOURCE):
    assert path.is_file(), f'Missing build input: {path}'
# This is an immutable archive build. Never replace any existing F1.666c output.
assert not DEPLOY.exists(), f'Refusing to replace existing archive: {DEPLOY}'
assert not SOURCE.exists(), f'Refusing to replace existing archive: {SOURCE}'

code = MAIN.read_bytes()
assets_bytes = ASSETS.read_bytes()
assets_doc = json.loads(assets_bytes)
page = PLAY.read_text(encoding='utf-8')
readme_bytes = README.read_bytes()
assert assets_doc['version'] == VERSION
assert b'VERSION = "F1.666c"' in code
assert all(token in page for token in (
    'SGGF1.666c', 'sggf1666c.apk', 'sggf1666c.tar.gz',
    'archive:"sggf1666c"', 'bundle = "sggf1666c"'))
assert 'sggf1666b.apk' not in page and 'sggf1666b.tar.gz' not in page
ast.parse(code.decode('utf-8'))
subprocess.run([sys.executable, '-m', 'py_compile', str(MAIN), str(TEST)], cwd=WORK, check=True)
subprocess.run([sys.executable, str(TEST)], cwd=WORK, check=True)

# Keep all existing F1.666b world definitions, assets and recipes byte/data-identical.
with zipfile.ZipFile(BASE_DEPLOY, 'r') as old:
    assert old.testzip() is None
    old_names = old.namelist()
    assert len(old_names) == 185 and len(old_names) == len(set(old_names))
    required_old = (
        'index.html', 'versions.html', 'versions.json', '_headers',
        'SGGF1.666b/play.html', 'SGGF1.666b/favicon.png',
        'SGGF1.666b/sggf1666b.apk', 'SGGF1.666b/sggf1666b.tar.gz',
        'SGGF1.666b/README_SGGF1666b.txt',
        'SGGF1.666a/play.html', 'SGGF1.666a/README_SGGF1666a.txt',
    )
    for name in required_old:
        assert name in old_names, f'Missing historical member: {name}'

    base_manifest = json.loads(old.read('versions.json'))
    assert len(base_manifest['versions']) == 36
    a_release = next(v for v in base_manifest['versions'] if v['version'] == 'SGGF1.666a')
    b_release = next(v for v in base_manifest['versions'] if v['version'] == 'SGGF1.666b')
    a_description = a_release['description']
    assert a_description.endswith('woops.. now it IS possible to escape')
    assert 'alternating Yorkshire Tea rewards' in b_release['description']

    # Build the two identical runtime payloads for the browser platforms.
    apkb = io.BytesIO()
    with zipfile.ZipFile(apkb, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as apk:
        apk.writestr('assets/main.py', code)
        apk.writestr('assets/luma_assets_e33.json', assets_bytes)

    tarb = io.BytesIO()
    with gzip.GzipFile(fileobj=tarb, mode='wb', compresslevel=9, mtime=0) as gz:
        with tarfile.open(fileobj=gz, mode='w') as tf:
            for name, payload in (
                ('assets/main.py', code),
                ('assets/luma_assets_e33.json', assets_bytes),
            ):
                info = tarfile.TarInfo(name)
                info.size = len(payload)
                info.mode = 0o644
                info.mtime = 0
                tf.addfile(info, io.BytesIO(payload))

    manifest = copy.deepcopy(base_manifest)
    for entry in manifest['versions']:
        entry['current'] = False
    manifest['versions'].insert(0, {
        'version': VERSION,
        'title': 'SGGF1.666c — Cozmo’s Exploit Recognition',
        'path': VERSION + '/play.html',
        # The user explicitly requested the F1.666a description verbatim.
        'description': a_description,
        'current': True,
    })
    manifest_bytes = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode('utf-8')

    index_html = old.read('index.html').decode('utf-8')
    versions_html = old.read('versions.html').decode('utf-8')
    for label, html in (('index.html', index_html), ('versions.html', versions_html)):
        assert '[a-z]?' in html, f'{label} does not support alphabetic version suffixes.'
        assert 'navigator.userAgentData?.mobile' in html
    favicon = old.read('SGGF1.666b/favicon.png')
    additions = [
        (VERSION + '/play.html', page.encode('utf-8')),
        (VERSION + '/favicon.png', favicon),
        (VERSION + '/' + BUNDLE + '.apk', apkb.getvalue()),
        (VERSION + '/' + BUNDLE + '.tar.gz', tarb.getvalue()),
        (VERSION + '/README_SGGF1666c.txt', readme_bytes),
    ]

    deploy_dir = WORK / 'deploy'
    deploy_dir.mkdir(exist_ok=True)
    (deploy_dir / 'index.html').write_text(index_html, encoding='utf-8')
    (deploy_dir / 'versions.html').write_text(versions_html, encoding='utf-8')
    (deploy_dir / 'versions.json').write_bytes(manifest_bytes)
    (deploy_dir / '_headers').write_bytes(old.read('_headers'))

    with zipfile.ZipFile(DEPLOY, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=8) as out:
        for member in old.infolist():
            payload = manifest_bytes if member.filename == 'versions.json' else old.read(member.filename)
            out.writestr(copy.copy(member), payload)
        for name, payload in additions:
            assert name not in old_names, f'Historical deployment path collision: {name}'
            out.writestr(name, payload)

# Validate no historical deployment member was replaced except the catalogue.
with zipfile.ZipFile(DEPLOY, 'r') as built, zipfile.ZipFile(BASE_DEPLOY, 'r') as old:
    assert built.testzip() is None
    names = built.namelist()
    assert len(names) == len(old_names) + len(additions) == 190
    assert len(names) == len(set(names))
    for name in old_names:
        if name != 'versions.json':
            assert built.read(name) == old.read(name), f'Historical deployment member changed: {name}'
    final_manifest = json.loads(built.read('versions.json'))
    assert len(final_manifest['versions']) == 37
    assert final_manifest['versions'][0]['version'] == VERSION
    assert final_manifest['versions'][0]['current'] is True
    assert final_manifest['versions'][0]['description'] == a_description
    assert final_manifest['versions'][1]['version'] == 'SGGF1.666b'
    assert final_manifest['versions'][1]['current'] is False
    assert next(v for v in final_manifest['versions'] if v['version'] == 'SGGF1.666a')['description'] == a_description
    assert sum(1 for v in final_manifest['versions'] if v.get('current')) == 1
    with zipfile.ZipFile(io.BytesIO(built.read(VERSION + '/' + BUNDLE + '.apk'))) as runtime:
        assert runtime.testzip() is None
        assert runtime.namelist() == ['assets/main.py', 'assets/luma_assets_e33.json']
        assert runtime.read('assets/main.py') == code
        assert runtime.read('assets/luma_assets_e33.json') == assets_bytes
    with tarfile.open(fileobj=io.BytesIO(built.read(VERSION + '/' + BUNDLE + '.tar.gz')), mode='r:gz') as runtime:
        assert runtime.extractfile('assets/main.py').read() == code
        assert runtime.extractfile('assets/luma_assets_e33.json').read() == assets_bytes

# Add immutable F1.666c source snapshots so the next release has an exact base.
for source_name, snapshot_name in (
    ('main.py', 'F1.666c_BASE_MAIN.py'),
    ('luma_assets_e33.json', 'F1.666c_BASE_LUMA_ASSETS.json'),
    ('F1_play.html', 'F1.666c_BASE_F1_play.html'),
    ('README_SGGF1666c.txt', 'F1.666c_BASE_README.txt'),
    ('test_f1666c.py', 'F1.666c_BASE_TEST_F1666C.py'),
    ('prepare_f1666c.py', 'F1.666c_BASE_PREPARE_F1666C.py'),
    ('revise_f1666c.py', 'F1.666c_BASE_REVISE_F1666C.py'),
):
    snapshot = WORK / snapshot_name
    assert not snapshot.exists(), f'Refusing to replace source snapshot: {snapshot_name}'
    snapshot.write_bytes((WORK / source_name).read_bytes())

meta = {
    'version': VERSION,
    'based_on': 'SGGF1.666b',
    'base_source_git_blob_sha': '5a7414f9ce54ad348a842b4e3ddf902ad2bc15d5',
    'base_deploy_git_blob_sha': '33cba5d5ee7ffa65e1917b54260cf6955bacc3b4',
    'previous_release_preserved': True,
    'repository': 'magiccozmo/QuackSink',
    'source_folder': 'ARCHIVES 8-30-2026/SGG/sggweb',
    'scope': 'Five once-only Cozmo exploit recognitions with a visible Tea Earned score, plus Quickload-after-death and three no-tea HELLgs hint milestones. No exploit path is patched or restricted.',
    'front_door_description_source': 'SGGF1.666a; copied verbatim; no F1.666b spoiler expansion.',
    'tea_achievements': {
        'events': ['hellgs_escape', 'bucket_theft', 'vault_clip', 'naz_guard_death', 'lout_guard_death'],
        'once_only': True,
        'first_award': 'hellgs_escape',
        'pending_rule': 'Other exploit recognitions discovered before HELLgs escape are held pending so the escape is always Tea #1.',
        'display': 'Visible TEA EARNED counter; no Yorkshire Tea inventory object is created.',
        'storage': 'Shared persistent sgg.config / browser E1Storage, outside individual save slots.',
        'legacy_migration': 'A nonzero F1.666b cozmo_exploiter_appearances value proves HELLgs escape was already recognized; migrate once as hellgs_escape with Tea Earned=1.',
    },
    'death_reload_hints': {
        'counter_start': 0,
        'increment': 'Only after a successful quickload made while the previous game was dead.',
        'quickload_access': 'Game Over button and existing configured quickload key.',
        'milestones': {
            '4': 'First interactive hint; asks whether player really wants help, followed by the DIFFERENT save hint.',
            '10': 'Automatic spoken line, then one interactive hint about forward-compatible saves and the raised eyebrow stage direction.',
            '20': 'Automatic spoken offer, admission-of-defeat choice, complete save-load exploit spoiler, then Cozmo vanishes.',
        },
        'tea_awarded': False,
        'storage': 'Persistent config outside individual save slots; reset to zero on new actual run.',
    },
    'save_compatibility': {
        'schema': 'spiffys-gift-save-v1',
        'policy': 'Preserve F1.666b central additive migration: old save area, coordinates and saved gameplay state remain authoritative; missing current objects/NPCs/fields receive defaults.',
        'area_ids': 'Keep existing area IDs valid; renamed/retired areas require explicit alias migration.',
    },
    'preserved': [
        'F1.666, F1.666a and F1.666b source and deployment archives are not replaced.',
        'F1.666b world geometry, world objects, area links, Luma recipes, fast travel, bucket/theft, vault clipping and NPC/guard mechanics are unchanged.',
        'F1.666a front-door description is reused exactly; F1.666b spoiler expansion is not copied.',
        'The five exploit recognitions and Tea score are independent of individual save slots.',
        'No new exit, escape path, exploit patch, anti-exploit restriction or death-hint Tea reward was added.',
        'All 185 previous deployment entries are byte-for-byte unchanged except versions.json; five distinct F1.666c entries are added.',
    ],
    'tests': [
        'PASS AST parse, module import and py_compile.',
        'PASS actual D1.1 cameo-queue runtime checks for bucket theft, Naz guard death, vault clip and Lout guard death.',
        'PASS HELLgs escape cameo + Tea #1; repeated event awards are rejected.',
        'PASS non-HELLgs achievements discovered first remain pending until escape; escape releases them after Tea #1.',
        'PASS fourth/tenth/twentieth hint cameo queue and progression; hint appearances award no Tea.',
        'PASS no Yorkshire Tea inventory object; visible TEA EARNED counter only.',
        'PASS F1.666b shared save migration, F1.6 fast-travel/game-over paths and core D1.1 mechanics remain unchanged.',
        'PASS HELLgs description copied verbatim from F1.666a; no F1.666b spoiler expansion.',
        'PASS all 185 old Cloudflare deployment entries retained byte-for-byte except versions.json; five F1.666c files added; runtime APK/TAR contain exact tested files.',
    ],
    'runtime_note': 'Static and in-memory runtime-queue checks passed. A live browser/Pygame launch was not run in this build environment; field testing remains necessary.',
    'hashes': {
        'main_sha256': hashlib.sha256(code).hexdigest(),
        'assets_sha256': hashlib.sha256(assets_bytes).hexdigest(),
        'base_deploy_sha256': hashlib.sha256(BASE_DEPLOY.read_bytes()).hexdigest(),
        'deploy_sha256': hashlib.sha256(DEPLOY.read_bytes()).hexdigest(),
        'base_source_sha256': hashlib.sha256(BASE_SOURCE.read_bytes()).hexdigest(),
    },
    'bytes': {'deploy': DEPLOY.stat().st_size},
    'deployment_entries': {
        'previous_entries': len(old_names),
        'new_entries': len(additions),
        'final_entries': len(old_names) + len(additions),
        'catalog_versions': 37,
    },
}
META_PATH.write_text(json.dumps(meta, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

# Package the complete new source, its tests, release tooling, and all version
# snapshots. The generated deploy index/catalog are included for easy access.
source_files = []
for path in sorted(WORK.iterdir()):
    if not path.is_file() or path.suffix.lower() in ('.zip', '.pyc') or path.name.startswith('.'):
        continue
    source_files.append((path.name, path))
for name in ('index.html', 'versions.html', 'versions.json', '_headers'):
    path = WORK / 'deploy' / name
    assert path.is_file()
    source_files.append(('deploy/' + name, path))
assert len({name for name, _ in source_files}) == len(source_files)
with zipfile.ZipFile(SOURCE, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as out:
    for arcname, path in source_files:
        out.write(path, arcname)
with zipfile.ZipFile(SOURCE, 'r') as z:
    assert z.testzip() is None
    assert z.read('main.py') == code
    assert z.read('luma_assets_e33.json') == assets_bytes
    assert z.read('F1_play.html') == page.encode('utf-8')
    assert z.read('README_SGGF1666c.txt') == readme_bytes
    assert z.read('F1.666c_BUILD_META.json') == META_PATH.read_bytes()
    assert len(z.namelist()) == len(source_files) == len(set(z.namelist()))

print(f'PASS deployment: {len(old_names)} prior entries retained; {len(additions)} F1.666c entries added.')
print(f'PASS source ZIP: {len(source_files)} source/build/history components.')
print('DEPLOY:', DEPLOY, DEPLOY.stat().st_size, 'bytes')
print('DEPLOY SHA256:', hashlib.sha256(DEPLOY.read_bytes()).hexdigest())
print('SOURCE:', SOURCE, SOURCE.stat().st_size, 'bytes')
print('SOURCE SHA256:', hashlib.sha256(SOURCE.read_bytes()).hexdigest())
print('MAIN SHA256:', meta['hashes']['main_sha256'])
print('ASSETS SHA256:', meta['hashes']['assets_sha256'])
