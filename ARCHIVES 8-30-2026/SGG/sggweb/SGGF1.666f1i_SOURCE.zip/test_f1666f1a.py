from pathlib import Path
import ast, json, zipfile, tarfile, io
W=Path(__file__).resolve().parent
main=(W/'main.py').read_text(encoding='utf-8')
ast.parse(main)
assert 'VERSION = "F1.666f1a"' in main
assert 'class F1666f1StateMachine(F1666fStateMachine):' in main
assert 'class F1666f1Interface(F1666fInterface):' in main
assets=json.loads((W/'luma_assets_e33.json').read_text(encoding='utf-8'))
assert assets['version']=='SGGF1.666f1a'
idx=(W/'deploy'/'index.html').read_text(encoding='utf-8')
vers=(W/'deploy'/'versions.html').read_text(encoding='utf-8')
assert idx==vers
assert '.card.no-art{grid-template-columns:minmax(0,1fr)}' in idx
assert '.card-copy{width:100%;min-width:0;align-self:stretch}' in idx
assert "article.className = entry.image ? 'card has-art' : 'card no-art';" in idx
cat=json.loads((W/'deploy'/'versions.json').read_text(encoding='utf-8'))
assert cat['versions'][0]['version']=='SGGF1.666f1a'
assert cat['versions'][0]['current'] is True and cat['versions'][0]['image'].endswith('/hell.png')
assert sum(bool(v.get('current')) for v in cat['versions'])==1
print('PASS F1.666f1a source test')
