from __future__ import annotations
import json, math, random
from pathlib import Path

W,H=1280,640
C=[]
def add(op, **kw): C.append({'op':op, **kw})
def rect(x,y,w,h,color,border=0,radius=0):
    add('rect',rect=[int(x),int(y),int(w),int(h)],color=list(color),border=border,radius=radius)
def line(points,color,width=1):
    add('line',points=[[int(x),int(y)] for x,y in points],color=list(color),width=width)
def poly(points,color,border=0):
    add('polygon',points=[[int(x),int(y)] for x,y in points],color=list(color),border=border)
def ellipse(x,y,w,h,color,border=0):
    add('ellipse',rect=[int(x),int(y),int(w),int(h)],color=list(color),border=border)
def circle(x,y,r,color,border=0):
    add('circle',center=[int(x),int(y)],radius=int(r),color=list(color),border=border)

def mix(a,b,t): return tuple(round(a[i]*(1-t)+b[i]*t) for i in range(3))

# 1. Calm blue sky, distant hills, and warm late-afternoon light.
for y in range(0,89,8):
    t=min(1,y/281)
    rect(0,y,W,8,mix((71,123,157),(127,166,177),t))
# soft cloud groups
for x,y,s in [(105,28,.62),(380,22,.52),(900,30,.58),(1100,36,.48)]:
    col=(224,229,214)
    ellipse(x,y+8,int(120*s),int(21*s),col)
    ellipse(x+24*s,y,int(60*s),int(34*s),col)
    ellipse(x+65*s,y+7*s,int(84*s),int(24*s),col)
# distant mountain silhouettes, kept low enough to frame the architecture
poly([(0,330),(118,264),(242,322),(367,251),(500,330),(650,270),(790,330),(935,254),(1070,323),(1182,267),(1280,315),(1280,392),(0,392)],(100,133,124))
poly([(0,365),(166,295),(305,359),(474,286),(634,366),(800,302),(972,365),(1115,295),(1280,354),(1280,430),(0,430)],(118,145,124))
# distant pines and shrubs
for x,y,s in [(34,334,.85),(175,345,.65),(1085,335,.75),(1240,348,.9),(455,344,.45),(830,341,.5)]:
    rect(x-3*s,y,6*s,35*s,(87,78,59))
    for j in range(3):
        yy=y-j*13*s
        poly([(x,yy-28*s),(x-17*s,yy),(x+17*s,yy)],(53,91,72))

# 2. Open grassy town court. The existing Market-facing arrival point
# (x=640,y=115) stands on the courtyard lawn. There is no narrow road shooting
# up to the screen edge; the Market transition is marked by its normal arrow.
for y in range(86,641,8):
    t=(y-86)/554
    base=(122,150,97)
    light=(139,160,105)
    col=tuple(round(base[i]*(1-t*.12)+light[i]*(t*.12)) for i in range(3))
    rect(0,y,W,8,col)
# broad, soft lawn variations and distant low planting; keep the arrival lane open
for x,y,w,h in [(20,102,280,58),(980,105,280,60),(0,202,230,58),(1050,205,230,55)]:
    ellipse(x,y,w,h,(129,154,100))
for x,y in [(80,118),(180,154),(1100,120),(1205,165),(365,128),(920,135)]:
    line([(x,y+13),(x-2,y)],(72,119,72),2)
    line([(x,y+13),(x+5,y+2)],(83,132,78),2)
    circle(x-2,y-2,2,(222,196,134))
    circle(x+5,y+2,2,(206,174,196))

# 3. Town wall, pale stonework, battlements and flanking towers.
# wall shadow/base
rect(0,276,W,151,(80,84,76))
rect(0,263,W,153,(158,157,139))
rect(0,260,W,13,(198,190,164))
rect(0,405,W,22,(93,94,82))
# rear wall courses, irregular blocks with outlines and highlights
rng=random.Random(16661)
for row,y in enumerate(range(276,405,22)):
    x=-22-(row%2)*34
    while x<1300:
        bw=rng.choice([48,54,60,66,72])
        col=rng.choice([(171,169,151),(180,177,157),(157,158,143),(190,184,162)])
        rect(x,y,bw-2,19,col,border=1)
        line([(x+4,y+3),(x+bw-8,y+3)],(204,198,176),1)
        x+=bw
# crenellated parapet along visible wall sections
for x in list(range(8,470,45))+list(range(810,1275,45)):
    rect(x,238,29,31,(152,153,139),border=2)
    rect(x+3,241,23,5,(196,191,171))
# towers flanking gate: simple square crenellated turrets
for tx in (78,1080):
    rect(tx,154,122,270,(123,129,119),border=4)
    rect(tx+8,163,106,253,(174,174,153),border=0)
    # courses
    for yy in range(175,408,24):
        line([(tx+8,yy),(tx+114,yy)],(121,128,119),2)
        for xx in (tx+40,tx+82): line([(xx,yy-22),(xx,yy)],(135,140,127),1)
    # upper parapet / battlements
    rect(tx-7,145,136,20,(87,94,88),border=2)
    for bx in range(tx-5,tx+128,26):
        rect(bx,130,17,20,(164,165,146),border=2)
        rect(bx+3,133,11,4,(205,198,174))
    # narrow tower window
    rect(tx+43,224,38,80,(62,68,66),border=4)
    rect(tx+48,230,28,68,(93,119,119))
    rect(tx+51,233,9,60,(180,185,160))
    rect(tx+64,233,9,60,(205,177,120))
    line([(tx+62,230),(tx+62,299)],(67,65,55),3)
    line([(tx+47,264),(tx+77,264)],(67,65,55),3)
# projecting stone buttresses
for x in (62,200,1060,1198):
    poly([(x,396),(x+20,384),(x+38,396),(x+33,423),(x+4,423)],(111,119,109))
    line([(x+5,402),(x+32,402)],(188,184,160),2)

# 4. Gatehouse wings: two handsome town buildings in the newer SGG style.
# Left armory/guardhouse body
poly([(198,246),(356,163),(514,246)],(66,48,43))
poly([(207,245),(356,175),(505,245)],(155,87,66))
# roof tiles, individually traced
for i in range(12):
    x=220+i*23
    ytop=174+abs(x-356)*0.48
    line([(x,ytop),(x+8,ytop+9)],(190,121,89),2)
    line([(x+7,ytop+9),(x+15,ytop+18)],(112,66,57),1)
rect(222,244,269,173,(211,188,148),border=4)
rect(232,253,249,154,(226,208,172))
# timber frame and stone base
for x in (233,253,480): rect(x,248,9,165,(106,69,48))
rect(220,398,282,22,(111,100,80),border=2)
for x in range(226,500,34):
    line([(x,400),(x+16,417)],(174,164,139),1)
# upper windows
for x in (263,403):
    rect(x,275,54,63,(77,53,39),border=4)
    rect(x+5,280,44,52,(97,131,138))
    rect(x+8,283,17,46,(205,176,122))
    rect(x+29,283,17,46,(154,177,167))
    line([(x+27,280),(x+27,333)],(76,56,41),3)
    line([(x+5,306),(x+49,306)],(76,56,41),3)
    rect(x-3,272,60,6,(135,91,61))
    rect(x-3,338,60,6,(119,86,58))
# armory door on left wing
rect(334,344,56,72,(66,45,33),border=4)
rect(340,350,44,65,(124,78,47))
rect(346,356,32,59,(83,51,35))
line([(362,353),(362,414)],(165,112,66),2)
circle(374,385,3,(229,190,101))
# warm hanging lanterns beside door
for x in (323,399):
    line([(x,337),(x,350)],(63,51,39),3)
    rect(x-7,349,14,25,(75,53,37),border=2)
    rect(x-4,352,8,18,(241,192,111))

# Right armory/weapon hall with a cool slate roof
poly([(774,246),(936,160),(1098,246)],(51,55,57))
poly([(784,244),(936,174),(1088,244)],(91,111,117))
for i in range(12):
    x=793+i*25
    ytop=174+abs(x-936)*0.43
    line([(x,ytop),(x+8,ytop+9)],(160,170,162),2)
    line([(x+8,ytop+9),(x+16,ytop+18)],(65,80,83),1)
rect(792,244,288,173,(212,194,158),border=4)
rect(803,253,266,154,(225,211,181))
for x in (801,822,1055): rect(x,248,9,165,(104,76,54))
rect(788,398,296,22,(112,104,88),border=2)
for x in range(794,1080,34): line([(x,400),(x+17,417)],(180,166,137),1)
# twin main windows and smaller upper loft windows
for x,y in [(835,277),(1012,277),(890,215),(962,215)]:
    ww,hh=(56,67) if y>250 else (38,46)
    rect(x,y,ww,hh,(73,57,44),border=4)
    rect(x+5,y+5,ww-10,hh-10,(111,143,143))
    rect(x+8,y+8,(ww-18)//2,hh-16,(195,176,133))
    rect(x+ww//2+2,y+8,(ww-18)//2,hh-16,(171,186,165))
    line([(x+ww//2,y+3),(x+ww//2,y+hh-3)],(66,57,45),3)
    line([(x+4,y+hh//2),(x+ww-4,y+hh//2)],(66,57,45),3)
    rect(x-3,y-4,ww+6,6,(127,92,64))
# right wing door
rect(927,337,63,80,(63,44,34),border=4)
rect(934,343,49,73,(128,81,48))
rect(941,350,35,66,(81,52,36))
line([(958,348),(958,414)],(176,122,72),3)
circle(972,383,3,(232,194,105))
# small weapon display silhouettes (no text)
for x in (814,1040):
    line([(x,367),(x,401)],(76,59,46),3)
    line([(x-12,374),(x+12,374)],(76,59,46),3)
    line([(x-8,365),(x+8,399)],(126,86,55),3)
    line([(x+8,365),(x-8,399)],(126,86,55),3)

# 5. Central city gate: completely rebuilt; a deep stone arch, portcullis and timber gate.
# rear arch shadow and outer mass
poly([(483,448),(483,286),(490,249),(507,215),(531,188),(562,169),(600,155),(640,149),(680,155),(718,169),(749,188),(773,215),(790,249),(797,286),(797,448)],(72,79,75))
poly([(495,444),(495,289),(503,252),(521,220),(544,196),(570,178),(604,166),(640,161),(676,166),(710,178),(736,196),(759,220),(777,252),(785,289),(785,444)],(183,179,153))
# arch wedge stones, segmented in curved bands
cx,cy=640,306
outer_rx,outer_ry=158,145
inner_rx,inner_ry=105,102
for i in range(12):
    a1=math.pi + i*math.pi/12
    a2=math.pi + (i+1)*math.pi/12
    def pt(rx,ry,a): return (cx+rx*math.cos(a),cy+ry*math.sin(a))
    points=[pt(outer_rx,outer_ry,a1),pt(outer_rx,outer_ry,a2),pt(inner_rx,inner_ry,a2),pt(inner_rx,inner_ry,a1)]
    colors=[(206,198,173),(188,184,159),(174,174,153),(195,187,161)]
    poly(points,colors[i%4])
    poly(points,(126,130,117),border=2)
# inner opening and deep vault
poly([(535,445),(535,309),(541,278),(555,250),(577,226),(605,209),(640,202),(675,209),(703,226),(725,250),(739,278),(745,309),(745,445)],(47,53,52))
poly([(552,442),(552,309),(560,278),(580,252),(606,235),(640,227),(674,235),(700,252),(720,278),(728,309),(728,442)],(58,67,63))
# inner arch courses, subtle outlines
for y in (269,292,315):
    line([(557,y),(723,y)],(91,99,89),2)
# raised portcullis rails at either side of the opening; the centre stays clear
# for the gold transition arrow and its Outside Gate label.
for x in (580,594,686,700):
    line([(x,239),(x,317)],(37,43,42),4)
    line([(x+2,242),(x+2,314)],(111,119,108),1)
line([(578,240),(702,240)],(139,137,116),5)
line([(578,315),(702,315)],(139,130,106),4)
# upper gatehouse stone keystone and arch details
poly([(626,159),(640,145),(654,159),(650,181),(630,181)],(223,212,180),border=2)
line([(640,149),(640,175)],(153,147,124),2)
# pilasters beside doorway
for x in (493,758):
    rect(x,302,27,133,(162,160,140),border=2)
    rect(x+4,306,19,124,(194,189,164))
    for yy in range(319,430,28): line([(x+4,yy),(x+22,yy)],(137,139,124),2)
    rect(x-8,297,42,9,(210,201,173),border=2)
    rect(x-8,431,42,12,(121,123,109),border=2)
# heavy iron bands along gate surround
for x in (545,735):
    rect(x,321,8,92,(61,57,50))
    for yy in (333,367,401): circle(x+4,yy,3,(207,171,91))
# gate threshold, visible just below door asset
poly([(523,443),(757,443),(791,468),(489,468)],(126,123,106),border=2)
poly([(534,446),(746,446),(766,461),(514,461)],(190,180,151))
line([(538,453),(742,453)],(222,210,177),2)

# 6. Foreground courtyard: broad paving to the gate, not a road continuing out the top.
# Large central trapezoid, ending squarely at the gate threshold.
poly([(523,459),(757,459),(930,640),(350,640)],(153,145,123))
poly([(535,463),(745,463),(903,640),(377,640)],(174,164,139))
# left branch to Gold District, connected to the courtyard at the left edge
poly([(0,411),(190,402),(514,453),(485,505),(218,470),(0,478)],(145,137,116))
poly([(0,419),(189,411),(493,458),(475,486),(219,453),(0,462)],(174,164,139))
# tile grid across central trapezoid; tapered rows create perspective
for row,y in enumerate(range(470,640,23)):
    t=(y-459)/(640-459)
    left=523+(350-523)*t
    right=757+(930-757)*t
    offset=(row%2)*26
    x=left-35+offset
    while x<right:
        tw=48+int(10*t)
        col=rng.choice([(183,172,148),(164,154,132),(194,183,157),(151,143,124),(175,164,140)])
        # clipped tile polygons stay within the trapezoid bounds
        xx1=max(x,left+2); xx2=min(x+tw,right-2)
        if xx2>xx1+8:
            tile=[(xx1,y),(xx2,y),(xx2-3,y+17),(xx1+2,y+17)]
            poly(tile,col)
            poly(tile,(117,108,91),border=1)
            line([(xx1+4,y+2),(xx2-5,y+2)],(210,199,171),1)
        x+=tw+4
# tiles on the left branch
for row,y in enumerate((421,443,465,487)):
    offset=(row%2)*28
    for x in range(-20+offset,520,57):
        # slightly irregular pavers, clipped to the branch shape visually
        ww=rng.randint(40,52)
        tile=[(x,y),(x+ww,y+1),(x+ww-4,y+17),(x+3,y+16)]
        poly(tile,rng.choice([(185,174,148),(157,148,127),(172,162,138),(196,184,157)]))
        poly(tile,(117,108,91),border=1)
        line([(x+4,y+2),(x+ww-5,y+2)],(211,199,169),1)
# subtle grass margins and stone edging
for x,y in [(355,489),(399,520),(445,554),(492,591),(819,497),(861,540),(898,579)]:
    line([(x,y+10),(x+3,y)],(79,116,73),2)
    circle(x+3,y-2,2,(196,177,103))
# short side curbs at road junction
poly([(462,476),(487,482),(399,640),(374,640)],(112,109,93))
poly([(786,476),(811,482),(906,640),(881,640)],(112,109,93))
line([(481,486),(388,635)],(209,196,163),2)
line([(797,486),(892,635)],(209,196,163),2)

# 7. Side gardens, lamp posts, flower borders and small decor, keeping the chicken clear.
# grass planters to left/right of central approach
for x,y,w,h in [(26,514,178,55),(1050,512,191,57),(38,590,220,39),(1026,589,217,39)]:
    ellipse(x,y,w,h,(75,112,72))
    ellipse(x+7,y+5,w-14,h-12,(96,137,83))
    for j in range(10):
        fx=x+12+j*(w-24)/9
        fy=y+14+(j%3)*7
        line([(fx,fy+12),(fx-2,fy)],(54,105,68),2)
        for ang in range(5):
            a=ang*2*math.pi/5
            circle(fx+4*math.cos(a),fy+4*math.sin(a),2,(238,209,146) if j%2 else (211,174,204))
        circle(fx,fy,2,(239,226,184))
# flanking lantern posts at the gate approach
for x in (455,825):
    ellipse(x-17,465,34,8,(69,78,66))
    rect(x-4,395,8,70,(70,62,48))
    rect(x-10,389,20,10,(122,95,59))
    rect(x-9,365,18,27,(67,54,42),border=2)
    rect(x-5,369,10,18,(240,185,103))
    poly([(x-13,365),(x,352),(x+13,365)],(82,63,42),border=2)
    line([(x-16,397),(x+16,397)],(190,148,81),2)
# modest stone planters at outer wall feet
for x in (115,1165):
    poly([(x-23,411),(x+23,411),(x+18,441),(x-18,441)],(123,101,75),border=2)
    rect(x-19,411,38,7,(174,139,91))
    for j in range(5):
        xx=x-12+j*6
        line([(xx,413),(xx-2,392-j%2*5)],(58,112,70),2)
        circle(xx-2,390-j%2*5,4,(71,137,81))
# subtle street lamps farther out
for x in (48,1230):
    rect(x-3,354,6,61,(75,65,49))
    rect(x-10,350,20,8,(113,88,57))
    rect(x-8,330,16,22,(65,54,43),border=2)
    rect(x-4,334,8,14,(240,189,112))

# 8. Final decorative details: banner cloth, masonry joints, flower pots and paving wear.
# purple/gold town banners on wall near the gate
for x in (416,864):
    line([(x,192),(x,112)],(70,57,45),4)
    poly([(x+3,116),(x+53,128),(x+3,146)],(112,65,103),border=2)
    poly([(x+7,121),(x+43,130),(x+7,139)],(210,173,96))
# small stone accents and wall wear
for x,y in [(36,298),(55,334),(1215,301),(1188,350),(280,392),(1004,391),(515,270),(768,270)]:
    line([(x,y),(x+21,y-2)],(210,201,174),2)
    line([(x+5,y+5),(x+17,y+4)],(121,128,116),1)
# scattered grass tufts in remaining grassy strips, avoid clear chicken area around 310,537
for x,y in [(24,493),(210,502),(225,583),(266,605),(1020,488),(1002,580),(1251,530),(1090,610),(70,617),(1184,603)]:
    line([(x,y),(x-2,y-8)],(76,117,71),2)
    line([(x,y),(x+5,y-6)],(87,130,78),2)

asset={'width':W,'height':H,'commands':C}
out=Path('/mnt/data/f1666f1c_work/front_gate_asset.json')
out.write_text(json.dumps(asset,separators=(',',':')),encoding='utf-8')
print(f'Wrote {out} with {len(C)} drawing commands; {out.stat().st_size:,} bytes')
