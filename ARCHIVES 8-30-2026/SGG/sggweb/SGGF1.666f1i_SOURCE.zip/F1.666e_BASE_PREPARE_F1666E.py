from pathlib import Path
import json

W = Path(__file__).resolve().parent
main_path = W / 'main.py'
assets_path = W / 'luma_assets_e33.json'
page_path = W / 'F1_play.html'

src = (W / 'F1.666d_BASE_MAIN.py').read_text(encoding='utf-8')
assert 'VERSION = "F1.666d"' in src
src = src.replace('VERSION = "F1.666d"', 'VERSION = "F1.666e"', 1)
assert 'import uuid' not in src
src = src.replace('import time\n', 'import time\nimport uuid\n', 1)

# E corrects the run-lifetime boundary. Save slots remain in the shared E1
# localStorage namespace so older SGG versions can write a quicksave that the
# still-open E tab can load. Cozmo/Tea/death/hint state is instead held only in
# this running E instance, so another version's config writes cannot erase or
# replay achievements in the open E tab.
e_insert = r'''

# ===========================================================================
# SGGF1.666e — run-scoped Cozmo ledger with shared cross-version save slots.
# The E1 save namespace is deliberately unchanged; only the achievement and
# hint ledger is scoped to this live run rather than shared browser config.
# ===========================================================================

class F1666eStateMachine(F1666dStateMachine):
    """F1.666d with a fresh Cozmo ledger per actual run and tab-local ownership."""

    RUN_LEDGER_DEFAULTS = {
        'cozmo_exploiter_appearances': 0,
        'cozmo_exploit_events': [],
        'cozmo_pending_tea_events': [],
        'cozmo_tea_earned': 0,
        'cozmo_tea_ledger_f1666d_migrated': False,
        'cozmo_death_reload_count': 0,
        'cozmo_hint_stage': 0,
    }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._f1666e_run_id = None
        self._f1666e_incoming_run_id = None
        self._f1666e_loaded_legacy_save = False

    def _f1666d_migrate_legacy_tea_credit(self):
        # D's one-time config migration is intentionally bypassed in E. A new
        # E run starts with a clean in-memory ledger; historical config values
        # are not proof that this run performed any exploit.
        return False

    def _f1666c_save_config(self, **changes):
        """Update this run's ledger in memory; never write it to shared config.

        Save games still use E1Storage's unchanged shared save-* keys. This
        ledger is owned by the live E state machine, so opening F1.3 or another
        SGG version in a second tab cannot overwrite the current E run's Tea,
        achievement, death/reload or hint state.
        """
        self.config.update(changes)
        self._log(
            'F1.666e RUN LEDGER',
            'Updated in-memory current-run fields: ' + ', '.join(sorted(changes))
        )
        return True

    def _f1666c_clean_loaded_cameos(self):
        """Ignore cameo history imported from a different/older run.

        E saves carry a top-level run marker. Older SGG versions deserialize
        and re-save only their known snapshot schema, so a save written by an
        older tab naturally loses that marker. Only a save written by this
        exact still-running E instance may restore its pending Cozmo cameo
        state. This prevents old save flags from awarding achievements or
        suppressing new-run recognitions.
        """
        flags = self._d11_flags()
        if flags is None:
            self._f1666e_loaded_legacy_save = True
            return
        same_run = bool(
            self._f1666e_run_id
            and self._f1666e_incoming_run_id == self._f1666e_run_id
        )
        if not same_run:
            flags['d11_cameo_events'] = []
            flags['d11_cameo_queue'] = []
            flags['d11_cameo_active'] = None
            self._f1666e_loaded_legacy_save = True
            self._log(
                'COZMO SAVE RESET',
                'Loaded save belongs to an older SGG version or a different run; '
                'discarded only saved Cozmo cameo history/queue/actor. World, '
                'quest, inventory, player location and all save data remain intact.'
            )
            return
        self._f1666e_loaded_legacy_save = False
        return super()._f1666c_clean_loaded_cameos()

    def _f1666c_migrate_legacy_achievements(self):
        # Legacy save flags describe discoveries made before this run began.
        # E must not turn those old flags into current-run Tea. Same-run E saves
        # already carry their run ledger in memory and their live cameo queue.
        if getattr(self, '_f1666e_loaded_legacy_save', False):
            self._log(
                'COZMO SAVE RESET',
                'Skipped legacy achievement migration for an older/different-run save.'
            )
            return False
        return super()._f1666c_migrate_legacy_achievements()

    def _read_save(self, slot):
        # Read only the tiny top-level marker before the normal shared E1 load.
        # The shared save slot itself is not mutated; this lets E distinguish a
        # same-live-run E save from an older-version or previous-run save.
        self._f1666e_incoming_run_id = None
        if slot in SAVE_SLOTS:
            try:
                raw = E1_STORAGE.get('save-' + slot)
                if raw:
                    incoming = json.loads(raw)
                    if isinstance(incoming, dict):
                        marker = incoming.get('_f1666e_run_id')
                        self._f1666e_incoming_run_id = marker if isinstance(marker, str) else None
            except Exception as exc:
                self._log('COZMO SAVE MARKER', f'Could not read optional E run marker: {type(exc).__name__}: {exc}')
        try:
            return super()._read_save(slot)
        finally:
            self._f1666e_incoming_run_id = None

    def _write_save(self, slot):
        # Same E1 shared save slot and exact game snapshot, with one optional
        # top-level marker that older versions ignore/drop on re-save.
        if not self.game or slot not in SAVE_SLOTS:
            return
        try:
            snapshot = self.game.snapshot()
            snapshot['_f1666e_run_id'] = self._f1666e_run_id
            blob = json.dumps(snapshot, ensure_ascii=False, separators=(',', ':'))
            E1_STORAGE.put('save-' + slot, blob)
            self._speech(f'Saved {slot} locally: {self.game.current_area.display_name}.')
            self._e1_notice(f'{slot.upper()} saved on this device.')
        except Exception as exc:
            self._speech('Save FAILED: ' + str(exc))
            self._e1_notice('Save FAILED: ' + str(exc))

    def _f1666e_reset_run_ledger(self):
        reset = {}
        for key, value in self.RUN_LEDGER_DEFAULTS.items():
            reset[key] = list(value) if isinstance(value, list) else value
        self.config.update(reset)
        self._log(
            'COZMO RUN RESET',
            'A genuinely new E run began: Tea=0; exploit recognitions cleared; '
            'pending Tea cleared; death/reload count=0; hint stage=0. '
            'No save-* browser storage keys were read, deleted or changed.'
        )

    def start_game(self):
        # The runtime calls start_game once on actual game launch. Returning to
        # the main screen and resuming this same game object is NOT a new run.
        # A different SGG version opened in another tab never calls this E
        # instance's start_game, so its shared config/save activity cannot
        # reset this still-running E ledger.
        new_run = self.game is None and not getattr(self, '_f1666c_run_initialized', False)
        if new_run:
            self._f1666e_run_id = uuid.uuid4().hex
            self._f1666e_loaded_legacy_save = False
            self._f1666e_reset_run_ledger()

        result = super().start_game()

        if new_run and self.game is not None:
            flags = self._d11_flags()
            if flags is not None:
                flags['d11_cameo_events'] = []
                flags['d11_cameo_queue'] = []
                flags['d11_cameo_active'] = None
            # This is the pre-existing Part One Cozmo encounter flag, also
            # fresh for a genuinely new world/run. Save slots are untouched.
            self.game.c1_flags['cozmo_finale_seen'] = False
            self._log(
                'COZMO RUN RESET',
                'Fresh game model: d11 cameo history/queue/active actor and '
                'Cozmo Part One encounter flag cleared.'
            )
        return result


class F1666eInterface(F1666dInterface):
    """F1.666e keeps D presentation; only the run-ledger lifetime changes."""
    pass
'''

assert 'async def main():' in src
assert 'class F1666eStateMachine' not in src
src = src.replace('\n\nasync def main():', e_insert + '\n\nasync def main():', 1)
src = src.replace('machine = F1666dStateMachine(archive, config, warning)',
                  'machine = F1666eStateMachine(archive, config, warning)', 1)
src = src.replace('ui = F1666dInterface(machine)',
                  'ui = F1666eInterface(machine)', 1)
main_path.write_text(src, encoding='utf-8')

# Preserve all D world/art content exactly; update only release identity/notes.
asset_doc = json.loads((W / 'F1.666d_BASE_LUMA_ASSETS.json').read_text(encoding='utf-8'))
assert asset_doc['version'] == 'SGGF1.666d'
asset_doc['version'] = 'SGGF1.666e'
asset_doc['notes'] = str(asset_doc.get('notes', '')) + (
    '\nSGGF1.666e: Cozmo Tea/achievement/death/hint state resets only when a '
    'genuinely new E run starts. The run ledger stays in the live E runtime, '
    'not the shared browser config, so another SGG version in another tab '
    'cannot overwrite it. E1 save-slot storage remains unchanged and shared '
    'across versions: old-version quicksaves remain available to this still-open '
    'E tab. Starting a new E run never deletes quicksave or named save slots. '
    'The HELLgs escape is still the first Tea achievement in each new run. '
    'The front-door description is copied verbatim from F1.666a.'
)
assets_path.write_text(json.dumps(asset_doc, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

page = (W / 'F1.666d_BASE_F1_play.html').read_text(encoding='utf-8')
assert 'SGGF1.666d' in page and 'sggf1666d' in page
page = page.replace('SGGF1.666d', 'SGGF1.666e').replace('sggf1666d', 'sggf1666e')
page_path.write_text(page, encoding='utf-8')

print('Prepared F1.666e from the immutable F1.666d snapshot.')
