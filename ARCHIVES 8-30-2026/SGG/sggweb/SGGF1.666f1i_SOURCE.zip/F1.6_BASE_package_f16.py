"""Package SGGF1.6 from the exact F1.5 baseline; preserve all deployed history."""
from pathlib import Path
import ast
import copy
import gzip
import hashlib
import io
import json
import re
import subprocess
import sys
import tarfile
import zipfile

ROOT = Path('/mnt/data')
WORK = Path(__file__).resolve().parent
BASE_DEPLOY = ROOT / 'SGGF1.5_CLOUDFLARE_DEPLOY.zip'
MAIN = WORK / 'main.py'
ASSETS = WORK / 'luma_assets_e33.json'
PLAY = WORK / 'F1_play.html'
README = WORK / 'README_SGGF16.txt'
PREVIEW = WORK / 'F1.6_CASTLE_HALL_PREVIEW.png'
DEPLOY = ROOT / 'SGGF1.6_CLOUDFLARE_DEPLOY.zip'
SOURCE = ROOT / 'SGGF1.6_SOURCE.zip'
META_PATH = WORK / 'F1.6_BUILD_META.json'

assert BASE_DEPLOY.exists(), BASE_DEPLOY
assert README.exists() and PREVIEW.exists()
code = MAIN.read_bytes()
assets_bytes = ASSETS.read_bytes()
assets_doc = json.loads(assets_bytes)
page = PLAY.read_text(encoding='utf-8')
assert assets_doc['version'] == 'SGGF1.6'
assert b'VERSION = "F1.6"' in code
assert all(x in page for x in ('SGGF1.6', 'sggf16.apk', 'sggf16.tar.gz', 'archive:"sggf16"'))

# Repeatable build checks.
ast.parse(code.decode('utf-8'))
subprocess.run([sys.executable, '-m', 'py_compile', str(MAIN)], cwd=WORK, check=True)
subprocess.run([sys.executable, str(WORK / 'test_f16.py')], cwd=WORK, check=True)

# Exact F1.5-to-F1.6 JSON scope lock: only release metadata and the Castle Hall
# navigation polygons may differ.
base_assets = json.loads((WORK / 'F1.5_BASE_LUMA_ASSETS.json').read_text(encoding='utf-8'))
expected = copy.deepcopy(base_assets)
expected['version'] = assets_doc['version']
expected['notes'] = assets_doc['notes']
base_hall = next(a for a in expected['world']['areas'] if a['area_id'] == 'castle_hall')
new_hall = next(a for a in assets_doc['world']['areas'] if a['area_id'] == 'castle_hall')
base_hall['navigation'] = copy.deepcopy(new_hall['navigation'])
assert assets_doc == expected, 'F1.6 world data changed outside the Castle Hall navigation/version/notes scope.'
assert len(assets_doc['assets']['c1_bg_castle_hall']['commands']) >= 600
assert assets_doc['assets']['c1_bg_castle_hall'] == base_assets['assets']['c1_bg_castle_hall']
assert assets_doc['assets']['locked_door'] == base_assets['assets']['locked_door']
assert (WORK / 'F1.5_BASE_MAIN.py').exists()
assert (WORK / 'F1.5_BASE_F1_play.html').exists()
assert (WORK / 'F1.5_BASE_test_f15.py').exists()

# Build the exact F1.6 runtime archives.
apkb = io.BytesIO()
with zipfile.ZipFile(apkb, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as apk:
    apk.writestr('assets/main.py', code)
    apk.writestr('assets/luma_assets_e33.json', assets_bytes)

tarb = io.BytesIO()
with gzip.GzipFile(fileobj=tarb, mode='wb', compresslevel=9, mtime=0) as gz:
    with tarfile.open(fileobj=gz, mode='w') as tf:
        for name, payload in (('assets/main.py', code), ('assets/luma_assets_e33.json', assets_bytes)):
            info = tarfile.TarInfo(name)
            info.size = len(payload)
            info.mode = 0o644
            info.mtime = 0
            tf.addfile(info, io.BytesIO(payload))

# Extend the F1.5 full deployment archive; preserve all older files unchanged
# except the release catalog, then append the five F1.6 runtime files.
with zipfile.ZipFile(BASE_DEPLOY, 'r') as old:
    assert old.testzip() is None
    old_names = old.namelist()
    assert len(old_names) == 165
    assert all(x in old_names for x in (
        'index.html', 'versions.html', 'versions.json', '_headers',
        'SGGF1.5/play.html', 'SGGF1.5/favicon.png',
        'SGGF1.5/sggf15.apk', 'SGGF1.5/sggf15.tar.gz', 'SGGF1.5/README_SGGF15.txt'))
    favicon = old.read('SGGF1.5/favicon.png')
    manifest = json.loads(old.read('versions.json'))
    assert manifest['versions'][0]['version'] == 'SGGF1.5'
    assert manifest['versions'][0]['current'] is True
    for entry in manifest['versions']:
        entry['current'] = False
    manifest['versions'].insert(0, {
        'version': 'SGGF1.6',
        'title': 'SGGF 1.6',
        'path': 'SGGF1.6/play.html',
        'description': 'Castle Hall navigation now matches its visible floor: the full stone floor is walkable, while a narrow connected lane preserves access to the existing off-centre vault seam. The Mage Room and outside doors, the bank-vault interaction and locked state, the Special Hard Hitbox slider, both existing seam-entry methods, and all other F1.5 gameplay are retained.',
        'current': True,
    })
    manifest_bytes = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    (WORK / 'deploy' / 'versions.json').write_bytes(manifest_bytes)
    additions = [
        ('SGGF1.6/play.html', page.encode('utf-8')),
        ('SGGF1.6/favicon.png', favicon),
        ('SGGF1.6/sggf16.apk', apkb.getvalue()),
        ('SGGF1.6/sggf16.tar.gz', tarb.getvalue()),
        ('SGGF1.6/README_SGGF16.txt', README.read_bytes()),
    ]
    with zipfile.ZipFile(DEPLOY, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=8) as out:
        for member in old.infolist():
            payload = manifest_bytes if member.filename == 'versions.json' else old.read(member.filename)
            out.writestr(copy.copy(member), payload)
        for name, payload in additions:
            out.writestr(name, payload)

# Validate deployment archive, payload contents and historical preservation.
with zipfile.ZipFile(DEPLOY, 'r') as z:
    assert z.testzip() is None
    names = z.namelist()
    assert len(names) == len(old_names) + len(additions) == 170
    assert len(set(names)) == len(names)
    with zipfile.ZipFile(BASE_DEPLOY, 'r') as old:
        for name in old_names:
            if name == 'versions.json':
                continue
            assert z.read(name) == old.read(name), f'Historic deployed file changed: {name}'
    final_doc = json.loads(z.read('versions.json'))
    assert len(final_doc['versions']) == 33
    assert final_doc['versions'][0]['version'] == 'SGGF1.6' and final_doc['versions'][0]['current'] is True
    assert final_doc['versions'][1]['version'] == 'SGGF1.5' and final_doc['versions'][1]['current'] is False
    assert sum(1 for v in final_doc['versions'] if v.get('current')) == 1
    for v in final_doc['versions']:
        assert re.fullmatch(r'SGG[A-Z]\d+(?:\.\d+)*', v['version'])
        assert re.fullmatch(r'SGG[A-Z]\d+(?:\.\d+)*\/(?:play|index)\.html', v['path'])
    with zipfile.ZipFile(io.BytesIO(z.read('SGGF1.6/sggf16.apk'))) as runtime:
        assert runtime.testzip() is None
        assert runtime.namelist() == ['assets/main.py', 'assets/luma_assets_e33.json']
        assert runtime.read('assets/main.py') == code
        assert runtime.read('assets/luma_assets_e33.json') == assets_bytes
    with tarfile.open(fileobj=io.BytesIO(z.read('SGGF1.6/sggf16.tar.gz')), mode='r:gz') as runtime:
        assert runtime.extractfile('assets/main.py').read() == code
        assert runtime.extractfile('assets/luma_assets_e33.json').read() == assets_bytes
    final_page = z.read('SGGF1.6/play.html').decode('utf-8')
    assert 'archive:"sggf16"' in final_page and 'sggf16.apk' in final_page and 'sggf16.tar.gz' in final_page
    for name in ('index.html', 'versions.html'):
        html = z.read(name).decode('utf-8')
        assert 'isPhoneOrTablet' in html and 'navigator.userAgentData?.mobile' in html
print(f'PASS deploy: {len(old_names)} previous/historical site entries preserved except versions.json; {len(additions)} F1.6 entries added.')

# Reproducible source archive. Include F1.5 snapshots plus the F1.6 builder and test.
source_files = []
for path in sorted(WORK.iterdir()):
    if not path.is_file():
        continue
    if path.suffix.lower() in ('.zip', '.pyc') or path.name.startswith('.'):
        continue
    if path.name == 'F1.6_BUILD_META.json':
        continue
    source_files.append((path.name, path))
for name in ('index.html', 'versions.html', 'versions.json', '_headers'):
    p = WORK / 'deploy' / name
    assert p.exists()
    source_files.append((f'deploy/{name}', p))
assert len({name for name, _ in source_files}) == len(source_files)

meta = {
    'version': 'SGGF1.6',
    'based_on': 'SGGF1.5',
    'repository': 'magiccozmo/QuackSink',
    'source_folder': 'ARCHIVES 8-30-2026/SGG/sggweb',
    'scope': 'Correct only the Castle Hall navigation mesh to match the visible floor while keeping a narrow connected approach to the original off-centre vault seam. F1.5 vault behavior, door transitions and all other game/world data remain unchanged.',
    'navigation': {
        'main_floor_polygon': [[24, 418], [1260, 418], [1260, 626], [24, 626]],
        'vault_seam_approach_polygon': [[1018, 306], [1074, 306], [1074, 418], [1018, 418]],
        'foot_anchor_offset_px': 14,
        'main_floor_walkable_player_center_y_min': 404,
        'seam_lane_walkable_player_center_y_range': [292, 404],
        'intent': 'Prevent walking across the visible back wall; retain the narrow connected seam approach.'
    },
    'preserved': [
        'All F1.5 Castle Hall artwork and the F1.5 vault-door illustration are byte-for-byte unchanged.',
        'All F1.5 objects, door positions, walk triggers, connections, collision definitions, vault dialogue, locked state, Special Hard Hitbox config and item-specific responses are unchanged.',
        'The existing vault_wall_seam object, castle_hall_to_vault_clip connection, directional carried-plate route, and direct E-interaction with the seam are retained.',
        'All other F1.5 world areas, game code behavior, saves, inventory, quests, Kitty, Stables, carriage, comments and Part One finale are unchanged.',
        'Every prior deployed site member is byte-for-byte preserved except versions.json; five F1.6 versioned browser files are appended.'
    ],
    'tests': [
        'PASS Python AST parse and py_compile.',
        'PASS strict F1.5-to-F1.6 JSON scope check: only version, notes and castle_hall.navigation changed.',
        'PASS all Luma commands supported and all art assets unchanged.',
        'PASS main floor reachability to left Mage Room and middle outside doors.',
        'PASS connected narrow route from main floor to plate target and hidden seam.',
        'PASS back-wall positions outside the seam lane are not walkable.',
        'PASS hidden seam E-interaction with carried plate remains available.',
        'PASS original directional plate clip, off-centre hitbox scaling, vault dialogue, permanently locked vault, and persistent config remain unchanged.',
        'PASS runtime APK/TAR content equality to the exact F1.6 source bytes.',
        'PASS deploy ZIP CRC, unique paths, 33-entry version manifest, and byte-for-byte preservation of all 165 prior deployment entries except versions.json.'
    ],
    'runtime_note': 'Static and packaging tests passed. The game was not launched in a live browser during this build; Cozmo must field-test floor boundaries, each door approach, seam access and the vault route.',
    'hashes': {
        'main_sha256': hashlib.sha256(code).hexdigest(),
        'assets_sha256': hashlib.sha256(assets_bytes).hexdigest(),
        'base_deploy_sha256': hashlib.sha256(BASE_DEPLOY.read_bytes()).hexdigest(),
        'deploy_sha256': hashlib.sha256(DEPLOY.read_bytes()).hexdigest(),
    },
    'bytes': {'deploy': DEPLOY.stat().st_size},
    'source_archive_digest_note': 'Not embedded: the source archive contains this metadata file, so embedding the archive SHA-256 would be self-referential. Calculate the source ZIP SHA-256 externally after packaging.',
    'deploy_entries': {
        'previous_entries_preserved': len(old_names),
        'catalog_versions': 33,
        'new_files': [name for name, _ in additions],
    },
}
META_PATH.write_text(json.dumps(meta, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
source_files.append((META_PATH.name, META_PATH))

with zipfile.ZipFile(SOURCE, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as out:
    for arcname, path in source_files:
        assert path.exists(), f'Missing source component: {path}'
        out.write(path, arcname)
with zipfile.ZipFile(SOURCE, 'r') as z:
    assert z.testzip() is None
    assert z.read('main.py') == code
    assert z.read('luma_assets_e33.json') == assets_bytes
    assert z.read('F1_play.html') == page.encode('utf-8')
    assert z.read('README_SGGF16.txt') == README.read_bytes()
    assert z.read('F1.6_BUILD_META.json') == META_PATH.read_bytes()
    assert z.read('F1.5_BASE_MAIN.py') != code
    assert len(z.namelist()) == len(source_files)
    assert len(set(z.namelist())) == len(z.namelist())

print('DEPLOY:', DEPLOY, DEPLOY.stat().st_size, 'bytes')
print('DEPLOY SHA256:', hashlib.sha256(DEPLOY.read_bytes()).hexdigest())
print('SOURCE:', SOURCE, SOURCE.stat().st_size, 'bytes')
print('SOURCE SHA256:', hashlib.sha256(SOURCE.read_bytes()).hexdigest())
print('MAIN SHA256:', meta['hashes']['main_sha256'])
print('ASSETS SHA256:', meta['hashes']['assets_sha256'])
print('SOURCE COMPONENTS:', len(source_files))
