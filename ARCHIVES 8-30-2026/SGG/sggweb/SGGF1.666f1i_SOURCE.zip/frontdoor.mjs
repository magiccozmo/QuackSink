
const box = document.getElementById('versions');
const YOUTUBE_URL = 'https://www.youtube.com/watch?v=XZ2GjHXn-kA&list=PLdhINWyYlsB4';
const GALLERY_IMAGES = [
  {"name": "hell.png", "url": "https://raw.githubusercontent.com/magiccozmo/QuackSink/main/ARCHIVES%208-30-2026/SGG/sggweb/pics/hell.png"},
  {"name": "castle exerior f1.4.png", "url": "https://raw.githubusercontent.com/magiccozmo/QuackSink/main/ARCHIVES%208-30-2026/SGG/sggweb/pics/castle%20exerior%20f1.4.png"},
  {"name": "castle hallf1.4.png", "url": "https://raw.githubusercontent.com/magiccozmo/QuackSink/main/ARCHIVES%208-30-2026/SGG/sggweb/pics/castle%20hallf1.4.png"},
  {"name": "castle hallf1.5.png", "url": "https://raw.githubusercontent.com/magiccozmo/QuackSink/main/ARCHIVES%208-30-2026/SGG/sggweb/pics/castle%20hallf1.5.png"},
  {"name": "castle outside-f1.2.png", "url": "https://raw.githubusercontent.com/magiccozmo/QuackSink/main/ARCHIVES%208-30-2026/SGG/sggweb/pics/castle%20outside-f1.2.png"},
  {"name": "castle path f1.2..png", "url": "https://raw.githubusercontent.com/magiccozmo/QuackSink/main/ARCHIVES%208-30-2026/SGG/sggweb/pics/castle%20path%20f1.2..png"},
  {"name": "castle path f1.3..png", "url": "https://raw.githubusercontent.com/magiccozmo/QuackSink/main/ARCHIVES%208-30-2026/SGG/sggweb/pics/castle%20path%20f1.3..png"},
  {"name": "gold dist.png", "url": "https://raw.githubusercontent.com/magiccozmo/QuackSink/main/ARCHIVES%208-30-2026/SGG/sggweb/pics/gold%20dist.png"},
  {"name": "inside alch.png", "url": "https://raw.githubusercontent.com/magiccozmo/QuackSink/main/ARCHIVES%208-30-2026/SGG/sggweb/pics/inside%20alch.png"},
  {"name": "inside inn.png", "url": "https://raw.githubusercontent.com/magiccozmo/QuackSink/main/ARCHIVES%208-30-2026/SGG/sggweb/pics/inside%20inn.png"},
  {"name": "market.png", "url": "https://raw.githubusercontent.com/magiccozmo/QuackSink/main/ARCHIVES%208-30-2026/SGG/sggweb/pics/market.png"},
  {"name": "new horse.png", "url": "https://raw.githubusercontent.com/magiccozmo/QuackSink/main/ARCHIVES%208-30-2026/SGG/sggweb/pics/new%20horse.png"},
  {"name": "new stables.png", "url": "https://raw.githubusercontent.com/magiccozmo/QuackSink/main/ARCHIVES%208-30-2026/SGG/sggweb/pics/new%20stables.png"},
  {"name": "now THAT IS and LOOKS like a horse.png", "url": "https://raw.githubusercontent.com/magiccozmo/QuackSink/main/ARCHIVES%208-30-2026/SGG/sggweb/pics/now%20THAT%20IS%20and%20LOOKS%20like%20a%20horse.png"},
  {"name": "outside inn.png", "url": "https://raw.githubusercontent.com/magiccozmo/QuackSink/main/ARCHIVES%208-30-2026/SGG/sggweb/pics/outside%20inn.png"},
  {"name": "path still ends in mid air and twsted.png", "url": "https://raw.githubusercontent.com/magiccozmo/QuackSink/main/ARCHIVES%208-30-2026/SGG/sggweb/pics/path%20still%20ends%20in%20mid%20air%20and%20twsted.png"},
  {"name": "stables old.png", "url": "https://raw.githubusercontent.com/magiccozmo/QuackSink/main/ARCHIVES%208-30-2026/SGG/sggweb/pics/stables%20old.png"}
];
const byId = (id) => document.getElementById(id);

// Luma’s spoken project introduction. The exact narration text is served with this site.
const aboutDialog = byId('about-dialog');
const aboutAudio = byId('luma-about-audio');
const aboutCopy = byId('about-copy');
const aboutStatus = byId('about-status');
const aboutAudioToggle = byId('about-audio-toggle');
const aboutTextPromise = fetch('./lumas%20explains%20sgg.txt', {cache:'no-store'})
  .then((response) => { if (!response.ok) throw new Error('Narration text unavailable (' + response.status + ')'); return response.text(); })
  .then((text) => {
    const paragraphs = text.trim().split(/\r?\n\s*\r?\n/).filter(Boolean);
    aboutCopy.replaceChildren(...paragraphs.map((paragraph) => { const p = document.createElement('p'); p.textContent = paragraph.trim(); return p; }));
  })
  .catch((error) => {
    aboutCopy.replaceChildren(); const p = document.createElement('p');
    p.textContent = 'Luma’s written introduction could not be loaded: ' + error.message; aboutCopy.append(p);
  });
function playAboutNarration() {
  const result = aboutAudio.play();
  if (result && typeof result.then === 'function') {
    result.then(() => { aboutAudioToggle.textContent = 'Stop talking'; aboutStatus.textContent = 'Luma is speaking. The text can be scrolled independently.'; })
      .catch(() => { aboutAudioToggle.textContent = 'Listen again'; aboutStatus.textContent = 'Your browser did not start audio automatically. Press “Listen again” to try.'; });
  }
}
function openAbout() {
  aboutDialog.hidden = false; document.body.style.overflow = 'hidden';
  try { aboutAudio.currentTime = 0; } catch (_) {}
  aboutAudioToggle.textContent = 'Stop talking'; aboutStatus.textContent = 'Starting Luma’s narration…';
  playAboutNarration();
  byId('about-close').focus();
}
function stopAboutNarration() {
  aboutAudio.pause();
  try { aboutAudio.currentTime = 0; } catch (_) {}
  aboutAudioToggle.textContent = 'Listen again';
  aboutStatus.textContent = 'Narration stopped. Press “Listen again” to hear it from the beginning.';
}
function closeAbout() {
  stopAboutNarration(); aboutDialog.hidden = true; document.body.style.overflow = ''; byId('open-about').focus();
}
byId('open-about').addEventListener('click', openAbout);
byId('about-close').addEventListener('click', closeAbout);
aboutAudioToggle.addEventListener('click', () => {
  if (!aboutAudio.paused && !aboutAudio.ended) stopAboutNarration();
  else { if (aboutAudio.ended) aboutAudio.currentTime = 0; playAboutNarration(); }
});
aboutAudio.addEventListener('ended', () => { aboutAudioToggle.textContent = 'Listen again'; aboutStatus.textContent = 'That’s the introduction. Press “Listen again” to replay it.'; });
aboutDialog.addEventListener('click', (event) => { if (event.target === aboutDialog) closeAbout(); });
document.addEventListener('keydown', (event) => { if (!aboutDialog.hidden && event.key === 'Escape') closeAbout(); });


// All visitors, including phones and tablets, load the same catalogue.
try {
  const res = await fetch('./versions.json', {cache:'no-store'});
  if (!res.ok) throw Error('Version catalog unavailable (' + res.status + ')');
  const doc = await res.json();
  if (!Array.isArray(doc.versions) || !doc.versions.length) throw Error('Version catalog is empty');
  box.replaceChildren();
  for (const entry of doc.versions) {
    if (!/^SGG[A-Z]\d+(?:\.\d+)*(?:[a-z][a-z0-9]*)?$/i.test(entry.version) ||
        !/^SGG[A-Z]\d+(?:\.\d+)*(?:[a-z][a-z0-9]*)?\/(?:play|index)\.html$/i.test(entry.path)) continue;
    const article = document.createElement('article'); article.className = entry.image ? 'card has-art' : 'card no-art';
    if (entry.image) {
      const preview = document.createElement('img');
      preview.className = 'card-art';
      preview.src = entry.image;
      preview.alt = (entry.title || entry.version) + ' selection artwork';
      preview.loading = 'lazy';
      article.append(preview);
    }
    const copy = document.createElement('div'); copy.className = 'card-copy';
    const title = document.createElement('h3'); title.textContent = entry.title || entry.version;
    if (entry.current) { const badge = document.createElement('span'); badge.className = 'badge'; badge.textContent = 'NEWEST'; title.append(badge); }
    const descr = document.createElement('p'); descr.textContent = entry.description || 'Playable archived release.';
    const a = document.createElement('a'); a.className = 'play'; a.href = './' + entry.path; a.textContent = 'Play ' + entry.version;
    copy.append(title, descr, a); article.append(copy); box.append(article);
  }
  if (!box.children.length) throw Error('No valid versions found');
} catch (e) {
  box.replaceChildren(); const p = document.createElement('p');
  p.textContent = 'Could not load the version catalog: ' + e.message; box.append(p);
}

// The gallery loads the PNGs from the public repository pics directory.
const dialog = byId('gallery-dialog');
const stage = byId('gallery-stage');
const image = byId('gallery-image');
const caption = byId('gallery-caption');
const count = byId('gallery-count');
let imageIndex = 0, zoom = 1, fitScale = 1, lastTouchX = null, pointers = new Map(), pinchStart = null;
const isPhone = () => window.matchMedia('(max-width:700px), (pointer:coarse)').matches;
function setZoom(value) {
  zoom = Math.max(1, Math.min(4, value));
  if (!image.naturalWidth || !isPhone()) return;
  image.style.width = Math.round(image.naturalWidth * fitScale * zoom) + 'px';
  image.style.height = Math.round(image.naturalHeight * fitScale * zoom) + 'px';
  if (zoom === 1) { stage.scrollLeft = 0; stage.scrollTop = 0; }
}
function fitCurrentImage() {
  if (!image.naturalWidth || !image.naturalHeight) return;
  zoom = 1;
  if (isPhone()) {
    const availableW = Math.max(200, stage.clientWidth - 24);
    const availableH = Math.max(180, stage.clientHeight - 24);
    fitScale = Math.min(1, availableW / image.naturalWidth, availableH / image.naturalHeight);
    setZoom(1);
  } else {
    fitScale = 1;
    image.style.width = 'auto'; image.style.height = 'auto';
  }
}
function showImage(index) {
  imageIndex = (index + GALLERY_IMAGES.length) % GALLERY_IMAGES.length;
  zoom = 1;
  image.style.width = 'auto'; image.style.height = 'auto';
  const item = GALLERY_IMAGES[imageIndex];
  image.alt = item.name;
  image.onload = fitCurrentImage;
  image.src = item.url;
  caption.textContent = item.name;
  count.textContent = '(' + (imageIndex + 1) + ' / ' + GALLERY_IMAGES.length + ')';
  stage.scrollLeft = 0; stage.scrollTop = 0;
}
function openGallery() { dialog.hidden = false; document.body.style.overflow = 'hidden'; showImage(0); byId('gallery-close').focus(); }
function closeGallery() { dialog.hidden = true; document.body.style.overflow = ''; byId('open-gallery').focus(); }
byId('open-gallery').addEventListener('click', openGallery);
byId('gallery-close').addEventListener('click', closeGallery);
byId('gallery-prev').addEventListener('click', () => showImage(imageIndex - 1));
byId('gallery-next').addEventListener('click', () => showImage(imageIndex + 1));
byId('zoom-in').addEventListener('click', () => setZoom(zoom + .5));
byId('zoom-out').addEventListener('click', () => setZoom(zoom - .5));
byId('zoom-reset').addEventListener('click', () => setZoom(1));
document.addEventListener('keydown', (event) => {
  if (dialog.hidden) return;
  if (event.key === 'Escape') closeGallery();
  else if (event.key === 'ArrowLeft') showImage(imageIndex - 1);
  else if (event.key === 'ArrowRight') showImage(imageIndex + 1);
  else if (event.key === '+' || event.key === '=') setZoom(zoom + .5);
  else if (event.key === '-') setZoom(zoom - .5);
});
stage.addEventListener('touchstart', (event) => {
  if (event.touches.length === 1 && zoom === 1) lastTouchX = event.touches[0].clientX;
}, {passive:true});
stage.addEventListener('touchend', (event) => {
  if (lastTouchX === null || event.changedTouches.length !== 1 || zoom !== 1) { lastTouchX = null; return; }
  const dx = event.changedTouches[0].clientX - lastTouchX;
  if (Math.abs(dx) > 65) showImage(imageIndex + (dx < 0 ? 1 : -1));
  lastTouchX = null;
}, {passive:true});
// Two-finger pinch changes image size so the enlarged image can be scrolled.
stage.addEventListener('pointerdown', (event) => {
  if (event.pointerType !== 'touch') return;
  pointers.set(event.pointerId, {x:event.clientX,y:event.clientY});
  if (pointers.size === 2) {
    const pts = [...pointers.values()];
    pinchStart = {distance:Math.hypot(pts[0].x-pts[1].x,pts[0].y-pts[1].y),zoom};
  }
});
stage.addEventListener('pointermove', (event) => {
  if (!pointers.has(event.pointerId)) return;
  pointers.set(event.pointerId, {x:event.clientX,y:event.clientY});
  if (pointers.size === 2 && pinchStart) {
    const pts = [...pointers.values()];
    const distance = Math.hypot(pts[0].x-pts[1].x,pts[0].y-pts[1].y);
    if (pinchStart.distance > 0) setZoom(pinchStart.zoom * distance / pinchStart.distance);
  }
});
function endPointer(event) { pointers.delete(event.pointerId); if (pointers.size < 2) pinchStart = null; }
stage.addEventListener('pointerup', endPointer);
stage.addEventListener('pointercancel', endPointer);
window.addEventListener('resize', () => { if (!dialog.hidden) fitCurrentImage(); });
