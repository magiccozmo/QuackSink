"""F1.6 regression checks: floor-aligned Castle Hall mesh, F1.5 vault preservation."""
from pathlib import Path
import copy
import json
import sys
from types import SimpleNamespace

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import main

class FakeRect:
    def __init__(self, x, y, w, h):
        self.x, self.y, self.width, self.height = float(x), float(y), float(w), float(h)
    def inflate(self, dx, dy):
        return FakeRect(self.x-dx/2, self.y-dy/2, self.width+dx, self.height+dy)
    def collidepoint(self, *point):
        if len(point) == 2:
            px, py = point
        else:
            px, py = point[0]
        return self.x <= px < self.x+self.width and self.y <= py < self.y+self.height

# The tests need only Rect semantics; pygame is supplied by the live app at runtime.
main.pygame = SimpleNamespace(Rect=FakeRect)

source = (HERE / 'main.py').read_text(encoding='utf-8')
assert main.VERSION == 'F1.6'
assert 'F1.6:' in source
assert 'Special Hard Hitbox' in source
assert 'SGGF1.6:' in source

# F1.5 configuration and all pre-existing behavior remain in place.
assert main.CONFIG_DEFAULTS['special_hard_hitbox'] == 3.0
assert main._normalized_config({})['special_hard_hitbox'] == 3.0
assert main._normalized_config({'special_hard_hitbox': 99})['special_hard_hitbox'] == 5.0
assert main._normalized_config({'special_hard_hitbox': -2})['special_hard_hitbox'] == 1.0
assert main._normalized_config({'special_hard_hitbox': 'not a number'})['special_hard_hitbox'] == 3.0

assets = json.loads((HERE / 'luma_assets_e33.json').read_text(encoding='utf-8'))
base = json.loads((HERE / 'F1.5_BASE_LUMA_ASSETS.json').read_text(encoding='utf-8'))
assert assets['version'] == 'SGGF1.6'
engine = main.LumaDrawEngine(HERE / 'luma_assets_e33.json')
assert all(cmd['op'] in main.LumaDrawEngine.SUPPORTED_OPS
           for asset in assets['assets'].values() for cmd in asset['commands'])

# The entire F1.5 world and every art asset are frozen except the Castle Hall
# navigation polygons, version, and release notes.
expected = copy.deepcopy(base)
expected['version'] = assets['version']
expected['notes'] = assets['notes']
base_hall = next(a for a in expected['world']['areas'] if a['area_id'] == 'castle_hall')
new_hall = next(a for a in assets['world']['areas'] if a['area_id'] == 'castle_hall')
base_hall['navigation'] = copy.deepcopy(new_hall['navigation'])
assert assets == expected, 'F1.6 changed F1.5 data outside Castle Hall navigation/version/notes.'

regions = new_hall['navigation']['regions']
assert regions == [
    [[24, 418], [1260, 418], [1260, 626], [24, 626]],
    [[1018, 306], [1074, 306], [1074, 418], [1018, 418]],
], 'Castle Hall mesh must be the floor polygon plus the connected vault-seam approach lane.'

# All three normal approaches and the narrow secret-lane approach are walkable.
game = main.F1GameModel(engine)
game.current_area_id = 'castle_hall'
game.player_x, game.player_y = 640.0, 426.0
assert game.can_move_to(296, 412), 'Mage Room door threshold is not reachable.'
assert game.can_move_to(640, 426), 'Central exterior threshold is not reachable.'
assert game.can_move_to(1046, 426), 'Main floor cannot reach the vault lane.'
assert game.can_move_to(1046, 404), 'The main floor/lane join is blocked.'
assert game.can_move_to(1046, 396), 'Vault approach lane is not reachable.'
assert game.can_move_to(1046, 333), 'Off-centre plate/seam approach is not reachable.'

# The old broad wall-walk route is now blocked outside the narrow seam lane.
for point in ((600, 333), (900, 333), (1100, 333), (1046, 285), (600, 250), (300, 390)):
    assert not game.can_move_to(*point), f'Back-wall/far-side position should be blocked: {point}'

# The seam's original E-interaction route remains available with a carried plate.
plate = game.c1_make_item('Iron Plate', 'plate')
game.carried_object_id = plate.object_id
plate.in_inventory = False
game.player_x, game.player_y = 1046.0, 333.0
seam = game.object_by_id('vault_wall_seam')
assert seam is not None and game.close_to_object(seam)
sm_seam = object.__new__(main.F1StateMachine)
sm_seam.game = game
sm_seam.d11_context_ref = None
sm_seam.logs = []
sm_seam._log = lambda *args: sm_seam.logs.append(args)
entered = []
sm_seam._area_enter = lambda conn: entered.append(conn.connection_id)
sm_seam._speech = lambda *args, **kwargs: None
sm_seam._activate(seam)
assert entered == ['castle_hall_to_vault_clip'], 'The existing seam E-interaction was not preserved.'
assert game.c1_vault_entered is True

# Return to the hall for the F1.5 plate hitbox/dialogue checks.
game.current_area_id = 'castle_hall'
game.c1_vault_entered = False
game.carried_object_id = plate.object_id
plate.in_inventory = False
sm = object.__new__(main.F1StateMachine)
sm.game = game
sm.special_hard_hitbox = 1.0
box_easy = sm._f15_plate_clip_rect()
sm.special_hard_hitbox = 5.0
box_hard = sm._f15_plate_clip_rect()
assert box_easy.width > box_hard.width and box_easy.height > box_hard.height
vault = game.object_by_id('vault_locked_door')
assert vault is not None and vault.kind == 'locked_door'
assert abs((box_hard.x+box_hard.width/2) - (vault.x+vault.width/2)) > 45
assert abs((box_hard.y+box_hard.height/2) - (vault.y+vault.height/2)) < 20

# Directional movement clip still uses the same off-centre, slider-controlled target.
sm.special_hard_hitbox = 3.0
box = sm._f15_plate_clip_rect()
game.player_x = box.x + box.width/2
game.player_y = box.y + box.height/2
assert sm._plate_clip_trigger(game, 1) is True
assert sm._plate_clip_trigger(game, 0) is False
assert sm._plate_clip_trigger(game, -1) is False
other = game.c1_make_item('Turnip', 'vegetable')
game.carried_object_id = other.object_id
assert sm._plate_clip_trigger(game, 1) is False

game.c1_consume(other)
plate.in_inventory = True
game.carried_object_id = None

# Vault object hit-test and dialogue remain exactly the F1.5 behavior.
game.player_x, game.player_y = 1000.0, 450.0
assert game.hit_test((vault.x+vault.width/2, vault.y+vault.height/2)) is vault
sm.game = game
sm.f15_vault_inventory_page = 0
sm.logs = []
sm._log = lambda *args: sm.logs.append(args)
sm._dialogue = lambda speaker, line, options: setattr(game, 'c1_dialogue', {
    'speaker': speaker, 'line': line, 'options': options[:5]})
sm._speech = lambda message, seconds=4: setattr(sm, 'last_speech', message)
sm._f15_vault_main_dialogue()
assert [o['text'] for o in game.c1_dialogue['options']] == ['Pick lock', 'Force open', 'Leave the vault alone']
sm._choose_dialogue(0)
assert "Are you kidding? Even the Skeleton Key ain't gonna pick this." in game.c1_dialogue['line']
sm._f15_vault_main_dialogue()
sm._choose_dialogue(1)
assert 'what should i force it open with?' in game.c1_dialogue['speaker'].lower()
plate_options = [o for o in game.c1_dialogue['options'] if o['action'] == 'f15_vault_item:' + plate.object_id]
assert plate_options, 'Carried plate not selectable from the inventory dialogue.'
plate_index = game.c1_dialogue['options'].index(plate_options[0])
sm._choose_dialogue(plate_index)
assert 'Oddly the plate ALMOST squeezes in a gap.' in game.c1_dialogue['line']
assert game.c1_vault_entered is False
assert vault.area_id == 'castle_hall'

gold = game.c1_make_item('Bag of Gold', 'gold')
sm._f15_vault_force_open = lambda: sm._f15_vault_inventory_dialogue(0)
sm._f15_vault_main_dialogue(); sm._choose_dialogue(1)
gold_option = next(i for i,o in enumerate(game.c1_dialogue['options'])
                   if o['action'] == 'f15_vault_item:' + gold.object_id)
sm._choose_dialogue(gold_option)
assert 'already full of money' in game.c1_dialogue['line']
assert vault.area_id == 'castle_hall' and game.c1_vault_entered is False

# The persistent setting remains independent and unchanged.
sm.special_hard_hitbox = 3.0
persisted = []
sm.persist_preference = lambda key, value: persisted.append((key,value)) or None
sm._f15_set_special_hard_hitbox(4.2)
assert sm.special_hard_hitbox == 4.2
assert persisted == [('special_hard_hitbox', 4.2)]

page = (HERE / 'F1_play.html').read_text(encoding='utf-8')
assert all(s in page for s in ('SGGF1.6', 'sggf16.apk', 'sggf16.tar.gz', 'archive:"sggf16"'))
assert 'sggf15' not in page
print('PASS F1.6 syntax, JSON scope, floor-aligned Castle Hall navigation, door/plate reachability, blocked wall walking, preserved seam E route, unchanged F1.5 vault/dialogue/config behavior, and F1.6 browser identifiers.')
