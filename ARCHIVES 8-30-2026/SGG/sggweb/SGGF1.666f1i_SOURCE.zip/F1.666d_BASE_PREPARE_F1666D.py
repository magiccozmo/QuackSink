from pathlib import Path
import json

W = Path(__file__).resolve().parent
main_path = W / 'main.py'
assets_path = W / 'luma_assets_e33.json'
page_path = W / 'F1_play.html'

src = (W / 'F1.666c_BASE_MAIN.py').read_text(encoding='utf-8')
assert 'VERSION = "F1.666c"' in src

# D is based on the immutable C snapshot. Change the release identity only.
src = src.replace('VERSION = "F1.666c"', 'VERSION = "F1.666d"', 1)

# Add a one-time marker for correcting C's accidental startup award. The old
# F1.666b appearance counter is not proof that the player performed the escape.
needle = '    "cozmo_tea_earned": 0,\n'
assert src.count(needle) == 1
src = src.replace(
    needle,
    needle + '    "cozmo_tea_ledger_f1666d_migrated": False,\n',
    1,
)

# Remove C's startup migration that incorrectly treated the legacy B cameo
# counter as a completed HELLgs escape. D grants that achievement only from
# the successful in-game save-load transition.
legacy_block = '''        try:\n            legacy_hellgs_appearances = int(self.config.get(self.COZMO_APPEARANCE_CONFIG_KEY, 0))\n        except (TypeError, ValueError, OverflowError):\n            legacy_hellgs_appearances = 0\n        if legacy_hellgs_appearances > 0 and 'hellgs_escape' not in self._f1666c_achievement_ids():\n            # F1.666b counted a cameo at every successful load from HELLgs.\n            # One or more such appearances prove the once-only escape event\n            # was already discovered. Credit that legacy event exactly once.\n            self._f1666c_award_achievement('hellgs_escape')\n            self._log('COZMO ACHIEVEMENT MIGRATION',\n                      f'Converted {legacy_hellgs_appearances} legacy HELLgs cameo(s) into the single hellgs_escape achievement.')\n'''
assert src.count(legacy_block) == 1
src = src.replace(legacy_block, '', 1)

# Do not mark the 20-death final spoiler as consumed merely because Cozmo
# appeared. It remains pending until the player explicitly accepts the spoiler.
needle = "            if hint_stage:\n                current_stage = int(self.config.get('cozmo_hint_stage', 0))\n"
replacement = "            if hint_stage and event != 'hint_20':\n                current_stage = int(self.config.get('cozmo_hint_stage', 0))\n"
assert src.count(needle) == 1
src = src.replace(needle, replacement, 1)

# At the 10-death encounter, the line is the same regardless of whether the
# player accepted, ignored, or escaped the first hint conversation.
old = """        elif event == 'hint_10':\n            self._dialogue('Cozmo', 'You really want another hint?',\n                [{'text': \"Yah, i'm still stumped\", 'action': 'f1666c_hint10_yes'}])\n"""
new = """        elif event == 'hint_10':\n            self._dialogue('Cozmo', \"I'm willing to give you an even better hint than last time\",\n                [{'text': \"Yah, i'm still stumped\", 'action': 'f1666c_hint10_yes'}])\n"""
assert src.count(old) == 1
src = src.replace(old, new, 1)

# The D state machine fixes the C ledger migration, preserves the final hint
# until accepted, and re-queues a pending hint milestone whenever a save lands
# in HELLgs after the required death/reload count.
d_insert = r'''

# ===========================================================================
# SGGF1.666d — gameplay-earned Tea and persistent, repeatable final hint offer.
# Based on the pushed F1.666c release; all C gameplay systems remain in place.
# ===========================================================================

class F1666dStateMachine(F1666cStateMachine):
    """F1.666c with the gameplay-only Tea ledger and repaired hint milestones."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._f1666d_migrate_legacy_tea_credit()

    def _f1666d_migrate_legacy_tea_credit(self):
        """Undo only C's known false startup credit; preserve real discoveries.

        C converted a nonzero F1.666b appearance counter into a completed
        hellgs_escape achievement before any gameplay. D removes that false
        flag and resets the score to zero. Any other already-discovered
        exploit achievements remain recognized but their points are held until
        the player performs the real HELLgs escape, so escape remains Tea #1.
        This repair runs exactly once per shared config.
        """
        if bool(self.config.get('cozmo_tea_ledger_f1666d_migrated', False)):
            return False

        try:
            legacy_appearances = int(self.config.get(self.COZMO_APPEARANCE_CONFIG_KEY, 0))
        except (TypeError, ValueError, OverflowError):
            legacy_appearances = 0

        valid = set(F1666C_EXPLOIT_ACHIEVEMENTS.values())
        raw_events = self.config.get('cozmo_exploit_events', [])
        if not isinstance(raw_events, list):
            raw_events = []
        events = []
        for value in raw_events:
            if isinstance(value, str) and value in valid and value not in events:
                events.append(value)

        pending_raw = self.config.get('cozmo_pending_tea_events', [])
        if not isinstance(pending_raw, list):
            pending_raw = []
        pending = []
        for value in pending_raw:
            if isinstance(value, str) and value in valid and value != 'hellgs_escape' and value not in pending:
                pending.append(value)

        false_c_startup_credit = legacy_appearances > 0 and 'hellgs_escape' in events
        if false_c_startup_credit:
            events = [value for value in events if value != 'hellgs_escape']
            # C could have paid the other four points early because its false
            # hellgs_escape flag was already set. Keep those real discoveries,
            # but hold their points until the actual cell-to-outside load.
            for value in events:
                if value != 'hellgs_escape' and value not in pending:
                    pending.append(value)
            self._f1666c_save_config(
                cozmo_exploit_events=events,
                cozmo_pending_tea_events=pending,
                cozmo_tea_earned=0,
                cozmo_tea_ledger_f1666d_migrated=True,
            )
            self._log(
                'COZMO TEA LEDGER MIGRATION',
                'Removed C startup-only HELLgs credit derived from the legacy appearance counter; '
                f'actual non-HELLgs discoveries remain pending={pending}; Tea Earned reset to 0.'
            )
            return True

        self._f1666c_save_config(cozmo_tea_ledger_f1666d_migrated=True)
        self._log(
            'COZMO TEA LEDGER MIGRATION',
            'No false C startup escape credit found; gameplay-earned Tea score and achievements preserved.'
        )
        return False

    def _f1666c_hint_talk(self, event):
        if event != 'hint_10':
            return super()._f1666c_hint_talk(event)
        info = self._d11_flags().get('d11_cameo_active')
        if not isinstance(info, dict):
            return
        info['talked'] = True
        self._dialogue(
            'Cozmo',
            "I'm willing to give you an even better hint than last time",
            [{'text': "Yah, i'm still stumped", 'action': 'f1666c_hint10_yes'}],
        )

    def _f1666c_queue_hint(self, reload_count):
        # A saved hint actor from a different area must not block a fresh
        # appearance at the HELLgs landing. The D1.1 area transition normally
        # clears this actor, but save loads replace the model atomically.
        flags = self._d11_flags()
        active = flags.get('d11_cameo_active') if flags else None
        if (isinstance(active, dict)
                and active.get('event') in F1666C_HINT_EVENTS
                and active.get('area') != self.game.current_area_id):
            flags['d11_cameo_active'] = None
        return super()._f1666c_queue_hint(reload_count)

    def _read_save(self, slot):
        previous_game = self.game
        super()._read_save(slot)
        if self.game is previous_game or self.game is None:
            return
        # The 20-death offer is not consumed by appearing or being ignored.
        # Recheck the milestone on every successful load into the cell, not
        # only on the death-triggered Quickload that first crossed the count.
        if self.game.current_area_id == 'hellgs_inn':
            try:
                reload_count = int(self.config.get('cozmo_death_reload_count', 0))
            except (TypeError, ValueError, OverflowError):
                reload_count = 0
            if reload_count >= 4:
                self._f1666c_queue_hint(reload_count)

    def _choose_dialogue(self, index):
        g = self.game
        if g and g.c1_dialogue:
            options = g.c1_dialogue.get('options', [])
            if 0 <= index < len(options):
                action = options[index].get('action')
                if action == 'f1666c_hint20_admit':
                    # Only this explicit player choice completes the final
                    # hint. Appearance, proximity, interaction, or Escape do not.
                    self._f1666c_save_config(cozmo_hint_stage=3)
                    self._log('COZMO HINT', 'Final spoiler milestone acknowledged by explicit player choice.')
        return super()._choose_dialogue(index)


class F1666dInterface(F1666cInterface):
    """F1.666d keeps the tested F1.666c Tea counter and Game Over Quickload UI."""
    pass
'''

assert 'async def main():' in src
assert 'class F1666dStateMachine' not in src
src = src.replace('\n\nasync def main():', d_insert + '\n\nasync def main():', 1)
src = src.replace('machine = F1666cStateMachine(archive, config, warning)',
                  'machine = F1666dStateMachine(archive, config, warning)', 1)
src = src.replace('ui = F1666cInterface(machine)', 'ui = F1666dInterface(machine)', 1)

main_path.write_text(src, encoding='utf-8')

# The world and Luma art remain identical to C apart from the release tag/note.
asset_doc = json.loads((W / 'F1.666c_BASE_LUMA_ASSETS.json').read_text(encoding='utf-8'))
assert asset_doc['version'] == 'SGGF1.666c'
asset_doc['version'] = 'SGGF1.666d'
asset_doc['notes'] = str(asset_doc.get('notes', '')) + (
    '\nSGGF1.666d: fixes C\'s legacy-counter startup credit so Tea is earned only '
    'by actual gameplay. HELLgs save-load escape remains Tea #1; previous non-HELLgs '
    'exploit discoveries remain pending until that escape. The 10-death interaction '
    'offers an even better hint regardless of whether the earlier hint was accepted. '
    'The 20-death spoiler remains available until the player explicitly accepts it. '
    'All other world, save migration, exploit and Quickload behavior is preserved.'
)
assets_path.write_text(json.dumps(asset_doc, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

page = (W / 'F1.666c_BASE_F1_play.html').read_text(encoding='utf-8')
assert 'SGGF1.666c' in page and 'sggf1666c' in page
page = page.replace('SGGF1.666c', 'SGGF1.666d').replace('sggf1666c', 'sggf1666d')
page_path.write_text(page, encoding='utf-8')

print('Prepared F1.666d from the immutable F1.666c source snapshot.')
