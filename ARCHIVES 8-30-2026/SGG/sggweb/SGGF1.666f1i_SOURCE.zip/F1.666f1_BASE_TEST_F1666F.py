from pathlib import Path
from types import SimpleNamespace
import ast
import copy
import importlib.util
import json
import math
import sys

W = Path(__file__).resolve().parent
MAIN = W / 'main.py'
ASSETS = W / 'luma_assets_e33.json'
PAGE = W / 'F1_play.html'
BASE_MAIN = W / 'F1.666e_BASE_MAIN.py'
BASE_ASSETS = W / 'F1.666e_BASE_LUMA_ASSETS.json'
BASE_PAGE = W / 'F1.666e_BASE_F1_play.html'
VERSION = 'F1.666f'
FAST_TRAVEL_MESSAGE = 'no fast travel allowed here, didja really think it would be THAT easy?'

source = MAIN.read_text(encoding='utf-8')
asset_doc = json.loads(ASSETS.read_text(encoding='utf-8'))
page = PAGE.read_text(encoding='utf-8')
assert 'VERSION = "F1.666f"' in source
assert asset_doc['version'] == 'SGGF1.666f'
assert 'SGGF1.666f' in page and 'sggf1666f.apk' in page and 'sggf1666f.tar.gz' in page
assert 'archive:"sggf1666f"' in page and 'bundle = "sggf1666f"' in page
assert 'sggf1666e.apk' not in page and 'sggf1666e.tar.gz' not in page
assert FAST_TRAVEL_MESSAGE in source
assert 'The spreading fire caught you and consumed you.' in source
assert 'hellgs_fire_seconds <=' not in source[source.index('class F1666fStateMachine'):source.index('class F1666fInterface')]

# The E asset/world definition is unchanged apart from the new version and release notes.
base_assets = json.loads(BASE_ASSETS.read_text(encoding='utf-8'))
expected_assets = copy.deepcopy(base_assets)
expected_assets['version'] = 'SGGF1.666f'
assert asset_doc['version'] == expected_assets['version']
assert asset_doc['notes'].startswith(base_assets['notes'])
assert asset_doc == {**expected_assets, 'notes': asset_doc['notes']}
for key in asset_doc:
    if key not in ('version', 'notes'):
        assert asset_doc[key] == base_assets[key], f'World/asset field changed: {key}'

# Verify every inherited E class is syntactically identical to its immutable baseline.
current_tree = ast.parse(source)
base_tree = ast.parse(BASE_MAIN.read_text(encoding='utf-8'))
def classes(tree):
    return {n.name: n for n in tree.body if isinstance(n, ast.ClassDef)}
current_classes = classes(current_tree)
base_classes = classes(base_tree)
for name, node in base_classes.items():
    assert ast.dump(current_classes[name], include_attributes=False) == ast.dump(node, include_attributes=False), \
        f'Historical class changed: {name}'
assert 'F1666fStateMachine' in current_classes and 'F1666fInterface' in current_classes
assert current_classes['F1666fStateMachine'].bases[0].id == 'F1666eStateMachine'
assert current_classes['F1666fInterface'].bases[0].id == 'F1666eInterface'
assert "STORAGE_NAMESPACE = 'spiffys-gift-sgge1-v1:'" in source

# Import safely without launching a Pygame display.
spec = importlib.util.spec_from_file_location('sgg_f1666f_test_module', MAIN)
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)
assert module.VERSION == VERSION


class FakeRect:
    def __init__(self, x, y, w, h):
        self.x, self.y, self.width, self.height = x, y, w, h
        self.left, self.top = x, y
        self.right, self.bottom = x + w, y + h
        self.centerx, self.centery = x + w / 2, y + h / 2

    def colliderect(self, other):
        return (self.left < other.right and self.right > other.left
                and self.top < other.bottom and self.bottom > other.top)


module.pygame = SimpleNamespace(
    Rect=FakeRect,
    KEYDOWN=1,
    K_m=2,
    KMOD_CTRL=64,
    KMOD_ALT=128,
    key=SimpleNamespace(get_mods=lambda: 0),
)


class FakeGame:
    def __init__(self, x=640, y=480):
        self.current_area_id = 'hellgs_inn'
        self.player_x, self.player_y = float(x), float(y)
        self.player_width, self.player_height = 26, 36
        self.c1_flags = {'hellgs_fire_active': True}
        self.c1_dead = None
        self.c1_launch_seconds = 1.0
        self.inventory_open = True
        self.c1_save_panel = True
        self.c1_dialogue = {'open': True}
        self.c13_game_config_open = True
        self.c13_cooking_open = True
        self.c1_config_open = True
        self.c13_slider_dragging = True
        self.c1_rebind = None

    def player_rect_at(self, x, y):
        return FakeRect(x - self.player_width / 2, y - self.player_height / 2,
                        self.player_width, self.player_height)


# Fast travel is refused in the cell with the exact requested speech, including during fire.
travel_machine = module.F1666fStateMachine.__new__(module.F1666fStateMachine)
travel_machine.game = FakeGame()
travel_machine.e33_fast_travel_open = False
travel_machine.travel_speech = []
travel_machine.travel_logs = []
travel_machine._speech = lambda message, *args: travel_machine.travel_speech.append(message)
travel_machine._log = lambda category, message: travel_machine.travel_logs.append((category, message))
event = SimpleNamespace(type=module.pygame.KEYDOWN, key=module.pygame.K_m)
travel_machine._dispatch_game(event, None)
assert travel_machine.travel_speech == [FAST_TRAVEL_MESSAGE]
assert travel_machine.e33_fast_travel_open is False
assert travel_machine.travel_logs[0][0] == 'FAST TRAVEL BLOCKED'

# The same inherited toggle still works outside HELLgs.
outside_machine = module.F1666fStateMachine.__new__(module.F1666fStateMachine)
outside_machine.game = None
outside_machine.e33_fast_travel_open = False
outside_machine._log = lambda *args: None
outside_machine._e33_toggle_travel()
assert outside_machine.e33_fast_travel_open is True

# The fire grid starts at the doorway, expands across/down, and fills the entire room.
fire_machine = module.F1666fStateMachine.__new__(module.F1666fStateMachine)
fire_machine.hellgs_fire_elapsed = 0.10
assert list(fire_machine._hellgs_f_active_fire_cells()) == []
fire_machine.hellgs_fire_elapsed = 2.60
active_mid = list(fire_machine._hellgs_f_active_fire_cells())
assert 0 < len(active_mid) < 396
fire_machine.hellgs_fire_elapsed = 3.60
active_full = list(fire_machine._hellgs_f_active_fire_cells())
assert len(active_full) == 36 * 11
assert max(fire_machine._hellgs_f_ignition_time(c, r)
           for c in range(36) for r in range(11)) < 3.5

# At the normal start position, the spreading fire makes physical contact.
fire_machine.hellgs_fire_elapsed = 2.60
spawn_game = FakeGame(640, 480)
assert fire_machine._hellgs_f_player_contact(spawn_game) == 'spreading room fire'

# The separate tongue pursues a moving player and advances faster than max soup movement.
chaser = module.F1666fStateMachine.__new__(module.F1666fStateMachine)
chaser.hellgs_fire_elapsed = 2.30
chaser.hellgs_fire_chaser_x, chaser.hellgs_fire_chaser_y = (640.0, 286.0)
chaser.hellgs_fire_heading = (0.0, 1.0)
chaser.soup_speed_multiplier = 4.0
chaser_game = FakeGame(900, 520)
before = math.hypot(chaser_game.player_x - chaser.hellgs_fire_chaser_x,
                    chaser_game.player_y - chaser.hellgs_fire_chaser_y)
chaser._hellgs_f_step_chaser(chaser_game, 0.1)
after = math.hypot(chaser_game.player_x - chaser.hellgs_fire_chaser_x,
                   chaser_game.player_y - chaser.hellgs_fire_chaser_y)
assert after < before
assert math.isclose(math.hypot(*chaser.hellgs_fire_heading), 1.0, rel_tol=1e-9)
assert math.isclose(before - after, 100.0, rel_tol=1e-6)

# The fire-start transition closes modal UI and an already-open travel map.
start_machine = module.F1666fStateMachine.__new__(module.F1666fStateMachine)
start_machine.HELLGS_FIRE_SOURCE = (640.0, 286.0)
start_machine.hellgs_fire_elapsed = 0.0
start_machine.hellgs_fire_chaser_x, start_machine.hellgs_fire_chaser_y = (640.0, 286.0)
start_machine.hellgs_fire_heading = (0.0, 1.0)
start_machine._hellgs_f_fire_initialized = False
start_machine.e57_comment_open = True
start_machine.e57_comment_sending = True
start_machine.e33_fast_travel_open = True
start_machine.logs = []
start_machine._log = lambda *args: start_machine.logs.append(args)
start_game = FakeGame()
start_machine._hellgs_f_begin_fire(start_game)
assert start_machine.hellgs_fire_elapsed == 0.0
assert start_machine._hellgs_f_fire_initialized
assert not start_game.inventory_open and not start_game.c1_save_panel
assert start_game.c1_dialogue is None
assert not start_game.c13_game_config_open and not start_game.c13_cooking_open
assert not start_game.c1_config_open and not start_game.c13_slider_dragging
assert not start_machine.e57_comment_open and not start_machine.e57_comment_sending
assert not start_machine.e33_fast_travel_open

# A zero legacy countdown cannot cause death when no flame touches the player.
# The real lower-level movement update is stubbed only to isolate the fire rule.
no_contact_machine = module.F1666fStateMachine.__new__(module.F1666fStateMachine)
no_contact_machine.game = FakeGame(1000, 350)
no_contact_machine.state = module.AppState.PLAY_GAME
no_contact_machine.hellgs_fire_active = True
no_contact_machine.hellgs_fire_elapsed = 0.10
no_contact_machine.hellgs_fire_seconds = 0.0
no_contact_machine.HELLGS_FIRE_DURATION = 0.0
no_contact_machine.soup_speed_multiplier = 2.0
no_contact_machine.hellgs_fire_chaser_x, no_contact_machine.hellgs_fire_chaser_y = (640, 286)
no_contact_machine.hellgs_fire_heading = (0.0, 1.0)
no_contact_machine._hellgs_f_step_chaser = lambda g, dt: None
no_contact_machine._speech = lambda *args: None
no_contact_machine._log = lambda *args: None
old_update = module.F1StateMachine.update
module.F1StateMachine.update = lambda self, dt, ui: None
try:
    no_contact_machine.update(0.05, None)
finally:
    module.F1StateMachine.update = old_update
assert not no_contact_machine.game.c1_flags.get('hellgs_game_over')
assert no_contact_machine.game.c1_dead is None
assert no_contact_machine.hellgs_fire_seconds == 0.0

# An actual room-fire collision is what sets Game Over.
contact_machine = module.F1666fStateMachine.__new__(module.F1666fStateMachine)
contact_machine.game = FakeGame(640, 480)
contact_machine.state = module.AppState.PLAY_GAME
contact_machine.hellgs_fire_active = True
contact_machine.hellgs_fire_elapsed = 2.50
contact_machine.hellgs_fire_seconds = 0.0
contact_machine.HELLGS_FIRE_DURATION = 0.0
contact_machine.soup_speed_multiplier = 2.0
contact_machine.hellgs_fire_chaser_x, contact_machine.hellgs_fire_chaser_y = (640, 286)
contact_machine.hellgs_fire_heading = (0.0, 1.0)
contact_machine._hellgs_f_step_chaser = lambda g, dt: None
contact_machine.speech = []
contact_machine.logs = []
contact_machine._speech = lambda message, *args: contact_machine.speech.append(message)
contact_machine._log = lambda *args: contact_machine.logs.append(args)
module.F1StateMachine.update = lambda self, dt, ui: None
try:
    contact_machine.update(0.05, None)
finally:
    module.F1StateMachine.update = old_update
assert contact_machine.game.c1_flags['hellgs_game_over'] is True
assert contact_machine.game.c1_dead == 'The spreading fire caught you and consumed you.'
assert contact_machine.game.c1_flags['hellgs_fire_active'] is False
assert contact_machine.speech == ['The flames catch you. GAME OVER.']
assert any(line[0] == 'HELLGS GAME OVER' for line in contact_machine.logs)

# The new interface still derives from E and keeps the inherited Quickload button layer.
assert issubclass(module.F1666fInterface, module.F1666eInterface)
assert module.F1666C_QUICKLOAD_RECT == (510, 470, 260, 48)
ui_source = ast.unparse(current_classes['F1666fInterface'])
assert 'The spreading fire caught you and consumed you.' in ui_source

print('PASS F1.666f preparation metadata and F1.666e class preservation')
print('PASS exact HELLgs fast-travel refusal; outside-cell fast travel remains functional')
print('PASS 36x11 room fire spreads completely; normal spawn is physically contacted')
print('PASS pursuing flame chases faster than maximum configured movement')
print('PASS fire start closes modal UI and fast-travel overlay')
print('PASS zero countdown does not cause Game Over without fire/player contact')
print('PASS actual fire/player contact alone triggers Game Over; inherited Quickload is retained')
