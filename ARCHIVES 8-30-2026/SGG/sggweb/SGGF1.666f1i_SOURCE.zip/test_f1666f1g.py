from __future__ import annotations
import ast, json, zipfile, tarfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
VERSION="SGGF1.666f1g"
PACKAGE="sggf1666f1g"
current=json.loads((ROOT/"luma_assets_e33.json").read_text(encoding="utf-8"))
base=json.loads((ROOT/"SGGF1.666f1f"/"assets"/"luma_assets_e33.json").read_text(encoding="utf-8"))
assert current["version"]==VERSION
assert current["world"]["areas"]==base["world"]["areas"]
assert current["world"]["connections"]==base["world"]["connections"]
for key,value in base["assets"].items():
    if key!="c1_bg_outside_gate": assert current["assets"][key]==value, key
assert current["assets"]["city_gate_double_leaf"]==base["assets"]["city_gate_double_leaf"]
assert current["assets"]["c1_bg_outside_gate"]!=base["assets"]["c1_bg_outside_gate"]
assert all(c["op"] in {"rect","line","polygon","circle","ellipse"} for c in current["assets"]["c1_bg_outside_gate"]["commands"])
old={o["object_id"]:o for o in base["world"]["objects"]}
new={o["object_id"]:o for o in current["world"]["objects"]}
for oid,o in old.items():
    n=new[oid]
    if oid=="city_gate_return":
        for k in ("object_id","name","kind","area_id","takeable","stealable","on_shelf","walk_trigger"): assert n.get(k)==o.get(k), (oid,k)
        assert (n["x"],n["y"],n["width"],n["height"])==(540,316,200,128)
    else: assert n==o, oid
main=(ROOT/"main.py").read_text(encoding="utf-8")
ast.parse(main)
assert 'VERSION = "F1.666f1g"' in main
assert "class F1666f1gInterface(F1666f1fInterface):" in main
assert "ui = F1666f1gInterface(machine)" in main
assert "name = 'city_gate_double_leaf'" in main
assert "render('Front Gate'" in main
version_dir=ROOT/VERSION
assert (version_dir/"play.html").is_file()
assert (version_dir/"outside_gate_preview.png").is_file()
assert (version_dir/"assets"/"main.py").read_bytes()==(ROOT/"main.py").read_bytes()
assert (version_dir/"assets"/"luma_assets_e33.json").read_bytes()==(ROOT/"luma_assets_e33.json").read_bytes()
with zipfile.ZipFile(version_dir/(PACKAGE+".apk")) as z: assert z.testzip() is None and set(z.namelist())=={"assets/main.py","assets/luma_assets_e33.json"}
with tarfile.open(version_dir/(PACKAGE+".tar.gz"),"r:gz") as t: assert set(t.getnames())=={"assets/main.py","assets/luma_assets_e33.json"}
versions=json.loads((ROOT/"deploy"/"versions.json").read_text(encoding="utf-8"))["versions"]
assert versions[0]["version"]==VERSION and sum(bool(v.get("current")) for v in versions)==1
print("F1.666f1g regression checks PASS")
