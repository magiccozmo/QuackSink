#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
DEPLOY="$ROOT/deploy"
GAME="$DEPLOY/SGGF1.666f1b"

python -m py_compile "$ROOT/F1.666f1b_BASE_MAIN.py"
node --check "$ROOT/frontdoor.mjs"
python -m json.tool "$ROOT/deploy/versions.json" >/dev/null
unzip -t "$GAME/sggf1666f1b.apk" >/dev/null
tar -tzf "$GAME/sggf1666f1b.tar.gz" >/dev/null

grep -q 'What the heck is this?' "$DEPLOY/index.html"
grep -q 'id="about-audio-toggle"' "$DEPLOY/index.html"
grep -q 'luma_explains.mp3' "$DEPLOY/index.html"
grep -q 'SGGF1.666f1b' "$DEPLOY/versions.json"
grep -q 'hell.png' "$DEPLOY/versions.json"
cmp -s "$DEPLOY/index.html" "$DEPLOY/versions.html"

echo 'F1.666f1b checks passed.'
