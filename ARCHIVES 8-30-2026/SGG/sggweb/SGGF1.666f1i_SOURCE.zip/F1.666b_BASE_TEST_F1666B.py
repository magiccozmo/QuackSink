from pathlib import Path
from types import SimpleNamespace, MethodType
import ast
import copy
import importlib.util
import json
import sys
import zipfile

W = Path(__file__).resolve().parent
MAIN = W / 'main.py'
ASSETS = W / 'luma_assets_e33.json'
PAGE = W / 'F1_play.html'
VERSION = 'F1.666b'

source = MAIN.read_text(encoding='utf-8')
asset_doc = json.loads(ASSETS.read_text(encoding='utf-8'))
page = PAGE.read_text(encoding='utf-8')
ast.parse(source)
assert f'VERSION = "{VERSION}"' in source
assert asset_doc['version'] == 'SGGF1.666b'
assert 'tea' in asset_doc['assets']
assert all(cmd['op'] in {'rect', 'line', 'polygon', 'circle', 'ellipse'}
           for cmd in asset_doc['assets']['tea']['commands'])
assert 'sggf1666b.apk' in page and 'sggf1666b.tar.gz' in page
assert 'archive:"sggf1666b"' in page and 'bundle = "sggf1666b"' in page
assert "Welcome brave exploiter to version F1.666 of Spiffy's Gift." in source
assert "cozmo_exploiter_appearances" in source
assert "hellgs_note')" not in source  # no per-object allowlist remains
assert "stable_carriage', 'stable_draft_horse', 'stables_foreground_fence', 'hellgs_note'" not in source

# Load the module without starting SDL/Pygame.
spec = importlib.util.spec_from_file_location('sgg_f1666b_main_test', MAIN)
module = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = module
spec.loader.exec_module(module)
assert module.F1666B_COZMO_TEXT == "Well dayum! I guess you are exploiter after all. This 'game' was truly designed and created for folks like you. Here is some Tea."

# Validate an actual F1.6-format save through the same classmethod used by the
# E1 local-storage quickload path, with the new HELLgs world as its destination.
old_doc = json.loads((W / 'F1.6_BASE_LUMA_ASSETS.json').read_text(encoding='utf-8'))
new_engine_doc = copy.deepcopy(asset_doc)
old_engine = SimpleNamespace(world=old_doc['world'])
new_engine = SimpleNamespace(world=new_engine_doc['world'])
old_game = module.C131GameModel(old_engine)
old_game.current_area_id = 'castle_hall'
old_game.player_x = 987.25
old_game.player_y = 322.75
old_game.c1_day = 17
old_game.c1_gold = 12345
old_game.c1_elapsed = 8765.5
old_game.c1_flags.update({'quest_done': True, 'f1666b_migration_probe': 'preserve-me'})
old_game.c1_npcs['naz']['x'] = 911.5
old_game.c1_npcs['naz']['moved'] = True
old_game.c1_npcs['naz']['future_satchel'] = {'cup': 0}
old_item = old_game.objects[0]
old_item.in_inventory = True
old_game.inventory = [old_item.object_id]
old_game.item_meta[old_item.object_id]['custom_saved_metadata'] = 'keep-this'
old_snapshot = old_game.snapshot()
old_snapshot['source_version'] = 'F1.6'
old_ids = {o['object_id'] for o in old_snapshot['objects']}
assert 'hellgs_note' not in old_ids

loaded = module.C131GameModel.from_snapshot(new_engine, copy.deepcopy(old_snapshot))
assert loaded.current_area_id == 'castle_hall'
assert (loaded.player_x, loaded.player_y) == (987.25, 322.75)
assert loaded.c1_day == 17 and loaded.c1_gold == 12345 and loaded.c1_elapsed == 8765.5
assert loaded.inventory == [old_item.object_id]
assert loaded.object_by_id(old_item.object_id).in_inventory is True
assert loaded.c1_flags['quest_done'] is True
assert loaded.c1_flags['f1666b_migration_probe'] == 'preserve-me'
assert loaded.c1_npcs['naz']['x'] == 911.5 and loaded.c1_npcs['naz']['moved'] is True
assert loaded.item_meta[old_item.object_id]['custom_saved_metadata'] == 'keep-this'
new_ids = {o.object_id for o in loaded.objects} - old_ids
assert new_ids == set(o['object_id'] for o in new_engine_doc['world']['objects']) - old_ids
assert 'hellgs_note' in new_ids
assert loaded.object_by_id('hellgs_note').area_id == 'hellgs_inn'
assert loaded.item_meta['hellgs_note']['object_id'] == 'hellgs_note'
for raw in old_snapshot['objects']:
    obj = loaded.object_by_id(raw['object_id'])
    assert obj is not None
    assert {k: getattr(obj, k) for k in raw} == raw, raw['object_id']

# The migration is generic, not a list of known release-specific IDs: simulate
# a later build with a new world object, a new NPC, a new save field and a new
# set field, then load the same older save into it.
future_doc = copy.deepcopy(new_engine_doc)
future_doc['world']['objects'].append({
    'object_id': 'future_world_object_probe', 'name': 'Future Prop', 'kind': 'herb',
    'area_id': 'castle_hall', 'x': 77, 'y': 88, 'width': 24, 'height': 31,
    'takeable': True, 'stealable': False, 'on_shelf': False,
})
future_doc['world']['npcs'][next(i for i, npc in enumerate(future_doc['world']['npcs']) if npc['npc_id'] == 'naz')]['future_satchel'] = {'spoon': 1, 'cup': 1}
future_doc['world']['npcs'].append({
    'npc_id': 'future_npc_probe', 'name': 'Future NPC', 'area_id': 'castle_hall',
    'x': 444, 'y': 333, 'width': 55, 'height': 75, 'asset': 'innkeeper',
    'speed': 0, 'lines': ['Hello from the future.'],
})
future_engine = SimpleNamespace(world=future_doc['world'])
original_save_fields = module.C131GameModel.SAVE_FIELDS
original_set_fields = module.C131GameModel.SAVE_SET_FIELDS
had_field = hasattr(module.C131GameModel, 'future_save_field_probe')
had_set = hasattr(module.C131GameModel, 'future_save_set_probe')
old_field = getattr(module.C131GameModel, 'future_save_field_probe', None)
old_set = getattr(module.C131GameModel, 'future_save_set_probe', None)
try:
    module.C131GameModel.future_save_field_probe = {'created_by': 'new version'}
    module.C131GameModel.future_save_set_probe = set()
    module.C131GameModel.SAVE_FIELDS = original_save_fields + ('future_save_field_probe',)
    module.C131GameModel.SAVE_SET_FIELDS = original_set_fields + ('future_save_set_probe',)
    future_loaded = module.C131GameModel.from_snapshot(future_engine, copy.deepcopy(old_snapshot))
    assert future_loaded.current_area_id == 'castle_hall'
    assert future_loaded.object_by_id('future_world_object_probe') is not None
    assert future_loaded.c1_npcs['future_npc_probe']['name'] == 'Future NPC'
    assert future_loaded.c1_npcs['future_npc_probe']['alive'] is True
    assert future_loaded.c1_npcs['naz']['future_satchel'] == {'spoon': 1, 'cup': 0}
    assert future_loaded.future_save_field_probe == {'created_by': 'new version'}
    assert future_loaded.future_save_set_probe == set()
finally:
    module.C131GameModel.SAVE_FIELDS = original_save_fields
    module.C131GameModel.SAVE_SET_FIELDS = original_set_fields
    if had_field:
        module.C131GameModel.future_save_field_probe = old_field
    else:
        delattr(module.C131GameModel, 'future_save_field_probe')
    if had_set:
        module.C131GameModel.future_save_set_probe = old_set
    else:
        delattr(module.C131GameModel, 'future_save_set_probe')

# A subsequent save containing a migrated object does not duplicate or reset
# it; saved state keeps precedence over the current default.
paper = loaded.object_by_id('hellgs_note')
paper.x, paper.y = 611.5, 493.5
paper.area_id = 'castle_hall'
paper.moved = True
second = module.C131GameModel.from_snapshot(new_engine, loaded.snapshot())
assert sum(1 for o in second.objects if o.object_id == 'hellgs_note') == 1
assert (second.object_by_id('hellgs_note').x, second.object_by_id('hellgs_note').y) == (611.5, 493.5)
assert second.object_by_id('hellgs_note').area_id == 'castle_hall'
assert second.object_by_id('hellgs_note').moved is True

# A synthetic dropped/custom object absent from the current world survives.
loaded.c1_make_item('Player Dropped Test Item', 'herb')
dynamic_id = loaded.inventory[-1]
loaded.object_by_id(dynamic_id).area_id = 'castle_hall'
loaded.object_by_id(dynamic_id).in_inventory = False
loaded.inventory.remove(dynamic_id)
third = module.C131GameModel.from_snapshot(new_engine, loaded.snapshot())
assert third.object_by_id(dynamic_id) is not None
assert third.object_by_id(dynamic_id).name == 'Player Dropped Test Item'

# Validate Cozmo's trigger: remember the pre-load location, then place his
# existing cameo at the newly loaded location. Mock only the base loader so
# this test remains headless and deterministic.
previous_base_read = module.F1666StateMachine._read_save
try:
    machine = module.F1666bStateMachine.__new__(module.F1666bStateMachine)
    prior_game = module.C131GameModel(new_engine)
    prior_game.current_area_id = 'hellgs_inn'
    loaded_game = module.C131GameModel(new_engine)
    loaded_game.current_area_id = 'castle_hall'
    loaded_game.player_x, loaded_game.player_y = (987.25, 322.75)
    machine.game = prior_game
    machine.config = {'cozmo_exploiter_appearances': 0}
    machine.logs = []
    machine.dialogues = []
    machine.speeches = []
    def persist(key, value):
        machine.config[key] = value
        return None
    machine.persist_preference = persist
    machine._log = lambda name, message: machine.logs.append((name, message))
    machine._dialogue = lambda speaker, line, options: machine.dialogues.append((speaker, line, options))
    machine._speech = lambda message, duration=4: machine.speeches.append((message, duration))
    def fake_base_read(self, slot):
        self.game = loaded_game
    module.F1666StateMachine._read_save = fake_base_read
    machine._read_save('quick')
    active = machine.game.c1_flags['d11_cameo_active']
    assert active['event'] == 'hellgs_save_return'
    assert active['area'] == 'castle_hall'
    assert active['appearance_number'] == 1 and active['tea_due'] is True
    assert machine.config['cozmo_exploiter_appearances'] == 1

    # First appearance gives exactly one tea; repeating the conversation does
    # not grant another item during the same cameo.
    machine._d11_talk()
    assert len(machine.game.inventory) == 1
    tea_id = machine.game.inventory[0]
    tea_obj = machine.game.object_by_id(tea_id)
    assert tea_obj.name == 'Yorkshire Tea' and tea_obj.kind == 'tea'
    machine._d11_talk()
    assert machine.game.inventory == [tea_id]
    assert all(d[0] == 'Cozmo' and d[1] == module.F1666B_COZMO_TEXT for d in machine.dialogues)

    # Second appearance is the alternating non-reward visit; third awards one.
    machine._f1666b_spawn_cozmo()
    assert machine.game.c1_flags['d11_cameo_active']['appearance_number'] == 2
    assert machine.game.c1_flags['d11_cameo_active']['tea_due'] is False
    machine._d11_talk()
    assert len(machine.game.inventory) == 1
    machine._d11_talk()
    assert len(machine.game.inventory) == 1
    machine._f1666b_spawn_cozmo()
    assert machine.game.c1_flags['d11_cameo_active']['appearance_number'] == 3
    assert machine.game.c1_flags['d11_cameo_active']['tea_due'] is True
    machine._d11_talk()
    assert len(machine.game.inventory) == 2
    machine._d11_talk()
    assert len(machine.game.inventory) == 2
finally:
    module.F1666StateMachine._read_save = previous_base_read

# A failed/no-op load must not create an appearance just because the player
# was in HELLgs; only a replaced game model counts as a successful load.
no_load_machine = module.F1666bStateMachine.__new__(module.F1666bStateMachine)
no_load_machine.game = prior_game
no_load_machine.config = {'cozmo_exploiter_appearances': 0}
no_load_machine.persist_preference = lambda key, value: no_load_machine.config.update({key: value})
no_load_machine._log = lambda *_args: None
previous_base_read = module.F1666StateMachine._read_save
try:
    module.F1666StateMachine._read_save = lambda self, slot: None
    no_load_machine._read_save('quick')
    assert no_load_machine.config['cozmo_exploiter_appearances'] == 0
    assert no_load_machine.game is prior_game
finally:
    module.F1666StateMachine._read_save = previous_base_read

# The Luma engine accepts the new tea item sprite as an available inventory art asset.
engine = module.LumaDrawEngine(ASSETS)
assert 'tea' in engine.assets

print('PASS F1.666b: generic old-save migration; saved areas/coordinates/state retained; all newly defined objects/NPCs/save fields/set fields receive defaults; dynamic objects and item metadata survive; Cozmo triggers from the pre-load HELLgs location and appears in the loaded area; tea alternates 1,0,1 and is granted only once per appearance; no-op loads do not trigger him.')
