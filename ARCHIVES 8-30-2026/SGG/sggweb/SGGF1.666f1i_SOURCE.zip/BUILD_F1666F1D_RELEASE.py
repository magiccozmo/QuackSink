from pathlib import Path
import json, zipfile, hashlib
ROOT=Path(__file__).resolve().parent
OUT=Path('/mnt/data')
VERSION='SGGF1.666f1d'

# Source archive: complete working source tree plus the new immutable version folder.
source_zip=OUT/f'{VERSION}_SOURCE.zip'
if source_zip.exists(): source_zip.unlink()
with zipfile.ZipFile(source_zip,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
    for p in sorted(ROOT.rglob('*')):
        if not p.is_file(): continue
        rel=p.relative_to(ROOT)
        if '__pycache__' in rel.parts or p.suffix=='.pyc': continue
        # Don't recursively bundle release output zips into the source package.
        if p.name.endswith('_SOURCE.zip') or p.name.endswith('_CLOUDFLARE_DEPLOY.zip'): continue
        z.write(p, rel.as_posix())

# Cloudflare update archive: intended as an overlay onto the existing site root.
# Older release directories remain in the user's existing hosted site and are
# deliberately not re-created or omitted from a destructive full-site replace.
deploy_zip=OUT/f'{VERSION}_CLOUDFLARE_DEPLOY.zip'
if deploy_zip.exists(): deploy_zip.unlink()
with zipfile.ZipFile(deploy_zip,'w',zipfile.ZIP_DEFLATED,compresslevel=8) as z:
    deploy=ROOT/'deploy'
    for p in sorted(deploy.iterdir()):
        if p.is_file(): z.write(p, p.name)
    newdir=ROOT/VERSION
    for p in sorted(newdir.rglob('*')):
        if p.is_file(): z.write(p, (Path(VERSION)/p.relative_to(newdir)).as_posix())
    note=ROOT/f'DEPLOY_OVERLAY_{VERSION}.txt'
    z.write(note, note.name)

# Verify both archives and critical payload structure.
for path in (source_zip,deploy_zip):
    with zipfile.ZipFile(path) as z:
        assert z.testzip() is None
        names=set(z.namelist())
        assert f'{VERSION}/play.html' in names
        assert f'{VERSION}/sggf1666f1d.tar.gz' in names
        assert f'{VERSION}/assets/main.py' in names
with zipfile.ZipFile(source_zip) as z:
    names=set(z.namelist())
    for old in ('SGGF1.666f1a/','SGGF1.666f1b/','SGGF1.666f1c/'):
        assert any(n.startswith(old) for n in names), f'Prior version missing: {old}'
    assert f'{VERSION}/README_{VERSION}.txt' in names
    assert 'deploy/versions.json' in names
    assert 'test_f1666f1d.py' in names
    assert 'main.py' in names and 'luma_assets_e33.json' in names
with zipfile.ZipFile(deploy_zip) as z:
    names=set(z.namelist())
    assert {'index.html','versions.html','versions.json','_headers'} <= names
    assert f'{VERSION}/play.html' in names
    assert f'{VERSION}/favicon.png' in names
    assert any(n.endswith('DEPLOY_OVERLAY_'+VERSION+'.txt') for n in names)

# Check deployment version index has a single current release and retains history.
versions=json.loads((ROOT/'deploy'/'versions.json').read_text(encoding='utf-8'))
assert versions['versions'][0]['version']==VERSION
assert sum(bool(v.get('current')) for v in versions['versions'])==1
assert len(versions['versions'])==45

for path in (source_zip,deploy_zip):
    h=hashlib.sha256(path.read_bytes()).hexdigest()
    print(f'{path.name}\t{path.stat().st_size:,} bytes\tsha256={h}')
print('Source ZIP and Cloudflare overlay ZIP passed structural checks.')
