SPIFFY'S GIFT — CLEAN DEPLOYMENT

CURRENT VERSION: SGGF1Clean2

This complete Cloudflare site retains the nine deliberately selected playable editions:
- SGGF1Clean2 — current Mountain Path makeover.
- SGGF1.666Cleanup1.0 — preceding clean release and rollback option.
- SGGF1.666f1s, SGGF1.666, SGGF1.6 and SGGF1.0 — selected F milestones.
- SGGE3.2, SGGE3.1 and SGGE2.0 — selected E milestones.

This is a curated milestone history, NOT the entire chain of daily/intermediate test releases. All other older intermediate releases remain in the full source archive, GitHub and Cozmo's local archives; they are intentionally excluded from this lean deployment. The site does not depend on GitHub at runtime.

The existing root index.html and versions.html remain in place and read versions.json. HELLgs Inn remains the F1.666-line default start; no start-mode change was made.
