SPIFFY'S GIFT — SGGE2.1+SGGE2.0 static website

Upload the FULL ZIP to the same Cloudflare Workers static project via a new deployment.
The ZIP root is the website root (index.html, _headers, SGGE2.1/, SGGE2.0/).
SGGE2.1 is listed first. SGGE2.0 is kept byte-for-byte unchanged.
Direct URLs are /SGGE2.1/ and /SGGE2.0/.
Do not upload only the SGGE2.1 subfolder: that would remove the old archive.
Existing localStorage save data is retained by the game on the same origin;
back up with F7 before deployment anyway.

This is not uploaded anywhere automatically. Operator must test in-browser.
