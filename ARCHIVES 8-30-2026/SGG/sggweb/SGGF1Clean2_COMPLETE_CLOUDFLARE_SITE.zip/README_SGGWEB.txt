SPIFFY'S GIFT — CLEAN DEPLOYMENT

CURRENT VERSION: SGGF1Clean2

This complete Cloudflare site retains exactly two playable clean versions:
- SGGF1Clean2 — current Mountain Path makeover.
- SGGF1.666Cleanup1.0 — previous clean release, retained unchanged as rollback.

Older playable milestones remain in the full source archive, GitHub and Cozmo's local archives. They are intentionally not included in this lean deployment. The site does not depend on GitHub at runtime.

The existing root index.html and versions.html remain in place and read versions.json. HELLgs Inn remains the F1.666-line default start; no start-mode change was made.
