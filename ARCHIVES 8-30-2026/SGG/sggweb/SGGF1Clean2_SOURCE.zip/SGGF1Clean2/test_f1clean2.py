import json, sys, zipfile, tarfile
from pathlib import Path
root = Path(__file__).resolve().parent
deploy = Path(sys.argv[1]).resolve()
assert 'VERSION = "F1Clean2"' in (root / 'main.py').read_text(encoding='utf-8')
json_data = json.loads((root / 'luma_assets_e33.json').read_text(encoding='utf-8'))
assert json_data['version'] == 'F1Clean2'
area = next(a for a in json_data['world']['areas'] if a['area_id'] == 'mountain_path')
assert len(area['navigation']['corridors']) == 4
versions = json.loads((deploy / 'versions.json').read_text(encoding='utf-8'))['versions']
assert [v['version'] for v in versions] == ['SGGF1Clean2', 'SGGF1.666Cleanup1.0']
assert versions[0]['current'] is True and versions[1]['current'] is False
assert sum(bool(v.get('current')) for v in versions) == 1
for n in ['SGGF1Clean2', 'SGGF1.666Cleanup1.0']:
    assert (deploy / n / 'play.html').is_file()
for n in ['SGGE2.0', 'SGGE3.1', 'SGGE3.2', 'SGGF1.0', 'SGGF1.6', 'SGGF1.666', 'SGGF1.666f1s']:
    assert not (deploy / n).exists(), n
apk = root / 'sggf1clean2.apk'
with zipfile.ZipFile(apk) as z:
    assert z.testzip() is None
    assert z.read('assets/main.py') == (root / 'main.py').read_bytes()
    assert z.read('assets/luma_assets_e33.json') == (root / 'luma_assets_e33.json').read_bytes()
tar = root / 'sggf1clean2.tar.gz'
with tarfile.open(tar, 'r:gz') as t:
    assert t.extractfile('assets/main.py').read() == (root / 'main.py').read_bytes()
    assert t.extractfile('assets/luma_assets_e33.json').read() == (root / 'luma_assets_e33.json').read_bytes()
print('PASS: Clean2 JSON/nav, lean two-version catalogue, old versions omitted, APK/TAR payloads exact.')
