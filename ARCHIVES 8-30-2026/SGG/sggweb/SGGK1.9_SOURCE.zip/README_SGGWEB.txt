SPIFFY'S GIFT — COMPLETE SOURCE AND DEPLOYMENT PACKAGE

Current edition: SGGK1.9. The Front Gate Little Lantern label now sits on its wooden signboard, and the Castle Hall Mage Lab arch now meets the floor. K1.8's tested Castle Hall / Exterior transition fixes remain intact.

The authoritative source is at the project root (main.py, assets/main.py and luma_assets_e33.json). The complete current static-site tree is deploy/. This package retains the eight legacy editions listed in “legacy verions.txt”, plus K1.8 and K1.9. Intermediate K1.0-K1.7 and J1.0 site folders are intentionally omitted from this new package.

No GitHub main push or Cloudflare deployment was performed by Luma. Cozmo handles publication and deployment.
