SPIFFY'S GIFT — CLEAN DEPLOYMENT

CURRENT VERSION: SGGF1Clean2.1

This complete Cloudflare site retains ten deliberately selected playable editions:
- SGGF1Clean2.1 — current Mountain Path Peak endpoint refinement.
- SGGF1Clean2 — preceding clean release/rollback option.
- SGGF1.666Cleanup1.0 — preceding curated milestone.
- SGGF1.666f1s, SGGF1.666, SGGF1.6 and SGGF1.0.
- SGGE3.2, SGGE3.1 and SGGE2.0.

The ordinary intermediate test releases remain excluded. Historical source files remain in the full source archive and Cozmo's repository/local archives. The site is self-contained and does not depend on GitHub at runtime. The previous SGGF1Clean2 release remains available as the prior clean edition as well as in the source handoff; the deployment adds SGGF1Clean2.1 as the new current choice.
