SPIFFY'S GIFT — SGGF2.0

CHOOSE YOUR PATH
• Easy: begin in the Stables; fast travel to every ordinary world area is available immediately.
• Normal: begin in the Stables; fast-travel destinations unlock as you discover new areas.
• Spiffy Challenge: begin in HELLgs Inn and retain the special locked-cell, cross-version save-escape challenge.

The three choices share the same world, quests, artwork, exploits, inventory, save system and transitions. The selected difficulty is stored with each save. Easy/Normal do not clear the shared quicksave; only a new Spiffy Challenge run performs the established HELLgs quicksave reset.

The existing HELLgs editions remain available in the version chooser. Their public descriptions intentionally avoid revealing the challenge details.

Live browser/gameplay field testing remains for Cozmo. Static checks and package integrity are recorded in SGGF2.0_TEST_RESULTS.txt.
