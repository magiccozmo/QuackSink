This is the SGGF2.0 current source/deployment folder. The source package includes assets/main.py and assets/luma_assets_e33.json; the complete Cloudflare deployment is mirrored under ../deploy/.
