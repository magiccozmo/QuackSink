SPIFFY'S GIFT — CURATED SOURCE HANDOFF

Current edition: SGGF2.0.
The embedded deploy/ folder is the complete Cloudflare site and contains exactly eight selectable editions: SGGF2.0 (current), SGGF1.666HellFinal, SGGF1.666, SGGF1.6, SGGF1.0, SGGE3.2, SGGE3.1 and SGGE2.0.

F2.0 introduces the Easy / Normal / Spiffy Challenge start selector. Easy and Normal begin at Stables; Easy fast travel exposes all ordinary areas immediately; Normal fast travel exposes discovered areas only. Spiffy Challenge begins in HELLgs Inn with the established cross-version save exploit challenge.

The prior HellFinal and six historical milestone deployments remain unchanged. The six historical playable milestone source archives retained in MILESTONE_SOURCE_ARCHIVES remain intact.

The current source folder is SGGF2.0. Root main.py and assets/main.py mirror the current runtime. No GitHub main push or Cloudflare deployment was performed by Luma.
