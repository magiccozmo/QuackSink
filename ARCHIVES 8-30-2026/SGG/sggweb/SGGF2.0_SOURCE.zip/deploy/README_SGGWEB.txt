SPIFFY'S GIFT — COMPLETE CLOUDFLARE SITE

Current release: SGGF2.0.
Exactly eight selectable editions are included: current SGGF2.0 plus prior SGGF1.666HellFinal and six legacy versions (SGGF1.666, SGGF1.6, SGGF1.0, SGGE3.2, SGGE3.1 and SGGE2.0).

F2.0 adds a three-way start choice: Easy and Normal begin in the Stables; Easy has all ordinary fast-travel destinations open; Normal has discovered destinations only; Spiffy Challenge begins in HELLgs Inn.
