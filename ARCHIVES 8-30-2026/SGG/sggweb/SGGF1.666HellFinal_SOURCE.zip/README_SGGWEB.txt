SPIFFY'S GIFT — CURATED SOURCE HANDOFF

Current edition: SGGF1.666HellFinal
The embedded deploy/ folder is the complete Cloudflare site and contains exactly seven selectable editions: SGGF1.666HellFinal (current), SGGF1.666, SGGF1.6, SGGF1.0, SGGE3.2, SGGE3.1 and SGGE2.0.

The six historical playable milestone source archives retained in MILESTONE_SOURCE_ARCHIVES correspond exactly to those six legacy editions. Other intermediate/test builds, Cleanup1.0 and F1s are not bundled in the new release ZIPs. Their older repository/Dropbox packages remain separate and untouched.

The current source folder is SGGF1.666HellFinal. The complete Cloudflare deployment mirror under deploy/ matches the standalone site ZIP. No GitHub main push or Cloudflare deployment was performed by Luma.
