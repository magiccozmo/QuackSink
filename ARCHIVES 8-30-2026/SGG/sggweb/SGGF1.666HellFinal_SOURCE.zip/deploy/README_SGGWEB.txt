SPIFFY'S GIFT — COMPLETE CLOUDFLARE SITE
Current release: SGGF1.666HellFinal
Exactly seven selectable editions are included: current SGGF1.666HellFinal plus the six legacy versions selected by Cozmo (SGGF1.666, SGGF1.6, SGGF1.0, SGGE3.2, SGGE3.1 and SGGE2.0). No other intermediate/test builds are bundled.
