from __future__ import annotations
import ast, copy, json, tarfile, zipfile
from pathlib import Path

HERE=Path(__file__).resolve().parent
PROJECT=HERE.parent if HERE.name=='SGGF1Clean2.8' else HERE
NEW=PROJECT/'SGGF1Clean2.8'
BASE=PROJECT/'SGGF1Clean2.7'

def load(p): return json.loads(Path(p).read_text(encoding='utf-8'))

def shifted(c,dx,dy):
    c=copy.deepcopy(c)
    if 'rect' in c:
        x,y,w,h=c['rect']; c['rect']=[x+dx,y+dy,w,h]
    if 'points' in c: c['points']=[[x+dx,y+dy] for x,y in c['points']]
    if 'center' in c:
        x,y=c['center']; c['center']=[x+dx,y+dy]
    return c

base=load(BASE/'assets'/'luma_assets_e33.json')
new=load(NEW/'assets'/'luma_assets_e33.json')
assert new['version']=='F1Clean2.8'
assert new['world']==base['world'], 'World state, objects, navigation and transitions must remain unchanged.'
assert new['assets']['c1_bg_castle_vault_kelp_original']==base['assets']['c1_bg_castle_vault'], 'Kelp original Vault recipe must be preserved exactly.'
assert len(new['assets']['c1_bg_castle_vault']['commands'])==583
assert new['assets']['locked_door']==base['assets']['locked_door']
commands=[shifted(c,575,185) for c in base['assets']['locked_door']['commands']]
bg=new['assets']['c1_bg_castle_vault']['commands']
assert any(bg[i:i+len(commands)]==commands for i in range(len(bg)-len(commands)+1)), 'Vault inner door must be exact Castle Hall locked_door recipe.'
for name,asset in base['assets'].items():
    if name!='c1_bg_castle_vault':
        assert new['assets'][name]==asset, f'Unrelated asset modified: {name}'
assert set(new['assets'])==set(base['assets'])|{'c1_bg_castle_vault_kelp_original'}
for p in (NEW/'main.py',NEW/'package_f1clean2_8.py'):
    source=p.read_text(encoding='utf-8'); ast.parse(source); compile(source,str(p),'exec')
assert 'VERSION = "F1Clean2.8"' in (NEW/'main.py').read_text(encoding='utf-8')
assert (NEW/'main.py').read_bytes()==(NEW/'assets'/'main.py').read_bytes()
assert (NEW/'luma_assets_e33.json').read_bytes()==(NEW/'assets'/'luma_assets_e33.json').read_bytes()
for name in ('sggf1clean2_8.apk','sggf1clean2_8.tar.gz'):
    assert (NEW/name).is_file()
with zipfile.ZipFile(NEW/'sggf1clean2_8.apk') as z:
    assert z.testzip() is None
    assert z.read('assets/main.py')==(NEW/'main.py').read_bytes()
    assert z.read('assets/luma_assets_e33.json')==(NEW/'luma_assets_e33.json').read_bytes()
with tarfile.open(NEW/'sggf1clean2_8.tar.gz','r:gz') as t:
    contents={m.name:t.extractfile(m).read() for m in t.getmembers() if m.isfile()}
    assert contents['assets/main.py']==(NEW/'main.py').read_bytes()
    assert contents['assets/luma_assets_e33.json']==(NEW/'luma_assets_e33.json').read_bytes()
print('SGGF1Clean2.8 portable self-test passed.')
