SPIFFY'S GIFT — SGG WEB PROJECT

Current edition: SGGK1.12. The Inn Lout's death now resolves Karlotta's problem and queues Cozmo's cameo/Tea reward whether he is killed by a guard or by Grumblegron's existing giant-assisted flight. K1.11's extended follow route into Giant Camp remains intact. The giant's patrol and launch mechanics are unchanged.

The full static site preserves all prior catalogued editions. See the current release folder and version catalogue for the active browser build.
