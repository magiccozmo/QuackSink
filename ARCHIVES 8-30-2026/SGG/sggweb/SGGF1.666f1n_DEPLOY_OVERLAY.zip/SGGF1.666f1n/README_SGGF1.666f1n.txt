SPIFFY'S GIFT — SGGF1.666f1n

BASE
Built additively from Cozmo's exact SGGF1.666f1m source archive. F1.666f1m and
all earlier version folders remain unchanged.

SIDE OF MOUNTAIN — CAVE REDO
The generic wooden door sprite is gone. Frosty's entrance is now an irregular,
shadowed natural cave mouth integrated into the existing cliff rockwork. The
underlying mountain_cave_entrance object remains invisible and movement-only,
so its ID and transition behavior continue to work with older saves.

WALKMESH
The overly broad single trail corridor is replaced with three connected
sections: the upper switchback, the mid-slope bend, and the lower cave approach.
Each is sized to the visible stone path. The broad lower ledge remains walkable.
The existing top-edge Southern Wilds arrow and all other exit arrows remain.

PRESERVED
All world objects, object IDs, connection IDs, arrival coordinates, other areas,
other asset recipes, game mechanics, Tea/hint state, YouTube link, save schema,
and earlier releases are retained. No existing release is overwritten.

TESTING
Automated source, JSON, connection, save-compatibility, walkmesh, syntax and
package checks are included. A live Cloudflare/browser playtest remains for
Cozmo after deployment.
