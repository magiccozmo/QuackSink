SPIFFY'S GIFT — SGGE4.9 / TIPSY TURNIP INN INTERIOR, COMPLETELY REDESIGNED

Deploy: upload sgge4.9.zip to Cloudflare as a complete static site.
Play: SGGE4.9/play.html (or select it from the root version list).

Based on field-tested E4.8. One-area redesign only: Inn Interior.
- A brand-new 1275-command interior environment, matching the warm timber,
  cobble and irregular architectural detail of Britrun Market and the E4.8 inn.
- The big fireplace is BUILT INTO the room; its cooking hearth object remains
  an interactive hitbox without double-drawing a generic fireplace sprite.
- The existing fully functional cooking-pot world object sits in front of fire.
- Black-Briar Mead is on a small dining table, not on the ground.
- The Wooden Serving Platter is on the bar counter, not floating in the air.
- Innkeeper stands in front of the bar; lout stands beside the table.
- Old blocking rectangles replaced by solids matching the hearth, table, bar.
- The inn exit is drawn once and still triggers when walking DOWN into it.
- No other area art/geometry or unrelated NPC/object data changed.
- Old save conversion moves only pristine, untouched inn objects/NPCs to their
  new locations. Inventory items and player-moved objects are not reset.

Preservation: ALL previous playable releases E2.0 through E4.8 are included
byte-for-byte, except versions.json to add the E4.9 selection.

Checks: Python syntax, asset schema, all other scene artwork unchanged, all
other world data unchanged, one-area diff, approximate connected-footpoint
walkmesh reachability to fireplace, cookpot, mead, platter, both NPCs, and
exit; ZIP member and nested APK/TAR integrity.

The browser test remains necessary for real-game visual and gameplay proof.
