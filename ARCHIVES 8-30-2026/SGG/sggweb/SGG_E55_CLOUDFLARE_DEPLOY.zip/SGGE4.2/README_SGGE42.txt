SPIFFY'S GIFT — SGGE4.2 / MARKET ALCHEMY ENTRANCE FIX

Upload sgge4.2.zip to Cloudflare Workers as the FULL replacement static site.
Navigate to SGGE4.2/play.html or choose SGGE4.2 from the site root.
All earlier game releases, including SGGE4.1, are preserved byte-for-byte.

Change from SGGE4.1:
- Only alchemy_shop_door's walk_trigger.rectangle in the JSON world objects
  has changed: [608,350,66,16] -> [608,325,66,41].
- The collision/walkmesh stops Spiffy near y=324 in front of the market shop
  facade. Previously, the active northward trigger required y>=342 and the
  held-Up player could not enter. The corrected activation zone spans that
  reachable threshold while retaining direction and horizontal checks.
- Actual engine logic, all other object coordinates, navigation/walkmesh,
  loot, other doors (including the INSIDE Alchemy Shop exit), market artwork,
  and other area artwork are unchanged; version identifier bumped to E4.2.
- The E4.1 Flight Recorder / Export Log feature remains in effect.
- If the browser previously selected a log folder, the recorder keeps the
  existing internal storage key to retain the folder selection if permitted.

Validation: Python compiles; JSON parsed; only intended rectangle differs in
world; old log positions reproduce fix; far-away/off-center/wrong-direction
checks pass; both game bundles unpack correctly; all earlier ZIP members
remain byte-for-byte unchanged except versions.json. Actual Cloudflare
browser field-test is still required.
