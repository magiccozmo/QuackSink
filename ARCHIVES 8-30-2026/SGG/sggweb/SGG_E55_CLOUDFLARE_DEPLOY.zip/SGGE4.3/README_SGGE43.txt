SPIFFY'S GIFT — SGGE4.3 / ALCHEMY SHOP ART + WALKMESH

Full Cloudflare static site deployment: upload sgge4.3.zip to Cloudflare.
Use SGGE4.3/play.html or select E4.3 from the root version selector.
ALL previous playable versions E2.0 through E4.2 are included byte-for-byte.

From E4.2:
- Alchemy Shop background: removed giant freestanding foreground arch and
  two awkward floor torch-posts; replaced with a flat burgundy directional
  floor runner and grounded stone/wood threshold leading south toward Market.
- Alchemy Shop laboratory-table collision rect ONLY:
  [888,385,245,90] -> [956,416,144,60]. The previous walk blocker
  started 60 pixels LEFT of the furniture art (x=948), explaining the ghost
  wall Spiffy met at x~873 and the blocked upward corridor at x=938,y=494.
  New rectangle follows the desk tabletop/leg footprint instead; movement
  through the real bench is still blocked. Central workbench solid unchanged.
- Existing door activation logic and door walk_trigger geometry are UNCHANGED,
  including directional north/south intent rules and cooldown. E selection,
  object coordinates, theft, inventory, quests, other scenes are UNCHANGED.
- Auto log filenames now include seconds:
  SGG_30OCT26_11-28-42amVE4.3.LOG
  Browser still controls final Downloads folder unless authorized otherwise.
- Flight recorder, EXPORT LOG, historic versions retained.

Validation: static source parses and compiles; all other world and visual
assets compare identical to E4.2; old blocked coordinates reproduced and
corrected against true collision model; laboratory bench stays solid;
log filename regression passes; complete deployment ZIP verified against
prior historical bytes; new .apk and .tar.gz contain exact updated code
and assets. Actual browser field test is still required.
