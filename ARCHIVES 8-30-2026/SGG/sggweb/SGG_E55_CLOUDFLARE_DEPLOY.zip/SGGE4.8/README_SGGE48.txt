SPIFFY'S GIFT — SGGE4.8 / TIPSY TURNIP INN EXTERIOR REBUILD

Upload sgge4.8.zip as the complete static Cloudflare site deployment.
Play via SGGE4.8/play.html or select it at the existing root version list.

One-area release based on SGGE4.7:
- Inn Outside completely redrawn from scratch (NOT another repaint of the E4.7
  flat symmetrical pyramid roof). Asymmetric timber/stone tavern with separate
  roof wings, roof tiles, warm casement windows, gabled frontage, properly
  recessed single entrance, hand-drawn TIPSY TURNIP sign, working-looking
  chimney and lanterns, a cobblestone approach, paths, foliage, herbs and
  rustic exterior furniture. 1696 drawing commands in the new scene recipe.
- Decorative scene footprint aligns with the EXISTING world navigation and
  solid rectangles. Same door world object and northward walk-through trigger.
- Suppress drawing the redundant generic inn_front_door sprite only; retains
  the door object and its actual transitions and metadata unchanged.
- Ambient chickens and dog are still provided by the original animation logic.
- No new interactions, no object repositioning, no edits to any other area.
- All preceding playable releases E2.0 through E4.7 retained byte-for-byte.

Static tests: Python AST compilation, JSON schema and asset compatibility,
E4.7->E4.8 source diff scoped to version strings and inn door sprite
suppression, exact world geometry equality, complete ZIP integrity and
bytewise historical member preservation, embedded APK and tar consistency.
Visual preview and a composite with the original animals/player provided
in the source archive. The actual browser field test remains to be done.
