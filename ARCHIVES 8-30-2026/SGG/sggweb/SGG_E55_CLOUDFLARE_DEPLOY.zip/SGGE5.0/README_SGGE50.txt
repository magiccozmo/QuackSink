SPIFFY'S GIFT — SGGE5.0 / GOLD DISTRICT COMPLETELY REBUILT

Deploy: upload sgge5.0.zip to Cloudflare as a complete static site.
Play: SGGE5.0/play.html (or select it from the root version list).

Based on field-tested E4.9. One-area redesign only: Gold District.
- A brand-new 1600+ command affluent-district scene in the same improved style
  family as the renovated inn and market environments.
- Keeps the Gold District's original purpose and transitions: two town houses,
  a fountain, the northbound Castle Path, and the side exits.
- The two houses are now distinct, not mirrored placeholders.
- The central route is now a proper elegant stone avenue instead of a giant slab.
- Landscaping is upgraded with curated flowerbeds, planters, lanterns and lawn detail.
- Fountain collision added so the player does not walk directly through the basin.
- All other area art, objects, NPCs, and mechanics remain unchanged.

Preservation: ALL previous playable releases E2.0 through E4.9 are included
byte-for-byte, except versions.json to add the E5.0 selection.

Checks: Python syntax, asset schema, all other scene artwork unchanged, all
other world data unchanged, one-area diff, connected walkmesh to Castle Path,
passable route on both sides of the fountain, ZIP member and nested APK/TAR
integrity.

The browser test remains necessary for final look-and-feel approval.
