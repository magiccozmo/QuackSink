SPIFFY’S GIFT — SGGE4.0 | EXPLICIT INTERACTION + WALK-THROUGH DOORS

Deploy sgge4.0.zip as the entire Cloudflare Workers static-assets site.
Website root still shows the version selector, with SGGE4.0 at SGGE4.0/play.html.
SGGE2.0–SGGE3.5 remain preserved byte-for-byte. Prior saves remain supported.

Changes:
- E acts ONLY on the one item, workstation, NPC, or vendor visibly under the mouse cursor,
  and only if that exact target can be reached. No nearest-object or NPC fallback.
- A hover miss does absolutely nothing, including if a thief is standing near shop goods.
- Carrying an object: to inventory it with E, hover over its actual carried sprite first.
  Clicking continues to carry/place, including bucket-on-head theft.
- Doors never require E or clicking. Walk toward and into their visible thresholds;
  the transition happens as a result of movement. Fourteen doors have JSON-authored
  walk-through regions, with approach direction and entry detection to prevent bounces.
- The blocked Inn Interior exit has a doorway-width opening in the old obstacle.
- All other artwork and all other object locations (including the Alchemy Shop
  merchandise and Britrun Market) are unchanged.
- All non-door pathways on screen edges still operate as before.
- M fast-travel and F1/menu/settings/save/backup features remain.
- HUD/game VERSION now reads E4.0.

Validation: source compile, JSON/object invariants, movement hit-zone reachability,
explicit E targeting tests, archive CRC and historical checks. Actual browser
field testing is still needed, especially rapid door traversal and theft with E.
