SPIFFY'S GIFT — SGGE2.1 — Browser usability candidate

Changes from E2.0:
- Consistent 1360 x 780 browser framebuffer and proportionally fitted canvas.
- Pygbag no longer starts with an intrinsic 1 x 1 canvas.
- Browser ignores SDL VIDEORESIZE; desktop keeps native resizing.
- Increased and adjustable in-game fonts. Click TEXT − / + in the game header.
- Existing game artwork, scenes, gameplay, save slots and backup format retained.

Deploy via the versioned full-site ZIP, NOT only the isolated version folder.
Existing SGGE2.0 stays online. The root index lists SGGE2.1 first.
This is a static Pygbag site requiring a network connection to the runtime CDN.
Browser performance and sizing need verification in Opera GX.
