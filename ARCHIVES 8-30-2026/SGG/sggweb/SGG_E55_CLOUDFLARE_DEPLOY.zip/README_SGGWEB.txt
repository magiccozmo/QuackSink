Spiffy's Gift -- SGGE3.3 full Cloudflare static-site upload.
Deploy sgge3.3.zip to the existing Cloudflare Worker. The site root is the version selector.
SGGE3.3: /SGGE3.3/play.html -- Press M to fast-travel to any area.
The complete prior SGGE2.0, 2.1, 3.0, 3.1 and 3.2 releases are preserved byte-for-byte.
Kelp's E3.2 Castle Vault remains unchanged. No other art, quests, world layout or items changed.
Earlier editions' save data is not modified by deployment. No GitHub upload.
