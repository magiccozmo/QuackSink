SGGE3.4 - The Alchemy Shop Reimagined

A complete Cloudflare-compatible copy of the Spiffy's Gift versioned site.

This release changes only assets/luma_assets_e33.json in the Pygbag runtime bundle (alchemy_shop_background, alchemy_table art, and alchemy_shop object/vendor placements). All game engine code, world navigation, other areas, and connection logic are identical to E3.3.

The frozen game engine still displays E3.3 in its own HUD; the website and deployable bundle are SGGE3.4.

Prior versions SGGE2.0 through SGGE3.3 preserved byte-for-byte at the file payload level.
