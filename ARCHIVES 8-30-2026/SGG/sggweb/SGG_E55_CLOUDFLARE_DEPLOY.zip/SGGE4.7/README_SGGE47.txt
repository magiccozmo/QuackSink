SPIFFY'S GIFT — SGGE4.7 / INN OUTSIDE ART REBUILD

Full Cloudflare deployment ZIP: sgge4.7.zip
Playable URL after deployment: SGGE4.7/play.html

This release uses SGGE4.6 as its base.  It changes ONLY the Inn Outside
scene artwork so the area better matches the style direction established by
Britrun Market.

Highlights:
* Inn Outside: full background repaint in the newer Market-style language.
* Replaces the old awkward exterior with a more coherent timber-framed inn.
* Adds a cleaner roofline, more believable door/path alignment, warmer windows,
  a better hanging sign, stronger silhouette, and cleaner landscaping.
* Keeps the gameplay role of the area intact; no world, walkmesh, door, NPC,
  inventory, save, or interaction logic was intentionally changed.
* All legacy playable versions E2.0-E4.6 are preserved byte-for-byte.

Source ZIP includes main.py, luma_assets_e33.json, the E4.7 packaging script,
this build note, and a preview render of the new Inn Outside scene.
