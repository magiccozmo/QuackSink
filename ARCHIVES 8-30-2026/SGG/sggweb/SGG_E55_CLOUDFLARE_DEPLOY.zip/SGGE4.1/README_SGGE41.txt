SPIFFY'S GIFT — SGGE4.1 / FLIGHT RECORDER

Deploy sgge4.1.zip as the COMPLETE Cloudflare Workers static asset upload.
Launch the new game via SGGE4.1/play.html or the existing selector at root.
Previous SGGE2.0–SGGE4.0 game releases are byte-for-byte preserved.

Changes relative to SGGE4.0:
- Walk-through doors use held movement intent near the doorway, even when a
  collision or walkmesh prevents crossing a tiny rectangular trigger boundary.
  They no longer demand backing up and re-entering a narrow trigger.
- A short post-transition cooldown helps prevent immediate return bounces.
- E remains strictly mouse-hover-targeted; clicking acts on the selected sprite.
  Neither E nor click activates doors, which remain movement-only.
- Diagnostic recorder keeps the latest 45,000 timestamped events in browser
  memory, including movement intent and blocked direction, doorway decisions,
  interactions, theft/witness checks, area transitions, errors and save status.
- EXPORT LOG button sits between Please Tip and MENU in the top bar.
- Automatic filenames in the form SGG_30OCT26_02-53pmVE4.1.LOG.
- Preferred Windows directory in F1 game configuration:
  D:\QuackSink\ARCHIVES 8-30-2026\SGG\sggweb
- CHOOSE FOLDER in F1 Settings requests native browser folder authorization,
  where available. Handle is stored in IndexedDB for subsequent exports.
  If unavailable/denied, EXPORT LOG uses the browser download mechanism.
  Browser security prevents silently forcing an absolute Windows path.
- Game scenery, object data, path geometry and previous downloadable archives
  are unchanged; version label is SGGE4.1.

Validation: source compiled; JSON identical to E4.0; log date/filename tests;
stationary blocked-door, direction, lateral bounds and cooldown tests; JS bridge
syntax checked with Node; complete ZIP/APK/tar integrity and historical files.
Actual Cloudflare browser gameplay and folder picker still require field test.
