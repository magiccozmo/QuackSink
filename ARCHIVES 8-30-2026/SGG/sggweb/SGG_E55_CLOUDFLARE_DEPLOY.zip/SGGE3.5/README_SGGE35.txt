SPIFFY'S GIFT — SGGE3.5 | Alchemy Shop: Merchandise Meets Furniture

Full site ZIP: upload sgge3.5.zip directly to Cloudflare Workers static assets, preserving every older playable build (E2.0—E3.4).

E3.5 is based on E3.4 and changes only the Alchemy Shop assets/world metadata, and selected game engine interaction code:
 - Two stealable herbs now rest on the west display table.
 - Potions, scroll, gold pouch and free trial vial rest on the central workbench, not on the floor.
 - Actual game object x/y positions and visual positions match; no fake visual-only relocation.
 - Shop workbench merchandise can be reached from the clear walkable strip along its front for E or a mouse click; hover-targeted E never falls through to an unrelated nearby target.
 - Vendor visibility is consistent with the open shop. A bucket on the vendor stops him witnessing the theft, while ownership rules remain intact.
 - The abandoned floor coffer was moved into a small workbench tray.
 - E fallback for doors and default nearest-object interaction remain available.
 - Game HUD version now correctly reads E3.5.

Scope: No other areas' art, object coordinates, collision/navigation, connections or quests changed. All past site version payloads are preserved byte-for-byte. Browser field validation remains necessary.
