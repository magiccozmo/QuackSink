SPIFFY'S GIFT — SGGE4.6 / ALCHEMY SHOP LAYER FIX

Full Cloudflare deployment ZIP: sgge4.6.zip
Playable URL after deployment: SGGE4.6/play.html

This release uses the last known-good SGGE4.5 as its base. It removes
actual old drawing commands instead of stacking overpaint patches:
* Alchemy Shop: removes the little standalone brown stand under the recipe.
* Alchemy Shop: removes both tall brown vertical posts at extreme scene edges.
* Removes all previous experimental interior-exit drawing commands.
* Replaces the exit with one coherent stone-and-wood south-wall doorway.
* Filters only the shop_exit_door object's redundant generic door sprite at
  render time; its world-object ID, rectangle, walk trigger and save data remain.
* Door movement intent (DOWN inside / UP outside), E targeting, inventory,
  corrected walkmesh, game logic and every other scene are unchanged.

Legacy playable versions E2.0-E4.5 are preserved byte-for-byte.

Source ZIP includes:
  main.py, luma_assets_e33.json, test_e46.py, package_e46.py,
  build_e46_assets.py, inspect_shop_layers.py, E46_DOOR_LAYER_AUDIT.png,
  README/build notes.

Validation: source compiled, JSON and exact source-diff regressions passed,
all world data and other scene assets compare unchanged against E4.5,
render-layer visual audit inspected, historical ZIP members byte-verified.
The user's browser field test remains the authoritative gameplay confirmation.
