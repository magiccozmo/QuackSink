SPIFFY'S GIFT — SGGE4.5 / ALCHEMY SHOP VISUAL CLEANUP

Full Cloudflare static site deployment: upload sgge4.5.zip to Cloudflare.
Use SGGE4.5/play.html or select E4.5 from the root version selector.
ALL previous playable versions E2.0 through E4.4 are included byte-for-byte.

From E4.4:
- Alchemy Shop background only.
- Removed the extra freestanding lower-center visual noise block.
- Removed the stacked/overpainted interior exit artwork.
- Rebuilt the lower market exit as one coherent stone-framed doorway.
- No door logic, walkmesh, or interaction-rule changes.

Validation: source compiles; JSON parses; E4.5 alchemy cleanup patch is present;
complete deployment ZIP verified against prior historical bytes except for the
new E4.5 additions and versions.json.
