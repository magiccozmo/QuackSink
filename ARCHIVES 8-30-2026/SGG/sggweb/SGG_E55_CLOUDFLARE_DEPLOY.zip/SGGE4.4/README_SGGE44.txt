SPIFFY'S GIFT — SGGE4.4 / ALCHEMY SHOP VISUAL CLEANUP

Full Cloudflare static site deployment: upload sgge4.4.zip to Cloudflare.
Use SGGE4.4/play.html or select E4.4 from the root version selector.
ALL previous playable versions E2.0 through E4.3 are included byte-for-byte.

From E4.3:
- Alchemy Shop background only: removed the little freestanding lower-center
  lectern/stand (the extra brown visual noise beneath the recipe area).
- Reworked the interior exit artwork into a cleaner, simpler stone-threshold
  door treatment. No burgundy runner/carpet and no arch surround.
- No world-object moves, no walkmesh edits, no trigger edits, no interaction
  rule changes. E behavior and door behavior are exactly as in E4.3.
- Historic versions, EXPORT LOG, flight recorder, saves, and all other areas
  are preserved.

Validation: source compiles; JSON parses; alchemy cleanup patch is present;
complete deployment ZIP verified against prior historical bytes except for the
new E4.4 additions and versions.json.
