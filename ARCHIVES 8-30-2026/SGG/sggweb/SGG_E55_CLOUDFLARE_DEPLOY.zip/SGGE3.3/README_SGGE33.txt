Spiffy's Gift SGGE3.3 — Fast Travel for testing.
M toggles a two-column menu listing all 21 current areas. Click to teleport to a validated entry point.
M or Esc closes the menu. Movement and game simulation pause while the map is open.
Teleport keeps objects, gold, quests, saves and inventory intact; bypasses travel prerequisites.
The Castle Vault artwork remains Kelp's E3.2 design. No art or world JSON changes.
Open play.html. All previous versions remain available in the root site selector.
