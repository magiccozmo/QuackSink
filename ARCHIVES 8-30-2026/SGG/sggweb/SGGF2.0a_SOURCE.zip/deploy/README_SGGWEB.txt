SPIFFY'S GIFT — COMPLETE CLOUDFLARE SITE

Current release: SGGF2.0a.
Exactly eight selectable editions are included: current SGGF2.0a plus prior SGGF1.666HellFinal and six legacy versions (SGGF1.666, SGGF1.6, SGGF1.0, SGGE3.2, SGGE3.1 and SGGE2.0).

F2.0a is a startup hotfix for the F2.0 class-definition ordering error. Easy and Normal begin in the Stables; Easy has all ordinary fast-travel destinations open; Normal has discovered destinations only; Spiffy Challenge begins in HELLgs Inn. Game behavior is otherwise unchanged.

The original F2.0 source and deployment packages remain separate, unchanged release archives.
