SPIFFY'S GIFT — TRIMMED COMPLETE CLOUDFLARE SITE

Current edition: SGGJ1.0. The selector contains SGGJ1.0 and the eight preserved legacy editions only. Intermediate G/H/I editions have been removed from the deployed version folders and catalog.

SGGJ1.0 is a packaging and version-identity release based on SGGI1.3. It retains the visible Giant Camp arrow/caption overlap transition and safe return re-arm behavior without gameplay changes. See SGGJ1.0/SGGJ1.0_README.txt, SGGJ1.0/SGGJ1.0_LUMA_LOG_Entry035.txt, and SGGJ1.0/SGGJ1.0_TEST_RESULTS.txt.

The Global Usage Worker source is included at SGGG1.4_GLOBAL_LOG_WORKER.js and accepts SGGJ1.0 game_version values. This Worker is a separate Cloudflare service and must be deployed separately by the site owner. Neither the static site nor Worker was deployed by Luma.
