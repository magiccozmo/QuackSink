"""SGGE5.7 surgical regression: only the anonymous comment feature is added."""
from pathlib import Path
import ast
import hashlib
import json
import zipfile

HERE = Path(__file__).resolve().parent
base_main = (HERE / 'E56_MAIN_BASE.py').read_text(encoding='utf-8')
main = (HERE / 'main.py').read_text(encoding='utf-8')
assets = (HERE / 'luma_assets_e33.json').read_bytes()
base_assets = (HERE / 'E56_BASE_LUMA_ASSETS.json').read_bytes()
ast.parse(main)
assert hashlib.sha256(assets).digest() == hashlib.sha256(base_assets).digest(), 'E5.6 art/world JSON changed'

# Undo only the explicitly authorized E5.7 insertions and release labels.
start = main.index('class E57StateMachine(E56StateMachine):')
end = main.index('async def main():', start)
reconstructed = main[:start] + 'async def main():' + main[end + len('async def main():'):]
reconstructed = reconstructed.replace('import threading\nimport urllib.error\nimport urllib.request\n', '', 1)
reconstructed = reconstructed.replace('VERSION = "E5.7"', 'VERSION = "E5.6"', 1)
reconstructed = reconstructed.replace('label = "SPIFFY\'S GIFT  |  E5.7  |  "',
                                      'label = "SPIFFY\'S GIFT  |  E5.6  |  "', 1)
js_new = '''    takeError: function () {
      const message = this.importError;
      this.importError = null;
      return message;
    },
    commentResult: null,
    postComment: function (message) {
      const self = this;
      self.commentResult = null;
      fetch("https://spiffys-gift-comments-api.magiccozmo.workers.dev/comment", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: String(message) })
      }).then(async function (response) {
        let payload = {};
        try { payload = await response.json(); } catch (e) {}
        self.commentResult = JSON.stringify({
          http_ok: response.ok,
          status: response.status,
          payload: payload
        });
      }).catch(function (error) {
        self.commentResult = JSON.stringify({ network_error: String(error) });
      });
    },
    takeCommentResult: function () {
      const result = this.commentResult;
      this.commentResult = null;
      return result;
    }
'''
js_old = '''    takeError: function () {
      const message = this.importError;
      this.importError = null;
      return message;
    }
'''
assert reconstructed.count(js_new) == 1, 'Comment network bridge does not match the reviewed insertion'
reconstructed = reconstructed.replace(js_new, js_old, 1)
reconstructed = reconstructed.replace('machine = E57StateMachine(archive, config, warning)',
                                      'machine = E56StateMachine(archive, config, warning)', 1)
reconstructed = reconstructed.replace('ui = E57Interface(machine)', 'ui = E41Interface(machine)', 1)
assert reconstructed == base_main, 'Unexpected change outside the E5.7 comment feature/version labels'

assert 'class E57StateMachine(E56StateMachine):' in main
assert 'class E57Interface(E41Interface):' in main
assert 'https://spiffys-gift-comments-api.magiccozmo.workers.dev/comment' in main
assert 'body: JSON.stringify({ message: String(message) })' in main
assert 'json.dumps({"message": message}' in main
assert 'self.e57_comment_text = (self.e57_comment_text + addition)[:1000]' in main
assert 'pygame.KMOD_CTRL' in main and 'pygame.TEXTINPUT' in main
assert 'LEAVE A COMMENT' in main
assert 'clear_right = max(0, smaller.x - 9)' in main
assert 'machine = E57StateMachine(archive, config, warning)' in main
assert 'ui = E57Interface(machine)' in main

# Header geometry at the fixed 1360px browser width: tip | export | comment | menu.
menu_x = 1360 - 114
comment_x = menu_x - 12 - 176
export_x = comment_x - 12 - 133
tip_x = export_x - 15 - 235
assert tip_x + 235 < export_x
assert export_x + 133 < comment_x
assert comment_x + 176 < menu_x
assert tip_x == 663 and export_x == 913 and comment_x == 1058 and menu_x == 1246

page = (HERE / 'play.html').read_text(encoding='utf-8')
assert 'SGGE5.7' in page and 'sgge57.tar.gz' in page and 'sgge57.apk' in page
assert 'SGGE5.6' not in page and 'sgge56' not in page

print('PASS E5.7 source syntax and exact-change audit: E5.6 main.py restored byte-for-byte after removing only the new feature/labels.')
print('PASS E5.6 artwork/world JSON preserved byte-for-byte.')
print('PASS comment API route, text cap, UI order and versioned static page.')
