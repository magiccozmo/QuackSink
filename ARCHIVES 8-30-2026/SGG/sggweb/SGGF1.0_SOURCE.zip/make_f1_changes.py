from pathlib import Path
import json, math, hashlib, re, textwrap
from PIL import Image, ImageDraw

WORK = Path('/mnt/data/sgg_f1_work')
MAIN = WORK / 'main.py'
ASSETS = WORK / 'luma_assets_e33.json'
DEPLOY_DIR = WORK / 'deploy_e57'

# Preserve exact E5.7 baselines for regression verification and future archaeology.
if not (WORK / 'E57_MAIN_BASE.py').exists():
    (WORK / 'E57_MAIN_BASE.py').write_bytes(MAIN.read_bytes())
if not (WORK / 'E57_BASE_LUMA_ASSETS.json').exists():
    (WORK / 'E57_BASE_LUMA_ASSETS.json').write_bytes(ASSETS.read_bytes())

# ---------------------------------------------------------------------------
# 1) Luma Draw Engine assets: procedural Stable yard, driver and breakfast.
# ---------------------------------------------------------------------------
art = []
def R(x, y, w, h, color, border=0, radius=0):
    art.append({'op':'rect','rect':[int(x),int(y),int(w),int(h)],'color':list(color),'border':int(border),'radius':int(radius)})
def P(points, color, border=0):
    art.append({'op':'polygon','points':[[int(x),int(y)] for x,y in points],'color':list(color),'border':int(border)})
def L(points, color, width=1):
    art.append({'op':'line','points':[[int(x),int(y)] for x,y in points],'color':list(color),'width':int(width)})
def C(x, y, r, color, border=0):
    art.append({'op':'circle','center':[int(x),int(y)],'radius':int(r),'color':list(color),'border':int(border)})
def E(x, y, w, h, color, border=0):
    art.append({'op':'ellipse','rect':[int(x),int(y),int(w),int(h)],'color':list(color),'border':int(border)})

# A soft autumn-blue sky with three distant ridgelines.
for i in range(12):
    t = i / 11
    col = (int(99 + 72*t), int(153 + 46*t), int(181 + 18*t))
    R(0, i*28, 1280, 29, col)
# Clouds, with restrained highlights.
for x,y,w,h in [(120,82,145,32),(440,105,118,27),(840,67,165,36),(1080,123,122,28)]:
    E(x,y,w,h,(210,220,203)); E(x+18,y-10,w//2,h//2,(222,229,211)); E(x+w//2,y-4,w//3,h//2,(218,227,208))
    L([(x+15,y+h-4),(x+w-14,y+h-4)],(188,204,190),2)
# Distant mountains and rolling foothills.
P([(0,347),(105,286),(205,334),(318,252),(436,337),(548,275),(694,353),(832,262),(960,342),(1090,279),(1280,352),(1280,438),(0,438)],(91,119,119))
P([(0,370),(157,316),(288,367),(431,300),(590,376),(742,309),(912,381),(1055,319),(1280,371),(1280,458),(0,458)],(105,132,117))
P([(0,392),(195,346),(364,391),(527,345),(695,397),(865,348),(1042,395),(1188,350),(1280,378),(1280,470),(0,470)],(120,145,103))
# Evergreen silhouettes on the horizon.
for x,base,h in [(28,390,66),(74,389,84),(130,394,57),(565,386,69),(615,390,91),(668,388,61),(1000,392,67),(1050,386,86),(1110,391,62),(1252,390,75)]:
    P([(x,base-h),(x-20,base-18),(x-9,base-22),(x-25,base-4),(x+25,base-4),(x+10,base-24),(x+19,base-19)],(53,83,67))
    R(x-2,base-6,4,10,(91,68,45))
# Meadow.
R(0,355,1280,285,(91,125,77))
P([(0,385),(178,367),(334,393),(512,370),(680,399),(862,369),(1042,395),(1172,368),(1280,382),(1280,640),(0,640)],(102,133,80))
P([(0,500),(195,470),(360,508),(540,480),(720,510),(900,477),(1080,508),(1280,468),(1280,640),(0,640)],(89,119,70))
# East-west stable-yard road: this visually reinforces the new side-to-side connection.
P([(0,411),(160,420),(365,413),(590,421),(815,411),(1030,418),(1280,404),(1280,573),(1035,582),(810,571),(585,582),(365,570),(165,580),(0,566)],(130,112,83))
P([(0,419),(165,428),(363,421),(586,430),(815,420),(1030,427),(1280,413),(1280,433),(1030,447),(815,440),(586,449),(363,441),(165,446),(0,438)],(164,145,111))
P([(0,550),(165,563),(365,551),(585,563),(810,552),(1035,562),(1280,548),(1280,573),(1035,582),(810,571),(585,582),(365,570),(165,580),(0,566)],(92,78,60))
# Cobblestones, staggered rows.
stone_cols=[(151,132,101),(143,125,96),(158,140,108),(136,119,93),(166,147,114)]
for row,y in enumerate((454,481,509,537)):
    for j,x in enumerate(range(-10+(row%2)*26,1285,54)):
        w=37+(j%3)*4
        E(x,y,w,12,stone_cols[(j+row*2)%len(stone_cols)])
        L([(x+5,y+3),(x+w-7,y+3)],(185,165,128),1)
# Roadside verge, grasses and wildflowers.
for i in range(78):
    x=(i*157+37)%1280
    y=365+((i*61)%38) if i%2==0 else 582+((i*31)%45)
    L([(x,y+12),(x-3,y-5)],(54,93,55),2)
    L([(x,y+12),(x+5,y-4)],(65,101,57),2)
    if i%6==0:
        C(x+4,y-7,3,(229,202,122))
# West gateway to Outside Gate: two stout stone piers and an open timber arch.
E(8,435,150,23,(42,55,45))
R(6,244,38,211,(104,105,91)); R(2,234,46,18,(145,143,119)); R(7,259,36,12,(130,129,109))
R(96,244,40,211,(104,105,91)); R(91,234,50,18,(145,143,119)); R(96,259,40,12,(130,129,109))
P([(42,253),(61,205),(85,205),(103,253)],(91,90,77))
R(53,207,39,10,(113,91,63)); R(52,216,42,8,(75,57,43))
for y in range(273,441,28):
    L([(7,y),(43,y)],(72,76,67),2); L([(96,y),(136,y)],(72,76,67),2)
# Wooden stable sign and hanging lanterns.
R(149,168,104,43,(74,45,31)); R(154,173,94,33,(168,125,70),2)
L([(166,180),(236,180)],(224,190,128),2); L([(166,190),(224,190)],(115,77,42),2)
R(187,149,5,20,(83,55,36)); R(218,149,5,20,(83,55,36))
# Main stable barn shadow, stone plinth and timber facade.
E(126,334,430,22,(46,64,46))
R(145,208,395,130,(104,70,47)); R(151,219,384,109,(139,97,63)); R(151,319,384,22,(91,78,63))
R(145,207,395,9,(67,48,37)); R(149,214,387,5,(177,132,83))
# Barn roof, shingles and ridge cap.
P([(116,211),(321,91),(569,211),(545,224),(321,116),(141,224)],(76,49,42))
P([(116,206),(321,89),(569,206),(557,218),(321,105),(129,218)],(117,65,48))
L([(116,206),(321,89),(569,206)],(183,120,76),5)
for n in range(1,10):
    x0=321-(n*20); x1=321+(n*25)
    L([(x0,101+n*11),(x0+30,205)],(146,82,57),2)
    L([(x1,101+n*11),(x1-23,205)],(146,82,57),2)
L([(130,220),(555,220)],(63,45,36),5)
# Upper hayloft and timber braces.
R(276,149,89,44,(79,54,39)); R(282,154,77,33,(170,130,82),2)
P([(290,178),(320,158),(349,178)],(83,57,37))
R(310,180,22,13,(47,37,28))
for x in (168,190,262,373,468,520):
    R(x,222,9,104,(73,48,34)); R(x+2,225,2,96,(177,124,70))
L([(159,231),(533,317)],(101,64,39),5)
L([(533,231),(159,317)],(101,64,39),5)
# Two open stall bays with door frames and warm interior straw.
for x in (213,374):
    R(x,244,125,86,(51,38,29)); R(x+8,252,109,76,(42,34,28))
    R(x+15,258,95,67,(93,67,43)); R(x+19,262,87,59,(111,79,50))
    for xx in range(x+20,x+108,22):
        R(xx,260,4,62,(69,47,34))
    L([(x+13,270),(x+112,270)],(182,132,76),3)
    L([(x+12,326),(x+113,326)],(72,49,34),4)
    # Straw piled at the back of the stall.
    for j in range(5):
        L([(x+19+j*17,319),(x+30+j*17,301)],(200,165,94),3)
# Barn side windows, hinges and decorative ironwork.
for x in (175,508):
    R(x,257,24,31,(49,39,31)); R(x+3,260,18,25,(164,174,150),2)
    L([(x+12,260),(x+12,285)],(62,56,45),2)
for x in (205,356,515):
    C(x,306,3,(215,176,101))
# Tack shed in the far east, above the hidden chest/kitty roaming space.
E(1054,317,206,18,(47,63,43))
R(1080,206,164,119,(110,75,50)); R(1087,218,151,100,(145,102,65))
P([(1064,213),(1159,151),(1260,213),(1248,225),(1159,173),(1077,225)],(87,52,42))
L([(1064,213),(1159,151),(1260,213)],(181,119,73),4)
for x in range(1092,1238,18): L([(x,221),(x+12,210)],(171,119,76),2)
R(1137,252,52,74,(50,39,30)); R(1142,258,42,64,(80,55,37))
R(1100,235,24,31,(61,43,32)); R(1104,239,16,23,(173,185,163),2)
# A small overhang, fence rails, feed trough and hay.
R(1074,224,177,8,(74,49,35)); R(1074,223,177,3,(188,133,75))
R(1035,383,110,18,(71,56,40)); R(1042,374,98,11,(127,91,55))
for x in (1049,1119): R(x,399,8,26,(67,54,40))
E(1080,361,70,25,(180,149,91)); L([(1082,374),(1147,374)],(207,178,113),2)
# Hay bales and barrels around the carriage yard.
R(542,382,56,35,(169,132,73)); R(548,375,47,10,(196,159,93)); L([(548,386),(589,414)],(117,84,44),3)
R(507,397,42,30,(149,113,62)); L([(512,399),(546,424)],(213,173,101),2)
R(565,428,40,25,(143,91,50)); R(561,425,48,7,(91,58,37))
# The carriage: a large red-brown coach with ornate trim and spoked wheels.
E(565,459,373,24,(45,57,39))
# wheels first, behind the coach body
for cx in (667,837):
    C(cx,424,48,(54,43,32),0); C(cx,424,40,(155,115,70),6); C(cx,424,34,(79,54,38),3)
    for deg in range(0,360,45):
        rad=math.radians(deg)
        L([(cx,424),(cx+int(33*math.cos(rad)),424+int(33*math.sin(rad)))],(220,178,111),3)
    C(cx,424,8,(202,162,101)); C(cx,424,3,(59,43,31))
# undercarriage and body
R(624,388,254,20,(54,42,31)); R(642,398,218,13,(101,65,39))
P([(609,324),(860,324),(889,383),(881,408),(627,408),(610,380)],(75,43,34))
P([(621,333),(851,333),(873,382),(861,397),(637,397),(624,376)],(142,65,47))
L([(624,333),(850,333),(873,382)],(224,172,99),5)
L([(632,391),(865,391)],(215,171,103),4)
R(656,344,179,37,(69,42,34)); R(665,350,161,24,(155,82,58),2)
# doors, windows and bright gold details
R(695,350,53,38,(55,39,33)); R(701,356,41,26,(104,143,142),2)
L([(721,357),(721,382)],(48,48,42),2)
R(766,350,55,38,(55,39,33)); R(772,356,43,26,(104,143,142),2)
L([(793,357),(793,382)],(48,48,42),2)
C(746,385,4,(239,194,112)); R(646,407,230,5,(213,168,96))
# driver's box and canopy
R(704,282,123,54,(91,55,37)); R(715,289,101,38,(133,86,54))
P([(680,287),(694,245),(833,245),(857,287)],(68,42,34))
P([(690,283),(704,253),(823,253),(844,283)],(125,66,47))
L([(687,285),(849,285)],(219,174,103),4)
R(709,289,117,6,(181,127,75)); R(724,303,88,5,(73,45,33))
# small lanterns on the carriage
for x in (628,867):
    R(x,351,13,22,(48,39,30)); R(x+3,355,7,13,(240,189,99)); L([(x+6,348),(x+6,355)],(49,38,27),2)
# Harness horse at the east/front side of the carriage.
E(887,376,100,57,(48,45,36)); E(899,365,82,43,(118,70,46))
P([(951,380),(963,328),(985,309),(1001,319),(982,371),(973,403)],(103,59,42))
E(975,300,44,43,(126,76,51)); P([(981,307),(976,285),(988,299)],(67,48,38)); P([(1001,307),(1010,286),(1011,309)],(67,48,38))
L([(988,324),(1005,326),(1017,339)],(66,47,36),6)
L([(897,402),(892,452)],(55,45,34),8); L([(918,405),(916,455)],(55,45,34),8)
L([(956,401),(954,449)],(55,45,34),8); L([(977,393),(981,447)],(55,45,34),8)
L([(889,449),(902,449)],(42,33,27),6); L([(910,452),(924,452)],(42,33,27),6)
L([(949,447),(963,447)],(42,33,27),6); L([(976,445),(990,445)],(42,33,27),6)
L([(975,328),(952,350),(931,365)],(49,39,32),6)
L([(961,340),(947,374),(911,379)],(194,143,83),3)
L([(997,323),(1018,339),(1015,373)],(192,145,88),3)
# Paddock fence in the middle distance, leaving open road portals at both ends.
for y in (360,385):
    L([(140,y),(520,y+5)],(103,72,43),5)
    L([(930,y+4),(1060,y)],(103,72,43),5)
for x in (160,235,310,385,460,520,940,1000,1060):
    R(x,y-8,7,45,(87,60,39))
# Water bucket, feed sacks, and a few flowers by the fence.
R(490,376,34,40,(74,82,75)); R(486,372,42,8,(149,144,119)); L([(494,380),(494,410)],(199,197,177),2)
R(451,376,28,23,(164,131,78)); L([(455,380),(477,396)],(210,179,112),2)
for x,y in [(115,590),(294,603),(530,592),(914,600),(1080,604),(1234,588)]:
    L([(x,y+15),(x-4,y-4)],(54,91,49),2); L([(x,y+15),(x+4,y-5)],(65,108,54),2)
    C(x-4,y-5,3,(212,174,100)); C(x+4,y-6,3,(219,197,120))
# Tiny chicken silhouettes pecking at the yard's edge.
for x,y in [(395,585),(447,572),(1150,574)]:
    E(x,y,26,17,(232,222,190)); C(x+21,y+4,7,(231,219,185)); P([(x+25,y+3),(x+33,y+7),(x+25,y+9)],(197,120,55))
    C(x+19,y+2,2,(39,34,29)); C(x+22,y-2,3,(177,53,44))
    L([(x+9,y+13),(x+9,y+22)],(92,67,43),2); L([(x+18,y+13),(x+18,y+22)],(92,67,43),2)
# Stable-yard lantern posts and detail.
for x in (175,565,1055):
    R(x,301,7,94,(72,53,38)); R(x-8,291,23,12,(60,42,31)); R(x-5,276,17,18,(194,143,76)); R(x-6,274,19,4,(70,47,31))
    C(x+3,285,4,(255,217,137))
    L([(x+3,301),(x+3,395)],(43,37,29),2)
# Road edging, hoof marks and wooden wheel-rut accents.
L([(0,410),(160,420),(365,413),(590,421),(815,411),(1030,418),(1280,404)],(80,72,56),4)
L([(0,566),(165,580),(365,570),(585,582),(810,571),(1035,582),(1280,573)],(82,72,55),4)
for x,y in [(230,462),(280,535),(985,480),(1050,525),(420,454),(520,540)]:
    E(x,y,20,8,(108,94,72))

stable_bg={'width':1280,'height':640,'commands':art}

# Procedural hangry/happy driver portraits: same character, expression changes only.
def make_driver(happy=False):
    c=[]
    def rr(x,y,w,h,col,b=0,rad=0): c.append({'op':'rect','rect':[x,y,w,h],'color':list(col),'border':b,'radius':rad})
    def pp(pts,col,b=0): c.append({'op':'polygon','points':pts,'color':list(col),'border':b})
    def ll(pts,col,w=1): c.append({'op':'line','points':pts,'color':list(col),'width':w})
    def cc(x,y,r,col,b=0): c.append({'op':'circle','center':[x,y],'radius':r,'color':list(col),'border':b})
    def ee(x,y,w,h,col,b=0): c.append({'op':'ellipse','rect':[x,y,w,h],'color':list(col),'border':b})
    ee(10,104,68,10,(42,45,36))
    # boots and trousers
    rr(20,88,19,18,(54,45,37)); rr(49,88,19,18,(54,45,37))
    rr(16,101,25,9,(37,31,27)); rr(45,101,25,9,(37,31,27))
    rr(23,59,17,33,(69,62,49)); rr(48,59,17,33,(69,62,49))
    # broad russet coat and waistcoat
    pp([(16,51),(24,40),(38,35),(58,39),(72,51),(67,88),(18,88)],(104,61,43))
    pp([(27,43),(42,46),(51,44),(62,50),(59,81),(28,81)],(169,112,65))
    ll([(43,46),(43,84)],(65,43,32),3)
    rr(29,80,33,6,(73,48,33)); cc(44,83,3,(224,181,106))
    # folded arms
    pp([(17,54),(8,64),(18,75),(35,71),(42,63)],(130,77,49))
    pp([(70,54),(79,64),(70,76),(52,72),(45,63)],(130,77,49))
    ll([(15,64),(31,71),(56,70),(72,62)],(196,142,83),4)
    # neck, face, ears
    rr(34,30,22,12,(177,117,77))
    ee(22,9,45,38,(199,147,101)); ee(18,22,10,13,(184,121,77)); ee(62,22,10,13,(184,121,77))
    # sideburns and hair
    pp([(20,20),(21,7),(31,1),(55,1),(67,12),(67,25),(61,20),(55,17),(31,18),(26,28)],(74,48,31))
    # cap
    pp([(15,12),(21,0),(61,0),(70,12),(64,17),(23,17)],(77,58,41))
    rr(20,13,48,5,(148,99,59)); rr(24,6,35,4,(109,73,47))
    # eyes and brows
    if happy:
        ll([(31,26),(37,28)],(44,35,28),2); ll([(51,28),(57,26)],(44,35,28),2)
        ee(37,31,7,3,(48,38,30)); ee(51,31,7,3,(48,38,30))
        # cheerful broad moustache / smile
        ll([(36,38),(43,42),(51,39),(56,37)],(89,49,30),3)
        ll([(39,44),(46,47),(53,44)],(116,60,39),2)
    else:
        ll([(28,24),(40,28)],(54,33,26),4); ll([(49,28),(62,23)],(54,33,26),4)
        cc(36,31,2,(37,31,26)); cc(54,31,2,(37,31,26))
        # frown + thick moustache
        ll([(36,41),(44,38),(51,41)],(76,43,28),4)
        ll([(39,47),(44,45),(50,47)],(68,38,29),3)
    # scarf and cap badge
    pp([(32,48),(44,53),(56,48),(59,56),(44,61),(29,56)],(73,91,75))
    cc(44,8,3,(221,178,92))
    return {'width':86,'height':116,'commands':c}

# Egg McGuffin Sammich icon, entirely drawn from Luma primitives.
sammich=[]
def sr(x,y,w,h,col,b=0,rad=0): sammich.append({'op':'rect','rect':[x,y,w,h],'color':list(col),'border':b,'radius':rad})
def sp(points,col,b=0): sammich.append({'op':'polygon','points':points,'color':list(col),'border':b})
def sl(points,col,w=1): sammich.append({'op':'line','points':points,'color':list(col),'width':w})
def sc(x,y,r,col,b=0): sammich.append({'op':'circle','center':[x,y],'radius':r,'color':list(col),'border':b})
def se(x,y,w,h,col,b=0): sammich.append({'op':'ellipse','rect':[x,y,w,h],'color':list(col),'border':b})
se(7,46,70,10,(48,39,31))
sp([(9,34),(17,17),(57,14),(75,34),(66,43),(16,43)],(180,116,55))
sp([(14,33),(19,22),(60,21),(70,34)],(242,206,131))
se(21,21,43,15,(248,226,174)); se(31,18,24,20,(255,239,205))
sc(43,28,7,(237,188,73)); sc(43,28,3,(248,225,155))
sp([(13,34),(69,34),(63,40),(18,40)],(68,119,62))
sp([(14,39),(67,39),(60,48),(22,49)],(166,95,48))
sl([(13,34),(70,34)],(105,67,40),2)
# tiny sesame seeds
for x,y in [(26,21),(35,17),(52,20),(61,25)]: se(x,y,3,2,(255,234,189))
sammich_asset={'width':82,'height':60,'commands':sammich}

# Load and update the current E5.7 world definition.
data=json.loads(ASSETS.read_text(encoding='utf-8'))
data['assets']['c1_bg_stables']=stable_bg
data['assets']['carriage_driver']=make_driver(False)
data['assets']['carriage_driver_happy']=make_driver(True)
data['assets']['sammich']=sammich_asset

stables=next(a for a in data['world']['areas'] if a['area_id']=='stables')
stables['vendors']=[{
    'vendor_id':'carriage_driver','name':'Carriage Driver','x':1024,'y':447,
    'width':76,'height':108,'sight_radius':365,'recipe':'carriage_driver'
}]
stables['solid_rects']=[
    [145,214,398,117],     # main stable barn
    [614,345,262,72],      # carriage coach body
    [1081,247,167,83],     # eastern tack shed
]
stables['sight_blockers']=[]
stables['conceal_zones']=[]
stables['navigation']={'regions':[[[20,327],[1260,327],[1260,627],[20,627]]]} 

connections=data['world']['connections']
connections[:]=[c for c in connections if c['connection_id'] not in ('outside_gate_bottom_stables','stables_top_outside_gate')]
# Insert explicit side-to-side link pair while preserving the Stables-to-Plains east link.
connections.append({
    'connection_id':'outside_gate_right_stables','from_area_id':'outside_gate','to_area_id':'stables',
    'trigger':'edge','edge':'right','arrival_x':60,'arrival_y':480,'label':'Enter Stables'
})
connections.append({
    'connection_id':'stables_left_outside_gate','from_area_id':'stables','to_area_id':'outside_gate',
    'trigger':'edge','edge':'left','arrival_x':1210,'arrival_y':480,'label':'Return to Outside Gate'
})
# Version metadata, while preserving all unrelated engine fields.
data['version']='SGGF1.0'
data['art_revision']='F1.0 — full procedural Stables yard, coach, and hangry carriage driver; original kitty recipes untouched.'
data['notes']='F1.0 completes the mage breakfast reward and Act One finale; Outside Gate and Stables connect west/east; all previous art/world data is retained except the rebuilt Stables background.'
ASSETS.write_text(json.dumps(data,ensure_ascii=False,separators=(',',':')),encoding='utf-8')

# Produce a PIL preview of the exact new background recipe for visual inspection.
img=Image.new('RGB',(1280,640),(0,0,0))
d=ImageDraw.Draw(img)
for cmd in stable_bg['commands']:
    op=cmd['op']; col=tuple(cmd['color']); border=int(cmd.get('border',0))
    if op=='rect':
        x,y,w,h=cmd['rect']; box=(x,y,x+w,y+h)
        if border: d.rectangle(box,outline=col,width=max(1,border))
        else: d.rounded_rectangle(box,radius=int(cmd.get('radius',0)),fill=col)
    elif op=='polygon':
        pts=[tuple(p) for p in cmd['points']]
        if border: d.polygon(pts,outline=col)
        else: d.polygon(pts,fill=col)
    elif op=='line': d.line([tuple(p) for p in cmd['points']],fill=col,width=int(cmd.get('width',1)))
    elif op=='circle':
        x,y=cmd['center']; r=cmd['radius']; box=(x-r,y-r,x+r,y+r)
        if border: d.ellipse(box,outline=col,width=max(1,border))
        else: d.ellipse(box,fill=col)
    elif op=='ellipse':
        x,y,w,h=cmd['rect']; box=(x,y,x+w,y+h)
        if border: d.ellipse(box,outline=col,width=max(1,border))
        else: d.ellipse(box,fill=col)
preview=WORK/'F1_STABLES_BACKGROUND_PREVIEW.png'
img.save(preview)
print('Stable art commands:',len(art),'preview:',preview)
print('New driver asset commands:',len(data['assets']['carriage_driver']['commands']))
print('New sammich asset commands:',len(data['assets']['sammich']['commands']))
