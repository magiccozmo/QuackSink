from pathlib import Path
import re

WORK = Path('/mnt/data/sgg_f1_work')
MAIN = WORK / 'main.py'
s = MAIN.read_text(encoding='utf-8')

# Version banner and version metadata.
assert 'VERSION = "E5.7"' in s
s = s.replace('VERSION = "E5.7"  # Major letter = feature/UI generation; whole number = release; decimal = minor fix.',
              'VERSION = "F1.0"  # First official Part One release.')

# Update the Stables contextual hint, retaining the existing chest discovery guidance.
old_hint = "elif g.current_area_id=='stables':hint=f'KITTY CARAVAN: hidden chest 2,000 gold, respawns in two days. Day {g.c1_day}.'"
new_hint = "elif g.current_area_id=='stables':hint=(f'KITTY CARAVAN: hidden chest 2,000 gold, respawns in two days. Day {g.c1_day}. ' + ('CARRIAGE READY: speak to Cozmo for the Part One finale.' if g.c1_flags.get('driver_fed') else 'HANGRY CARRIAGE DRIVER: he needs breakfast.'))"
assert old_hint in s
s = s.replace(old_hint, new_hint)

insert_anchor = '\n\nasync def main():\n'
assert s.count(insert_anchor) == 1

f1_classes = r'''

# ===========================================================================
# SGGF1.0 — Part One finale, carriage breakfast quest, and Stables patrol.
# This layer intentionally preserves the E5.7 comments system and save schema.
# ===========================================================================

class F1GameModel(E56GameModel):
    """E5.7 world with durable Part One completion flags."""

    def c1_make_item(self, name, kind, *, price=0, area=None, stolen=False):
        obj = super().c1_make_item(name, kind, price=price, area=area, stolen=stolen)
        if kind == 'sammich':
            obj.width, obj.height = 82, 60
        return obj

    def f1_prepare_state(self):
        flags = self.c1_flags
        flags.setdefault('egg_mcguffin_awarded', False)
        flags.setdefault('driver_fed', False)
        flags.setdefault('carriage_unlocked', bool(flags.get('driver_fed')))
        flags.setdefault('cozmo_finale_seen', False)

        # The driver is a normal world vendor so the existing approach, click,
        # E-key, speech-anchor, save and bucket systems continue to work.
        stables = self.areas.get('stables')
        if stables is not None:
            driver = next((v for v in stables.vendors
                           if v.get('vendor_id') == 'carriage_driver'), None)
            if driver is not None:
                driver['recipe'] = ('carriage_driver_happy' if flags.get('driver_fed')
                                    else 'carriage_driver')
            cozmo = next((v for v in stables.vendors
                          if v.get('vendor_id') == 'cozmo_part_one'), None)
            if flags.get('driver_fed'):
                if cozmo is None:
                    stables.vendors.append({
                        'vendor_id': 'cozmo_part_one',
                        'name': 'Cozmo',
                        'x': 390, 'y': 466,
                        'width': 70, 'height': 99,
                        'sight_radius': 365,
                        'recipe': 'cozmo_magician',
                    })
            elif cozmo is not None:
                stables.vendors[:] = [v for v in stables.vendors
                                      if v.get('vendor_id') != 'cozmo_part_one']

    def f1_existing_sammich(self):
        return next((o for o in self.objects
                     if o.kind == 'sammich' and o.area_id != '__consumed__'), None)


class F1StateMachine(E57StateMachine):
    """F1.0 gameplay layer: Fearmonger's sandwich, hungry driver, Part One."""

    def _f1_upgrade_model(self):
        g = self.game
        if g is None:
            return
        if not isinstance(g, F1GameModel):
            g.__class__ = F1GameModel
        g.f1_prepare_state()
        self._f1_award_legacy_quest_reward(announce=True)
        g.f1_prepare_state()

    def _f1_award_legacy_quest_reward(self, announce=False):
        """Grant the promised reward to completed E5.7 saves exactly once."""
        g = self.game
        if g is None or not g.c1_flags.get('quest_done'):
            return False
        flags = g.c1_flags
        if flags.get('egg_mcguffin_awarded'):
            return False
        existing = g.f1_existing_sammich()
        if existing is None:
            g.c1_make_item('Egg McGuffin Sammich', 'sammich', price=0)
            created = True
        else:
            created = False
        flags['egg_mcguffin_awarded'] = True
        self._log('F1 QUEST', 'Egg McGuffin Sammich reward attached to completed Fearmonger quest; '
                              f'created={created}')
        if announce and created:
            self._speech('FEARMONGER OWES YOU BREAKFAST! An Egg McGuffin Sammich has been added to your inventory.', 8)
        return created

    def start_game(self):
        super().start_game()
        self._f1_upgrade_model()
        self._set_status('SGGF1.0: Part One finale, carriage breakfast, and rebuilt Stables.')

    def _read_save(self, slot):
        super()._read_save(slot)
        self._f1_upgrade_model()

    def _talk(self, npc):
        if npc.get('npc_id') != 'fearmonger':
            return super()._talk(npc)
        result = super()._talk(npc)
        g = self.game
        if g is not None and g.c1_flags.get('quest_done'):
            created = self._f1_award_legacy_quest_reward(announce=False)
            g.f1_prepare_state()
            if created:
                self._dialogue(
                    'Fearmonger',
                    'Ah! My confidence is restored! And as promised, here is the Egg McGuffin Sammich. '
                    'A small token of my gratitude. Please, take it!',
                    [{'text': 'I shall put it to good use.', 'action': 'close'}])
        return result

    def _talk_vendor(self, vendor):
        vendor_id = vendor.get('vendor_id')
        g = self.game
        if g is None:
            return super()._talk_vendor(vendor)

        if vendor_id == 'carriage_driver':
            g.f1_prepare_state()
            flags = g.c1_flags
            if flags.get('driver_fed'):
                self._dialogue(
                    'Carriage Driver',
                    'Ahhh. Breakfast! I am a new man. The carriage is ready, and the horses are eager. '
                    'The road beyond Britrun is still being prepared, though. No onward passengers just yet!',
                    [{'text': 'Enjoy the rest of your breakfast.', 'action': 'close'}])
                return
            sammich = g.c1_have(lambda o: o.kind == 'sammich')
            if sammich is not None:
                self._dialogue(
                    'Carriage Driver',
                    'Wait a minute... Is that an EGG MCGUFFIN SAMMICH? '
                    'You beautiful genius! May I have it? I am absolutely STARVING!',
                    [{'text': 'Give him the Egg McGuffin Sammich.', 'action': 'f1_feed_driver'},
                     {'text': 'Not just yet.', 'action': 'close'}])
                return
            if flags.get('quest_done'):
                self._dialogue(
                    'Carriage Driver',
                    'Fearmonger said he had an Egg McGuffin Sammich for me. '
                    'Check your pack, friend. I am still HANGRY, and I am not moving this carriage until breakfast arrives!',
                    [{'text': 'I will look for it.', 'action': 'close'}])
                return
            self._dialogue(
                'Carriage Driver',
                'HANGRY! I was promised breakfast, DAMNIT! No Egg McGuffin Sammich, no carriage service. '
                'Go have a word with that mage at the castle. He knows exactly what I mean!',
                [{'text': 'I will see what I can do.', 'action': 'close'}])
            return

        if vendor_id == 'cozmo_part_one':
            if not g.c1_flags.get('cozmo_finale_seen'):
                self._dialogue(
                    'Cozmo',
                    'END OF PART ONE!\n\nTHANK YOU for reaching this point. Luma and I put a lot of love and effort into making this little world.',
                    [{'text': 'Go on...', 'action': 'f1_cozmo_page2'}])
            else:
                self._dialogue(
                    'Cozmo',
                    'Welcome back! And thank you again for playing Spiffy\'s Gift. '
                    'The carriage is ready; we just have to build somewhere new for it to go!',
                    [{'text': 'Looking forward to it.', 'action': 'close'}])
            return

        return super()._talk_vendor(vendor)

    def _choose_dialogue(self, index):
        g = self.game
        if not g or not g.c1_dialogue:
            return
        options = g.c1_dialogue.get('options', [])
        if index < 0 or index >= len(options):
            return
        action = options[index].get('action')

        if action == 'f1_driver_breakfast_info':
            g.c1_dialogue = None
            self._dialogue('Carriage Driver',
                           'An Egg McGuffin Sammich! Fried egg, lovely bread, and all the trimmings. '
                           'Fearmonger promised me one. He is not getting out of this!',
                           [{'text': 'I will talk to the mage.', 'action': 'close'}])
            return

        if action == 'f1_feed_driver':
            sammich = g.c1_have(lambda o: o.kind == 'sammich')
            if sammich is None:
                g.c1_dialogue = None
                self._dialogue('Carriage Driver', 'No sammich? Then I am still HANGRY. Come back when you have breakfast!',
                               [{'text': 'Right. Sorry.', 'action': 'close'}])
                return
            g.c1_dialogue = None
            g.c1_consume(sammich)
            g.c1_flags['driver_fed'] = True
            g.c1_flags['carriage_unlocked'] = True
            g.f1_prepare_state()
            self._log('F1 QUEST', 'Egg McGuffin Sammich delivered; carriage unlocked; Cozmo Part One finale made available.')
            self._dialogue('Carriage Driver',
                           'OH, THAT HITS THE SPOT! Breakfast at last! You have made me the happiest carriage driver in Britrun. '
                           'The carriage is ready whenever the next road is built!',
                           [{'text': 'Glad I could help.', 'action': 'close'}])
            return

        pages = {
            'f1_cozmo_page2': (
                'If we get some positive feedback, comments, or tips, then we WILL continue. '
                '(We probably will anyway, because we are having so much fun!) '
                'Please click that Comment button and/or tip us.',
                'f1_cozmo_page3'),
            'f1_cozmo_page3': (
                'Part of the funds received will go toward upgrading Luma\'s ChatGPT access from Free to Plus. '
                'That gives us more tools to work with and should save us development time.',
                'f1_cozmo_page4'),
            'f1_cozmo_page4': (
                'Again, THANK YOU for getting this far. The carriage is ready, but its next destinations have not been built yet. '
                'Check back later... maybe the carriage will take you to new places!',
                'f1_cozmo_finish'),
        }
        if action in pages:
            g.c1_dialogue = None
            line, next_action = pages[action]
            self._dialogue('Cozmo', line, [{'text': 'Continue...', 'action': next_action}])
            return
        if action == 'f1_cozmo_finish':
            g.c1_dialogue = None
            g.c1_flags['cozmo_finale_seen'] = True
            self._speech('Thank you for visiting Britrun. U B U!', 5)
            self._log('F1 FINALE', 'Player completed Cozmo\'s Part One thank-you conversation.')
            return

        return super()._choose_dialogue(index)

    def _sell(self):
        g = self.game
        if g is not None:
            obj = g.object_by_id(g.inventory_selected_id)
            if obj is not None and obj.kind == 'sammich':
                self._speech('That Egg McGuffin Sammich is promised to the carriage driver. Best not sell his breakfast!')
                return
        return super()._sell()


class F1Interface(E57Interface):
    """F1.0 display: new Stables kitty route and F1.0 header, E5.7 comments retained."""

    def _draw_header(self):
        super()._draw_header()
        if self.machine.state is AppState.PLAY_GAME:
            smaller, _ = self.e21_font_buttons()
            clear_right = max(0, smaller.x - 9)
            pygame.draw.rect(self.screen, (22, 18, 31), (0, 0, clear_right, 40))
            label = "SPIFFY'S GIFT  |  F1.0  |  " + ('BROWSER' if BROWSER else 'DESKTOP')
            self._draw_text(label, self.game_small_font, (239, 225, 195),
                            14, 12, max_width=max(0, clear_right - 24))
            self._draw_e21_font_buttons()
        # Redraw the existing comment button above the header repaint.
        button = self.e57_comment_button()
        hovering = button.collidepoint(pygame.mouse.get_pos())
        fill = (77, 104, 88) if hovering else (57, 82, 76)
        pygame.draw.rect(self.screen, fill, button, border_radius=5)
        pygame.draw.rect(self.screen, (204, 193, 141), button, 2, border_radius=5)
        label_font = pygame.font.SysFont("consolas", 15, bold=True)
        label = label_font.render("LEAVE A COMMENT", True, (245, 238, 193))
        self.screen.blit(label, label.get_rect(center=button.center))

    def _draw_kitty_caravan(self, surface, g):
        # A complete patrol begins on the hidden chest, wanders through the
        # eastern paddock, and returns to the chest before looping. The four
        # original kitty recipes are used unchanged.
        route = (
            (1205.0, 347.0, 1.25, True),
            (1222.0, 381.0, 2.15, False),
            (1215.0, 431.0, 2.20, False),
            (1180.0, 472.0, 2.35, False),
            (1134.0, 465.0, 2.35, False),
            (1102.0, 428.0, 2.20, False),
            (1110.0, 384.0, 2.10, False),
            (1155.0, 357.0, 2.15, False),
            (1205.0, 347.0, 2.30, False),
        )
        cycle = sum(item[2] for item in route)
        t = g.c1_elapsed % cycle
        x = route[0][0]
        y = route[0][1]
        facing_right = True
        sitting = True
        for i, current in enumerate(route):
            duration = current[2]
            nxt = route[(i + 1) % len(route)]
            if t < duration:
                if current[3]:
                    x, y = current[0], current[1]
                    sitting = True
                else:
                    ratio = max(0.0, min(1.0, t / duration))
                    # Smoothstep prevents sharp starts/stops without changing
                    # the path's guaranteed chest-to-chest loop.
                    eased = ratio * ratio * (3.0 - 2.0 * ratio)
                    x = current[0] + (nxt[0] - current[0]) * eased
                    y = current[1] + (nxt[1] - current[1]) * eased
                    facing_right = nxt[0] >= current[0]
                    sitting = False
                break
            t -= duration
        if sitting:
            asset = 'kitty_sit_blink' if int(g.c1_elapsed * 3) % 17 == 0 else 'kitty_sit'
        else:
            asset = 'kitty_walk_a' if int(g.c1_elapsed * 5) % 2 == 0 else 'kitty_walk_b'
        rect = pygame.Rect(round(x - 53), round(y), 107, 94)
        engine = self.machine.draw_engine
        if facing_right:
            engine.draw_asset(surface, asset, rect)
        else:
            frame = pygame.Surface((rect.width, rect.height), pygame.SRCALPHA)
            engine.draw_asset(frame, asset, pygame.Rect(0, 0, rect.width, rect.height))
            surface.blit(pygame.transform.flip(frame, True, False), rect.topleft)

'''
s = s.replace(insert_anchor, f1_classes + insert_anchor)

# Switch the actual app loop to F1.0 while preserving the E57 bridge and controls.
s = s.replace('machine = E57StateMachine(archive, config, warning)',
              'machine = F1StateMachine(archive, config, warning)')
s = s.replace('ui = E57Interface(machine)', 'ui = F1Interface(machine)')

MAIN.write_text(s, encoding='utf-8')
print('Patched main.py:', len(s), 'characters')
