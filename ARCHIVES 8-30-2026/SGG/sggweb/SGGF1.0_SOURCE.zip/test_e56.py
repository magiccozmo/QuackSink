"""SGGE5.6 focused regression: gate-to-road join, grounded winding route and transition."""
from pathlib import Path
import ast
import json
import math
from PIL import Image

HERE = Path(__file__).resolve().parent
base = json.loads((HERE / 'E55_BASE_LUMA_ASSETS.json').read_text(encoding='utf-8'))
new = json.loads((HERE / 'luma_assets_e33.json').read_text(encoding='utf-8'))
meta = json.loads((HERE / 'E56_BUILD_META.json').read_text(encoding='utf-8'))
old_main = (HERE / 'E55_MAIN_BASE.py').read_text(encoding='utf-8')
new_main = (HERE / 'main.py').read_text(encoding='utf-8')
ast.parse(new_main)

# The only engine changes are release labels/class names and the exact upper-
# bend threshold coordinate/direction derived from the new road centreline.
expected_main = old_main.replace('E5.5', 'E5.6')
expected_main = expected_main.replace('E55GameModel', 'E56GameModel')
expected_main = expected_main.replace('E55StateMachine', 'E56StateMachine')
expected_main = expected_main.replace(
    'CASTLE_APPROACH = (792.9, 355.3)',
    f"CASTLE_APPROACH = ({meta['transition_point'][0]:.1f}, {meta['transition_point'][1]:.1f})")
expected_main = expected_main.replace(
    'CASTLE_FORWARD = (-0.5875, -0.8092)',
    f"CASTLE_FORWARD = ({meta['transition_forward'][0]:.4f}, {meta['transition_forward'][1]:.4f})")
expected_main = expected_main.replace(
    'CASTLE_LATERAL = (0.8092, -0.5875)',
    f"CASTLE_LATERAL = ({meta['transition_lateral'][0]:.4f}, {meta['transition_lateral'][1]:.4f})")
assert new_main == expected_main, 'Unexpected engine changes outside E5.6 scope'
assert 'VERSION = "E5.6"' in new_main
assert 'class E56GameModel' in new_main and 'class E56StateMachine' in new_main
assert "machine = E56StateMachine(archive, config, warning)" in new_main
# The E5.5 Black-Briar joke and inventory/quest logic remain byte-for-byte intact.
assert 'What will it take to get you to forget about Kartlotta?' in new_main
assert 'Bring me some Black-Briar Mead.' in new_main
assert 'g.c1_consume(bottle)' in new_main
assert "self._resolve_lout('bribed')" in new_main

# E5.6 changes only the Castle Path art/navigation/landing points. All other
# image assets, areas, props, NPCs and gameplay definitions remain unchanged.
assert new['version'] == 'SGGE5.6'
assert set(new['assets']) == set(base['assets'])
for key in base['assets']:
    if key != 'c1_bg_castle_path':
        assert new['assets'][key] == base['assets'][key], f'unrelated asset changed: {key}'
assert set(new['world']) == set(base['world'])
for key in base['world']:
    if key == 'areas':
        old_areas = {a['area_id']: a for a in base['world']['areas']}
        new_areas = {a['area_id']: a for a in new['world']['areas']}
        assert set(old_areas) == set(new_areas)
        for area_id in old_areas:
            if area_id == 'castle_path':
                a, b = dict(old_areas[area_id]), dict(new_areas[area_id])
                a.pop('navigation'); b.pop('navigation')
                assert a == b, 'Unexpected Castle Path area property change'
            else:
                assert old_areas[area_id] == new_areas[area_id], f'unrelated area changed: {area_id}'
    elif key == 'connections':
        expected_connections = json.loads(json.dumps(base['world']['connections']))
        for c in expected_connections:
            if c['connection_id'] == 'gold_district_top_castle_path':
                c['arrival_x'], c['arrival_y'] = meta['entry_arrival']
            elif c['connection_id'] == 'castle_exterior_bottom_castle_path':
                c['arrival_x'], c['arrival_y'] = meta['return_arrival']
        assert new['world']['connections'] == expected_connections, 'Unexpected connection changes'
    else:
        assert new['world'][key] == base['world'][key], f'unrelated world field changed: {key}'
for key in base:
    if key not in ('assets', 'world', 'version', 'art_revision', 'notes'):
        assert new[key] == base[key], f'unrelated JSON root field changed: {key}'

# The old gate and landscape are exactly preserved; only the road command block
# is replaced with the new connected approach.
base_commands = base['assets']['c1_bg_castle_path']['commands']
new_asset = new['assets']['c1_bg_castle_path']
new_commands = new_asset['commands']
rs = meta['base_road_start']
re = meta['base_road_end']
ns = meta['new_road_start']
ne = meta['new_road_end']
assert ns == rs and re == meta['base_road_end']
assert new_commands[:rs] == base_commands[:rs]
assert new_commands[ne:] == base_commands[re:]
assert ne - ns > 500, 'Road layer unexpectedly incomplete'
assert new_asset['width'] == 1280 and new_asset['height'] == 640
for i, c in enumerate(new_commands):
    assert c['op'] in ('rect', 'line', 'polygon', 'circle', 'ellipse'), (i, c.get('op'))
    assert len(c['color']) == 3 and all(isinstance(v, int) and 0 <= v <= 255 for v in c['color']), (i, c)
    if c['op'] in ('rect', 'ellipse'):
        assert len(c['rect']) == 4 and c['rect'][2] > 0 and c['rect'][3] > 0, (i, c)
    if c['op'] == 'line':
        assert len(c['points']) >= 2, (i, c)
    if c['op'] == 'polygon':
        assert len(c['points']) >= 3, (i, c)
    if c['op'] == 'circle':
        assert c['radius'] > 0, (i, c)

# Independently reconstruct the authored centreline and tapered road width.
def unit(v):
    d = math.hypot(v[0], v[1]) or 1.0
    return (v[0]/d, v[1]/d)
def lerp(a, b, t):
    return (a[0] + (b[0]-a[0])*t, a[1] + (b[1]-a[1])*t)
def sample_line(a, b, step=4.0):
    n = max(1, int(math.ceil(math.dist(a, b)/step)))
    return [lerp(a, b, i/n) for i in range(1, n+1)]
def make_centerline(points, trim=78.0):
    out = [tuple(points[0])]
    for i in range(1, len(points)-1):
        p = points[i]
        u0 = unit((p[0]-points[i-1][0], p[1]-points[i-1][1]))
        u1 = unit((points[i+1][0]-p[0], points[i+1][1]-p[1]))
        t = min(trim, math.dist(points[i-1], p)*.32, math.dist(points[i+1], p)*.32)
        before = (p[0]-u0[0]*t, p[1]-u0[1]*t)
        after = (p[0]+u1[0]*t, p[1]+u1[1]*t)
        out.extend(sample_line(out[-1], before, 4.0))
        for k in range(1, 21):
            q = k/20
            out.append(((1-q)**2*before[0]+2*(1-q)*q*p[0]+q*q*after[0],
                        (1-q)**2*before[1]+2*(1-q)*q*p[1]+q*q*after[1]))
    out.extend(sample_line(out[-1], points[-1], 4.0))
    return out
control = [(640.,164.),(640.,218.),(642.,260.),(662.,296.),(700.,326.),
           (746.,350.),(792.,370.),(830.,407.),(851.,449.),(849.,491.),
           (821.,530.),(780.,566.),(733.,596.),(686.,619.),(654.,635.),(640.,640.)]
center = make_centerline(control)
assert len(center) == meta['road_samples']
assert math.dist(center[0], (640.,164.)) < .01
assert math.dist(center[-1], (640.,640.)) < .01
# The road starts inside the gate tunnel with a horizontal cross-section.
start_tangent = unit((center[1][0]-center[0][0], center[1][1]-center[0][1]))
assert abs(start_tangent[0]) < .03 and start_tangent[1] > .99
start_half = 24.0
assert abs(meta['gate_start_edge'][0] - (640-start_half)) < .1
assert abs(meta['gate_start_edge'][2] - (640+start_half)) < .1
assert meta['gate_start_edge'][1] == meta['gate_start_edge'][3] == 164
# The road then widens to match the gate threshold and broadens with perspective.
CUM = [0.0]
for a, b in zip(center, center[1:]): CUM.append(CUM[-1]+math.dist(a,b))
TOTAL = CUM[-1]
def half_width(s):
    return 24.0 + 84.0 * max(0.0, min(1.0, s/TOTAL))**.42
at_threshold = min(range(len(center)), key=lambda i: abs(center[i][1]-218))
assert 96 <= 2*half_width(CUM[at_threshold]) <= 140
assert 150 <= meta['road_width_at_transition'] <= 180
assert 205 <= meta['road_width_at_foreground'] <= 225
# The route is a single broad S sweep; it never doubles back vertically or
# creates a tight turn at the castle mouth.
assert all(center[i+1][1] > center[i][1] for i in range(len(center)-1)), 'Road doubles back vertically'
dx_signs = []
for a, b in zip(center, center[1:]):
    dx = b[0]-a[0]
    sign = 1 if dx > .1 else -1 if dx < -.1 else 0
    if sign and (not dx_signs or sign != dx_signs[-1]): dx_signs.append(sign)
assert dx_signs == [1, -1], f'Unexpected road sweep: {dx_signs}'
turns = []
for i in range(1, len(center)-1):
    a = unit((center[i][0]-center[i-1][0], center[i][1]-center[i-1][1]))
    b = unit((center[i+1][0]-center[i][0], center[i+1][1]-center[i][1]))
    turns.append(abs(math.degrees(math.atan2(a[0]*b[1]-a[1]*b[0], a[0]*b[0]+a[1]*b[1]))))
assert max(turns) < 3.0, f'Road has an abrupt bend: {max(turns):.2f} degrees/sample'
transition_index = min(range(len(center)), key=lambda i: math.dist(center[i], (792.,370.)))
transition = center[transition_index]
tan = unit((center[transition_index+1][0]-center[transition_index-1][0],
            center[transition_index+1][1]-center[transition_index-1][1]))
forward = (-tan[0], -tan[1])
lateral = (-forward[1], forward[0])
assert math.dist(transition, meta['transition_point']) < .01
assert math.dist(forward, meta['transition_forward']) < .00001
assert math.dist(lateral, meta['transition_lateral']) < .00001
assert math.dist(transition, (800.,355.)) < 30.0
assert f"CASTLE_APPROACH = ({meta['transition_point'][0]:.1f}, {meta['transition_point'][1]:.1f})" in new_main

# Playable road is only the lower stretch. Both landings fit inside its corridor.
area = next(a for a in new['world']['areas'] if a['area_id'] == 'castle_path')
nav, width = area['navigation']['corridors'][0]
assert width == 104 and len(nav) == meta['navigation_nodes']
assert nav[0] == [round(transition[0]), round(transition[1])]
assert nav[-1] == [640,640]
assert all(0 <= x <= 1280 and 0 <= y <= 640 for x,y in nav)
assert all(nav[i+1][1] >= nav[i][1] for i in range(len(nav)-1))
def segdist(p, a, b):
    vx,vy=b[0]-a[0],b[1]-a[1]; den=vx*vx+vy*vy
    t=0 if den == 0 else max(0,min(1,((p[0]-a[0])*vx+(p[1]-a[1])*vy)/den))
    return math.dist(p,(a[0]+vx*t,a[1]+vy*t))
def navdist(p): return min(segdist(p,a,b) for a,b in zip(nav,nav[1:]))
limit = width/2 - 9
entry_foot = (meta['entry_arrival'][0], meta['entry_arrival'][1]+14)
return_foot = (meta['return_arrival'][0], meta['return_arrival'][1]+14)
for label, foot in [('Gold District entry',entry_foot),('Castle Exterior return',return_foot),
                    ('Castle Path bottom',(640,630)),('Upper threshold',(round(transition[0]),round(transition[1])) )]:
    assert navdist(foot) <= limit, f'{label} outside corridor: {navdist(foot):.1f}>{limit:.1f}'
assert navdist((640,200)) > limit, 'Gate segment accidentally became walkable'
assert math.dist(entry_foot, meta['entry_point']) < 2
assert math.dist(return_foot, meta['return_point']) < 2
# Crossing toward the gate triggers the same visible threshold.
previous = (transition[0]-forward[0]*20, transition[1]-forward[1]*20)
current = (transition[0]+forward[0]*10, transition[1]+forward[1]*10)
progress = lambda p: (p[0]-transition[0])*forward[0] + (p[1]-transition[1])*forward[1]
assert progress(previous) < 0 <= progress(current)
assert abs((current[0]-transition[0])*lateral[0] + (current[1]-transition[1])*lateral[1]) < 1e-6

# Visual QA: gate light remains visible behind the road, the road surface is
# continuous inside the tunnel, and the gold marker is visible at the trigger.
for name in ('E56_CASTLE_PATH_BACKGROUND.png','E56_CASTLE_PATH_COMPOSITE.png','E56_CASTLE_PATH_NAV_AUDIT.png','castle_exterior_ref.png'):
    f = HERE/name
    assert f.exists() and f.stat().st_size > 10_000, name
bg = Image.open(HERE/'E56_CASTLE_PATH_BACKGROUND.png').convert('RGB')
assert bg.size == (1280,640)
assert bg.getpixel((640,150)) == (143,153,119), 'Open gate tunnel light was obscured'
assert bg.getpixel((640,164)) != (38,45,43), 'Road does not enter the gate tunnel'
assert bg.getpixel((640,190)) != (38,45,43), 'Road is not continuous through the gate threshold'
gold_pixels = 0
cx,cy = round(transition[0]),round(transition[1])
for y in range(cy-12,cy+13):
    for x in range(cx-100,cx+101):
        r,g,b = bg.getpixel((x,y))
        if r>205 and g>135 and b<145: gold_pixels += 1
assert gold_pixels > 60, f'Transition marker is not visually clear: {gold_pixels} gold pixels'

print('PASS: exact E5.6 engine scope; E5.5 quest dialogue and item-consumption logic preserved')
print('PASS: gatehouse/other art unchanged; Castle Path only road layer, navigation and two arrival points revised')
print(f"PASS: road begins inside gate at y=164, widens through threshold to {meta['road_width_at_foreground']:.0f}px foreground width")
print(f"PASS: broad single S sweep; transition {transition[0]:.1f},{transition[1]:.1f}; {len(nav)} navigation nodes")
print('PASS SGGE5.6 focused regression')
