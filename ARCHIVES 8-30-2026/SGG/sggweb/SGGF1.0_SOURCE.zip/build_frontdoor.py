from pathlib import Path
import json
WORK=Path('/mnt/data/sgg_f1_work')
DEPLOY=WORK/'deploy_e57'
script_old="""<script type=\"module\">\nconst box = document.getElementById('versions');\ntry {\n const res=await fetch('./versions.json',{cache:'no-store'});\n if(!res.ok)throw Error('Version catalog unavailable ('+res.status+')');\n const doc=await res.json();if(!Array.isArray(doc.versions)||doc.versions.length===0)throw Error('Version catalog is empty');\n box.replaceChildren();\n // The packager discovers folders; this browser code does not hardcode releases.\n for(const entry of doc.versions){\n  if(!/^SGGE\\d+(?:\\.\\d+)*$/.test(entry.version) || !/^SGGE\\d+(?:\\.\\d+)*\\/(?:play|index)\\.html$/.test(entry.path)) continue;\n  const article=document.createElement('article');article.className='card';\n  const title=document.createElement('h3');title.textContent=entry.title||entry.version;\n  if(entry.current){const badge=document.createElement('span');badge.className='badge';badge.textContent='NEWEST';title.append(badge);}\n  const descr=document.createElement('p');descr.textContent=entry.description||'Playable archived release.';\n  const a=document.createElement('a');a.className='play';a.href='./'+entry.path;a.textContent='Play '+entry.version;\n  article.append(title,descr,a);box.append(article);\n }\n if(!box.children.length)throw Error('No valid versions found');\n} catch(e) {box.replaceChildren();const p=document.createElement('p');p.textContent='Could not load the version catalog: '+e.message;box.append(p);}\n</script>"""
script_new="""<script type=\"module\">\nconst box = document.getElementById('versions');\nconst warning = document.getElementById('device-warning');\nfunction isPhoneOrTablet(){\n const ua=navigator.userAgent||'';\n const platform=navigator.platform||'';\n const points=Number(navigator.maxTouchPoints||0);\n const mobileHint=navigator.userAgentData?.mobile===true;\n const mobileUA=/(Android|iPhone|iPad|iPod|Mobile|Tablet|Windows Phone|IEMobile)/i.test(ua);\n const iPadOS=(platform==='MacIntel'&&points>1);\n const compactTouch=(points>1&&window.matchMedia('(pointer: coarse)').matches&&Math.min(screen.width||0,screen.height||0)<=700);\n return mobileHint||mobileUA||iPadOS||compactTouch;\n}\nif(isPhoneOrTablet()){\n document.body.classList.add('device-blocked');\n warning.hidden=false;\n} else {\n try {\n  const res=await fetch('./versions.json',{cache:'no-store'});\n  if(!res.ok)throw Error('Version catalog unavailable ('+res.status+')');\n  const doc=await res.json();if(!Array.isArray(doc.versions)||doc.versions.length===0)throw Error('Version catalog is empty');\n  box.replaceChildren();\n  // The packager discovers folders; this browser code does not hardcode releases.\n  for(const entry of doc.versions){\n   if(!/^SGG[A-Z]\\d+(?:\\.\\d+)*$/.test(entry.version) || !/^SGG[A-Z]\\d+(?:\\.\\d+)*\\/(?:play|index)\\.html$/.test(entry.path)) continue;\n   const article=document.createElement('article');article.className='card';\n   const title=document.createElement('h3');title.textContent=entry.title||entry.version;\n   if(entry.current){const badge=document.createElement('span');badge.className='badge';badge.textContent='NEWEST';title.append(badge);}\n   const descr=document.createElement('p');descr.textContent=entry.description||'Playable archived release.';\n   const a=document.createElement('a');a.className='play';a.href='./'+entry.path;a.textContent='Play '+entry.version;\n   article.append(title,descr,a);box.append(article);\n  }\n  if(!box.children.length)throw Error('No valid versions found');\n } catch(e) {box.replaceChildren();const p=document.createElement('p');p.textContent='Could not load the version catalog: '+e.message;box.append(p);}\n}\n</script>"""

for name in ('index.html','versions.html'):
 p=DEPLOY/name
 html=p.read_text(encoding='utf-8')
 if script_old not in html:
  raise SystemExit(f'Expected catalog script not found in {name}')
 html=html.replace(script_old,script_new)
 marker='</style>'
 css=""".device-warning{display:none;max-width:680px;margin:clamp(40px,12vh,130px) auto;padding:35px 30px;border:1px solid #b99473;border-radius:16px;background:linear-gradient(140deg,#342342,#251b32);box-shadow:0 18px 40px #09051088;color:#f5e9da;text-align:center;font:700 clamp(22px,4vw,31px)/1.5 Arial,sans-serif}\n.device-warning p{margin:0;color:#f9dfa8}\nbody.device-blocked main{display:none}\nbody.device-blocked .device-warning{display:block}\n"""
 if marker not in html: raise SystemExit(f'No style end in {name}')
 html=html.replace(marker,css+marker,1)
 bodymarker='<body>'
 warning="<body>\n<div id=\"device-warning\" class=\"device-warning\" role=\"status\" hidden><p>Spiffy's Gift CURRENTLY only supports a browser running on a computer. Support for other devices may happen!</p></div>"
 if bodymarker not in html: raise SystemExit(f'No body tag in {name}')
 html=html.replace(bodymarker,warning,1)
 p.write_text(html,encoding='utf-8')
 print('updated',name,len(html))

# New release manifest: preserve all historical entries and only change the current marker.
p=DEPLOY/'versions.json'
doc=json.loads(p.read_text(encoding='utf-8'))
for e in doc['versions']:
 e['current']=False
new={
 'version':'SGGF1.0',
 'title':'SGGF 1.0',
 'path':'SGGF1.0/play.html',
 'description':'Part One finale: rebuilt Stables, the hangry carriage driver, Fearmonger\'s Egg McGuffin Sammich reward, the carriage breakfast handoff, and Cozmo\'s thank-you. Includes the existing anonymous comments feature.',
 'current':True
}
doc['versions'].insert(0,new)
p.write_text(json.dumps(doc,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print('updated versions.json entries=',len(doc['versions']))
