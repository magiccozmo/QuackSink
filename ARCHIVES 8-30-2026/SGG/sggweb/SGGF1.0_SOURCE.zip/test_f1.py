"""SGGF1.0 source/world/save/dialogue/mobile-gate regression checks."""
from pathlib import Path
import ast
import json
import re
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import main

src = (HERE / 'main.py').read_text(encoding='utf-8')
ast.parse(src)
assert main.VERSION == 'F1.0'
assert 'machine = F1StateMachine(archive, config, warning)' in src
assert 'ui = F1Interface(machine)' in src
assert 'class F1GameModel(E56GameModel)' in src
assert 'class F1StateMachine(E57StateMachine)' in src
assert 'class F1Interface(E57Interface)' in src

assets = json.loads((HERE / 'luma_assets_e33.json').read_text(encoding='utf-8'))
base = json.loads((HERE / 'E57_BASE_LUMA_ASSETS.json').read_text(encoding='utf-8'))
assert assets['version'] == 'SGGF1.0'
assert len(assets['assets']['c1_bg_stables']['commands']) >= 650
assert all(op.get('op') in main.LumaDrawEngine.SUPPORTED_OPS
           for op in assets['assets']['c1_bg_stables']['commands'])
for key in ('kitty_walk_a', 'kitty_walk_b', 'kitty_sit', 'kitty_sit_blink'):
    assert assets['assets'][key] == base['assets'][key], f'Kitty art changed: {key}'
assert assets['assets']['sammich']['width'] == 82
assert 'carriage_driver' in assets['assets'] and 'carriage_driver_happy' in assets['assets']
areas = {a['area_id']: a for a in assets['world']['areas']}
stables = areas['stables']
assert stables['background_asset'] == 'c1_bg_stables'
assert any(v['vendor_id'] == 'carriage_driver' for v in stables['vendors'])
conn = {c['connection_id']: c for c in assets['world']['connections']}
assert 'outside_gate_bottom_stables' not in conn and 'stables_top_outside_gate' not in conn
assert conn['outside_gate_right_stables']['edge'] == 'right'
assert conn['stables_left_outside_gate']['edge'] == 'left'
assert conn['stables_right_plains']['edge'] == 'right'
assert conn['plains_left_stables']['edge'] == 'left'

# Instantiate the real model against the new world JSON (the draw engine's
# validation checks every world background and fixed-object recipe).
engine = main.LumaDrawEngine(HERE / 'luma_assets_e33.json')
game = main.F1GameModel(engine)
game.f1_prepare_state()
assert game.areas['stables'].vendors[0]['recipe'] == 'carriage_driver'
sammich = game.c1_make_item('Egg McGuffin Sammich', 'sammich', price=0)
assert (sammich.width, sammich.height) == (82, 60)
game.c1_consume(sammich)
game.c1_flags['driver_fed'] = True
game.c1_flags['carriage_unlocked'] = True
game.f1_prepare_state()
vendors = {v['vendor_id']: v for v in game.areas['stables'].vendors}
assert vendors['carriage_driver']['recipe'] == 'carriage_driver_happy'
assert vendors['cozmo_part_one']['recipe'] == 'cozmo_magician'

# A real C1.3.1 snapshot survives the F1 upgrade and reconstructs the added
# Cozmo vendor solely from the saved driver_fed flag.
snapshot = game.snapshot()
loaded = main.C131GameModel.from_snapshot(engine, snapshot)
loaded.__class__ = main.F1GameModel
loaded.f1_prepare_state()
loaded_vendors = {v['vendor_id']: v for v in loaded.areas['stables'].vendors}
assert loaded.c1_flags['driver_fed'] is True
assert loaded_vendors['carriage_driver']['recipe'] == 'carriage_driver_happy'
assert 'cozmo_part_one' in loaded_vendors

# Exercise the actual F1 dialogue handlers with a lightweight state-machine
# harness; gameplay classes are real, only renderer/network methods are stubbed.
sm = object.__new__(main.F1StateMachine)
sm.game = game
sm.d11_context_ref = None
sm.logs = []
sm._log = lambda *args: sm.logs.append(args)
sm._dialogue = lambda speaker, line, options: setattr(game, 'c1_dialogue',
    {'speaker': speaker, 'line': line, 'options': options[:5]})
sm._speech = lambda message, seconds=4: setattr(sm, 'last_speech', message)
# reset to pre-feed with a fresh sandwich
for v in game.areas['stables'].vendors[:]:
    if v.get('vendor_id') == 'cozmo_part_one': game.areas['stables'].vendors.remove(v)
game.c1_flags.update({'driver_fed': False, 'carriage_unlocked': False, 'cozmo_finale_seen': False})
game.f1_prepare_state()
item = game.c1_make_item('Egg McGuffin Sammich', 'sammich', price=0)
driver = next(v for v in game.areas['stables'].vendors if v['vendor_id'] == 'carriage_driver')
sm._talk_vendor(driver)
assert game.c1_dialogue['options'][0]['action'] == 'f1_feed_driver'
sm._choose_dialogue(0)
assert game.c1_flags['driver_fed'] and game.c1_flags['carriage_unlocked']
assert item.area_id == '__consumed__'
assert any(v['vendor_id'] == 'cozmo_part_one' for v in game.areas['stables'].vendors)
cozmo = next(v for v in game.areas['stables'].vendors if v['vendor_id'] == 'cozmo_part_one')
sm._talk_vendor(cozmo)
assert 'END OF PART ONE' in game.c1_dialogue['line']
for action in ('f1_cozmo_page2', 'f1_cozmo_page3', 'f1_cozmo_page4', 'f1_cozmo_finish'):
    game.c1_dialogue = {'speaker': 'Cozmo', 'line': '', 'options': [{'text': 'Continue', 'action': action}]}
    sm._choose_dialogue(0)
assert game.c1_flags['cozmo_finale_seen'] is True

# Fearmonger quest: the existing 5,000 gold is still granted and the sandwich
# reward is newly attached exactly once.
reward_game = main.F1GameModel(engine)
reward_game.c1_flags['quest_started'] = True
potion = reward_game.c1_make_item('Potion of Increased Physical Enhancement', 'potion', price=69000)
reward_sm = object.__new__(main.F1StateMachine)
reward_sm.game = reward_game
reward_sm.d11_context_ref = None
reward_sm._log = lambda *args: None
reward_sm._speech = lambda message, seconds=4: setattr(reward_sm, 'last_speech', message)
reward_sm._dialogue = lambda speaker, line, options: setattr(reward_game, 'c1_dialogue',
    {'speaker': speaker, 'line': line, 'options': options[:5]})
fearmonger = {'npc_id': 'fearmonger', 'name': 'Fearmonger', 'area_id': 'mages_lab',
              'x': 640, 'y': 400, 'height': 80, 'alive': True}
reward_sm._talk(fearmonger)
assert reward_game.c1_flags['quest_done'] is True
assert reward_game.c1_gold == 5000
assert reward_game.c1_flags['egg_mcguffin_awarded'] is True
assert reward_game.c1_have(lambda o: o.kind == 'sammich') is not None
reward_count = sum(o.kind == 'sammich' and o.area_id != '__consumed__' for o in reward_game.objects)
reward_sm._talk(fearmonger)
assert sum(o.kind == 'sammich' and o.area_id != '__consumed__' for o in reward_game.objects) == reward_count

# Root pages block supported mobile/tablet signatures before fetching the menu;
# both E and F generations remain valid under the release-path validator.
for name in ('index.html', 'versions.html'):
    page = (HERE / 'deploy_e57' / name).read_text(encoding='utf-8')
    assert 'isPhoneOrTablet' in page and 'body.device-blocked main{display:none}' in page
    assert "Other devices may happen!" in page
    assert "navigator.userAgentData?.mobile" in page
    assert "^SGG[A-Z]\\d+(?:\\.\\d+)*$" in page
assert re.fullmatch(r'SGG[A-Z]\d+(?:\.\d+)*', 'SGGF1.0')
assert re.fullmatch(r'SGG[A-Z]\d+(?:\.\d+)*', 'SGGE5.7')

print('PASS F1.0 syntax, draw-engine/world validation, art preservation, west/east transitions, save migration, sandwich reward, carriage handoff, Cozmo finale, and mobile front-door gate.')
