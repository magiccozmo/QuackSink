"""Build and validate SGGF1.0 deployment/source packages from the E5.7 baseline."""
from pathlib import Path
import ast
import copy
import hashlib
import io
import json
import re
import subprocess
import sys
import tarfile
import zipfile

ROOT = Path('/mnt/data')
WORK = Path(__file__).resolve().parent
BASE_DEPLOY = ROOT / 'SGG_E57_CLOUDFLARE_DEPLOY.zip'
MAIN = WORK / 'main.py'
ASSETS = WORK / 'luma_assets_e33.json'
README = WORK / 'README_SGGF10.txt'
PLAY = WORK / 'F1_play.html'
DEPLOY = ROOT / 'SGGF1.0_CLOUDFLARE_DEPLOY.zip'
SOURCE = ROOT / 'SGGF1.0_SOURCE.zip'
SITE = WORK / 'deploy_e57'

code = MAIN.read_bytes()
assets = ASSETS.read_bytes()
page = PLAY.read_text(encoding='utf-8')
root_index = (SITE / 'index.html').read_bytes()
root_versions = (SITE / 'versions.html').read_bytes()
manifest_bytes = (SITE / 'versions.json').read_bytes()
manifest = json.loads(manifest_bytes)

ast.parse(code.decode('utf-8'))
subprocess.run([sys.executable, str(WORK / 'test_f1.py')], cwd=WORK, check=True)
assert BASE_DEPLOY.exists(), BASE_DEPLOY
assert all(x in page for x in ('SGGF1.0', 'sggf10.apk', 'sggf10.tar.gz'))
assert 'sgge57' not in page and 'SGGE5.7' not in page
assert '1360' in page and '780' in page
assert manifest['versions'][0]['version'] == 'SGGF1.0'
assert manifest['versions'][0]['current'] is True
assert all(not x.get('current') for x in manifest['versions'][1:])

# Build the two exact runtime payloads used by Pygbag.
apkb = io.BytesIO()
with zipfile.ZipFile(apkb, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as apk:
    apk.writestr('assets/main.py', code)
    apk.writestr('assets/luma_assets_e33.json', assets)

tarb = io.BytesIO()
with tarfile.open(fileobj=tarb, mode='w:gz', compresslevel=9) as tf:
    for name, payload in (('assets/main.py', code), ('assets/luma_assets_e33.json', assets)):
        info = tarfile.TarInfo(name)
        info.size = len(payload)
        info.mode = 0o644
        info.mtime = 0
        tf.addfile(info, io.BytesIO(payload))

with zipfile.ZipFile(BASE_DEPLOY, 'r') as old:
    assert old.testzip() is None
    old_names = old.namelist()
    assert all(name in old_names for name in ('index.html', 'versions.html', 'versions.json',
                                               'SGGE5.7/play.html', 'SGGE5.7/favicon.png',
                                               'SGGE5.7/sgge57.apk', 'SGGE5.7/sgge57.tar.gz'))
    historical_count = len(old_names)
    additions = [
        ('SGGF1.0/play.html', page.encode('utf-8')),
        ('SGGF1.0/favicon.png', old.read('SGGE5.7/favicon.png')),
        ('SGGF1.0/sggf10.apk', apkb.getvalue()),
        ('SGGF1.0/sggf10.tar.gz', tarb.getvalue()),
        ('SGGF1.0/README_SGGF10.txt', README.read_bytes()),
    ]
    replacement = {
        'index.html': root_index,
        'versions.html': root_versions,
        'versions.json': manifest_bytes,
    }
    with zipfile.ZipFile(DEPLOY, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=8) as out:
        for member in old.infolist():
            payload = replacement.get(member.filename, old.read(member.filename))
            out.writestr(copy.copy(member), payload)
        for name, payload in additions:
            out.writestr(name, payload)

    with zipfile.ZipFile(DEPLOY, 'r') as z:
        assert z.testzip() is None
        names = z.namelist()
        assert len(names) == len(old_names) + len(additions)
        assert len(set(names)) == len(names)
        for name in old_names:
            expected = replacement[name] if name in replacement else old.read(name)
            assert z.read(name) == expected, f'Unexpected base-site change: {name}'
        for name, payload in additions:
            assert z.read(name) == payload, f'New file mismatch: {name}'
        final_doc = json.loads(z.read('versions.json'))
        assert len(final_doc['versions']) == 27
        assert final_doc['versions'][0]['version'] == 'SGGF1.0'
        assert final_doc['versions'][0]['current'] is True
        assert all(v['current'] is False for v in final_doc['versions'][1:])
        for v in final_doc['versions']:
            assert re.fullmatch(r'SGG[A-Z]\d+(?:\.\d+)*', v['version'])
            assert re.fullmatch(r'SGG[A-Z]\d+(?:\.\d+)*\/(?:play|index)\.html', v['path'])
        for runtime_name in ('SGGF1.0/sggf10.apk',):
            with zipfile.ZipFile(io.BytesIO(z.read(runtime_name))) as runtime:
                assert runtime.testzip() is None
                assert runtime.namelist() == ['assets/main.py', 'assets/luma_assets_e33.json']
                assert runtime.read('assets/main.py') == code
                assert runtime.read('assets/luma_assets_e33.json') == assets
        with tarfile.open(fileobj=io.BytesIO(z.read('SGGF1.0/sggf10.tar.gz')), mode='r:gz') as runtime:
            assert runtime.extractfile('assets/main.py').read() == code
            assert runtime.extractfile('assets/luma_assets_e33.json').read() == assets
        f1page = z.read('SGGF1.0/play.html').decode('utf-8')
        assert 'archive:"sggf10"' in f1page
        assert 'sggf10.apk' in f1page and 'sggf10.tar.gz' in f1page
        for name in ('index.html', 'versions.html'):
            html = z.read(name).decode('utf-8')
            assert 'device-warning' in html
            assert 'navigator.userAgentData?.mobile' in html
            assert 'SGG[A-Z]' in html
        print(f'PASS deployment: {historical_count} E5.7-era entries preserved, {len(additions)} F1.0 entries added.')

meta = {
    'version': 'SGGF1.0',
    'based_on': 'SGGE5.7',
    'scope': 'Part One Stables remake, side-to-side Outside Gate link, hangry carriage driver, Egg McGuffin Sammich reward, driver handoff, Cozmo finale, and mobile/tablet front-door notice. Existing E5.7 comment API preserved.',
    'source_main_sha256': hashlib.sha256(code).hexdigest(),
    'assets_json_sha256': hashlib.sha256(assets).hexdigest(),
    'previous_site_sha256': hashlib.sha256(BASE_DEPLOY.read_bytes()).hexdigest(),
    'deploy_sha256': hashlib.sha256(DEPLOY.read_bytes()).hexdigest(),
    'deploy_bytes': DEPLOY.stat().st_size,
    'historical_entry_count': historical_count,
    'new_version_files': [name for name, _ in additions],
    'mobile_gate': 'UA / User-Agent Client Hints / iPadOS touch / compact coarse-pointer detection at root front door; no version catalog fetch on blocked devices.',
    'validation': 'Python AST/py_compile, Luma engine JSON load, quest/save/dialogue harness, manifest checks, ZIP CRC checks, APK and tar payload equality checks. Browser runtime not launched in this build environment.',
}
(WORK / 'F1_BUILD_META.json').write_text(json.dumps(meta, indent=2), encoding='utf-8')

source_files = [
    ('main.py', MAIN),
    ('luma_assets_e33.json', ASSETS),
    ('README_SGGF10.txt', README),
    ('F1_play.html', PLAY),
    ('test_f1.py', WORK / 'test_f1.py'),
    ('make_f1_changes.py', WORK / 'make_f1_changes.py'),
    ('patch_f1_main.py', WORK / 'patch_f1_main.py'),
    ('build_frontdoor.py', WORK / 'build_frontdoor.py'),
    ('package_f1.py', WORK / 'package_f1.py'),
    ('F1_BUILD_META.json', WORK / 'F1_BUILD_META.json'),
    ('F1_STABLES_BACKGROUND_PREVIEW.png', WORK / 'F1_STABLES_BACKGROUND_PREVIEW.png'),
    ('E57_MAIN_BASE.py', WORK / 'E57_MAIN_BASE.py'),
    ('E57_BASE_LUMA_ASSETS.json', WORK / 'E57_BASE_LUMA_ASSETS.json'),
    ('E57_BUILD_META.json', WORK / 'E57_BUILD_META.json'),
    ('E56_MAIN_BASE.py', WORK / 'E56_MAIN_BASE.py'),
    ('E56_BASE_LUMA_ASSETS.json', WORK / 'E56_BASE_LUMA_ASSETS.json'),
    ('E56_BUILD_META.json', WORK / 'E56_BUILD_META.json'),
    ('test_e56.py', WORK / 'test_e56.py'),
    ('test_e57.py', WORK / 'test_e57.py'),
    ('deploy/index.html', SITE / 'index.html'),
    ('deploy/versions.html', SITE / 'versions.html'),
    ('deploy/versions.json', SITE / 'versions.json'),
    ('deploy/_headers', SITE / '_headers'),
]
with zipfile.ZipFile(SOURCE, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as out:
    for arcname, path in source_files:
        assert path.exists(), f'Missing source component: {path}'
        out.write(path, arcname)
with zipfile.ZipFile(SOURCE, 'r') as z:
    assert z.testzip() is None
    expected_files = [arc for arc, _ in source_files]
    assert set(expected_files).issubset(set(z.namelist()))
    assert z.read('main.py') == code
    assert z.read('luma_assets_e33.json') == assets

print('DEPLOY:', DEPLOY, DEPLOY.stat().st_size, 'bytes')
print('DEPLOY SHA256:', hashlib.sha256(DEPLOY.read_bytes()).hexdigest())
print('SOURCE:', SOURCE, SOURCE.stat().st_size, 'bytes')
print('SOURCE SHA256:', hashlib.sha256(SOURCE.read_bytes()).hexdigest())
