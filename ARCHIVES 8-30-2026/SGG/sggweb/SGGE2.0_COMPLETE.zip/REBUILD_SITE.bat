@echo off
cd /d "%~dp0"
python REBUILD_SITE.py
if errorlevel 1 (echo Build failed. & pause & exit /b 1)
pause
