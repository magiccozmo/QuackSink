SPIFFY'S GIFT — SGGE2.0 — DIRECT-UPLOAD WEBSITE CANDIDATE
=========================================================

IMPORTANT: This package is NOT a local Python game server. The SITE folder
contains a complete STATIC website with index.html, zipped Python/Pygame game
files, and artwork. It runs through the standard Pygbag browser runtime CDN.

1. LOCAL TEST:
   - Close other SGGE/Pygbag test servers first (especially port 8000).
   - Double-click TEST_LOCAL.bat, or cd into site and run:
       python -m http.server 8000
   - In Opera GX visit http://localhost:8000
   - Python's HTTP server sends files; it does NOT run SGG.

2. CLOUDFLARE PAGES:
   - Make a NEW Pages project with Direct Upload. Leave your existing
     Purple Python Browser site unchanged.
   - Upload the contents of the site folder; alternatively upload the
     separate SGGE2.0_CLOUDFLARE_SITE.zip directly.
   - The Pages URL will serve index.html automatically.
   - No Cloudflare-QuackSink GitHub integration is required.

3. CONTINUED DEVELOPMENT:
   - Shared Python/Pygame code and JSON artwork are in source/.
   - Windows development: RUN_DESKTOP.bat (install pygame-ce if necessary).
   - Rebuild static site after a future source change with REBUILD_SITE.bat.
     This repacks source/main.py and artwork into site/ without requiring
     Pygbag installation. The site is never auto-deployed.
   - Keep game CLOSED while developing a new complete version, as usual.

4. SAVE FILES:
   - No accounts. Saves/settings are browser-local on the website's origin.
   - localhost and the Cloudflare Pages URL have SEPARATE browser storage.
   - F5/F9 saves; F7 exports a backup JSON; F8 imports. Export regularly.

5. KNOWN LIMITATION:
   - This environment cannot fetch/install Pygbag/Pygame or make an
     interactive WebAssembly run, so this is an UNVERIFIED deployment candidate.
     Its pack format, local static contents and Python/JSON consistency were
     checked. Your Opera GX field test is needed before publishing publicly.
   - Pygbag's Python/WASM runtime is loaded from its CDN at runtime. The
     delivery ZIP is complete as website files, but not offline self-contained.

No changes to any GitHub repo or existing Cloudflare project were performed.
