@echo off
cd /d "%~dp0source"
python main.py
if errorlevel 1 (echo Desktop run failed. Install pygame-ce into your venv. & pause)
