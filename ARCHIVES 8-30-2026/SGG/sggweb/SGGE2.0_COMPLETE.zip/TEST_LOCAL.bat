@echo off
cd /d "%~dp0site"
echo Static SGGE2.0 website at http://localhost:8000
echo Open that address in your browser.
python -m http.server 8000
if errorlevel 1 (echo Unable to start local static HTTP server. & pause)
