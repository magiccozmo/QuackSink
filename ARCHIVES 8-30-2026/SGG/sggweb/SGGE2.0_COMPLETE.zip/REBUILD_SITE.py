#!/usr/bin/env python3
"""Repackage the SGGE2.0 source and artwork into the static site, no Pygbag CLI needed.
Uses Pygbag's normal assets/ archive structure. Does not run or touch a live game.
"""
from pathlib import Path
import tarfile
import zipfile
import ast
import json

root=Path(__file__).resolve().parent
source=root/'source'
site=root/'site'
assert (site/'index.html').is_file(), 'Keep existing site/index.html'
assert (source/'main.py').is_file(), 'Missing source/main.py'
assert (source/'luma_assets_e20.json').is_file(), 'Missing source artwork JSON'
ast.parse((source/'main.py').read_text(encoding='utf-8'))
json.loads((source/'luma_assets_e20.json').read_text(encoding='utf-8'))
filenames=('main.py','luma_assets_e20.json')
with zipfile.ZipFile(site/'sgge2.apk','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name in filenames:
        z.write(source/name,'assets/'+name)
with tarfile.open(site/'sgge2.tar.gz','w:gz') as t:
    for name in filenames:
        t.add(source/name,arcname='assets/'+name,recursive=False)
print('Rebuilt static SGGE2.0 game bundles in',site)
print('Test with TEST_LOCAL.bat, then upload site/ directly to Cloudflare Pages.')
