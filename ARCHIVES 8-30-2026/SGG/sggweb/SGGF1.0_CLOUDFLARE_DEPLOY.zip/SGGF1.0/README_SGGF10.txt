SPIFFY'S GIFT — SGGF1.0
First official Part One release

WHAT'S NEW
- Complete procedural art rebuild of the Stables yard: timber barn, tack shed, open cobbled approach, carriage and horse.
- Outside Gate and Stables now connect west/east. Stables and Plains remain connected east/west.
- A new hangry carriage driver waits for breakfast.
- Fearmonger now rewards the completed enhancement-potion quest with the Egg McGuffin Sammich, in addition to the existing 5,000 gold. Existing completed E5.7 saves receive the missing sandwich once when loaded.
- Give the sammich to the driver to feed him, unlock the carriage and reveal Cozmo's Part One thank-you conversation.
- Kitty artwork is unchanged. Her patrol now begins at the hidden caravan chest, wanders through the eastern paddock and returns to the chest.
- Existing anonymous visitor comments, save/load, quests, inventory, controls and preserved historical releases remain.
- The front door detects phones/tablets and displays the current computer-browser-only notice instead of loading the version picker.

PART ONE ENDING
The carriage is ready, but no new destination is included in this release. Cozmo explains that additional places may arrive in a later update.

DEPLOYMENT
Upload the contents of SGGF1.0_CLOUDFLARE_DEPLOY.zip to the existing Cloudflare static-assets site. The existing separate comments API Worker and D1 database remain unchanged.

SOURCE
SGGF1.0_SOURCE.zip contains the updated Python source, Luma Draw Engine JSON, build and validation scripts, the E5.7 baseline files, and the Stables preview.

TEST NOTE
The source was syntax-checked and the deployment/runtime archives and manifests were validated. The game was not launched in a live browser during this build; please field-test the deployed version and report any gameplay or layout issues.
