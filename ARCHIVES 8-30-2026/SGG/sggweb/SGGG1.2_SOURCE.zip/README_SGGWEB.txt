SPIFFY'S GIFT — CURATED SOURCE HANDOFF

Current edition: SGGG1.1 (G generation), based on the exact SGGG1.0 source and complete Cloudflare site packages.

The embedded deploy/ directory is the complete Cloudflare site. It retains all nine editions previously selectable in SGGG1.0 (including SGGF2.0a and every legacy edition), plus SGGG1.1 as the new current edition. No earlier edition has been removed or overwritten. The historical source milestone archives remain intact.

SGGG1.1 changes Yorkshire Tea rewards to a save-bound counter, adds Easy auto-reward and Normal/Spiffy Challenge talk-to-claim behavior, gives each Tea-rewarding Cozmo cameo unique dialogue, shortens ordinary Cozmo cameo scheduling to one in-game second, and makes the public Global Usage Log a fixed-height scrolling panel with paged older events.

Tea Earned, reward-detected state, and reward-claimed state are stored inside the existing saved-game c1_flags. Saving captures the count and ledger; loading restores them. A new game starts a fresh Tea count. Scenic-overlook Cozmo remains non-rewarding. HELLgs escape rewards remain Spiffy Challenge-only.

The existing Global Log Worker, D1 database, and schema are unchanged. No Worker redeployment or database migration is required for G1.1. The site uses the already-deployed Global Log API.

Static/package checks are recorded in SGGG1.1_TEST_RESULTS.txt. No GitHub main push or Cloudflare site deployment was performed by Luma. Browser field testing remains for Cozmo.
