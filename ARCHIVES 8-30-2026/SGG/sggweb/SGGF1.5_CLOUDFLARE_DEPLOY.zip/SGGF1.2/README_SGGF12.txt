SPIFFY'S GIFT — SGGF1.2
Horse rendering polish: explicit fills and corrected Stable-yard depth order

WHAT CHANGED
- Corrected the live-renderer hollow-horse defect. In Luma Draw Engine, a polygon command with a nonzero border is an outline-only stroke. The original F1.1 horse recipe had several filled shapes authored as outline-only commands. F1.2 adds an explicit border=0 fill pass immediately before each matching outline pass (14 polygons).
- Corrected Stables painter order: carriage first, fence second, horse third. The fence is now behind the horse and the horse fully occludes the rail where their silhouettes overlap.
- No new horse anatomy or silhouette redesign: the F1.1 horse's color, scale, shape, mane, head, harness, and carriage relationship are retained.

WHAT DID NOT CHANGE
- F1.1 world data, Stable-yard geometry, object positions/sizes, collision, navigation, background art, and carriage/fence vector recipes are unchanged.
- Kitty's animation art, patrol behavior, and the rest of the yard are preserved.
- Driver dialogue, Fearmonger reward, Egg McGuffin Sammich handoff, carriage unlock, Cozmo's four-page Part One finale, comments, inventory and all F1.1 gameplay are unchanged.
- F1.0/F1.1 save data remains readable; the three stable static scene objects continue to be migrated as missing objects only.
- All historical releases remain in the Cloudflare deployment package. F1.2 is added as the current catalog release; F1.1 and earlier releases stay available.

FILES
- main.py: F1.2 code and corrected scene painter order.
- luma_assets_e33.json: F1.2 JSON assets with explicit horse shape fills.
- F1.2_STABLES_PREVIEW.png and F1.2_HORSE_ASSET_PREVIEW.png: previews rendered with the actual Pygame/LumaDrawEngine.
- F1.1_MAIN_BASE.py and F1.1_BASE_LUMA_ASSETS.json: exact F1.1 comparison baseline. F1.0 baselines are also retained.

DEPLOYMENT
Upload the contents of SGGF1.2_CLOUDFLARE_DEPLOY.zip to the existing Cloudflare static-assets site, preserving the archive folder structure. The comments API Worker and D1 database are unchanged.

TESTING
Static/model regressions verify Python syntax, JSON and recipe integrity, explicit fill/outline pairs, renderer order, unchanged carriage/fence art, Kitty art, Stables geometry, F1.0 save migration, the driver breakfast handoff, Fearmonger quest reward, and the four-page finale. The build environment does not launch a live browser session; browser field testing remains the final runtime check.
