SGGM1.2 MAP-ISOLATION PROBE
Route: /SGGM1.2_MAP_PROBE/play

This is a diagnostic build, not a release. It keeps the exact M1.1 play.html loader and M1.1 main.py game engine, and substitutes only the M1.2 m1_world_layers.json. The Luma artwork JSON is identical between the two releases and is taken from M1.1. The test bundle uses a unique archive/app directory name to avoid cache collisions.

Interpretation:
- If this starts and reaches gameplay, the M1.2 map alone does not cause the blank-screen failure; investigate the M1.2 edition path, archive naming, deployment routing/cache, or runtime packaging.
- If this also blanks after difficulty selection, the M1.2 map change or its interaction with the unchanged engine is implicated.

No Worker, D1, sound, voice, or NPC behavior changes are included.
