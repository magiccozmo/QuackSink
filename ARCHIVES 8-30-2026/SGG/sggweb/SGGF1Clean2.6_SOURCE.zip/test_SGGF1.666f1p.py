import ast, json, math, tarfile, zipfile
from pathlib import Path
BASE=Path(__file__).resolve().parent
OLD=json.loads((BASE/"SGGF1.666f1o/assets/luma_assets_e33.json").read_text(encoding="utf-8"))
NEW=json.loads((BASE/"SGGF1.666f1p/assets/luma_assets_e33.json").read_text(encoding="utf-8"))
# All art assets except the Side of Mountain background are identical.
assert set(OLD["assets"]) == set(NEW["assets"])
for key in OLD["assets"]:
    if key != "c13_bg_mountain_side": assert OLD["assets"][key] == NEW["assets"][key], key
oldbg=OLD["assets"]["c13_bg_mountain_side"]
newbg=NEW["assets"]["c13_bg_mountain_side"]
for key in oldbg:
    if key != "commands": assert oldbg[key] == newbg[key], key
oldcmd=oldbg["commands"]; newcmd=newbg["commands"]
assert len(oldcmd) == len(newcmd) == 199
assert newcmd[:143] == oldcmd[:143]
assert [c["op"] for c in newcmd[143:146]] == ["polygon"]*3
assert newcmd[146:] == oldcmd[146:]
# Trail taper endpoint reaches into the cave opening; polygon layers converge smoothly.
road=newcmd[143:146]
assert [c["color"] for c in road] == [[69,75,61],[169,151,111],[192,174,132]]
for layer in road: assert max(point[0] for point in layer["points"]) >= 688
# World connections, all objects, and all other world records are unchanged.
assert OLD["world"]["connections"] == NEW["world"]["connections"]
assert OLD["world"]["objects"] == NEW["world"]["objects"]
for key in OLD["world"]:
    if key != "areas": assert OLD["world"][key] == NEW["world"][key], key
oldareas={a["area_id"]:a for a in OLD["world"]["areas"]}
newareas={a["area_id"]:a for a in NEW["world"]["areas"]}
assert oldareas.keys() == newareas.keys()
for aid in oldareas:
    if aid != "side_of_mountain": assert oldareas[aid] == newareas[aid], aid
oldside=dict(oldareas["side_of_mountain"]); newside=dict(newareas["side_of_mountain"])
assert oldside["background_asset"] == newside["background_asset"] == "c13_bg_mountain_side"
assert oldside["navigation"] == newside["navigation"]
# Confirm the revised final path remains within the existing 112px corridor, using the engine's foot anchor.
line=[(x,y+14) for x,y in [(625,412),(650,400),(660,395),(675,386),(691,379)]]
polyline,width=oldside["navigation"]["corridors"][0]
def segdist(p,a,b):
    dx=b[0]-a[0];dy=b[1]-a[1]
    t=max(0.0,min(1.0,((p[0]-a[0])*dx+(p[1]-a[1])*dy)/max(.01,dx*dx+dy*dy)))
    return math.hypot(p[0]-a[0]-dx*t,p[1]-a[1]-dy*t)
for point in line:
    d=min(segdist(point,a,b) for a,b in zip(polyline,polyline[1:]))
    assert d <= width/2-9+1e-6, (point,d)
# Cave door identity, kind, position, dimensions, and walk trigger are preserved.
oldc=next(o for o in OLD["world"]["objects"] if o["object_id"]=="mountain_cave_entrance")
newc=next(o for o in NEW["world"]["objects"] if o["object_id"]=="mountain_cave_entrance")
assert oldc == newc
# Main runtime parses and only version/classes/instantiation are advanced.
main=(BASE/"SGGF1.666f1p/assets/main.py").read_text(encoding="utf-8")
ast.parse(main)
assert 'VERSION = "F1.666f1p"' in main
assert "F1666f1pStateMachine" in main and "F1666f1pInterface" in main
play=(BASE/"SGGF1.666f1p/play.html").read_text(encoding="utf-8")
assert "sggf1666f1p.tar.gz" in play and "sggf1666f1p.apk" in play
for name in ("sggf1666f1p.tar.gz",):
    with tarfile.open(BASE/"SGGF1.666f1p"/name,"r:gz") as tf:
        assert set(tf.getnames()) == {"assets/main.py","assets/luma_assets_e33.json"}
with zipfile.ZipFile(BASE/"SGGF1.666f1p"/"sggf1666f1p.apk") as z:
    assert z.testzip() is None
    assert set(z.namelist()) == {"assets/main.py","assets/luma_assets_e33.json"}
# Version catalog keeps all prior entries and makes only F1p current.
import json as _json
catalog=_json.loads((BASE/"deploy"/"versions.json").read_text(encoding="utf-8"))
assert catalog["versions"][0]["version"] == "SGGF1.666f1p"
assert sum(1 for x in catalog["versions"] if x.get("current")) == 1
print("SGGF1.666f1p art, cave transition, corridor coverage, preservation and runtime tests passed")
