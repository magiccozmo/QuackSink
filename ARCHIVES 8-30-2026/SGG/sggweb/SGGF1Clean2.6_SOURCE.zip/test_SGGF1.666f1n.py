import json, ast
from pathlib import Path
BASE=Path(__file__).resolve().parent
D=json.loads((BASE/"SGGF1.666f1n/assets/luma_assets_e33.json").read_text())
B=json.loads((BASE/"SGGF1.666f1m/assets/luma_assets_e33.json").read_text())
a=next(x for x in D["world"]["areas"] if x["area_id"]=="side_of_mountain")
b=next(x for x in B["world"]["areas"] if x["area_id"]=="side_of_mountain")
assert a["navigation"]["regions"] and a["navigation"]["corridors"]
assert a["navigation"] != b["navigation"]
C={x["connection_id"]:x for x in D["world"]["connections"]}
assert C["side_of_mountain_top_southern_wilds"]["edge"]=="left"
assert C["southern_wilds_bottom_side_of_mountain"]["arrival_x"]==65
O={x["object_id"]:x for x in D["world"]["objects"]}
assert O["mountain_cave_entrance"]["kind"]=="door"
assert O["mountain_cave_entrance"]["walk_trigger"]["approach"]=="north"
S=(BASE/"SGGF1.666f1n/assets/main.py").read_text()
ast.parse(S)
assert 'VERSION = "F1.666f1n"' in S
assert "('side_of_mountain', 'mountain_cave_entrance')" in S
def in_poly(x,y,p):
    inside=False; j=len(p)-1
    for i in range(len(p)):
        xi,yi=p[i]; xj,yj=p[j]
        if ((yi>y)!=(yj>y)) and x < (xj-xi)*(y-yi)/(yj-yi+1e-12)+xi: inside=not inside
        j=i
    return inside
def segdist(x,y,a,b):
    ax,ay=a; bx,by=b; dx=bx-ax; dy=by-ay
    t=max(0,min(1,((x-ax)*dx+(y-ay)*dy)/max(.01,dx*dx+dy*dy)))
    return ((x-ax-dx*t)**2+(y-ay-dy*t)**2)**.5
def walkable(x,y):
    fy=y+14
    if any(in_poly(x,fy,p) for p in a["navigation"]["regions"]): return True
    return any(min(segdist(x,fy,p,q) for p,q in zip(line,line[1:])) <= width/2-8 for line,width in a["navigation"]["corridors"])
for pt in [(65,500),(200,480),(400,470),(570,445),(650,405),(1100,500)]:
    assert walkable(*pt), (pt,"must be walkable")
assert not walkable(640,100), "sky route must be blocked"
assert not walkable(1000,250), "cliff route must be blocked"
print("F1.666f1n structural and walkmesh checks passed")
