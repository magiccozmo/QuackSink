from pathlib import Path
import json, shutil, re, zipfile, tarfile, io, hashlib, subprocess, sys, textwrap
from PIL import Image, ImageDraw

BASE = Path('/mnt/data/sgg_clean2_work')
SRC = BASE / 'source_work'
DEPLOY_BASE = BASE / 'deploy_work'
OUT = Path('/mnt/data')
RELEASE = 'SGGF1Clean2'
PREV = 'SGGF1.666Cleanup1.0'
BUNDLE = 'sggf1clean2'

base_versions = json.loads((DEPLOY_BASE / 'versions.json').read_text(encoding='utf-8'))['versions']
assert [e['version'] for e in base_versions] == [
    PREV, 'SGGF1.666f1s', 'SGGF1.666', 'SGGF1.6', 'SGGF1.0', 'SGGE3.2', 'SGGE3.1', 'SGGE2.0'
], 'The curated Cleanup1.0 milestone catalogue changed; inspect before packaging.'

# Recreate the new source release folder from the exact preceding clean version.
new_src = SRC / RELEASE
if new_src.exists():
    shutil.rmtree(new_src)
shutil.copytree(SRC / PREV, new_src)

# Apply the release label to the main working source. The only code change is VERSION.
main = (SRC / 'main.py').read_text(encoding='utf-8')
main, count = re.subn(r'^VERSION\s*=\s*"[^"]+".*$', 'VERSION = "F1Clean2"  # Mountain Path makeover; preserves all other gameplay.', main, count=1, flags=re.M)
assert count == 1
(SRC / 'main.py').write_text(main, encoding='utf-8')

assets_text = (SRC / 'luma_assets_e33.json').read_text(encoding='utf-8')
assets = json.loads(assets_text)
assert assets['version'] == 'F1Clean2'
area = next(a for a in assets['world']['areas'] if a['area_id'] == 'mountain_path')
assert len(area['navigation']['corridors']) == 4

# Confirm that no other game systems/world connections changed from Cleanup1.0.
base_assets = json.loads((BASE / 'source_base' / f'{PREV}_SOURCE' / 'luma_assets_e33.json').read_text(encoding='utf-8'))
assert assets['world']['connections'] == base_assets['world']['connections']
base_areas = {a['area_id']: a for a in base_assets['world']['areas']}
for a in assets['world']['areas']:
    if a['area_id'] != 'mountain_path':
        assert a == base_areas[a['area_id']], f"Unexpected area change: {a['area_id']}"
for key, value in assets['world'].items():
    if key != 'areas':
        assert value == base_assets['world'][key], f"Unexpected world field changed: {key}"

# Copy current code and Luma recipes into the new release's complete handoff.
(new_src / 'main.py').write_text(main, encoding='utf-8')
(new_src / 'luma_assets_e33.json').write_text(json.dumps(assets, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
(new_src / 'assets' / 'main.py').write_text(main, encoding='utf-8')
(new_src / 'assets' / 'luma_assets_e33.json').write_text(json.dumps(assets, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

package_py = textwrap.dedent(f'''\
    from pathlib import Path
    from io import BytesIO
    import tarfile, zipfile
    W = Path(__file__).resolve().parent
    code = (W / "main.py").read_bytes()
    assets = (W / "luma_assets_e33.json").read_bytes()
    bundle = "{BUNDLE}"
    with zipfile.ZipFile(W / (bundle + ".apk"), "w", zipfile.ZIP_DEFLATED, compresslevel=8) as z:
        z.writestr("assets/main.py", code)
        z.writestr("assets/luma_assets_e33.json", assets)
    with tarfile.open(W / (bundle + ".tar.gz"), "w:gz") as t:
        for name, data in (("assets/main.py", code), ("assets/luma_assets_e33.json", assets)):
            info = tarfile.TarInfo(name)
            info.size = len(data)
            info.mtime = 0
            t.addfile(info, BytesIO(data))
    print("Built {RELEASE} runtime packages.")
''')
(new_src / 'package_f1clean2.py').write_text(package_py, encoding='utf-8')

play = (SRC / PREV / 'play.html').read_text(encoding='utf-8')
play = play.replace('F1.666Cleanup1.0', 'F1Clean2').replace('sggf1666cleanup10', BUNDLE)
play = play.replace("Spiffy's Gift | Play Now", "Spiffy's Gift | F1Clean2")
(new_src / 'play.html').write_text(play, encoding='utf-8')
shutil.copy2(SRC / PREV / 'favicon.png', new_src / 'favicon.png')

readme = f'''SPIFFY'S GIFT — {RELEASE}

BASELINE
Built from the exact {PREV} source ZIP and complete Cloudflare site ZIP in magiccozmo/QuackSink main. Both original ZIPs were verified and matched their GitHub blob hashes after retrieval.

THIS RELEASE
The Mountain Path background asset (c1_bg_mountain_path) is redesigned as a narrower, perspective-tapered mountain footpath with broad, readable switchbacks. The trail is drawn through the Luma Draw Engine JSON; it is not a flattened replacement image. Its navigation corridors were rebuilt to follow the visible trail at matching widths.

The foreground Plains connector is retained. The Plains and Peak transitions, their connection definitions, player start, save compatibility/migration, Hellgs Inn challenge, inventory, quests, NPCs, dialogue, and all other areas are preserved. This release does not change the default start: the F1.666 line continues to begin in Hellgs Inn until SGGF1.666Final is complete.

DEPLOY HISTORY
The curated deployment carries forward all eight playable milestone editions from {PREV}: SGGE2.0, SGGE3.1, SGGE3.2, SGGF1.0, SGGF1.6, SGGF1.666, SGGF1.666f1s and {PREV}. It adds {RELEASE} as the ninth choice. This preserves the special/archive versions Cozmo expects at the front door while keeping the many ordinary intermediate test releases out of the deployment.

TESTING
- Exact baseline source/deploy archive identity verified against the current GitHub main tree.
- Original baseline ZIP integrity verified before extraction.
- Python source compiled; Luma JSON parsed.
- Only c1_bg_mountain_path, mountain_path navigation, release version metadata/label changed.
- World connection table, all non-Mountain Path area definitions, and other world-level fields compared unchanged against the baseline.
- Navigation corridor continuity and art/walkmesh width correspondence checked.
- Runtime APK/TAR archive integrity and byte-for-byte payloads checked.
- Deployment catalogue checked for {RELEASE} plus the eight curated Cleanup1.0 milestone editions. Every prior selected milestone directory was verified byte-for-byte unchanged.

LIMITATION
A live browser launch, player movement session, and in-game save/load regression test were not possible in this build environment. Cozmo should field-test the delivered build before treating it as the next live baseline.
'''
(new_src / f'README_{RELEASE}.txt').write_text(readme, encoding='utf-8')

meta = {
    'version': RELEASE,
    'runtime_version': 'F1Clean2',
    'base': PREV,
    'release_type': 'Mountain Path artwork and matching navigation refinement; lean deployment continuation',
    'changed': [
        'c1_bg_mountain_path Luma Draw Engine JSON drawing recipe',
        'mountain_path navigation corridors, aligned to visible footpath width',
        'current release label and deployment catalogue'
    ],
    'preserved': [
        'all existing world connection definitions, including Plains and Peak transitions',
        'all non-Mountain Path areas and their artwork/navigation',
        'foreground Plains connector road',
        'Hellgs Inn default start and F1.666 challenge state',
        'save schema and backward-compatible save migration',
        'gameplay, NPCs, dialogue, items, quests, inventory and Tea counters'
    ],
    'deployment_versions': [RELEASE] + [e['version'] for e in base_versions],
    'source_history': 'Deployment preserves the eight curated milestone versions from Cleanup1.0 and adds Clean2. Intermediate daily/test versions are excluded. Full source archive retains its milestone source ZIPs and development history.',
    'tests': [
        'Exact Cleanup1.0 baseline ZIP SHA identity and ZIP integrity verified.',
        'Python syntax compilation and Luma JSON parse successful.',
        'Non-Mountain Path world area definitions and world connection table compared unchanged.',
        'Navigation corridors are connected and match visible trail widths.',
        'Runtime APK ZIP integrity and exact source payload comparison passed.',
        'Runtime TAR.GZ integrity and exact source payload comparison passed.',
        'Deployment contains Clean2 plus all eight curated Cleanup1.0 milestone directories and catalogue entries.',
        'All eight prior selected milestone directories verified byte-for-byte unchanged.'
    ],
    'runtime_note': 'Live browser/gameplay and save/load regression testing were not performed in this build environment.'
}
(new_src / f'{RELEASE}_BUILD_META.json').write_text(json.dumps(meta, indent=2) + '\n', encoding='utf-8')

# Build runtime package with the same Pygbag APK/TAR layout as the previous clean release.
subprocess.run([sys.executable, str(new_src / 'package_f1clean2.py')], check=True)

# Copy the version-specific build/test notes into the root source handoff.
for name in ['package_f1clean2.py', f'README_{RELEASE}.txt', f'{RELEASE}_BUILD_META.json']:
    shutil.copy2(new_src / name, SRC / name)

# Source art preview and an overlay representing the exact walkable width.
preview = OUT / 'SGGF1Clean2_MountainPath_Preview.png'
assert preview.is_file() and preview.stat().st_size > 10000
shutil.copy2(preview, new_src / 'mountain_path_preview.png')
S = 3
im = Image.open(preview).convert('RGBA').resize((1280 * S, 640 * S), Image.Resampling.LANCZOS)
draw = ImageDraw.Draw(im, 'RGBA')
for points, width in area['navigation']['corridors']:
    coords = [(round(x * S), round(y * S)) for x, y in points]
    allowed_width = max(1, round((width - 18) * S))
    draw.line(coords, fill=(65, 210, 130, 85), width=allowed_width, joint='curve')
    for x, y in points:
        r = 2 * S
        draw.ellipse((x * S - r, y * S - r, x * S + r, y * S + r), fill=(55, 230, 140, 180))
walkmesh_preview = OUT / 'SGGF1Clean2_MountainPath_Walkmesh_Preview.png'
im.resize((1280, 640), Image.Resampling.LANCZOS).save(walkmesh_preview)
shutil.copy2(walkmesh_preview, new_src / 'mountain_path_walkmesh_preview.png')
shutil.copy2(preview, SRC / 'SGGF1Clean2_MountainPath_Preview.png')
shutil.copy2(walkmesh_preview, SRC / 'SGGF1Clean2_MountainPath_Walkmesh_Preview.png')

# Create deployment from the exact curated Cleanup1.0 deployment.
# Preserve ALL eight deliberate milestone editions, then add the new Clean2 edition.
# The Cleanup1.0 catalogue is the authority for this curated set; do not restore
# the many intermediate F1.666 test releases found in older source snapshots.
new_deploy = BASE / 'deploy_clean2'
if new_deploy.exists():
    shutil.rmtree(new_deploy)
shutil.copytree(DEPLOY_BASE, new_deploy)
new_pub = new_deploy / RELEASE
if new_pub.exists():
    shutil.rmtree(new_pub)
new_pub.mkdir()
for fn in [
    'play.html', 'main.py', 'luma_assets_e33.json', 'favicon.png',
    f'{RELEASE}_BUILD_META.json', f'README_{RELEASE}.txt',
    'mountain_path_preview.png', 'mountain_path_walkmesh_preview.png',
    'sggf1clean2.apk', 'sggf1clean2.tar.gz'
]:
    shutil.copy2(new_src / fn, new_pub / fn)

# Keep the entire curated catalogue from Cleanup1.0, changing only its former
# current flag. The seven named milestone editions remain selectable as before.
retained_entries = []
for original in base_versions:
    entry = dict(original)
    entry['current'] = False
    retained_entries.append(entry)
versions = {
    'schema': 'spiffys-gift-site-versions-v1',
    'versions': [
        {
            'version': RELEASE,
            'title': f'{RELEASE} — Mountain Path Reimagined',
            'path': f'{RELEASE}/play.html',
            'description': 'Current Mountain Path makeover with a narrower storybook trail, broad switchbacks and aligned walkmesh. Plains and Peak connections remain intact. The seven curated historical milestones and previous clean release are retained below.',
            'image': f'{RELEASE}/mountain_path_preview.png',
            'current': True
        },
        *retained_entries
    ]
}
(new_deploy / 'versions.json').write_text(json.dumps(versions, indent=2) + '\n', encoding='utf-8')
(new_deploy / 'README_SGGWEB.txt').write_text(f'''SPIFFY'S GIFT — CLEAN DEPLOYMENT

CURRENT VERSION: {RELEASE}

This complete Cloudflare site retains the nine deliberately selected playable editions:
- {RELEASE} — current Mountain Path makeover.
- {PREV} — preceding clean release and rollback option.
- SGGF1.666f1s, SGGF1.666, SGGF1.6 and SGGF1.0 — selected F milestones.
- SGGE3.2, SGGE3.1 and SGGE2.0 — selected E milestones.

This is a curated milestone history, NOT the entire chain of daily/intermediate test releases. All other older intermediate releases remain in the full source archive, GitHub and Cozmo's local archives; they are intentionally excluded from this lean deployment. The site does not depend on GitHub at runtime.

The existing root index.html and versions.html remain in place and read versions.json. HELLgs Inn remains the F1.666-line default start; no start-mode change was made.
''', encoding='utf-8')

# Keep the source handoff's deploy/ mirror aligned with the actual corrected Cloudflare bundle.
source_deploy = SRC / 'deploy'
if source_deploy.exists():
    shutil.rmtree(source_deploy)
shutil.copytree(new_deploy, source_deploy)

# Create a standalone source-side test script; it does not go into the Cloudflare site.
test_py = textwrap.dedent('''\
    import json, sys, zipfile, tarfile
    from pathlib import Path
    root = Path(__file__).resolve().parent
    deploy = Path(sys.argv[1]).resolve()
    assert 'VERSION = "F1Clean2"' in (root / 'main.py').read_text(encoding='utf-8')
    json_data = json.loads((root / 'luma_assets_e33.json').read_text(encoding='utf-8'))
    assert json_data['version'] == 'F1Clean2'
    area = next(a for a in json_data['world']['areas'] if a['area_id'] == 'mountain_path')
    assert len(area['navigation']['corridors']) == 4
    versions = json.loads((deploy / 'versions.json').read_text(encoding='utf-8'))['versions']
    expected = ['SGGF1Clean2', 'SGGF1.666Cleanup1.0', 'SGGF1.666f1s', 'SGGF1.666', 'SGGF1.6', 'SGGF1.0', 'SGGE3.2', 'SGGE3.1', 'SGGE2.0']
    assert [v['version'] for v in versions] == expected
    assert versions[0]['current'] is True
    assert all(v.get('current') is False for v in versions[1:])
    assert sum(bool(v.get('current')) for v in versions) == 1
    for entry in versions:
        target = deploy / entry['path']
        assert target.is_file(), f'Missing selectable edition: {entry["version"]} -> {target}'
        if entry.get('image'):
            assert (deploy / entry['image']).is_file(), f'Missing edition art: {entry["image"]}'
    for n in expected:
        assert (deploy / n).is_dir(), n
    for n in ['SGGF1.666a', 'SGGF1.666b', 'SGGF1.666c', 'SGGF1.666d', 'SGGF1.666e', 'SGGF1.666f']:
        assert not (deploy / n).exists(), f'Uncurated intermediate release included: {n}'
    apk = root / 'sggf1clean2.apk'
    with zipfile.ZipFile(apk) as z:
        assert z.testzip() is None
        assert z.read('assets/main.py') == (root / 'main.py').read_bytes()
        assert z.read('assets/luma_assets_e33.json') == (root / 'luma_assets_e33.json').read_bytes()
    tar = root / 'sggf1clean2.tar.gz'
    with tarfile.open(tar, 'r:gz') as t:
        assert t.extractfile('assets/main.py').read() == (root / 'main.py').read_bytes()
        assert t.extractfile('assets/luma_assets_e33.json').read() == (root / 'luma_assets_e33.json').read_bytes()
    print('PASS: Clean2 JSON/nav, nine-entry curated milestone catalogue, intermediate versions omitted, APK/TAR payloads exact.')
''')
(new_src / 'test_f1clean2.py').write_text(test_py, encoding='utf-8')
shutil.copy2(new_src / 'test_f1clean2.py', SRC / 'test_f1clean2.py')

# Compile current Python and execute project tests.
subprocess.run([sys.executable, '-m', 'py_compile', str(new_src / 'main.py')], check=True)
subprocess.run([sys.executable, str(new_src / 'test_f1clean2.py'), str(new_deploy)], check=True)

# Complete source ZIP. Full source archive is retained; lumas log remains a separate delivery.
source_zip = OUT / f'{RELEASE}_SOURCE.zip'
if source_zip.exists():
    source_zip.unlink()
with zipfile.ZipFile(source_zip, 'w', zipfile.ZIP_DEFLATED, compresslevel=7) as z:
    for p in sorted(SRC.rglob('*')):
        if p.is_file() and '__pycache__' not in p.parts and p.suffix != '.pyc':
            z.write(p, p.relative_to(SRC).as_posix())

# Complete static site ZIP: Clean2 plus the eight curated milestone folders.
deploy_zip = OUT / f'{RELEASE}_COMPLETE_CLOUDFLARE_SITE.zip'
if deploy_zip.exists():
    deploy_zip.unlink()
with zipfile.ZipFile(deploy_zip, 'w', zipfile.ZIP_DEFLATED, compresslevel=8) as z:
    for p in sorted(new_deploy.rglob('*')):
        if p.is_file():
            z.write(p, p.relative_to(new_deploy).as_posix())

# Final archive integrity and lean-version structure checks.
with zipfile.ZipFile(source_zip) as z:
    assert z.testzip() is None
    source_names = z.namelist()
    assert f'{RELEASE}/main.py' in source_names
    assert f'{RELEASE}/luma_assets_e33.json' in source_names
    assert f'{RELEASE}/sggf1clean2.apk' in source_names
    assert f'{RELEASE}/sggf1clean2.tar.gz' in source_names
    assert not any(n.lower().endswith('lumas log.txt') for n in source_names)
with zipfile.ZipFile(deploy_zip) as z:
    assert z.testzip() is None
    deploy_names = z.namelist()
    assert 'index.html' in deploy_names and 'versions.html' in deploy_names
    zipped_versions = json.loads(z.read('versions.json'))['versions']
    expected_versions = [RELEASE] + [e['version'] for e in base_versions]
    assert [v['version'] for v in zipped_versions] == expected_versions
    known_versions = set(expected_versions)
    present_version_dirs = sorted({n.split('/')[0] for n in deploy_names if '/' in n and n.split('/')[0] in known_versions})
    assert present_version_dirs == sorted(expected_versions), present_version_dirs
    assert len(zipped_versions) == 9
    for entry in base_versions:
        base_dir = DEPLOY_BASE / entry['version']
        current_dir = new_deploy / entry['version']
        for base_file in base_dir.rglob('*'):
            if base_file.is_file():
                relative = base_file.relative_to(base_dir)
                copied = current_dir / relative
                assert copied.exists() and hashlib.sha256(base_file.read_bytes()).digest() == hashlib.sha256(copied.read_bytes()).digest(), str(base_file)

# Prove every prior curated milestone deployment folder is byte-identical to the baseline.
for entry in base_versions:
    base_dir = DEPLOY_BASE / entry['version']
    current_dir = new_deploy / entry['version']
    for p in base_dir.rglob('*'):
        if p.is_file():
            q = current_dir / p.relative_to(base_dir)
            assert q.exists() and hashlib.sha256(p.read_bytes()).digest() == hashlib.sha256(q.read_bytes()).digest(), str(p)

print(json.dumps({
    'source_zip': str(source_zip), 'source_bytes': source_zip.stat().st_size,
    'deploy_zip': str(deploy_zip), 'deploy_bytes': deploy_zip.stat().st_size,
    'source_files': len(source_names), 'deploy_files': len(deploy_names),
    'deploy_version_dirs': present_version_dirs,
    'runtime_apk_bytes': (new_src / 'sggf1clean2.apk').stat().st_size,
    'runtime_tar_bytes': (new_src / 'sggf1clean2.tar.gz').stat().st_size,
    'preview_bytes': preview.stat().st_size,
    'walkmesh_preview_bytes': walkmesh_preview.stat().st_size
}, indent=2))
