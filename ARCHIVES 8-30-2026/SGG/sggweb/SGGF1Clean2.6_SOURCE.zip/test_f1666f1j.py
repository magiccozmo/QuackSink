from __future__ import annotations
import ast,copy,json,zipfile,tarfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
V="SGGF1.666f1j"; P="sggf1666f1j"
cur=json.loads((ROOT/"luma_assets_e33.json").read_text(encoding="utf-8"))
base=json.loads((ROOT/"SGGF1.666f1i"/"assets"/"luma_assets_e33.json").read_text(encoding="utf-8"))
assert cur["version"]==V
ba={a['area_id']:a for a in base['world']['areas']}; ca={a['area_id']:a for a in cur['world']['areas']}
assert set(ba)==set(ca)
for k in ba:
    if k!='plains': assert ca[k]==ba[k],k
# Only Plains navigation differs, and the ground/crossroads polygon is identical.
pb=ba['plains']; pc=ca['plains']
assert pc['navigation']['regions'][0]==pb['navigation']['regions'][0]
assert pc['navigation']['regions'][1]!=pb['navigation']['regions'][1]
assert pc['navigation']['regions'][1]==[[628,286],[654,286],[657,304],[660,323],[666,344],[672,365],[682,388],[698,411],[718,435],[584,435],[602,411],[617,388],[627,365],[634,344],[639,323],[637,304]]
# Player navigation uses foot_y = player_y + 14. The path reaches the camp
# threshold but no longer admits a point in the sky or far off the path.
def inside(x,y,p):
    yes=False; lx,ly=p[-1]
    for px,py in p:
        if ((py>y)!=(ly>y)) and x < px+(lx-px)*(y-py)/(ly-py): yes=not yes
        lx,ly=px,py
    return yes
def allowed(x,player_y):
    foot=player_y+14
    return any(inside(x,foot,p) for p in pc['navigation']['regions'])
assert allowed(640,300)  # transition approach is reachable
assert allowed(640,280)  # player can reach the horizon marker
assert not allowed(640,240) # no walking into the sky
assert not allowed(570,280) # no wandering beside the road
assert allowed(640,470) # crossroads remain fully walkable
assert allowed(70,470) and allowed(1210,470) # the west/east route approaches remain
# All connection records remain identical: no exit moved.
assert cur['world']['connections']==base['world']['connections']
assert cur['world']['objects']==base['world']['objects']
# Only the Plains background asset and its top-level metadata changed.
for k,v in base['assets'].items():
    if k!='c1_bg_plains': assert cur['assets'][k]==v,k
assert cur['assets']['c1_bg_plains']['commands'][:47]==base['assets']['c1_bg_plains']['commands'][:47]
main=(ROOT/'main.py').read_text(encoding='utf-8'); ast.parse(main)
assert 'VERSION = "F1.666f1j"' in main
assert 'class F1666f1jInterface(F1666f1iInterface):' in main
assert 'ui = F1666f1jInterface(machine)' in main
assert 'previous_y > 300 >= game.player_y' in main
# Other version directory remains present and unmodified at source level.
assert (ROOT/'SGGF1.666f1i'/'play.html').is_file()
v=ROOT/V
assert (v/'play.html').is_file()
assert (v/'assets'/'main.py').read_bytes()==(ROOT/'main.py').read_bytes()
assert (v/'assets'/'luma_assets_e33.json').read_bytes()==(ROOT/'luma_assets_e33.json').read_bytes()
with zipfile.ZipFile(v/(P+'.apk')) as z:
    assert z.testzip() is None and set(z.namelist())=={'assets/main.py','assets/luma_assets_e33.json'}
with tarfile.open(v/(P+'.tar.gz'),'r:gz') as t:
    assert set(t.getnames())=={'assets/main.py','assets/luma_assets_e33.json'}
manifest=json.loads((ROOT/'deploy'/'versions.json').read_text(encoding='utf-8'))['versions']
assert len(manifest)==52 and manifest[0]['version']==V and sum(bool(x.get('current')) for x in manifest)==1
