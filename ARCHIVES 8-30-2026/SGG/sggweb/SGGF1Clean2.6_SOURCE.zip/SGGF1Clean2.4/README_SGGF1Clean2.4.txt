SPIFFY'S GIFT — SGGF1Clean2.4

CURRENT CANDIDATE: SGGF1Clean2.4
BASE: Exact SGGF1Clean2.3 source and complete Cloudflare deployment.

MOUNTAINSIDE CAVE ENTRANCE SAVE / HOVER REPAIR
- A successful save load now restores only the canonical name and kind for the existing mountain_cave_entrance object, using the current Luma world definition.
- The matching item_meta name/kind values are normalized too, so older snapshots cannot retain a corrupted display identity.
- The hover label for this one object displays its proper name, FROSTY’S CAVE ENTRANCE, rather than the generic RETURN TO MARKET label.
- The object position, dimensions, area, walk trigger, connection, interaction behavior, inventory/moved state and all unrelated saved fields are preserved.

PRESERVED
- Peak summit, Scenic Overlook panorama, Cozmo dialogue, Peak removal of the duplicate Troll Cave door, and the Peak return route.
- Mountain Path art and walkmesh, Side of Mountain art/collision/walkmesh, all existing transitions, and all other area definitions.
- All twelve previous playable versions and their release folders; only the catalogue gains this new current version and marks Clean2.3 as previous.
- Existing source history and the JSON-controlled Luma Draw Engine.

TEST STATUS
Static syntax, JSON, save-migration simulation, hover-label routing, preservation, runtime payload, catalogue and ZIP-integrity checks are recorded in SGGF1Clean2.4_TEST_RESULTS.txt. Pygame is not installed in this build environment; the old-save behavior still requires Cozmo's live browser field test.
