#!/usr/bin/env python3
"""Focused SGGF1Clean2.4 regression tests: legacy Mountainside cave-door identity."""
from __future__ import annotations
import ast, copy, hashlib, json, math, pathlib, sys, tarfile, types, zipfile

ROOT = pathlib.Path(__file__).resolve().parent
SOURCE_ROOT = ROOT.parent
BASE_SOURCE = SOURCE_ROOT / 'SGGF1Clean2.3'
DEPLOY = pathlib.Path(sys.argv[1]).resolve()
BASE_DEPLOY = pathlib.Path(sys.argv[2]).resolve()
VERSION = 'SGGF1Clean2.4'


def check(ok, message):
    if not ok:
        raise AssertionError(message)
    print('PASS:', message)


def digest(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def tree_digest(folder):
    folder = pathlib.Path(folder)
    return {p.relative_to(folder).as_posix(): digest(p)
            for p in sorted(folder.rglob('*')) if p.is_file()}

# Source syntax, version identity and exact current world definition.
main_path = ROOT / 'main.py'
asset_path = ROOT / 'luma_assets_e33.json'
main = main_path.read_text(encoding='utf-8')
ast_tree = ast.parse(main, filename=str(main_path))
compile(main, str(main_path), 'exec')
check('VERSION = "F1Clean2.4"' in main, 'runtime identifies F1Clean2.4')
check('F1Clean2_4StateMachine(archive, config, warning)' in main,
      'the active app uses the focused F1Clean2.4 state-machine extension')
check("if hover.object_id == \"mountain_cave_entrance\":" in main and
      'tip, tip_color = hover.name.upper(), (170, 215, 255)' in main,
      'the Mountainside cave hover uses the canonical object name and blue door label')

new = json.loads(asset_path.read_text(encoding='utf-8'))
old = json.loads((BASE_SOURCE / 'luma_assets_e33.json').read_text(encoding='utf-8'))
check(new['version'] == 'F1Clean2.4', 'Luma asset JSON identifies F1Clean2.4')
check(new['world'] == old['world'], 'all world data, including cave object and connection, is unchanged')
check(new['assets'] == old['assets'], 'all Luma Draw Engine artwork recipes are unchanged')
changed_top = {key for key in set(old) | set(new) if old.get(key) != new.get(key)}
check(changed_top == {'version', 'art_revision', 'notes'},
      'only release metadata changed in the Luma asset JSON')
canonical = next(o for o in new['world']['objects'] if o['object_id'] == 'mountain_cave_entrance')
check(canonical['name'] == 'Frosty’s Cave Entrance' and canonical['kind'] == 'door',
      'canonical Mountainside door name and kind remain correct in current world data')
check(canonical['area_id'] == 'side_of_mountain', 'the original entrance remains in Side of Mountain')

# Exercise the actual migration method in isolation, without requiring Pygame.
class FakeBase:
    def __init__(self, live_game, loaded_game=None):
        self.game = live_game
        self.loaded_game = loaded_game
        self.draw_engine = types.SimpleNamespace(world=new['world'])
        self.logs = []
        self.fail_load = False

    def _log(self, category, message):
        self.logs.append((category, message))

    def _read_save(self, slot):
        if not self.fail_load:
            self.game = self.loaded_game

    def start_game(self):
        self.game = self.loaded_game


# Compile just the production state-machine class with a fake parent so its
# production methods (not a reimplementation) run in the small migration test.
state_node = next(n for n in ast_tree.body
                  if isinstance(n, ast.ClassDef) and n.name == 'F1Clean2_4StateMachine')
module = ast.Module(body=[state_node], type_ignores=[])
namespace = {'F1Clean2_2StateMachine': FakeBase}
exec(compile(module, str(main_path), 'exec'), namespace)
MigrationMachine = namespace['F1Clean2_4StateMachine']

class FakeObject:
    def __init__(self, object_id, name, kind, **attrs):
        self.object_id, self.name, self.kind = object_id, name, kind
        self.area_id = attrs.get('area_id', 'side_of_mountain')
        self.x = attrs.get('x', 590.0)
        self.y = attrs.get('y', 278.0)
        self.width = attrs.get('width', 140)
        self.height = attrs.get('height', 120)
        self.takeable = attrs.get('takeable', False)
        self.stealable = attrs.get('stealable', False)
        self.in_inventory = attrs.get('in_inventory', False)
        self.moved = attrs.get('moved', False)
        self.on_shelf = attrs.get('on_shelf', False)

class FakeGame:
    def __init__(self, objects, item_meta, **state):
        self.objects = objects
        self.item_meta = item_meta
        self.inventory = list(state.get('inventory', []))
        self.carried_object_id = state.get('carried_object_id')
        self.selected_object_id = state.get('selected_object_id')

    def object_by_id(self, oid):
        return next((o for o in self.objects if o.object_id == oid), None)

canonical_name = canonical['name']
canonical_kind = canonical['kind']
corrupt_name = 'ÃƒÂ¢Ã¢â€šÂ¬Ã¢â€žÂ¢ÃƒÂ¢Ã¢â€šÂ¬Ã¢â€žÂ¢s Cave Entrance'
corrupt_kind = 'scenic_overlook'
loaded_object = FakeObject('mountain_cave_entrance', corrupt_name, corrupt_kind,
                           area_id='side_of_mountain', x=601.25, y=281.5,
                           width=141, height=119, moved=True, in_inventory=False)
unrelated_object = FakeObject('unrelated_test_object', 'Do Not Change', 'rock',
                              area_id='plains', x=123.0, y=321.0, width=44, height=55,
                              moved=True)
loaded_meta = {
    'mountain_cave_entrance': {
        'object_id': 'mountain_cave_entrance', 'name': corrupt_name,
        'kind': corrupt_kind, 'value': 0, 'stealable': False, 'owner': 'preserve-me'
    },
    'unrelated_test_object': {
        'object_id': 'unrelated_test_object', 'name': 'Do Not Change',
        'kind': 'rock', 'value': 7, 'owner': 'unrelated-owner'
    }
}
loaded_game = FakeGame([loaded_object, unrelated_object], loaded_meta,
                       inventory=['old_saved_item'], selected_object_id='mountain_cave_entrance')
old_live = FakeGame([FakeObject('live_other', 'Existing live game', 'rock')], {})
machine = MigrationMachine(old_live, loaded_game)
machine._read_save('F9')
repaired = machine.game.object_by_id('mountain_cave_entrance')
check(machine.game is loaded_game, 'a successful save load is the only game instance migrated')
check(repaired.name == canonical_name and repaired.kind == canonical_kind,
      'corrupted old-save object name/kind are replaced by current canonical values')
check((repaired.area_id, repaired.x, repaired.y, repaired.width, repaired.height) ==
      ('side_of_mountain', 601.25, 281.5, 141, 119),
      'saved object area, position and dimensions are preserved exactly')
check(repaired.moved is True and repaired.in_inventory is False and repaired.takeable is False,
      'saved moved/inventory/takeable state is preserved')
check(machine.game.inventory == ['old_saved_item'] and
      machine.game.selected_object_id == 'mountain_cave_entrance',
      'saved inventory and selection references are preserved')
check(loaded_meta['mountain_cave_entrance']['name'] == canonical_name and
      loaded_meta['mountain_cave_entrance']['kind'] == canonical_kind,
      'matching item_meta name/kind values are normalized too')
check(loaded_meta['mountain_cave_entrance']['owner'] == 'preserve-me' and
      loaded_meta['mountain_cave_entrance']['value'] == 0,
      'all unrelated saved item_meta fields are preserved')
check((unrelated_object.name, unrelated_object.kind, unrelated_object.x,
       loaded_meta['unrelated_test_object']['owner']) ==
      ('Do Not Change', 'rock', 123.0, 'unrelated-owner'),
      'other saved objects and their metadata remain untouched')
check(any(c == 'MOUNTAINSIDE CAVE SAVE MIGRATION' for c, _ in machine.logs),
      'the targeted save migration is recorded in the existing flight recorder')

# Idempotence: no change, no additional migration log on a second pass.
logs_before = len(machine.logs)
assert machine._normalize_mountain_cave_entrance('repeat check') is False
check(len(machine.logs) == logs_before, 'reapplying the migration is idempotent')

# A failed load does not normalize the already-running game.
failed_obj = FakeObject('mountain_cave_entrance', corrupt_name, corrupt_kind, x=44.0, y=55.0)
failed_game = FakeGame([failed_obj], {'mountain_cave_entrance': {'name': corrupt_name, 'kind': corrupt_kind}})
failed_machine = MigrationMachine(failed_game, None)
failed_machine.fail_load = True
failed_machine._read_save('F6')
check(failed_machine.game is failed_game and failed_obj.name == corrupt_name and
      failed_obj.kind == corrupt_kind,
      'a failed save load leaves the previous live game untouched')

# Deployment catalogue and byte-for-byte preservation.
old_versions = json.loads((BASE_DEPLOY / 'versions.json').read_text(encoding='utf-8'))['versions']
new_versions = json.loads((DEPLOY / 'versions.json').read_text(encoding='utf-8'))['versions']
expected_order = [VERSION] + [v['version'] for v in old_versions]
check([v['version'] for v in new_versions] == expected_order,
      'front-door catalogue adds Clean2.4 and retains all twelve prior choices in order')
check(new_versions[0]['current'] is True and
      all(v.get('current') is False for v in new_versions[1:]),
      'only Clean2.4 is marked current')
for i, previous in enumerate(old_versions):
    expected = copy.deepcopy(previous)
    if i == 0:
        expected['current'] = False
    check(new_versions[i + 1] == expected,
          f'previous catalogue entry {previous["version"]} is preserved except current flag')
for v in new_versions:
    check((DEPLOY / v['path']).is_file(), f"catalogue launch path exists for {v['version']}")
    if v.get('image'):
        check((DEPLOY / v['image']).is_file(), f"catalogue image path exists for {v['version']}")
for version in expected_order[1:]:
    old_dir, new_dir = BASE_DEPLOY / version, DEPLOY / version
    check(old_dir.is_dir() and new_dir.is_dir() and tree_digest(old_dir) == tree_digest(new_dir),
          f'previous deployment folder {version} is byte-for-byte unchanged')

# Root and packaged source runtime copies match.
for p in [SOURCE_ROOT / 'main.py', SOURCE_ROOT / 'assets' / 'main.py',
          DEPLOY / VERSION / 'main.py']:
    check(p.is_file() and digest(p) == digest(main_path),
          f'runtime main.py matches: {p.relative_to(SOURCE_ROOT) if SOURCE_ROOT in p.parents else p}')
for p in [SOURCE_ROOT / 'luma_assets_e33.json',
          SOURCE_ROOT / 'assets' / 'luma_assets_e33.json',
          DEPLOY / VERSION / 'luma_assets_e33.json']:
    check(p.is_file() and digest(p) == digest(asset_path),
          f'runtime Luma JSON matches: {p.relative_to(SOURCE_ROOT) if SOURCE_ROOT in p.parents else p}')

apk = DEPLOY / VERSION / 'sggf1clean2_4.apk'
tar = DEPLOY / VERSION / 'sggf1clean2_4.tar.gz'
with zipfile.ZipFile(apk) as z:
    check(z.testzip() is None, 'runtime APK ZIP passes integrity')
    check(z.read('assets/main.py') == main_path.read_bytes(), 'APK main.py equals current source')
    check(z.read('assets/luma_assets_e33.json') == asset_path.read_bytes(), 'APK Luma JSON equals current source')
with tarfile.open(tar, 'r:gz') as t:
    check(t.extractfile('assets/main.py').read() == main_path.read_bytes(), 'runtime TAR main.py equals current source')
    check(t.extractfile('assets/luma_assets_e33.json').read() == asset_path.read_bytes(), 'runtime TAR Luma JSON equals current source')

source_mirror = SOURCE_ROOT / 'deploy'
check(tree_digest(source_mirror) == tree_digest(DEPLOY),
      'source ZIP embedded deploy tree matches complete Cloudflare deployment')
print('ALL CLEAN2.4 STATIC REGRESSION CHECKS PASSED')
