import json, ast, zipfile, tarfile, tempfile, hashlib
from pathlib import Path

BASE = Path(__file__).resolve().parent
VER = "SGGF1.666f1m"
DOC = json.loads((BASE / "SGGF1.666f1m" / "assets" / "luma_assets_e33.json").read_text(encoding="utf-8"))
BASE_DOC = json.loads((BASE / "SGGF1.666f1l" / "assets" / "luma_assets_e33.json").read_text(encoding="utf-8"))
assert DOC["version"] == VER
assert DOC["world"]["connections"] == BASE_DOC["world"]["connections"]
assert DOC["world"]["objects"] == BASE_DOC["world"]["objects"]
assert len(DOC["world"]["areas"]) == len(BASE_DOC["world"]["areas"])
for old, new in zip(BASE_DOC["world"]["areas"], DOC["world"]["areas"]):
    if old["area_id"] == "side_of_mountain":
        a=dict(old); b=dict(new); a.pop("navigation",None); b.pop("navigation",None)
        assert a == b
    else:
        assert old == new
for key, old_asset in BASE_DOC["assets"].items():
    if key != "c13_bg_mountain_side":
        assert DOC["assets"][key] == old_asset, key
areas = {a["area_id"]: a for a in DOC["world"]["areas"]}
assert "side_of_mountain" in areas
side = areas["side_of_mountain"]
assert side["background_asset"] == "c13_bg_mountain_side"
assert len(DOC["assets"]["c13_bg_mountain_side"]["commands"]) >= 350
assert side["navigation"].get("corridors") and side["navigation"].get("regions")
objs = {o["object_id"]: o for o in DOC["world"]["objects"]}
door = objs["mountain_cave_entrance"]
assert door["kind"] == "door" and door["x"] == 590 and door["y"] == 278
assert door["walk_trigger"] == {"rect":[583,402,124,21],"approach":"north"}
conn_ids = {c["connection_id"] for c in DOC["world"]["connections"]}
assert {"southern_wilds_bottom_side_of_mountain","side_of_mountain_top_southern_wilds","side_of_mountain_to_troll_cave","troll_cave_to_side_of_mountain"} <= conn_ids
src = (BASE / "SGGF1.666f1m" / "assets" / "main.py").read_text(encoding="utf-8")
ast.parse(src)
assert 'VERSION = "F1.666f1m"' in src
assert 'machine = F1666f1mStateMachine' in src and 'ui = F1666f1mInterface' in src
assert 'class F1666f1mStateMachine(F1666f1lStateMachine)' in src
cat = json.loads((BASE / "deploy" / "versions.json").read_text(encoding="utf-8"))
assert len(cat["versions"]) == 55
assert sum(bool(x.get("current")) for x in cat["versions"]) == 1
assert cat["versions"][0]["version"] == VER

# Verify walkmesh at all existing connection arrivals and the cave approach.
def inside(x,y,p):
    c=False; j=len(p)-1
    for i in range(len(p)):
        xi,yi=p[i]; xj,yj=p[j]
        if ((yi>y)!=(yj>y)) and x < (xj-xi)*(y-yi)/(yj-yi+1e-12)+xi: c=not c
        j=i
    return c
def sd(x,y,a,b):
    ax,ay=a; bx,by=b; dx=bx-ax; dy=by-ay
    t=max(0,min(1,((x-ax)*dx+(y-ay)*dy)/max(.01,dx*dx+dy*dy)))
    return ((x-ax-dx*t)**2+(y-ay-dy*t)**2)**.5
def ok(x,y):
    fy=y+14
    if any(inside(x,fy,p) for p in side["navigation"]["regions"]): return True
    for line,w in side["navigation"]["corridors"]:
        if min(sd(x,fy,a,b) for a,b in zip(line,line[1:])) <= w/2-8: return True
    return False
for pt in [(640,110),(640,30),(640,438),(640,430),(640,610)]:
    assert ok(*pt), (pt,"must be walkable")
assert not ok(1000,250), "unintended cliff/sky corridor should be blocked"
print("F1.666f1m checks passed")
