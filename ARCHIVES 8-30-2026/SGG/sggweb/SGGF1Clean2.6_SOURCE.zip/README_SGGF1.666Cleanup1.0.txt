SPIFFY'S GIFT — SGGF1.666Cleanup1.0

BASE: Exact SGGF1.666f1s source and complete Cloudflare site archives retrieved from magiccozmo/QuackSink main and verified by SHA-256 and ZIP integrity.

PURPOSE: Packaging consolidation only. This release keeps the current F1s game as the new current release while reducing the historical version menu to a curated set of major playable milestones.

RETAINED PLAYABLE HISTORY:
- SGGE2.0
- SGGE3.1
- SGGE3.2
- SGGF1.0
- SGGF1.6
- SGGF1.666 (the original HELLgs Inn challenge start)
- SGGF1.666f1s (the previous current F1.666 release)

GAMEPLAY: The current F1s game is preserved. HELLgs Inn remains the starting scenario throughout the F1.666 line. Troll Cave retains the tested Frosty/PPP far-left placement, with the pineapple just to Frosty's right and open kiting space to the right. No gameplay, area, art, walkmesh, save schema, save migration, Tea, hint, Fast Travel, inventory or transition behavior was intentionally changed.

SAVE COMPATIBILITY: The exact F1s migration logic is retained. Untouched default Frosty/PPP positions migrate as before; moved or collected pineapple state and active chase state are not reset.

TESTING: Rebuilt Pygbag APK/TAR from the updated main.py and luma_assets_e33.json; ZIP/TAR integrity and byte-for-byte payload checks pass; selected version catalog and folder links are checked. A live browser launch/gameplay session was not performed in this packaging environment.
