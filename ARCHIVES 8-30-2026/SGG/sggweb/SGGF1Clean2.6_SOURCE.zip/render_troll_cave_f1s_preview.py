from pathlib import Path
import json
from PIL import Image, ImageDraw
ROOT = Path(__file__).resolve().parent
D = json.loads((ROOT / "luma_assets_e33.json").read_text(encoding="utf-8"))
ASSETS = D["assets"]; S = 3
def draw_recipe(im, recipe, x, y, w=None, h=None):
    a=ASSETS[recipe]; w=float(w or a["width"]); h=float(h or a["height"]); sx=w/a["width"]; sy=h/a["height"]; dr=ImageDraw.Draw(im)
    for c in a["commands"]:
        op=c["op"]; col=tuple(c.get("color",(255,255,255))); border=max(0,int(round(float(c.get("border",0))*S*(abs(sx)+abs(sy))/2)))
        if op in ("rect","ellipse"):
            rx,ry,rw,rh=c["rect"]; box=((x+rx*sx)*S,(y+ry*sy)*S,(x+(rx+rw)*sx)*S,(y+(ry+rh)*sy)*S)
            if op=="rect": dr.rectangle(box,outline=col if border else None,fill=None if border else col,width=max(1,border))
            else: dr.ellipse(box,outline=col if border else None,fill=None if border else col,width=max(1,border))
        elif op=="polygon":
            pts=[((x+px*sx)*S,(y+py*sy)*S) for px,py in c["points"]]
            if border: dr.line(pts+[pts[0]],fill=col,width=max(1,border),joint="curve")
            else: dr.polygon(pts,fill=col)
        elif op=="line":
            pts=[((x+px*sx)*S,(y+py*sy)*S) for px,py in c["points"]]; width=max(1,int(round(c.get("width",1)*S*(abs(sx)+abs(sy))/2))); dr.line(pts,fill=col,width=width,joint="curve")
        elif op=="circle":
            cx,cy=c["center"]; r=float(c["radius"])*S*(abs(sx)+abs(sy))/2; box=((x+cx*sx)*S-r,(y+cy*sy)*S-r,(x+cx*sx)*S+r,(y+cy*sy)*S+r)
            if border: dr.ellipse(box,outline=col,width=max(1,border))
            else: dr.ellipse(box,fill=col)
scene=Image.new("RGBA",(1280*S,640*S),(42,43,43,255))
draw_recipe(scene,"c1_bg_troll_cave",0,0,1280,640)
n=next(n for n in D["world"]["npcs"] if n["npc_id"]=="troll")
draw_recipe(scene,n["asset"],n["x"]-n["width"]/2,n["y"]-n["height"]/2,n["width"],n["height"])
o=next(o for o in D["world"]["objects"] if o["object_id"]=="purple_passion_pineapple")
draw_recipe(scene,o["kind"],o["x"],o["y"],o["width"],o["height"])
scene.convert("RGB").resize((1280,640),Image.Resampling.LANCZOS).save(ROOT/"troll_cave_preview_f1s.png",quality=95)
print("Rendered the F1s Troll Cave placement preview.")
