#!/usr/bin/env python3
"""Create the F1Clean2 Mountain Path art and matching navigation corridor.

The Luma Draw Engine remains the source of truth: this script writes drawing
recipes into luma_assets_e33.json, not a flattened replacement background.
Only c1_bg_mountain_path and mountain_path navigation are changed.
"""
from __future__ import annotations
import json, math, random
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ASSET_FILE = ROOT / 'luma_assets_e33.json'
DATA = json.loads(ASSET_FILE.read_text(encoding='utf-8'))

# Command helpers. LumaDrawEngine supports rect, ellipse, polygon, line, circle.
C = []
def rect(x,y,w,h,color): C.append({'op':'rect','rect':[round(x,2),round(y,2),round(w,2),round(h,2)],'color':list(color),'border':0,'radius':0})
def ellipse(x,y,w,h,color): C.append({'op':'ellipse','rect':[round(x,2),round(y,2),round(w,2),round(h,2)],'color':list(color),'border':0})
def poly(points,color,border=0): C.append({'op':'polygon','points':[[round(x,2),round(y,2)] for x,y in points],'color':list(color),'border':border})
def line(points,color,width=1): C.append({'op':'line','points':[[round(x,2),round(y,2)] for x,y in points],'color':list(color),'width':width})
def circle(x,y,r,color): C.append({'op':'circle','center':[round(x,2),round(y,2)],'radius':round(r,2),'color':list(color),'border':0})

# --- Sky, distant ridges and the mountain mass ---
for y in range(44, 361, 10):
    t=(y-44)/316
    col=(round(67+95*t), round(101+69*t), round(120+47*t))
    rect(0,y,1280,10,col)
# Soft high-cloud groups.
for x,y,s in [(120,112,1.0),(370,86,.72),(865,105,.85),(1085,150,1.08),(690,175,.60)]:
    cloud=(207,216,199)
    ellipse(x,y,102*s,17*s,cloud); ellipse(x+27*s,y-13*s,50*s,30*s,cloud); ellipse(x+65*s,y+2*s,78*s,17*s,cloud)
# Far mountain chain: lower contrast and lighter toward the horizon.
poly([(0,350),(98,294),(180,320),(296,252),(390,295),(505,226),(630,268),(735,210),(850,272),(966,234),(1085,296),(1174,264),(1280,330),(1280,465),(0,465)],(132,154,151))
poly([(0,382),(122,334),(230,355),(345,296),(465,349),(585,284),(716,337),(850,286),(974,349),(1100,315),(1200,359),(1280,344),(1280,480),(0,480)],(154,169,157))
# Small snow catches on distant summits.
poly([(268,269),(296,252),(324,276),(308,270),(296,273),(284,266)],(222,224,204))
poly([(477,246),(505,226),(530,251),(512,244),(499,250),(490,242)],(227,229,211))
poly([(708,230),(735,210),(765,238),(746,232),(732,235),(720,227)],(225,228,210))
poly([(940,253),(966,234),(991,260),(972,253),(960,258),(950,250)],(224,226,207))
# Main mountain silhouette, broad enough to visibly support the switchbacks.
poly([(0,440),(0,373),(120,320),(230,288),(345,309),(446,264),(535,204),(635,143),(744,172),(850,222),(958,266),(1087,309),(1190,354),(1280,398),(1280,640),(0,640)],(112,129,120))
# Sunlit central shoulder and darker side faces make the slope read as terrain.
poly([(0,432),(124,358),(242,322),(352,340),(456,304),(548,232),(637,166),(690,194),(612,273),(528,338),(450,408),(362,475),(0,520)],(132,145,128))
poly([(1280,432),(1160,370),(1060,330),(955,313),(862,341),(805,402),(876,482),(1005,530),(1280,548)],(88,107,105))
poly([(0,520),(172,451),(314,399),(430,374),(524,322),(607,244),(641,166),(588,278),(520,378),(432,465),(294,560),(0,640)],(88,108,106))
poly([(1280,535),(1138,471),(1015,424),(908,384),(822,376),(761,398),(832,451),(952,515),(1110,585),(1280,620)],(101,119,111))
# Rock strata and ledges on the exposed mountain faces.
for pts,col in [
 ([(66,405),(172,367),(265,349),(340,359)],(158,165,143)),
 ([(120,457),(234,412),(320,397),(392,403)],(116,133,119)),
 ([(865,300),(967,318),(1062,352),(1146,387)],(139,151,131)),
 ([(900,359),(1004,381),(1096,420),(1182,450)],(67,88,89)),
 ([(276,333),(358,309),(432,282),(488,247)],(156,164,139)),
 ([(802,229),(874,255),(943,279),(1010,298)],(143,156,134)),
 ([(205,508),(312,474),(402,436)],(72,94,93)),
 ([(930,500),(1045,535),(1148,566)],(70,89,89)),
]: line(pts,col,3)
# A few natural scree fans and shaded gullies.
poly([(178,462),(260,431),(330,417),(292,466),(230,494)],(100,119,112))
poly([(958,405),(1035,420),(1108,461),(1040,451)],(76,97,97))
poly([(505,262),(550,218),(600,188),(575,239)],(101,120,112))
poly([(750,207),(797,225),(843,252),(804,242)],(76,96,96))

# --- Mountain trail: a narrow, carved route with broad, supported switchbacks ---
# The trail is deliberately narrower than the old road. Its banks merge into
# the hillside, and retaining stones appear only on the exposed outside bends.
control=[
 (640,478,13),(590,448,13),(530,425,12),(470,409,12),(420,394,12),
 (390,376,12),(382,356,11),(397,340,11),(435,329,11),(500,320,11),
 (580,312,10),(665,304,10),(745,293,10),(815,278,10),(855,260,10),
 (862,241,9),(847,225,9),(815,214,9),(760,207,9),(690,202,8),
 (610,197,8),(535,190,8),(475,180,8),(438,166,8),(425,148,8),
 (435,130,7),(465,116,7),(510,103,7),(560,88,7),(610,69,6),(650,45,6)
]
# Catmull-Rom samples maintain a calm road curvature without folded hairpins.
def catmull(p0,p1,p2,p3,t):
    t2=t*t; t3=t2*t
    return .5*((2*p1)+(-p0+p2)*t+(2*p0-5*p1+4*p2-p3)*t2+(-p0+3*p1-3*p2+p3)*t3)
path=[]
for i in range(len(control)-1):
    p0=control[max(0,i-1)]; p1=control[i]; p2=control[i+1]; p3=control[min(len(control)-1,i+2)]
    for k in range(5):
        t=k/5
        x=catmull(p0[0],p1[0],p2[0],p3[0],t)
        y=catmull(p0[1],p1[1],p2[1],p3[1],t)
        w=p1[2]+(p2[2]-p1[2])*t
        path.append((x,y,w))
path.append(control[-1])
# The path is rendered as a single narrow track, not a filled road polygon.
# Its width tapers with distance, and the irregular stone texture breaks up any
# suggestion of a smooth paper ribbon.
sections=[(0,45,20),(45,95,16),(95,125,12),(125,len(path)-1,8)]
for lo,hi,thickness in sections:
    pts=[(x,y) for x,y,_ in path[lo:min(hi+1,len(path))]]
    if len(pts)>=2:
        line(pts,(137,132,111),thickness)
        # Narrow, broken lighter wear on the uphill side of the trail.
        hi_pts=[]
        for i in range(lo,min(hi+1,len(path)),2):
            x,y,w=path[i]; a=path[max(0,i-1)]; b=path[min(len(path)-1,i+1)]
            dx=b[0]-a[0]; dy=b[1]-a[1]; ln=max(1,math.hypot(dx,dy))
            nx=-dy/ln; ny=dx/ln
            hi_pts.append((x+nx*2.0,y+ny*2.0))
        if len(hi_pts)>=2: line(hi_pts,(161,151,123),1)
# Small broken stone patches and wheel-worn grooves keep the track organic.
for i in range(5,len(path)-4,7):
    x,y,w=path[i]; a=path[max(0,i-1)]; b=path[min(len(path)-1,i+1)]
    dx=b[0]-a[0]; dy=b[1]-a[1]; ln=max(1,math.hypot(dx,dy)); nx=-dy/ln; ny=dx/ln
    if i%2:
        ellipse(x-2,y-2,4,3,(161,150,122))
    else:
        line([(x-nx*2,y-ny*2),(x+nx*2,y+ny*2)],(117,114,98),1)

# A few short exposed-rock strata reinforce the existing slope without
# creating artificial platforms or continuous borders around the trail.
for pts,col in [
    ([(66,405),(172,367),(265,349),(340,359)],(158,165,143)),
    ([(120,457),(234,412),(320,397),(392,403)],(116,133,119)),
    ([(865,300),(967,318),(1062,352),(1146,387)],(139,151,131)),
    ([(900,359),(1004,381),(1096,420),(1182,450)],(67,88,89)),
    ([(276,333),(358,309),(432,282),(488,247)],(156,164,139)),
    ([(802,229),(874,255),(943,279),(1010,298)],(143,156,134)),
]: line(pts,col,3)

# Natural rough stone edging appears in small groups at the exposed bends.
# These are individual hillside boulders, not a continuous guardrail or ribbon edge.
for idx,side in [(30,-1),(70,1),(111,-1)]:
    x,y,w=path[idx]
    a=path[max(0,idx-1)]; b=path[min(len(path)-1,idx+1)]
    dx=b[0]-a[0]; dy=b[1]-a[1]; ln=max(1,math.hypot(dx,dy))
    nx=-dy/ln*side; ny=dx/ln*side
    for offset,scale in [(18,.75),(27,.5)]:
        bx=x+nx*offset; by=y+ny*offset
        ellipse(bx-5*scale,by-3*scale,10*scale,6*scale,(103,117,102))
        line([(bx-3*scale,by-1*scale),(bx,by-2.4*scale),(bx+3*scale,by-1*scale)],(150,153,128),1)
# --- Forest, boulders and alpine details (kept clear of the road) ---
def pine(x,y,s=1.0,tone=0):
    trunk=(91,74,55); greens=[(50,83,70),(59,96,77),(70,106,83)]
    c=greens[tone%3]
    rect(x-3*s,y,6*s,20*s,trunk)
    poly([(x,y-55*s),(x-21*s,y-18*s),(x+21*s,y-18*s)],c)
    poly([(x,y-40*s),(x-25*s,y-5*s),(x+25*s,y-5*s)],tuple(max(0,v-8) for v in c))
    poly([(x,y-25*s),(x-29*s,y+9*s),(x+29*s,y+9*s)],tuple(min(255,v+7) for v in c))
    line([(x-7*s,y-28*s),(x-2*s,y-35*s)],(122,147,111),1)
for item in [(76,443,.95,0),(160,365,.8,1),(270,332,.72,0),(355,286,.62,2),
             (928,292,.76,1),(1040,354,.95,0),(1172,431,1.05,2),(1200,492,.72,0),
             (140,513,.72,2),(300,538,.60,0),(1008,540,.70,1)]:
    pine(*item)
# Scree boulders and pale broken stone faces.
for x,y,rx,ry,c in [
    (98,415,26,13,(143,147,129)),(218,398,19,11,(127,139,126)),
    (328,368,24,15,(152,153,131)),(370,449,32,17,(105,122,112)),
    (888,330,30,16,(132,144,126)),(1008,394,22,12,(149,151,129)),
    (1130,449,28,15,(123,138,123)),(1185,524,22,11,(142,148,128)),
    (265,566,25,13,(113,129,116)),(914,560,31,15,(120,136,120))]:
    ellipse(x-rx,y-ry,rx*2,ry*2,c)
    line([(x-rx*.5,y-ry*.2),(x,y-ry*.75),(x+rx*.35,y-ry*.35)],tuple(min(255,v+20) for v in c),1)
# Alpine grass and tiny flowers, randomized only in clear hillside pockets.
rng=random.Random(1662)
for _ in range(95):
    x=rng.uniform(24,1250); y=rng.uniform(295,630)
    # Keep the foreground road and all switchback shoulders clear.
    if 455 <= y <= 565: continue
    nearest=min(math.hypot(x-px,y-py) for px,py,_ in path)
    if nearest < 86: continue
    if any(abs(x-tx)<35 and abs(y-ty)<36 for tx,ty,*_ in [(76,443),(160,365),(270,332),(928,292),(1040,354),(1172,431)]): continue
    h=rng.uniform(5,12)
    line([(x,y),(x-rng.uniform(1,4),y-h)],(93,130,86),1)
    if rng.random()<.22: circle(x+2,y-h,1.5,(213,190,125))

# --- Foreground connector trail to Plains; the climb joins behind it ---
poly([(0,463),(175,461),(360,463),(520,466),(640,469),(790,473),(975,480),(1120,486),(1280,491),
      (1280,568),(1112,560),(950,553),(775,548),(620,543),(428,544),(245,547),(0,552)],(76,77,68))
poly([(0,469),(174,467),(354,468),(520,471),(640,474),(790,478),(975,485),(1120,491),(1280,496),
      (1280,558),(1115,552),(950,546),(775,541),(620,537),(430,538),(245,541),(0,546)],(164,151,126))
line([(0,470),(174,468),(354,469),(520,472),(640,475),(790,479),(975,486),(1120,492),(1280,497)],(212,194,160),3)
line([(0,546),(245,541),(430,538),(620,537),(775,541),(950,546),(1115,552),(1280,558)],(111,98,78),3)
# Foreground road wear and small edge stones.
for i in range(42):
    x=rng.uniform(18,1260); y=rng.uniform(488,530)
    line([(x,y),(x+rng.uniform(8,24),y+rng.uniform(-2,2))],(153,137,111),1)
for x,y in [(86,469),(312,468),(470,470),(860,480),(1088,490),(1225,496)]:
    ellipse(x-7,y-2,14,5,(127,119,101))

# The Peak approach is the visible continuation; transition markers are still
# rendered from world.connections, not baked into this background.

DATA['assets']['c1_bg_mountain_path']={
    'width':1280,'height':640,'commands':C,
    'description':'Mountain Path: a broad stone trail cut into the mountain through supported, rounded switchbacks. The climb joins the foreground Plains road and reaches the Peak exit.'
}

# Ground navigation mirrors the visible route. Keep the existing Plains cross-trail
# walkable region; replace only the former oversized zig-zag corridor.
area=next(a for a in DATA['world']['areas'] if a['area_id']=='mountain_path')
def nav_points(start, end):
    return [[round(x,2), round(y,2)] for x,y,_ in path[start:end+1]]
area['navigation']={
    'regions':[[[20,460],[1260,460],[1260,573],[20,573]]],
    'corridors':[
        [nav_points(0,45), 38],
        [nav_points(45,95), 34],
        [nav_points(95,125), 30],
        [nav_points(125,len(path)-1), 26]
    ]
}

DATA['version']='F1Clean2'
DATA['art_revision']='F1Clean2 — Mountain Path rebuilt as supported storybook switchbacks; Plains/Peak exits retained.'
DATA.setdefault('notes',[])
if isinstance(DATA['notes'],list):
    DATA['notes']=[n for n in DATA['notes'] if not (isinstance(n,str) and 'Mountain Path' in n)]
    DATA['notes'].append('F1Clean2: rebuilt only c1_bg_mountain_path and its matching navigation corridor; kept the foreground Plains route and both existing transitions.')
ASSET_FILE.write_text(json.dumps(DATA,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(f'Wrote {len(C)} Luma Draw Engine commands; {len(path)} trail samples; corridors 38/34/30/26.')
