SPIFFY'S GIFT — SGGF1Clean2

BASELINE
Built from the exact SGGF1.666Cleanup1.0 source ZIP and complete Cloudflare site ZIP in magiccozmo/QuackSink main. Both original ZIPs were verified and matched their GitHub blob hashes after retrieval.

THIS RELEASE
The Mountain Path background asset (c1_bg_mountain_path) is redesigned as a narrower, perspective-tapered mountain footpath with broad, readable switchbacks. The trail is drawn through the Luma Draw Engine JSON; it is not a flattened replacement image. Its navigation corridors were rebuilt to follow the visible trail at matching widths.

The foreground Plains connector is retained. The Plains and Peak transitions, their connection definitions, player start, save compatibility/migration, Hellgs Inn challenge, inventory, quests, NPCs, dialogue, and all other areas are preserved. This release does not change the default start: the F1.666 line continues to begin in Hellgs Inn until SGGF1.666Final is complete.

DEPLOY HISTORY
The curated deployment carries forward all eight playable milestone editions from SGGF1.666Cleanup1.0: SGGE2.0, SGGE3.1, SGGE3.2, SGGF1.0, SGGF1.6, SGGF1.666, SGGF1.666f1s and SGGF1.666Cleanup1.0. It adds SGGF1Clean2 as the ninth choice. This preserves the special/archive versions Cozmo expects at the front door while keeping the many ordinary intermediate test releases out of the deployment.

TESTING
- Exact baseline source/deploy archive identity verified against the current GitHub main tree.
- Original baseline ZIP integrity verified before extraction.
- Python source compiled; Luma JSON parsed.
- Only c1_bg_mountain_path, mountain_path navigation, release version metadata/label changed.
- World connection table, all non-Mountain Path area definitions, and other world-level fields compared unchanged against the baseline.
- Navigation corridor continuity and art/walkmesh width correspondence checked.
- Runtime APK/TAR archive integrity and byte-for-byte payloads checked.
- Deployment catalogue checked for SGGF1Clean2 plus the eight curated Cleanup1.0 milestone editions. Every prior selected milestone directory was verified byte-for-byte unchanged.

LIMITATION
A live browser launch, player movement session, and in-game save/load regression test were not possible in this build environment. Cozmo should field-test the delivered build before treating it as the next live baseline.
