"""Static regression checks for SGGF1Clean2.6 Peak walkmesh."""
from pathlib import Path
import ast, hashlib, json, math, re, tarfile, zipfile

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parent
DEPLOY = PROJECT / 'deploy'
EXPECTED = [
    'SGGF1Clean2.6', 'SGGF1Clean2.5', 'SGGF1Clean2.4', 'SGGF1Clean2.2',
    'SGGF1.666Cleanup1.0', 'SGGF1.666f1s', 'SGGF1.666', 'SGGF1.6',
    'SGGF1.0', 'SGGE3.2', 'SGGE3.1', 'SGGE2.0'
]
PLATFORM = [[420,438],[490,419],[560,407],[640,402],[720,407],[791,420],[860,446],
            [842,416],[790,397],[720,386],[640,380],[560,386],[490,397],[442,416]]
TRAIL = [[640,620],[638,579],[633,548],[630,520],[633,493],[639,470],[640,445],[640,402]]

def segdist(x,y,a,b):
    ax,ay=a; bx,by=b; dx=bx-ax; dy=by-ay
    t=max(0.0,min(1.0,((x-ax)*dx+(y-ay)*dy)/max(0.01,dx*dx+dy*dy)))
    return math.hypot(x-ax-dx*t,y-ay-dy*t)

def inside(x,y,p):
    c=False
    for i,(xi,yi) in enumerate(p):
        xj,yj=p[i-1]
        if ((yi>y)!=(yj>y)) and x < (xj-xi)*(y-yi)/(yj-yi+1e-15)+xi: c=not c
    return c

def polygon_distance(x,y,p):
    if inside(x,y,p): return 0.0
    return min(segdist(x,y,a,b) for a,b in zip(p,p[1:]+p[:1]))

def nav_error(x_body,y_body,spec):
    x,y=x_body,y_body+14.0
    errors=[polygon_distance(x,y,p) for p in spec.get('regions',[])]
    for polyline,width in spec.get('corridors',[]):
        closest=min(segdist(x,y,a,b) for a,b in zip(polyline,polyline[1:]))
        errors.append(max(0.0,closest-width/2+9))
    return min(errors) if errors else 0.0

def main():
    source=(HERE/'main.py').read_text(encoding='utf-8'); ast.parse(source)
    assert 'VERSION = "F1Clean2.6"' in source
    luma=json.loads((HERE/'luma_assets_e33.json').read_text(encoding='utf-8'))
    assert luma['version']=='F1Clean2.6'
    areas=luma['world']['areas']; peak=next(a for a in areas if a['area_id']=='peak')
    spec=peak['navigation']
    assert spec=={'regions':[PLATFORM],'corridors':[[TRAIL,42]]}
    assert len(spec['regions'])==1 and len(spec['corridors'])==1
    # Existing arrival and bottom-exit foot anchors are both walkable.
    assert nav_error(640,507,spec)<=1.0, ('Mountain Path arrival blocked',nav_error(640,507,spec))
    assert nav_error(640,600,spec)<=1.0, ('bottom exit approach blocked',nav_error(640,600,spec))
    # The trail and the full central Scenic Overlook deck remain walkable.
    for x,y in [(640,606),(638,565),(633,534),(630,506),(633,479),(639,456),(640,431),
                (440,405),(500,396),(560,383),(640,376),(720,382),(790,393),(842,402)]:
        assert nav_error(x,y,spec)<=1.0, ('walkable approach/deck point blocked',(x,y),nav_error(x,y,spec))
    # Representative sky, ridge, valley, cliff, and off-platform positions are blocked.
    for x,y in [(640,120),(640,250),(930,300),(300,390),(1000,390),(250,520),(1030,520),(760,540),(900,445)]:
        assert nav_error(x,y,spec)>1.0, ('scenery unexpectedly walkable',(x,y),nav_error(x,y,spec))
    versions=json.loads((DEPLOY/'versions.json').read_text(encoding='utf-8'))['versions']
    assert [v['version'] for v in versions]==EXPECTED
    assert [v['version'] for v in versions if v.get('current')]==['SGGF1Clean2.6']
    pattern=re.compile(r'^SGG[A-Z]\d+(?:\.\d+)*(?:[a-z][a-z0-9]*)?(?:\.\d+)*$',re.I)
    path_pattern=re.compile(r'^SGG[A-Z]\d+(?:\.\d+)*(?:[a-z][a-z0-9]*)?(?:\.\d+)*\/(?:play|index)\.html$',re.I)
    for v in versions:
        assert pattern.fullmatch(v['version']) and path_pattern.fullmatch(v['path'])
        assert (DEPLOY/v['path']).is_file()
        if v.get('image'): assert (DEPLOY/v['image']).is_file()
    assert (DEPLOY/'SGGF1Clean2.6'/'play.html').is_file()
    # All non-Peak world content and all other Luma recipes must be identical to Clean2.5.
    old=json.loads((PROJECT/'SGGF1Clean2.5'/'luma_assets_e33.json').read_text(encoding='utf-8'))
    new_world=json.loads(json.dumps(luma['world']))
    old_world=json.loads(json.dumps(old['world']))
    old_peak=next(a for a in old_world['areas'] if a['area_id']=='peak')
    new_peak=next(a for a in new_world['areas'] if a['area_id']=='peak')
    old_peak.pop('navigation',None); new_peak.pop('navigation',None)
    assert new_world==old_world
    assert luma['assets']==old['assets']
    # Only Peak navigation in the deployment source changed; all historical folders are kept.
    retained=['SGGF1Clean2.5','SGGF1Clean2.4','SGGF1Clean2.2','SGGF1.666Cleanup1.0','SGGF1.666f1s','SGGF1.666','SGGF1.6','SGGF1.0','SGGE3.2','SGGE3.1','SGGE2.0']
    for name in retained:
        assert (DEPLOY/name).is_dir() and (PROJECT/'deploy'/name).is_dir()
    # Runtime APK/TAR payloads are byte-identical to active source files.
    with zipfile.ZipFile(HERE/'sggf1clean2_6.apk') as z:
        assert z.read('assets/main.py')==(HERE/'main.py').read_bytes()
        assert z.read('assets/luma_assets_e33.json')==(HERE/'luma_assets_e33.json').read_bytes()
    with tarfile.open(HERE/'sggf1clean2_6.tar.gz','r:gz') as t:
        assert t.extractfile('assets/main.py').read()==(HERE/'main.py').read_bytes()
        assert t.extractfile('assets/luma_assets_e33.json').read()==(HERE/'luma_assets_e33.json').read_bytes()
    # Runtime files in the active deploy folder must match the active source exactly.
    for name in ('main.py','luma_assets_e33.json'):
        assert (DEPLOY/'SGGF1Clean2.6'/name).read_bytes()==(HERE/name).read_bytes()
    print('PASS: Python syntax and F1Clean2.6/Luma release identity')
    print('PASS: Peak has one platform polygon and one narrow corridor only')
    print('PASS: Mountain Path arrival and bottom exit remain walkable')
    print('PASS: approach and Scenic Overlook deck samples remain walkable')
    print('PASS: representative sky, ridge, valley, cliff and off-platform samples are blocked')
    print('PASS: non-Peak world data and all Luma Draw Engine recipes are unchanged')
    print('PASS: exact twelve-entry catalogue, one current release, paths and preview references')
    print('PASS: historical deployment folders remain present')
    print('PASS: runtime APK and TAR contain source byte-for-byte')
    print('PASS: current deployment runtime matches source')
if __name__=='__main__': main()
