"""Static release checks for SGGF1Clean2.5's curated archive packaging."""
from pathlib import Path
import json, re, ast, zipfile, tarfile

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parent
DEPLOY = PROJECT / 'deploy'
EXPECTED = [
    'SGGF1Clean2.5', 'SGGF1Clean2.4', 'SGGF1Clean2.2',
    'SGGF1.666Cleanup1.0', 'SGGF1.666f1s', 'SGGF1.666',
    'SGGF1.6', 'SGGF1.0', 'SGGE3.2', 'SGGE3.1', 'SGGE2.0'
]

def main():
    source = (HERE / 'main.py').read_text(encoding='utf-8')
    ast.parse(source)
    assert 'VERSION = "F1Clean2.5"' in source
    luma = json.loads((HERE / 'luma_assets_e33.json').read_text(encoding='utf-8'))
    assert luma['version'] == 'F1Clean2.5'
    versions = json.loads((DEPLOY / 'versions.json').read_text(encoding='utf-8'))['versions']
    assert [x['version'] for x in versions] == EXPECTED
    assert [x['version'] for x in versions if x.get('current')] == ['SGGF1Clean2.5']
    pattern = re.compile(r'^SGG[A-Z]\d+(?:\.\d+)*(?:[a-z][a-z0-9]*)?(?:\.\d+)*$', re.I)
    path_pattern = re.compile(r'^SGG[A-Z]\d+(?:\.\d+)*(?:[a-z][a-z0-9]*)?(?:\.\d+)*\/(?:play|index)\.html$', re.I)
    for entry in versions:
        assert pattern.fullmatch(entry['version'])
        assert path_pattern.fullmatch(entry['path'])
        assert (DEPLOY / entry['path']).is_file()
        if entry.get('image'):
            assert (DEPLOY / entry['image']).is_file()
    for name in ('SGGF1Clean2', 'SGGF1Clean2.1', 'SGGF1Clean2.3'):
        assert not (DEPLOY / name).exists()
        assert not (PROJECT / name).exists()
    assert (DEPLOY / 'SGGF1Clean2.5' / 'play.html').is_file()
    # The runtime bundles must carry the exact source code and asset data.
    with zipfile.ZipFile(HERE / 'sggf1clean2_5.apk') as z:
        assert z.read('assets/main.py') == (HERE / 'main.py').read_bytes()
        assert z.read('assets/luma_assets_e33.json') == (HERE / 'luma_assets_e33.json').read_bytes()
    with tarfile.open(HERE / 'sggf1clean2_5.tar.gz', 'r:gz') as t:
        assert t.extractfile('assets/main.py').read() == (HERE / 'main.py').read_bytes()
        assert t.extractfile('assets/luma_assets_e33.json').read() == (HERE / 'luma_assets_e33.json').read_bytes()
    page = (DEPLOY / 'versions.html').read_text(encoding='utf-8')
    assert pattern.pattern in page
    print('PASS: Clean2.5 source parses and metadata identifies F1Clean2.5')
    print('PASS: exact eleven-entry curated catalogue and sole current flag')
    print('PASS: front-door version and launch-path validators accept every retained ID')
    print('PASS: every launch path and optional preview image resolves')
    print('PASS: three intermediate Clean2 test folders are absent')
    print('PASS: APK and TAR embed main.py and Luma JSON byte-for-byte')

if __name__ == '__main__':
    main()
