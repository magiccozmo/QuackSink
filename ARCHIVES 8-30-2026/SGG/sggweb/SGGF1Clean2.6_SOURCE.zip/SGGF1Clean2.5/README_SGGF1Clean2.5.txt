SPIFFY'S GIFT — SGGF1Clean2.5

CURRENT RELEASE: SGGF1Clean2.5
BASE: Exact SGGF1Clean2.4 source and complete Cloudflare deployment.
RELEASE TYPE: Curated package/archive consolidation only. No gameplay or artwork revision.

CURATED PLAYABLE ARCHIVE
This release keeps the seven established legacy milestones (SGGE2.0, SGGE3.1, SGGE3.2, SGGF1.0, SGGF1.6, SGGF1.666 and SGGF1.666f1s), plus SGGF1.666Cleanup1.0, SGGF1Clean2.2, SGGF1Clean2.4 and this new current SGGF1Clean2.5.

The intermediate SGGF1Clean2, SGGF1Clean2.1 and SGGF1Clean2.3 test releases are no longer bundled in this compact package. Their original repository and release archives are not deleted or overwritten.

GAME PRESERVATION
SGGF1Clean2.5 inherits the Clean2.4 runtime unchanged apart from the release-version marker. Its save-compatible Mountainside cave-door name/kind normalization and FROSTY'S CAVE ENTRANCE hover label remain. All world areas, objects, connections, walkmeshes, artwork recipes, dialogue, inventory, gameplay, transitions, saves and the Luma Draw Engine are unchanged.

TEST STATUS
This is a packaging-only release. Static checks verify the 11-entry front-door catalogue, all launch and preview paths, retained milestone directories, absence of the three pruned test editions from both bundled trees, source/deployment mirror parity, runtime APK/TAR payload identity, JSON structure, Python syntax and ZIP integrity. No live Pygame/browser or Cloudflare session was run by Luma; Cozmo should field-test the release after publishing it.
