import ast, copy, json, math, tarfile, zipfile
from pathlib import Path
BASE = Path(__file__).resolve().parent
old = json.loads((BASE/"BASELINES"/"F1r_luma_assets_e33.json").read_text(encoding="utf-8"))
new = json.loads((BASE/"luma_assets_e33.json").read_text(encoding="utf-8"))
assert new["version"] == "F1.666f1s"
assert old["assets"] == new["assets"], "No art recipe may change."
expected = copy.deepcopy(old)
expected["version"] = new["version"]
expected["art_revision"] = new["art_revision"]
expected["notes"] = new["notes"]
old_npcs = {n["npc_id"]: n for n in expected["world"]["npcs"]}
new_npcs = {n["npc_id"]: n for n in new["world"]["npcs"]}
old_npcs["troll"]["x"], old_npcs["troll"]["y"] = 160, 393
old_objs = {o["object_id"]: o for o in expected["world"]["objects"]}
new_objs = {o["object_id"]: o for o in new["world"]["objects"]}
old_objs["purple_passion_pineapple"]["x"], old_objs["purple_passion_pineapple"]["y"] = 245, 370
assert expected == new, "Only version/release notes and the two requested object positions may change."
assert old_npcs["troll"]["width"] == new_npcs["troll"]["width"] and old_npcs["troll"]["height"] == new_npcs["troll"]["height"]
assert old_objs["purple_passion_pineapple"]["kind"] == new_objs["purple_passion_pineapple"]["kind"]
assert old_objs["purple_passion_pineapple"]["width"] == new_objs["purple_passion_pineapple"]["width"]
assert old_objs["purple_passion_pineapple"]["height"] == new_objs["purple_passion_pineapple"]["height"]
old_areas={a["area_id"]:a for a in old["world"]["areas"]}; new_areas={a["area_id"]:a for a in new["world"]["areas"]}
assert old_areas["troll_cave"]["navigation"] == new_areas["troll_cave"]["navigation"], "Walkmesh must remain unchanged."
poly=new_areas["troll_cave"]["navigation"]["regions"][0]
def inside(x,y,p):
    result=False; j=len(p)-1
    for i,(xi,yi) in enumerate(p):
        xj,yj=p[j]
        if ((yi>y)!=(yj>y)) and x < (xj-xi)*(y-yi)/(yj-yi)+xi: result=not result
        j=i
    return result
# Frosty's ground anchor and pineapple's interaction center stay on the same walkable floor.
assert inside(160,393,poly)
assert inside(245+42/2,370+62/2,poly)
# Frosty sprite's right edge leaves a small visible gap before the Pineapple.
assert 0 < (245 - (160+109/2)) <= 40
# The large right side remains available as the chase/kiting lane.
assert 1280 - (245+42) >= 900
main=(BASE/"main.py").read_text(encoding="utf-8"); ast.parse(main)
assert 'VERSION = "F1.666f1s"' in main
assert 'class F1666f1sStateMachine(F1666f1rStateMachine)' in main
assert 'class F1666f1sInterface(F1666f1rInterface)' in main
assert 'machine = F1666f1sStateMachine(archive, config, warning)' in main
assert 'ui = F1666f1sInterface(machine)' in main
assert all(s in main for s in ('(560.0, 180.0)','(560.0, 393.0)','(638.0, 146.0)','(638.0, 370.0)','(160.0, 393.0)','(245.0, 370.0)'))
assert 'not g.c1_troll_angry' in main and 'not fruit.in_inventory and not fruit.moved' in main
assert 'F1s SAVE MIGRATION' in main
# Site catalogue: only F1s current; F1r remains available as the immediate prior version.
site=BASE/"deploy"; catalog=json.loads((site/"versions.json").read_text(encoding="utf-8"))
assert catalog["versions"][0]["version"] == "SGGF1.666f1s" and catalog["versions"][0]["current"] is True
assert sum(bool(x.get("current")) for x in catalog["versions"]) == 1
assert next(x for x in catalog["versions"] if x["version"]=="SGGF1.666f1r")["current"] is False
newdir=site/"SGGF1.666f1s"
assert (newdir/"main.py").read_bytes() == main.encode()
assert (newdir/"luma_assets_e33.json").read_bytes() == (BASE/"luma_assets_e33.json").read_bytes()
play=(newdir/"play.html").read_text(encoding="utf-8")
assert "sggf1666f1s.tar.gz" in play and "sggf1666f1s.apk" in play and "F1.666f1s" in play
for html_name in ("index.html","versions.html"):
    html=(site/html_name).read_text(encoding="utf-8")
    assert "GALLERY_IMAGES" in html
with zipfile.ZipFile(newdir/"sggf1666f1s.apk") as z:
    assert z.testzip() is None and set(z.namelist())=={"assets/main.py","assets/luma_assets_e33.json"}
    assert z.read("assets/main.py")==main.encode()
    assert z.read("assets/luma_assets_e33.json")== (BASE/"luma_assets_e33.json").read_bytes()
with tarfile.open(newdir/"sggf1666f1s.tar.gz","r:gz") as t:
    assert set(t.getnames())=={"assets/main.py","assets/luma_assets_e33.json"}
    assert t.extractfile("assets/main.py").read()==main.encode()
    assert t.extractfile("assets/luma_assets_e33.json").read()==(BASE/"luma_assets_e33.json").read_bytes()
# Historical releases must still exist, including the original F1r and its F1q predecessor.
for v in ("SGGF1.666f1q","SGGF1.666f1r"):
    assert (site/v).is_dir(), f"Missing historical release {v}"
for old_dir in (site/"SGGF1.666f1q", site/"SGGF1.666f1r"):
    assert any(old_dir.iterdir())
print("F1s: exact F1r-to-F1s data diff, art preservation, cave walkmesh, left placement, open-right kiting lane, save migration guards, Python syntax, browser loader, APK/TAR contents and historical release checks passed.")
