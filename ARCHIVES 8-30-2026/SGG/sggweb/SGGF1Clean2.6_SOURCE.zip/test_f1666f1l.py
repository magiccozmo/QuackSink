from __future__ import annotations
import ast,copy,json,zipfile,tarfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
V="SGGF1.666f1l"; P="sggf1666f1l"
cur=json.loads((ROOT/"luma_assets_e33.json").read_text(encoding="utf-8"))
base=json.loads((ROOT/"SGGF1.666f1k"/"assets"/"luma_assets_e33.json").read_text(encoding="utf-8"))
assert cur["version"]==V
ba={a['area_id']:a for a in base['world']['areas']}; ca={a['area_id']:a for a in cur['world']['areas']}
assert set(ba)==set(ca)
for k in ba:
    if k!='southern_wilds': assert ca[k]==ba[k],k
# Preserve all connections except the reverse entrance's new grounded arrival.
old={c['connection_id']:c for c in base['world']['connections']}
new={c['connection_id']:c for c in cur['world']['connections']}
assert set(old)==set(new)
for k in old:
    if k!='plains_bottom_southern_wilds': assert new[k]==old[k],k
assert new['plains_bottom_southern_wilds']['from_area_id']=='plains'
assert new['plains_bottom_southern_wilds']['to_area_id']=='southern_wilds'
assert new['plains_bottom_southern_wilds']['arrival_x']==640
assert new['plains_bottom_southern_wilds']['arrival_y']==360
assert new['southern_wilds_top_plains']['arrival_y']==520
assert new['southern_wilds_bottom_side_of_mountain']==old['southern_wilds_bottom_side_of_mountain']
assert cur['world']['objects']==base['world']['objects']
# Exactly one broad meadow polygon; no walkable sky corridor.
area=ca['southern_wilds']; nav=area['navigation']['regions']
assert nav==[[[20,310],[1260,310],[1260,640],[20,640]]]
def inside(x,y,p):
    yes=False; lx,ly=p[-1]
    for px,py in p:
        if ((py>y)!=(ly>y)) and x < px+(lx-px)*(y-py)/(ly-py): yes=not yes
        lx,ly=px,py
    return yes
allowed=lambda x,player_y: inside(x,player_y+14,nav[0])
# Sky is blocked, horizon/entry and both road/meadow depths are walkable.
assert not allowed(640,275)
assert allowed(640,300)
assert allowed(640,346)  # grounded arrival from Plains at y=360 (player center 360)
assert allowed(720,440)
assert allowed(640,560)
assert allowed(640,615)
# Art-only modification: all assets except Southern Wilds art are byte-structure identical.
for k,v in base['assets'].items():
    if k!='c1_bg_southern_wilds': assert cur['assets'][k]==v,k
commands=cur['assets']['c1_bg_southern_wilds']['commands']
assert len(commands)>500
# The trail's drawing commands begin at the land boundary and never reach the sky.
road_polys=[c for c in commands if c.get('op')=='polygon' and c.get('color') in ([57,87,61],[92,79,60],[137,117,89],[151,132,103],[160,142,112])]
assert len(road_polys)==5
for c in road_polys:
    ys=[p[1] for p in c['points']]
    assert min(ys)>=300
# Main parses and carries the custom horizon trigger plus horizon-level arrow.
main=(ROOT/'main.py').read_text(encoding='utf-8'); ast.parse(main)
assert 'VERSION = "F1.666f1l"' in main
assert 'class F1666f1lStateMachine(F1666f1StateMachine):' in main
assert 'machine = F1666f1lStateMachine(archive, config, warning)' in main
assert 'ui = F1666f1lInterface(machine)' in main
assert 'previous_y > 310 >= g.player_y' in main
assert "conn.connection_id == 'southern_wilds_top_plains'" in main
# Previous releases and browser packages remain in source; f1l folder matches root.
assert (ROOT/'SGGF1.666f1k'/'play.html').is_file()
v=ROOT/V
assert (v/'play.html').is_file()
assert (v/'assets'/'main.py').read_bytes()==(ROOT/'main.py').read_bytes()
assert (v/'assets'/'luma_assets_e33.json').read_bytes()==(ROOT/'luma_assets_e33.json').read_bytes()
with zipfile.ZipFile(v/(P+'.apk')) as z:
    assert z.testzip() is None and set(z.namelist())=={'assets/main.py','assets/luma_assets_e33.json'}
with tarfile.open(v/(P+'.tar.gz'),'r:gz') as t:
    assert set(t.getnames())=={'assets/main.py','assets/luma_assets_e33.json'}
manifest=json.loads((ROOT/'deploy'/'versions.json').read_text(encoding='utf-8'))['versions']
assert len(manifest)==54 and manifest[0]['version']==V and sum(bool(x.get('current')) for x in manifest)==1
