from __future__ import annotations
import ast,copy,json,zipfile,tarfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
V="SGGF1.666f1k"; P="sggf1666f1k"
cur=json.loads((ROOT/"luma_assets_e33.json").read_text(encoding="utf-8"))
base=json.loads((ROOT/"SGGF1.666f1j"/"assets"/"luma_assets_e33.json").read_text(encoding="utf-8"))
assert cur["version"]==V
ba={a['area_id']:a for a in base['world']['areas']}; ca={a['area_id']:a for a in cur['world']['areas']}
assert set(ba)==set(ca)
for k in ba:
    if k!='southern_wilds': assert ca[k]==ba[k],k
# Both Wilds connections remain byte-identical, including their exit side,
# arrival coordinates, IDs and labels.
assert cur['world']['connections']==base['world']['connections']
assert cur['world']['objects']==base['world']['objects']
# The broad walkable meadow is unchanged in width/top and extended to the
# actual bottom boundary; upper polygon is a tapered trail, not a rectangle.
area=ca['southern_wilds']; nav=area['navigation']['regions']
assert nav[0]==[[20,310],[1260,310],[1260,640],[20,640]]
assert len(nav)==2 and len(nav[1])>=20
xs=[p[0] for p in nav[1]]; ys=[p[1] for p in nav[1]]
assert min(ys)==44 and 310<max(ys)<360 and min(xs)<640<max(xs)
# Point-in-polygon check uses the engine's player foot anchor (player_y + 14).
def inside(x,y,p):
    yes=False; lx,ly=p[-1]
    for px,py in p:
        if ((py>y)!=(ly>y)) and x < px+(lx-px)*(y-py)/(ly-py): yes=not yes
        lx,ly=px,py
    return yes
def allowed(x,player_y):
    foot=player_y+14
    return any(inside(x,foot,p) for p in nav)
# Incoming arrivals from Plains and Side of Mountain, and the top-edge approach.
assert allowed(640,110)
assert allowed(640,31)
# The road is walkable through the saddle, with off-trail sky blocked.
assert allowed(680,180)
assert allowed(670,280)
assert not allowed(500,180)
assert not allowed(800,180)
# On the meadow the player can cross the whole scene and reach bottom trigger.
assert allowed(640,520)
assert allowed(640,615)
# Art changed only the Wilds recipe; everything else is identical.
for k,v in base['assets'].items():
    if k!='c1_bg_southern_wilds': assert cur['assets'][k]==v,k
assert cur['assets']['c1_bg_southern_wilds']['width']==1280
assert cur['assets']['c1_bg_southern_wilds']['height']==640
assert len(cur['assets']['c1_bg_southern_wilds']['commands'])>500
# The engine uses the same top and bottom edge trigger logic as f1j.
main=(ROOT/'main.py').read_text(encoding='utf-8'); ast.parse(main)
assert 'VERSION = "F1.666f1k"' in main
assert 'class F1666f1kInterface(F1666f1jInterface):' in main
assert 'ui = F1666f1kInterface(machine)' in main
assert 'game.player_y <= 31' in main and 'game.player_y >= GAME_HEIGHT - 25' in main
# Earlier versions remain available and unmodified; package mirrors root code/assets.
assert (ROOT/'SGGF1.666f1j'/'play.html').is_file()
v=ROOT/V
assert (v/'play.html').is_file()
assert (v/'assets'/'main.py').read_bytes()==(ROOT/'main.py').read_bytes()
assert (v/'assets'/'luma_assets_e33.json').read_bytes()==(ROOT/'luma_assets_e33.json').read_bytes()
with zipfile.ZipFile(v/(P+'.apk')) as z:
    assert z.testzip() is None and set(z.namelist())=={'assets/main.py','assets/luma_assets_e33.json'}
with tarfile.open(v/(P+'.tar.gz'),'r:gz') as t:
    assert set(t.getnames())=={'assets/main.py','assets/luma_assets_e33.json'}
manifest=json.loads((ROOT/'deploy'/'versions.json').read_text(encoding='utf-8'))['versions']
assert len(manifest)==53 and manifest[0]['version']==V and sum(bool(x.get('current')) for x in manifest)==1
