SPIFFY'S GIFT — CLEAN DEPLOYMENT

CURRENT VERSION: SGGF1Clean2.6

This complete Cloudflare site retains twelve deliberately selected playable editions:
- SGGF1Clean2.6 — Peak walkmesh now follows only the winding summit approach and Scenic Overlook deck.
- SGGF1Clean2.5 — curated milestone archive.
- SGGF1Clean2.4 — Frosty's Cave Entrance save/hover correction.
- SGGF1Clean2.2 — Scenic Overlook summit experience.
- SGGF1.666Cleanup1.0 — curated F1 milestone consolidation.
- SGGF1.666f1s, SGGF1.666, SGGF1.6, SGGF1.0, SGGE3.2, SGGE3.1 and SGGE2.0 — preserved legacy milestones.

Intermediate SGGF1Clean2, SGGF1Clean2.1 and SGGF1Clean2.3 test releases are omitted from this compact bundle. Their original historical archives are not deleted or overwritten.

Only the Peak navigation mesh changed in the game world: one corridor follows the visible approach and connects to one deck-shaped walkable region. The Peak artwork, panorama, objects, arrival and exit connections, and every other area's data remain unchanged. Existing saves remain compatible; players saved outside the new Peak walkable surface are moved by the existing safe-spawn handling to the nearest valid walkable point when loaded.
