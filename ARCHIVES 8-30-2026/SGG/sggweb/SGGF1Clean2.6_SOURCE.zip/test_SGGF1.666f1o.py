import json, ast
from pathlib import Path
BASE=Path(__file__).resolve().parent
OLD=json.loads((BASE/"SGGF1.666f1n/assets/luma_assets_e33.json").read_text())
NEW=json.loads((BASE/"SGGF1.666f1o/assets/luma_assets_e33.json").read_text())
C={x["connection_id"]:x for x in NEW["world"]["connections"]}
B={x["connection_id"]:x for x in OLD["world"]["connections"]}
assert C["southern_wilds_bottom_side_of_mountain"]["edge"]=="right"
assert C["southern_wilds_bottom_side_of_mountain"]["arrival_x"]==B["southern_wilds_bottom_side_of_mountain"]["arrival_x"]==65
assert C["southern_wilds_bottom_side_of_mountain"]["arrival_y"]==B["southern_wilds_bottom_side_of_mountain"]["arrival_y"]==500
assert C["side_of_mountain_top_southern_wilds"]["edge"]=="left"
assert [C["side_of_mountain_top_southern_wilds"]["arrival_x"],C["side_of_mountain_top_southern_wilds"]["arrival_y"]]==[1215,552]
assert C["southern_wilds_top_plains"]==B["southern_wilds_top_plains"]
# Exactly two intended connection-field edits; every other connection is preserved.
for key in B:
    if key=="southern_wilds_bottom_side_of_mountain":
        expected=dict(B[key]); expected["edge"]="right"
        assert C[key]==expected
    elif key=="side_of_mountain_top_southern_wilds":
        expected=dict(B[key]); expected["arrival_x"]=1215; expected["arrival_y"]=552
        assert C[key]==expected
    else:
        assert C[key]==B[key], key
# No area, NPC, object, player, save or navigation state changed.
for key in OLD["world"]:
    if key!="connections": assert NEW["world"][key]==OLD["world"][key], key
# All assets except the Southern Wilds background recipe remain identical.
for key in OLD["assets"]:
    if key!="c1_bg_southern_wilds": assert NEW["assets"][key]==OLD["assets"][key], key
oldbg=OLD["assets"]["c1_bg_southern_wilds"]
newbg=NEW["assets"]["c1_bg_southern_wilds"]
for key in oldbg:
    if key!="commands": assert newbg[key]==oldbg[key], key
oldcmd=oldbg["commands"]
newcmd=newbg["commands"]
assert newcmd[:230]==oldcmd[:230]
assert len(newcmd[230:230+23])==23
assert newcmd[230+23:]==oldcmd[273:]
# The path begins at the Plains horizon, descends, then travels substantially right.
road_edge=newcmd[230+9]["points"]
assert road_edge[0][1] < road_edge[len(road_edge)//2][1]
assert road_edge[-1][0] > road_edge[len(road_edge)//2][0] + 400
assert max(p[0] for c in newcmd[230:253] if c["op"] in ("polygon","line") for p in c["points"]) >= 1270
assert all(x["op"] in {"rect","line","polygon","circle","ellipse"} for x in newcmd)
main=(BASE/"SGGF1.666f1o/assets/main.py").read_text()
ast.parse(main)
assert 'VERSION = "F1.666f1o"' in main
assert "F1666f1oStateMachine" in main and "F1666f1oInterface" in main
play=(BASE/"SGGF1.666f1o/play.html").read_text()
assert "sggf1666f1o.tar.gz" in play and "sggf1666f1o.apk" in play
print("SGGF1.666f1o transition, preservation, Luma and Python checks passed")
