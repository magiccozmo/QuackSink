#!/usr/bin/env bash
set -euo pipefail
ROOT=$(cd "$(dirname "$0")" && pwd)
DEPLOY=${1:?Pass the extracted Cloudflare deploy directory as argument 1}
NEW='SGGF1.666Cleanup1.0'
BUNDLE='sggf1666cleanup10'

grep -Fq 'VERSION = "F1.666Cleanup1.0"' "$ROOT/main.py"
jq -e '.version == "F1.666Cleanup1.0"' "$ROOT/luma_assets_e33.json" >/dev/null
jq -e '.versions[0].version == "SGGF1.666Cleanup1.0" and .versions[0].current == true and ([.versions[] | select(.current == true)] | length) == 1' "$DEPLOY/versions.json" >/dev/null
for v in SGGE2.0 SGGE3.1 SGGE3.2 SGGF1.0 SGGF1.6 SGGF1.666 SGGF1.666f1s "$NEW"; do test -d "$DEPLOY/$v"; done
jq -e '[.versions[].version] == ["SGGF1.666Cleanup1.0","SGGF1.666f1s","SGGF1.666","SGGF1.6","SGGF1.0","SGGE3.2","SGGE3.1","SGGE2.0"]' "$DEPLOY/versions.json" >/dev/null
PLAY="$DEPLOY/$NEW/play.html"
grep -Fq "$BUNDLE.tar.gz" "$PLAY"
grep -Fq "$BUNDLE.apk" "$PLAY"
grep -Fq 'F1.666Cleanup1.0' "$PLAY"
for f in "$DEPLOY/$NEW/$BUNDLE.apk" "$DEPLOY/$NEW/$BUNDLE.tar.gz"; do test -s "$f"; done
unzip -tq "$DEPLOY/$NEW/$BUNDLE.apk"
tar -tzf "$DEPLOY/$NEW/$BUNDLE.tar.gz" > "$ROOT/.cleanup_tar_listing.tmp"
grep -Fxq assets/main.py "$ROOT/.cleanup_tar_listing.tmp"
grep -Fxq assets/luma_assets_e33.json "$ROOT/.cleanup_tar_listing.tmp"
unzip -p "$DEPLOY/$NEW/$BUNDLE.apk" assets/main.py | cmp - "$ROOT/main.py"
unzip -p "$DEPLOY/$NEW/$BUNDLE.apk" assets/luma_assets_e33.json | cmp - "$ROOT/luma_assets_e33.json"
tar -xOzf "$DEPLOY/$NEW/$BUNDLE.tar.gz" assets/main.py | cmp - "$ROOT/main.py"
tar -xOzf "$DEPLOY/$NEW/$BUNDLE.tar.gz" assets/luma_assets_e33.json | cmp - "$ROOT/luma_assets_e33.json"
grep -Fq 'F1S_TROLL_HOME = (160.0, 393.0)' "$ROOT/main.py"
grep -Fq 'F1S_PINEAPPLE_HOME = (245.0, 370.0)' "$ROOT/main.py"
grep -Fq 'class F1666f1sStateMachine(F1666f1rStateMachine)' "$ROOT/main.py"
for p in "$DEPLOY"/*/; do
  n=$(basename "$p")
  case "|SGGE2.0|SGGE3.1|SGGE3.2|SGGF1.0|SGGF1.6|SGGF1.666|SGGF1.666f1s|SGGF1.666Cleanup1.0|" in *"|$n|"*) ;; *) echo "Unexpected version directory: $n" >&2; exit 1 ;; esac
done
# Verify the full source handoff contains exactly the curated older milestone source archives.
for n in SGGE2.0_COMPLETE.zip sgge3.1.zip sgge3.2.zip SGGF1.0_SOURCE.zip SGGF1.6_SOURCE.zip SGGF1.666_SOURCE.zip; do test -s "$ROOT/MILESTONE_SOURCE_ARCHIVES/$n"; unzip -tq "$ROOT/MILESTONE_SOURCE_ARCHIVES/$n"; done
for n in SGGF1.666f1a SGGF1.666f1b SGGF1.666f1c SGGF1.666f1d SGGF1.666f1e SGGF1.666f1f SGGF1.666f1g SGGF1.666f1h SGGF1.666f1i SGGF1.666f1j SGGF1.666f1k SGGF1.666f1l SGGF1.666f1m SGGF1.666f1n SGGF1.666f1o SGGF1.666f1p SGGF1.666f1q SGGF1.666f1r; do test ! -e "$ROOT/$n"; done
printf '%s\n' 'PASS: Cleanup10 version label, Luma JSON, selected catalogue/folders, play links, APK/TAR integrity and exact payloads, preserved Troll Cave positions/state machine, no extra deploy versions, and all selected milestone source archives.'
