import ast, json, re, tarfile, zipfile
from pathlib import Path
BASE=Path(__file__).resolve().parent
old=json.loads((BASE/'BASELINES'/'F1p1_luma_assets_e33.json').read_text(encoding='utf-8'))
new=json.loads((BASE/'luma_assets_e33.json').read_text(encoding='utf-8'))
assert new['version']=='F1.666f1q'
changed={k for k in old['assets'] if old['assets'][k] != new['assets'][k]}
expected={'c1_bg_troll_cave','troll','troll_animated_0','troll_animated_1','troll_animated_2'}
assert changed==expected, (changed,expected)
assert old['assets']['pineapple']==new['assets']['pineapple']
assert old['world']==new['world']
assert old['engine']==new['engine'] and old['schema']==new['schema']
main=(BASE/'main.py').read_text(encoding='utf-8'); ast.parse(main)
assert 'VERSION = "F1.666f1q"' in main
assert 'class F1666f1qStateMachine(F1666f1pStateMachine)' in main
assert 'class F1666f1qInterface(F1666f1pInterface)' in main
assert 'machine = F1666f1qStateMachine(archive, config, warning)' in main
assert 'ui = F1666f1qInterface(machine)' in main
assert 'WALK into the cave opening to flee' in main
# Confirm the invisibly retained door object and natural opening have not
# changed world data; the pineapple art and placed object stay intact.
objects=old['world']['objects']
exit_old=next(x for x in objects if x.get('object_id')=='troll_cave_exit')
exit_new=next(x for x in new['world']['objects'] if x.get('object_id')=='troll_cave_exit')
pine_old=next(x for x in objects if x.get('object_id')=='purple_passion_pineapple')
pine_new=next(x for x in new['world']['objects'] if x.get('object_id')=='purple_passion_pineapple')
assert exit_old==exit_new and pine_old==pine_new
pics=sorted(x.name for x in (BASE/'pics').iterdir() if x.is_file() and x.suffix.lower()=='.png')
assert len(pics)==34
for html in (BASE/'deploy'/'index.html',BASE/'deploy'/'versions.html'):
    m=re.search(r'const GALLERY_IMAGES = \[(.*?)\];',html.read_text(encoding='utf-8'),re.S)
    assert m
    gallery=json.loads('['+m.group(1)+']')
    assert sorted(x['name'] for x in gallery)==pics
    assert len({x['url'] for x in gallery})==34
    assert all('%20' in x['url'] for x in gallery if ' ' in x['name'])
site=BASE/'deploy'; catalog=json.loads((site/'versions.json').read_text(encoding='utf-8'))
assert catalog['versions'][0]['version']=='SGGF1.666f1q'
assert sum(bool(x.get('current')) for x in catalog['versions'])==1
q=site/'SGGF1.666f1q'
source_q=BASE/'SGGF1.666f1q'
assert (source_q/'assets'/'main.py').read_bytes()==(BASE/'main.py').read_bytes()
assert (source_q/'assets'/'luma_assets_e33.json').read_bytes()==(BASE/'luma_assets_e33.json').read_bytes()
assert (source_q/'play.html').read_bytes()==(q/'play.html').read_bytes()
play=(q/'play.html').read_text(encoding='utf-8')
assert 'sggf1666f1q.tar.gz' in play and 'sggf1666f1q.apk' in play
assert 'F1.666f1q' in play and 'sggf1666f1p.tar.gz' not in play
apk=q/'sggf1666f1q.apk'; tar=q/'sggf1666f1q.tar.gz'
with zipfile.ZipFile(apk) as z:
    assert z.testzip() is None
    assert set(z.namelist())=={'assets/main.py','assets/luma_assets_e33.json'}
    assert z.read('assets/main.py')==(q/'main.py').read_bytes()
    assert z.read('assets/luma_assets_e33.json')==(q/'luma_assets_e33.json').read_bytes()
with tarfile.open(tar,'r:gz') as t:
    assert set(t.getnames())=={'assets/main.py','assets/luma_assets_e33.json'}
    assert t.extractfile('assets/main.py').read()==(q/'main.py').read_bytes()
    assert t.extractfile('assets/luma_assets_e33.json').read()==(q/'luma_assets_e33.json').read_bytes()
# The source overlay and complete site must keep the same updated front door.
for name in ('index.html','versions.html','versions.json'):
    assert (BASE/'deploy'/name).read_bytes()==(site/name).read_bytes()
print('F1q source preservation, gallery, runtime and catalogue tests passed.')
