#!/usr/bin/env python3
"""SGGF1Clean2.2 — Peak summit and Scenic Overlook.

All scene artwork is written as Luma Draw Engine JSON commands. This build
removes the redundant Peak-to-Troll-Cave doorway while preserving the existing
Mountainside cave entrance and the reciprocal Peak/Mountain Path route.
"""
from __future__ import annotations
import json, math, random
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ASSET_FILE = ROOT / 'luma_assets_e33.json'
DATA = json.loads(ASSET_FILE.read_text(encoding='utf-8'))

# Luma Draw Engine primitive helpers.
C=[]
def rect(x,y,w,h,color,radius=0): C.append({'op':'rect','rect':[round(x,2),round(y,2),round(w,2),round(h,2)],'color':list(color),'border':0,'radius':radius})
def ellipse(x,y,w,h,color): C.append({'op':'ellipse','rect':[round(x,2),round(y,2),round(w,2),round(h,2)],'color':list(color),'border':0})
def poly(points,color,border=0): C.append({'op':'polygon','points':[[round(x,2),round(y,2)] for x,y in points],'color':list(color),'border':border})
def line(points,color,width=1): C.append({'op':'line','points':[[round(x,2),round(y,2)] for x,y in points],'color':list(color),'width':width})
def circle(x,y,r,color): C.append({'op':'circle','center':[round(x,2),round(y,2)],'radius':round(r,2),'color':list(color),'border':0})

def pine(x,y,s=1.0,tone=0):
    greens=[(48,83,67),(57,96,75),(70,108,84)]
    c=greens[tone%len(greens)]
    rect(x-2*s,y-4*s,4*s,10*s,(91,72,53))
    poly([(x,y-30*s),(x-12*s,y-10*s),(x+12*s,y-10*s)],c)
    poly([(x,y-21*s),(x-15*s,y-3*s),(x+15*s,y-3*s)],tuple(max(0,v-7) for v in c))

def house(x,y,s=1.0,wall=(185,158,119),roof=(112,77,66)):
    # Elevated-view house cluster, facing the overlook.
    rect(x-12*s,y-8*s,24*s,15*s,wall)
    poly([(x-15*s,y-8*s),(x,y-19*s),(x+15*s,y-8*s)],roof)
    rect(x-3*s,y-1*s,6*s,8*s,(75,65,55))
    rect(x-9*s,y-3*s,4*s,4*s,(114,158,164))
    rect(x+5*s,y-3*s,4*s,4*s,(114,158,164))

def tower(x,y,s=1.0,stone=(183,170,137),roof=(96,72,79)):
    rect(x-10*s,y-32*s,20*s,33*s,stone)
    poly([(x-13*s,y-32*s),(x,y-51*s),(x+13*s,y-32*s)],roof)
    rect(x-3*s,y-23*s,6*s,8*s,(65,76,84))
    line([(x,y-51*s),(x,y-58*s)],(231,214,163),2)

# ---------------------------------------------------------------------------
# 1. New Peak area painting: summit ridge, valley view and a real ledge.
# ---------------------------------------------------------------------------
C=[]
# High alpine sky and soft evening-blue haze.
for y in range(44,306,8):
    t=(y-44)/262
    col=(round(62+77*t),round(101+70*t),round(126+57*t))
    rect(0,y,1280,8,col)
for x,y,s in [(90,120,1.0),(330,82,.7),(840,106,.92),(1080,154,1.12)]:
    cc=(218,224,207)
    ellipse(x,y,76*s,13*s,cc); ellipse(x+18*s,y-10*s,39*s,24*s,cc); ellipse(x+48*s,y+1*s,61*s,13*s,cc)
# Distant mountain layers.
poly([(0,306),(104,252),(192,273),(295,218),(390,268),(505,205),(615,250),(735,190),(842,246),(960,210),(1080,263),(1170,226),(1280,285),(1280,430),(0,430)],(116,145,143))
poly([(0,330),(128,283),(242,301),(355,250),(470,302),(600,244),(722,296),(842,238),(972,292),(1090,261),(1190,304),(1280,280),(1280,455),(0,455)],(145,165,153))
poly([(0,347),(145,314),(270,332),(390,291),(526,336),(654,286),(785,337),(915,290),(1056,333),(1170,302),(1280,340),(1280,466),(0,466)],(170,181,158))
# Snow on the far, high points.
for p,col in [([(278,226),(295,218),(316,239),(303,235),(292,239)],(224,226,210)),
              ([(488,217),(505,205),(530,229),(512,222),(500,227)],(231,232,216)),
              ([(714,204),(735,190),(760,215),(744,209),(730,214)],(226,230,212)),
              ([(942,222),(960,210),(984,232),(969,227),(957,232)],(228,229,210))]: poly(p,col)
# Valley floor, visible between the summit shoulders.
poly([(0,368),(140,337),(264,358),(370,320),(490,355),(610,322),(745,356),(870,318),(1000,349),(1128,325),(1280,367),(1280,510),(0,510)],(121,150,125))
# Patchwork farmland and meadow terraces.
for pts,col in [([(28,378),(180,351),(246,369),(170,397)],(126,159,119)),
                ([(230,378),(365,340),(445,366),(352,402)],(171,166,111)),
                ([(420,380),(560,349),(625,375),(503,412)],(135,164,115)),
                ([(690,365),(820,333),(905,357),(795,396)],(183,171,113)),
                ([(940,376),(1084,343),(1167,369),(1042,407)],(136,160,113)),
                ([(1110,408),(1235,378),(1280,393),(1280,447)],(175,162,108))]: poly(pts,col)
# River ribbon, narrow in the distance and widening into the valley.
poly([(865,268),(890,281),(852,302),(832,322),(855,340),(826,365),(782,384),(804,399),(777,422),(745,442),(729,467),(692,478),(710,449),(742,427),(760,406),(783,389),(804,369),(819,348),(800,328),(812,306),(842,285)],(91,149,164))
line([(865,271),(852,294),(830,315),(848,337),(820,360),(795,382),(773,402),(749,424),(724,451)],(177,205,195),3)
# Main road towards BritRun, with gentle bend.
line([(150,466),(260,432),(370,426),(478,438),(565,417),(654,414),(738,397),(826,382),(914,379),(1030,394)],(103,94,74),13)
line([(150,463),(260,429),(370,423),(478,435),(565,414),(654,411),(738,394),(826,379),(914,376),(1030,391)],(203,181,137),9)
# Woodland pockets scattered over the valley slopes.
for item in [(78,400,.58,0),(145,386,.52,1),(202,412,.62,2),(308,393,.54,0),(370,378,.48,1),
             (470,395,.52,2),(540,380,.46,1),(610,390,.5,0),(904,362,.52,2),(970,385,.62,0),
             (1080,382,.5,1),(1160,414,.63,2),(1208,390,.48,0),(102,448,.65,1),(1130,458,.58,0)]: pine(*item)
# BritRun settlement — recognisable districts rather than an anonymous village.
# Market roofs and square near the centre.
for x,y,s,wall,roof in [(420,387,.72,(201,177,134),(130,80,66)),(450,375,.68,(188,162,121),(105,73,69)),
                         (482,390,.72,(210,184,140),(144,83,62)),(512,374,.65,(177,157,126),(102,73,64)),
                         (542,389,.67,(208,181,129),(129,78,70)),(575,376,.63,(187,167,132),(119,80,61)),
                         (600,397,.68,(203,174,128),(153,91,68)),(636,383,.68,(185,161,126),(114,80,73))]:
    house(x,y,s,wall,roof)
# Market awnings: tiny colour accents make the square legible from above.
poly([(458,386),(470,380),(482,386),(482,390),(458,390)],(152,87,67))
poly([(522,386),(533,380),(544,386),(544,390),(522,390)],(73,112,116))
# Castle on its hill, with towers and a wall.
poly([(720,370),(760,334),(824,322),(885,343),(918,378),(885,397),(764,396)],(117,128,103))
rect(765,350,117,40,(185,174,145))
for xx in (773,806,842,874): rect(xx,343,13,11,(185,174,145))
tower(777,350,.82); tower(871,348,.82); tower(823,340,1.02,(197,185,151),(91,69,82))
# Gold District — taller, warmer roofs and a broad lane.
for x,y,s,wall,roof in [(945,390,.77,(200,176,128),(160,117,63)),(981,375,.72,(190,170,132),(149,101,55)),
                         (1016,394,.82,(211,185,132),(167,119,57)),(1052,377,.72,(185,163,126),(133,91,57)),
                         (1085,399,.75,(207,178,128),(161,111,55))]:
    house(x,y,s,wall,roof)
# Stables and the western outskirts.
for x,y,s in [(285,408,.72),(319,422,.68),(350,405,.63),(382,420,.58)]:
    house(x,y,s,(177,160,128),(94,91,66))
# Distant roads linking the districts.
line([(382,403),(418,394),(455,390),(500,397),(548,403),(600,407),(653,403),(708,391),(762,380),(820,375)],(226,203,153),2)
line([(905,382),(930,388),(955,395),(987,402),(1025,408)],(218,192,145),2)
# The summit approach stays visually open; the valley is the focal point.
# Summit shoulders enclose the valley like a natural amphitheatre.
poly([(0,350),(82,344),(174,369),(270,403),(366,450),(442,496),(490,548),(490,640),(0,640)],(81,101,91))
poly([(0,374),(94,367),(193,398),(286,432),(374,478),(431,521),(0,640)],(105,123,105))
poly([(1280,346),(1192,348),(1110,376),(1028,415),(933,461),(858,505),(812,557),(812,640),(1280,640)],(73,93,88))
poly([(1280,382),(1186,374),(1090,408),(1001,448),(920,493),(864,537),(1280,640)],(95,114,101))
# Main summit ground. The player arrives on this broad, safe apron.
poly([(430,640),(450,566),(490,504),(545,466),(602,447),(680,448),(741,467),(796,507),(836,568),(858,640)],(122,130,108))
poly([(480,640),(503,566),(540,517),(590,482),(645,469),(704,478),(755,512),(789,564),(811,640)],(146,148,119))
# A worn stone path runs from the arrival apron up to the overlook platform.
line([(640,620),(638,579),(632,548),(629,520),(632,493),(638,470)],(91,91,79),24)
line([(640,616),(638,578),(633,548),(630,520),(633,493),(639,470)],(169,156,126),18)
line([(636,612),(634,577),(630,548),(627,521),(630,495),(636,472)],(197,183,147),2)
# Broken stone seams and natural scrub along the summit.
for pts,col in [([(504,535),(555,519),(596,522)],(91,104,91)), ([(724,527),(773,546),(799,574)],(92,105,90)),
                ([(470,586),(517,570),(548,574)],(111,121,99)), ([(755,594),(792,610),(816,638)],(98,111,92))]:
    line(pts,col,3)
for item in [(473,553,.42,0),(500,507,.38,1),(548,481,.34,2),(743,486,.34,0),(791,529,.44,1),(824,571,.52,2)]:
    pine(*item)
# Ledge lip at the far side; the Scenic Overlook object is drawn atop it.
poly([(420,438),(490,419),(560,407),(640,402),(720,407),(791,420),(860,446),(845,465),(780,447),(710,435),(640,431),(568,436),(500,450),(446,466)],(62,73,69))
line([(426,438),(495,419),(560,407),(640,402),(720,407),(791,420),(858,446)],(185,174,139),5)
# The foreground ledge edge gives the player a clear sense of height.
poly([(0,604),(103,590),(205,597),(304,620),(410,640),(0,640)],(67,82,76))
poly([(880,640),(979,611),(1093,590),(1194,593),(1280,605),(1280,640)],(62,78,73))
# Subtle alpine flowers and stone flecks, kept away from the central path.
rng=random.Random(2202)
for _ in range(70):
    x=rng.uniform(24,1255); y=rng.uniform(365,625)
    if abs(x-640)<160 and 455<y<620: continue
    col=(91,119,86) if rng.random()<.6 else (205,180,124)
    if rng.random()<.8: line([(x,y),(x-2,y-7)],col,1)
    else: circle(x,y,1.4,col)
DATA['assets']['c1_bg_peak']={'width':1280,'height':640,'commands':C,
    'description':'A high alpine summit above BritRun. Layered ridges and valley districts lie beyond a broad, grounded stone apron and a deliberate Scenic Overlook platform; no cave doorway is present.'}

# ---------------------------------------------------------------------------
# 2. Clickable Scenic Overlook prop, rendered through the Luma Draw Engine.
# ---------------------------------------------------------------------------
C=[]
ellipse(12,83,216,15,(47,53,49))
# Broad sandstone deck with dark foundation and pale wear edge.
poly([(10,63),(35,45),(201,45),(230,63),(211,83),(28,83)],(67,73,69))
poly([(14,58),(39,40),(198,40),(225,58),(205,75),(32,75)],(155,149,126))
poly([(27,55),(47,45),(190,45),(211,57),(195,68),(43,68)],(181,171,139))
line([(39,45),(199,45),(218,58)],(218,207,168),2)
# Brass-edged viewing rail, low enough to see over.
rect(29,25,5,25,(96,79,58)); rect(205,25,5,25,(96,79,58))
rect(26,22,11,5,(201,164,95)); rect(202,22,11,5,(201,164,95))
line([(32,25),(207,25)],(192,158,91),5)
line([(34,31),(205,31)],(90,91,81),2)
for x in (57,91,126,160,194):
    rect(x,26,3,18,(123,105,75))
# Telescope mount and brass scope, angled out toward BritRun.
poly([(143,63),(160,55),(188,60),(195,69),(164,75)],(82,75,60))
line([(164,58),(192,27)],(74,70,57),9)
line([(164,56),(192,25)],(196,158,91),5)
line([(188,26),(202,13)],(67,70,68),12)
line([(188,23),(202,10)],(207,173,103),6)
ellipse(195,4,18,11,(79,93,100)); ellipse(199,5,10,5,(155,194,196))
# Engraved brass plaque on the front.
rect(80,70,79,12,(82,71,57),radius=2)
rect(83,72,73,8,(201,164,95),radius=2)
line([(89,76),(150,76)],(90,72,49),1)
DATA['assets']['scenic_overlook']={'width':240,'height':100,'commands':C,
    'description':'Interactive stone viewing platform with brass rail and telescope. Hover to identify the Scenic Overlook; E or click opens the summit panorama.'}

# ---------------------------------------------------------------------------
# 3. Wide, rewarding view from the top of the mountain.
# ---------------------------------------------------------------------------
C=[]
for y in range(0,246,6):
    t=y/246
    col=(round(51+91*t),round(88+76*t),round(116+66*t))
    rect(0,y,1280,6,col)
# Sunlight and thin clouds.
ellipse(1035,70,96,96,(231,205,144)); ellipse(1055,90,56,56,(240,219,165))
for x,y,s in [(95,112,.9),(370,74,.68),(786,115,.86),(1130,172,.78)]:
    cc=(228,228,210)
    ellipse(x,y,94*s,14*s,cc); ellipse(x+22*s,y-11*s,45*s,25*s,cc); ellipse(x+58*s,y+1*s,70*s,14*s,cc)
# Very distant high peaks, pale with atmospheric perspective.
poly([(0,260),(110,197),(220,226),(338,158),(453,225),(571,172),(680,220),(798,151),(918,210),(1040,169),(1150,224),(1280,180),(1280,378),(0,378)],(111,142,148))
poly([(0,294),(138,236),(263,257),(387,204),(514,267),(641,212),(762,268),(891,201),(1010,259),(1133,222),(1280,274),(1280,407),(0,407)],(135,160,151))
# Sunlit mountain shoulders and shadowed cuts.
poly([(0,338),(110,287),(227,302),(340,253),(445,295),(548,257),(671,294),(780,244),(887,291),(1008,250),(1123,296),(1280,261),(1280,452),(0,452)],(156,171,151))
poly([(0,365),(124,328),(249,344),(363,306),(489,348),(610,308),(736,347),(865,299),(991,343),(1119,315),(1280,356),(1280,478),(0,478)],(172,179,147))
# Distinct snow tongues catch light on the far summits.
for p in [[(327,164),(338,158),(357,178),(345,175),(335,180)],[(557,183),(571,172),(591,195),(576,190),(566,194)],[(784,166),(798,151),(822,177),(805,171),(793,177)],[(1024,181),(1040,169),(1060,190),(1046,187),(1034,190)]]:
    poly(p,(229,231,214))
# Enormous rolling valley floor.
poly([(0,374),(102,343),(221,354),(345,316),(470,349),(590,320),(717,353),(842,312),(970,346),(1092,318),(1196,349),(1280,332),(1280,548),(0,548)],(116,151,119))
poly([(0,423),(140,386),(266,405),(386,362),(522,394),(650,356),(780,393),(910,355),(1044,388),(1167,361),(1280,388),(1280,568),(0,568)],(135,161,119))
# Patchwork farm fields in the foreground valley.
for pts,col in [([(0,430),(146,399),(242,420),(117,466)],(172,167,105)),
                ([(155,414),(300,380),(398,406),(267,454)],(113,156,99)),
                ([(352,419),(490,382),(594,409),(465,457)],(188,174,112)),
                ([(560,406),(693,374),(789,399),(677,445)],(111,151,103)),
                ([(762,408),(908,371),(1009,398),(883,446)],(177,166,103)),
                ([(980,414),(1126,379),(1224,407),(1097,453)],(114,153,104)),
                ([(1162,463),(1280,429),(1280,510)],(180,166,105))]: poly(pts,col)
# Hedgerows separate the parcels.
for pts in [[(30,452),(146,422),(242,444)],[(190,438),(300,406),(388,430)],[(392,443),(490,405),(581,431)],
            [(604,432),(693,397),(782,421)],[(799,433),(910,394),(1002,420)],[(1012,433),(1123,398),(1210,424)]]:
    line(pts,(74,112,77),3)
# The river winds along the far eastern valley wall, clear of the Castle hill.
poly([(1176,220),(1200,234),(1181,258),(1198,280),(1177,302),(1201,326),(1180,348),(1208,370),(1186,393),(1209,417),(1191,440),(1168,462),(1145,483),(1124,505),(1103,527),(1080,540),(1096,517),(1117,495),(1139,473),(1160,451),(1178,429),(1161,406),(1184,383),(1162,360),(1180,340),(1157,316),(1176,292),(1157,269),(1165,244)],(79,143,164))
line([(1182,225),(1190,245),(1175,265),(1191,284),(1171,307),(1194,329),(1174,351),(1200,373),(1179,397),(1201,420),(1184,443),(1161,465),(1138,487),(1118,508),(1097,530)],(180,207,198),3)
line([(1174,230),(1182,249),(1168,271),(1184,290),(1165,312),(1187,334),(1168,354),(1193,378),(1172,400),(1194,424)],(120,174,180),2)
# Forest belts on the slopes.
for item in [(35,384,.68,0),(82,370,.56,2),(144,391,.61,1),(211,367,.65,0),(274,392,.59,2),(326,365,.56,1),
             (378,386,.57,0),(640,374,.52,2),(693,354,.6,0),(742,370,.58,1),(805,348,.55,2),
             (930,351,.58,0),(1005,369,.61,1),(1072,347,.56,2),(1140,366,.65,0),(1205,350,.57,1),
             (58,496,.9,0),(166,488,.72,2),(306,484,.7,0),(458,482,.78,1),(580,477,.68,2),
             (890,482,.75,0),(1040,486,.85,1),(1180,487,.76,2)]: pine(*item)
# BritRun itself — a recognisable cluster of streets, squares and districts.
# Stables and western cottages.
for item in [(214,431,.82,(190,168,132),(106,89,67)),(252,415,.76,(184,160,127),(93,80,65)),
             (288,435,.78,(194,171,133),(110,81,69)),(325,418,.7,(177,160,132),(91,83,69)),
             (359,435,.75,(199,175,135),(120,85,68))]: house(*item)
# Market quarter — denser, warmer roofs around an open square.
for item in [(430,430,.92,(208,180,137),(139,83,69)),(470,410,.78,(191,164,126),(115,77,71)),
             (511,435,.88,(213,186,142),(148,89,71)),(552,410,.84,(186,165,130),(113,77,66)),
             (590,435,.9,(209,181,132),(143,81,69)),(631,415,.82,(191,169,133),(123,81,74)),
             (672,438,.92,(211,181,134),(148,89,69)),(710,415,.8,(188,164,130),(119,80,70))]: house(*item)
# Market square and awnings.
poly([(470,445),(555,430),(624,447),(539,462)],(188,177,142))
poly([(485,437),(505,428),(525,436),(525,442),(485,447)],(164,83,67))
poly([(566,437),(585,430),(604,438),(604,444),(566,447)],(76,119,126))
# The castle hill rises above the market.
poly([(690,399),(743,348),(813,333),(885,358),(927,406),(889,431),(760,426)],(105,125,99))
rect(744,365,151,54,(190,178,148))
for xx in (753,790,830,870): rect(xx,358,14,14,(190,178,148))
tower(762,365,.92); tower(878,364,.94); tower(820,354,1.28,(202,190,157),(91,70,83))
# Gold District: larger, brighter roofs and a formal square.
for item in [(947,432,.94,(212,188,139),(167,119,59)),(990,410,.88,(199,178,137),(152,105,55)),
             (1034,435,.98,(216,190,139),(170,121,58)),(1076,412,.86,(198,176,135),(153,103,57)),
             (1117,438,.92,(213,185,134),(168,119,62)),(1158,415,.82,(194,171,134),(147,103,57))]: house(*item)
poly([(970,455),(1069,435),(1145,454),(1049,477)],(194,177,123))
# City road connects the three landmarks.
line([(363,445),(430,429),(493,425),(553,435),(625,445),(696,430),(759,414),(826,416),(901,431),(967,444)],(78,77,65),13)
line([(363,442),(430,426),(493,422),(553,432),(625,442),(696,427),(759,411),(826,413),(901,428),(967,441)],(211,190,145),8)
# Hillside paths and small bridges cross the river.
line([(811,321),(835,308),(860,310),(882,329)],(196,177,132),4)
line([(846,356),(867,352),(884,363)],(90,84,69),5)
# A few distant farmsteads and outlying paths.
for item in [(138,470,.59,(186,163,125),(113,86,64)),(385,475,.56,(184,164,130),(111,82,69)),
             (757,468,.62,(188,166,128),(130,91,63)),(1200,468,.6,(194,171,127),(143,97,59))]: house(*item)
# Foreground ravine edges frame the view downward off the mountain.
poly([(0,452),(94,470),(180,492),(253,527),(314,575),(352,640),(0,640)],(64,82,75))
poly([(0,484),(92,501),(176,526),(234,559),(272,612),(286,640),(0,640)],(91,109,96))
poly([(1280,433),(1190,457),(1109,489),(1041,528),(986,576),(952,640),(1280,640)],(60,78,73))
poly([(1280,475),(1188,500),(1110,530),(1051,565),(1014,613),(998,640),(1280,640)],(90,108,94))
# A rocky lip directly below the viewer; foreground flowers add depth.
line([(0,464),(94,480),(180,504),(255,539),(316,586)],(157,157,126),4)
line([(1280,446),(1193,471),(1116,503),(1044,542),(980,590)],(154,156,128),4)
for x,y in [(45,535),(110,550),(200,576),(1070,560),(1172,532),(1234,552)]:
    line([(x,y),(x-5,y-14)],(94,137,86),2); circle(x-4,y-15,2,(210,189,127))
# Small atmospheric details: birds over the valley.
for x,y in [(278,138),(301,146),(824,182),(846,189),(873,181)]:
    line([(x-5,y),(x,y-3),(x+5,y)],(56,76,85),2)
# Subtle lower vignette/ledge line keeps the viewpoint grounded.
poly([(0,616),(130,604),(248,614),(336,640),(0,640)],(49,64,61))
poly([(1280,606),(1154,596),(1040,611),(948,640),(1280,640)],(48,62,59))
DATA['assets']['c1_peak_overlook']={'width':1280,'height':640,'commands':C,
    'description':'Wide Luma Draw Engine panorama from the Peak above BritRun: layered snowy ranges, forested hills, patchwork farmland, a winding river, the Market, Castle and Gold District, all framed by the mountain ledge.'}

# ---------------------------------------------------------------------------
# 4. World changes: remove only the redundant cave door and its connection.
# ---------------------------------------------------------------------------
world=DATA['world']
# The old Peak's pair of invisible rock blockers and upper cave-approach strip
# belonged to the removed doorway. Keep the broad lower summit apron as the
# single walkable surface; it covers the new Scenic Overlook deck and arrival.
peak_area=next(a for a in world['areas'] if a['area_id']=='peak')
peak_area['solid_rects']=[]
peak_area['navigation']['regions']=peak_area['navigation']['regions'][:1]
world['objects']=[o for o in world['objects'] if o.get('object_id')!='troll_cave_entrance']
world['connections']=[c for c in world['connections'] if c.get('connection_id')!='peak_to_troll_cave']
# Add the Scenic Overlook as a non-takeable, clickable scenic world object.
world['objects']=[o for o in world['objects'] if o.get('object_id')!='scenic_overlook']
world['objects'].append({
    'object_id':'scenic_overlook','name':'Scenic Overlook','kind':'scenic_overlook','area_id':'peak',
    'x':520,'y':355,'width':240,'height':100,'takeable':False,'stealable':False,'on_shelf':False,
    'activity':'scenic_overlook'
})
# The upper path remains navigable as a summit approach; the established Peak
# arrival and return corridors are deliberately untouched.
DATA['version']='F1Clean2.2'
DATA['art_revision']='F1Clean2.2 — Peak summit rebuilt as a Scenic Overlook; redundant Peak cave entrance removed.'
notes=DATA.setdefault('notes',[])
if isinstance(notes,list):
    notes=[n for n in notes if not (isinstance(n,str) and ('Peak summit' in n or 'Scenic Overlook' in n or 'Peak cave' in n))]
    notes.append('F1Clean2.2: replaced the old Peak cave-door composition with a summit ledge and interactive Scenic Overlook. The second Troll Cave entrance from Peak is removed; the existing Mountainside entrance remains. The Peak/Mountain Path return route is preserved.')
    DATA['notes']=notes
ASSET_FILE.write_text(json.dumps(DATA,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(f'Updated Luma Draw Engine: Peak={len(DATA["assets"]["c1_bg_peak"]["commands"])} commands; overlook={len(DATA["assets"]["c1_peak_overlook"]["commands"])} commands; prop={len(DATA["assets"]["scenic_overlook"]["commands"])} commands.')
