import json, sys, zipfile, tarfile
from pathlib import Path
root = Path(__file__).resolve().parent
deploy = Path(sys.argv[1]).resolve()
assert 'VERSION = "F1Clean2"' in (root / 'main.py').read_text(encoding='utf-8')
json_data = json.loads((root / 'luma_assets_e33.json').read_text(encoding='utf-8'))
assert json_data['version'] == 'F1Clean2'
area = next(a for a in json_data['world']['areas'] if a['area_id'] == 'mountain_path')
assert len(area['navigation']['corridors']) == 4
versions = json.loads((deploy / 'versions.json').read_text(encoding='utf-8'))['versions']
expected = ['SGGF1Clean2', 'SGGF1.666Cleanup1.0', 'SGGF1.666f1s', 'SGGF1.666', 'SGGF1.6', 'SGGF1.0', 'SGGE3.2', 'SGGE3.1', 'SGGE2.0']
assert [v['version'] for v in versions] == expected
assert versions[0]['current'] is True
assert all(v.get('current') is False for v in versions[1:])
assert sum(bool(v.get('current')) for v in versions) == 1
for entry in versions:
    target = deploy / entry['path']
    assert target.is_file(), f'Missing selectable edition: {entry["version"]} -> {target}'
    if entry.get('image'):
        assert (deploy / entry['image']).is_file(), f'Missing edition art: {entry["image"]}'
for n in expected:
    assert (deploy / n).is_dir(), n
for n in ['SGGF1.666a', 'SGGF1.666b', 'SGGF1.666c', 'SGGF1.666d', 'SGGF1.666e', 'SGGF1.666f']:
    assert not (deploy / n).exists(), f'Uncurated intermediate release included: {n}'
apk = root / 'sggf1clean2.apk'
with zipfile.ZipFile(apk) as z:
    assert z.testzip() is None
    assert z.read('assets/main.py') == (root / 'main.py').read_bytes()
    assert z.read('assets/luma_assets_e33.json') == (root / 'luma_assets_e33.json').read_bytes()
tar = root / 'sggf1clean2.tar.gz'
with tarfile.open(tar, 'r:gz') as t:
    assert t.extractfile('assets/main.py').read() == (root / 'main.py').read_bytes()
    assert t.extractfile('assets/luma_assets_e33.json').read() == (root / 'luma_assets_e33.json').read_bytes()
print('PASS: Clean2 JSON/nav, nine-entry curated milestone catalogue, intermediate versions omitted, APK/TAR payloads exact.')
