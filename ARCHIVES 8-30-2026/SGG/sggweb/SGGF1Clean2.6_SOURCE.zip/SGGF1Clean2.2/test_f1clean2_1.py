import json, math, zipfile, tarfile, hashlib
from pathlib import Path
root=Path(__file__).resolve().parent
deploy=Path(__import__('sys').argv[1]).resolve()
assets=json.loads((root/'luma_assets_e33.json').read_text(encoding='utf-8'))
assert assets['version']=='F1Clean2.1'
area=next(a for a in assets['world']['areas'] if a['area_id']=='mountain_path')
assert len(area['navigation']['corridors'])==3
assert area['navigation']['corridors'][-1][0][-1]==[677.7,184.7]
base_assets=json.loads((root.parent/'SGGF1Clean2'/'luma_assets_e33.json').read_text(encoding='utf-8'))
base_area=next(a for a in base_assets['world']['areas'] if a['area_id']=='mountain_path')
assert area['navigation']['corridors'][:2]==base_area['navigation']['corridors'][:2]
assert assets['world']['connections']==base_assets['world']['connections']
main=(root/'main.py').read_text(encoding='utf-8')
compile(main,str(root/'main.py'),'exec')
assert 'class F1Clean2_1StateMachine' in main
assert 'PEAK_APPROACH = (677.7, 184.7)' in main
assert 'machine = F1Clean2_1StateMachine(archive, config, warning)' in main
assert "conn.connection_id == 'mountain_path_top_peak'" in main
import re
pattern=re.compile(r'^SGG[A-Z]\d+(?:\.\d+)*(?:[a-z][a-z0-9]*)?(?:\.\d+)*$',re.I)
vers=json.loads((deploy/'versions.json').read_text(encoding='utf-8'))['versions']
expected=['SGGF1Clean2.1','SGGF1Clean2','SGGF1.666Cleanup1.0','SGGF1.666f1s','SGGF1.666','SGGF1.6','SGGF1.0','SGGE3.2','SGGE3.1','SGGE2.0']
assert [x['version'] for x in vers]==expected
assert all(pattern.fullmatch(x['version']) for x in vers)
assert vers[0]['current'] is True and sum(bool(x.get('current')) for x in vers)==1
for v in vers:
 assert (deploy/v['path']).is_file()
 if v.get('image'): assert (deploy/v['image']).is_file()
for d in ['SGGF1.666Cleanup1.0','SGGF1.666f1s','SGGF1.666','SGGF1.6','SGGF1.0','SGGE3.2','SGGE3.1','SGGE2.0']:
 assert (deploy/d).is_dir()
assert (deploy/'SGGF1Clean2').is_dir()
with zipfile.ZipFile(root/'sggf1clean2_1.apk') as z:
 assert z.testzip() is None
 assert z.read('assets/main.py')==(root/'main.py').read_bytes()
 assert z.read('assets/luma_assets_e33.json')==(root/'luma_assets_e33.json').read_bytes()
with tarfile.open(root/'sggf1clean2_1.tar.gz','r:gz') as t:
 assert t.extractfile('assets/main.py').read()==(root/'main.py').read_bytes()
 assert t.extractfile('assets/luma_assets_e33.json').read()==(root/'luma_assets_e33.json').read_bytes()
print('PASS: JSON, navigation endpoint, machine/transition integration, runtime payloads and ten-entry preserved deploy catalogue.')
