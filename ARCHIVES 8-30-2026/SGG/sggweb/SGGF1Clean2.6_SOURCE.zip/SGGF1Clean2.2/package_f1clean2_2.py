from pathlib import Path
from io import BytesIO
import tarfile, zipfile
W=Path(__file__).resolve().parent
code=(W/"main.py").read_bytes()
assets=(W/"luma_assets_e33.json").read_bytes()
bundle="sggf1clean2_2"
with zipfile.ZipFile(W/(bundle+".apk"),"w",zipfile.ZIP_DEFLATED,compresslevel=8) as z:
 z.writestr("assets/main.py",code)
 z.writestr("assets/luma_assets_e33.json",assets)
with tarfile.open(W/(bundle+".tar.gz"),"w:gz") as t:
 for name,data in (("assets/main.py",code),("assets/luma_assets_e33.json",assets)):
  info=tarfile.TarInfo(name); info.size=len(data); info.mtime=0; t.addfile(info,BytesIO(data))
print("Built SGGF1Clean2.2 runtime packages.")
