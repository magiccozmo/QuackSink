#!/usr/bin/env python3
"""Static/regression tests for SGGF1Clean2.2. Run with deployment and baseline-deploy paths."""
from __future__ import annotations
import ast, hashlib, json, pathlib, re, sys, zipfile, tarfile

ROOT = pathlib.Path(__file__).resolve().parent
if ROOT.name != 'SGGF1Clean2.2':
    ROOT = ROOT / 'SGGF1Clean2.2'
DEPLOY = pathlib.Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else ROOT.parent.parent / 'deploy'
BASE_DEPLOY = pathlib.Path(sys.argv[2]).resolve() if len(sys.argv) > 2 else DEPLOY.parent
BASE_SOURCE = ROOT.parent / 'SGGF1Clean2.1'

def check(ok, message):
    if not ok:
        raise AssertionError(message)
    print('PASS:', message)

def digest(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

def tree_digest(folder):
    folder = pathlib.Path(folder)
    return {p.relative_to(folder).as_posix(): digest(p)
            for p in sorted(folder.rglob('*')) if p.is_file()}

main_path = ROOT / 'main.py'
source_json_path = ROOT / 'luma_assets_e33.json'
check(main_path.is_file() and source_json_path.is_file(), 'release source files are present')
main = main_path.read_text(encoding='utf-8')
ast.parse(main, filename=str(main_path))
compile(main, str(main_path), 'exec')
check('VERSION = "F1Clean2.2"' in main, 'runtime version is F1Clean2.2')
check('class F1Clean2_2StateMachine(F1Clean2_1StateMachine)' in main,
      'new state machine extends Clean2.1')
check('class F1Clean2_2Interface(F1666f1sInterface)' in main,
      'new interface retains the established SGG interface')
check('machine = F1Clean2_2StateMachine(' in main and 'ui = F1Clean2_2Interface(machine)' in main,
      'new state machine/interface are the active runtime')
expected_line = ("Now aint THAT just a thing.  Luma really did a nice job on that view.  "
                 "We hope you enjoyed it. Either way, please leave a comment and let us know. "
                 "Enjoy the rest of your adventures")
tree = ast.parse(main, filename=str(main_path))
constant_line = None
for node in ast.walk(tree):
    if isinstance(node, ast.ClassDef) and node.name == 'F1Clean2_2StateMachine':
        for child in node.body:
            if isinstance(child, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'PEAK_OVERLOOK_LINE' for t in child.targets):
                constant_line = ast.literal_eval(child.value)
check(constant_line == expected_line, 'Cozmo dialogue matches the requested wording exactly')
for token, label in [
    ('def _remove_legacy_peak_cave', 'old-save migration removes the retired doorway'),
    ('def _return_from_overlook', 'movement-key return opens the Cozmo outro'),
    ('def _finish_peak_overlook_dialogue', 'Cozmo is cleared after the dialogue'),
    ('def _choose_dialogue', 'dialogue choice routes through the outro handler'),
    ('if self.peak_overlook_open:', 'panorama state pauses world updates and captures input'),
    ("'scenic_overlook'", 'Scenic Overlook is a recognized interactive object'),
    ("'c1_peak_overlook'", 'panorama is rendered through the Luma Draw Engine'),
]:
    check(token in main, label)

new = json.loads(source_json_path.read_text(encoding='utf-8'))
old = json.loads((BASE_SOURCE / 'luma_assets_e33.json').read_text(encoding='utf-8'))
check(new['version'] == 'F1Clean2.2', 'Luma asset document identifies F1Clean2.2')
check(new['schema']['supported_drawing_ops'] == ['rect', 'line', 'polygon', 'circle', 'ellipse'],
      'existing Luma Draw Engine schema remains intact')

# The only permitted asset changes are a redesigned Peak, plus the Overlook prop and panorama.
changed_assets = {k for k in set(old['assets']) | set(new['assets']) if old['assets'].get(k) != new['assets'].get(k)}
check(changed_assets == {'c1_bg_peak', 'scenic_overlook', 'c1_peak_overlook'},
      f'only the Peak background and two new Overlook recipes changed ({sorted(changed_assets)})')
for key in ('c1_bg_peak', 'scenic_overlook', 'c1_peak_overlook'):
    recipe = new['assets'][key]
    check(isinstance(recipe.get('commands'), list) and recipe['commands'], f'{key} has drawing commands')
    for ci, cmd in enumerate(recipe['commands']):
        if cmd.get('op') not in new['schema']['supported_drawing_ops']:
            raise AssertionError(f'{key} command {ci} uses unsupported primitive {cmd.get("op")}')
        col = cmd.get('color')
        if col is not None and not (isinstance(col, list) and len(col) in (3, 4)
                                    and all(isinstance(v, int) and 0 <= v <= 255 for v in col)):
            raise AssertionError(f'{key} command {ci} has invalid color channels')
    check(True, f'{key} uses supported Luma primitives and valid color channels ({len(recipe["commands"])} commands)')

# Every existing area other than Peak is identical. Every non-Peak world-level field is unchanged.
old_areas = {a['area_id']: a for a in old['world']['areas']}
new_areas = {a['area_id']: a for a in new['world']['areas']}
check(set(old_areas) == set(new_areas), 'the same complete set of game areas is retained')
check(all(old_areas[k] == new_areas[k] for k in old_areas if k != 'peak'),
      'all non-Peak area artwork and geometry are unchanged')
for key in set(old['world']) - {'areas', 'objects', 'connections'}:
    check(old['world'][key] == new['world'][key], f'world field {key} is unchanged')

old_objects = {o['object_id']: o for o in old['world']['objects']}
new_objects = {o['object_id']: o for o in new['world']['objects']}
check(set(old_objects) - set(new_objects) == {'troll_cave_entrance'}, 'only the duplicate Peak cave object is removed')
check(set(new_objects) - set(old_objects) == {'scenic_overlook'}, 'only the Scenic Overlook object is added')
check(all(old_objects[k] == new_objects[k] for k in set(old_objects) & set(new_objects)),
      'all pre-existing world objects are unchanged')
overlook = new_objects['scenic_overlook']
check(overlook['name'] == 'Scenic Overlook' and overlook['kind'] == 'scenic_overlook'
      and overlook['area_id'] == 'peak' and overlook['takeable'] is False,
      'the Peak platform has the exact hover label and non-takeable interaction')

old_connections = {c['connection_id']: c for c in old['world']['connections']}
new_connections = {c['connection_id']: c for c in new['world']['connections']}
check(set(old_connections) - set(new_connections) == {'peak_to_troll_cave'},
      'only the redundant Peak-to-Troll-Cave connection is removed')
check(set(old_connections) == set(new_connections) | {'peak_to_troll_cave'},
      'no unrelated transitions were added or removed')
check(all(old_connections[k] == new_connections[k] for k in new_connections),
      'all retained transitions, including the Mountain Path reciprocal exits, are unchanged')

# Mountainside is the sole remaining Troll Cave entrance.
remaining_cave = [o for o in new['world']['objects'] if o['object_id'] == 'mountain_cave_entrance']
remaining_conn = [c for c in new['world']['connections'] if c['connection_id'] == 'side_of_mountain_to_troll_cave']
check(len(remaining_cave) == 1 and remaining_cave[0]['area_id'] == 'side_of_mountain',
      'the original Mountainside Troll Cave entrance remains')
check(len(remaining_conn) == 1, 'the original Mountainside-to-Troll-Cave connection remains')

peak = new_areas['peak']
check(peak.get('solid_rects') == [], 'retired Peak cave blockers are removed')
regions = peak.get('navigation', {}).get('regions', [])
check(len(regions) == 1 and regions[0] == [[190, 230], [1090, 230], [1090, 625], [190, 625]],
      'Peak walkmesh is a single grounded summit platform that includes arrival and overlook')

# Ensure every area background and world-object recipe resolves in the complete asset map.
asset_keys = set(new['assets'])
for area in new['world']['areas']:
    check(area.get('background_asset') in asset_keys, f"area {area['area_id']} background recipe exists")
for obj in new['world']['objects']:
    check(obj.get('kind') in asset_keys or obj.get('kind') in {'door','npc','vendor'},
          f"world object {obj['object_id']} has a valid render recipe/kind")

# Version catalogue and old deployments remain complete and unchanged.
versions_path = DEPLOY / 'versions.json'
versions = json.loads(versions_path.read_text(encoding='utf-8'))['versions']
expected_versions = ['SGGF1Clean2.2','SGGF1Clean2.1','SGGF1Clean2','SGGF1.666Cleanup1.0',
                     'SGGF1.666f1s','SGGF1.666','SGGF1.6','SGGF1.0','SGGE3.2','SGGE3.1','SGGE2.0']
check([v['version'] for v in versions] == expected_versions, 'front-door catalogue contains all 11 curated releases in order')
check(versions[0].get('current') is True and all(v.get('current') is False for v in versions[1:]),
      'only Clean2.2 is marked current')
for v in versions:
    check((DEPLOY / v['path']).is_file(), f"catalogue path exists for {v['version']}")
    if v.get('image'):
        check((DEPLOY / v['image']).is_file(), f"catalogue preview exists for {v['version']}")
for release in expected_versions[1:]:
    old_dir = BASE_DEPLOY / release
    new_dir = DEPLOY / release
    check(old_dir.is_dir() and new_dir.is_dir() and tree_digest(old_dir) == tree_digest(new_dir),
          f'prior deployed release {release} is byte-for-byte unchanged')

# New static package bundle must embed the same main + Luma asset document as source.
for bundle_name in ('sggf1clean2_2.apk', 'sggf1clean2_2.tar.gz'):
    bundle = ROOT / bundle_name
    check(bundle.is_file() and bundle.stat().st_size > 0, f'{bundle_name} exists')
    if bundle.suffix == '.apk':
        with zipfile.ZipFile(bundle) as zf:
            check(zf.testzip() is None, 'APK ZIP integrity is clean')
            names = set(zf.namelist())
            main_member = next((n for n in names if n.endswith('/main.py') or n == 'main.py'), None)
            json_member = next((n for n in names if n.endswith('/luma_assets_e33.json') or n == 'luma_assets_e33.json'), None)
            check(main_member and json_member, 'APK contains the runtime and Luma assets')
            check(zf.read(main_member) == main_path.read_bytes(), 'APK runtime matches source main.py exactly')
            check(zf.read(json_member) == source_json_path.read_bytes(), 'APK Luma assets match source JSON exactly')
    else:
        with tarfile.open(bundle, 'r:gz') as tf:
            names = tf.getnames()
            check(any(n.endswith('/main.py') or n == 'main.py' for n in names), 'TAR contains main.py')
            check(any(n.endswith('/luma_assets_e33.json') or n == 'luma_assets_e33.json' for n in names), 'TAR contains Luma JSON')

# Ensure previous roots remain and no large video files enter the deployment.
check(not any(p.suffix.lower() in {'.mp4','.mov','.avi','.mkv'} for p in DEPLOY.rglob('*') if p.is_file()),
      'deployment contains no large video files')
print('ALL SGGF1Clean2.2 STATIC REGRESSION TESTS PASSED')
