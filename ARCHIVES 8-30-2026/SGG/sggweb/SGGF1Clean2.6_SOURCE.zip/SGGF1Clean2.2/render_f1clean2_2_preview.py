from PIL import Image, ImageDraw, ImageFont
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
D=json.loads((ROOT/'luma_assets_e33.json').read_text(encoding='utf-8'))

def render(name):
    a=D['assets'][name]
    im=Image.new('RGBA',(a['width'],a['height']),(0,0,0,0)); dr=ImageDraw.Draw(im)
    for c in a['commands']:
        op=c['op']; col=tuple(c.get('color',(255,255,255)))
        if op=='rect':
            x,y,w,h=c['rect']; r=[round(x),round(y),round(x+w),round(y+h)]
            rad=max(0,int(c.get('radius',0)))
            if rad: dr.rounded_rectangle(r,radius=rad,fill=col)
            else: dr.rectangle(r,fill=col)
        elif op=='ellipse':
            x,y,w,h=c['rect']; dr.ellipse((round(x),round(y),round(x+w),round(y+h)),fill=col)
        elif op=='polygon': dr.polygon([tuple(map(round,p)) for p in c['points']],fill=col)
        elif op=='line': dr.line([tuple(map(round,p)) for p in c['points']],fill=col,width=max(1,int(c.get('width',1))),joint='curve')
        elif op=='circle':
            x,y=c['center']; r=c['radius']; dr.ellipse((x-r,y-r,x+r,y+r),fill=col)
    return im

bg=render('c1_bg_peak')
prop=render('scenic_overlook')
bg.alpha_composite(prop,(520,355))
d=ImageDraw.Draw(bg)
try: f=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',18)
except: f=ImageFont.load_default()
d.text((15,12),'PEAK — arrival view',font=f,fill=(250,240,215))
bg.convert('RGB').save('/mnt/data/SGGF1Clean2.2_Peak_Preview.png',quality=95)

view=render('c1_peak_overlook')
d=ImageDraw.Draw(view)
try:
    ft=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',30)
    fs=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',16)
    fl=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',14)
except: ft=fs=fl=ImageFont.load_default()
d.rounded_rectangle((330,16,950,89),radius=9,fill=(22,31,33),outline=(212,187,135),width=2)
t='THE VIEW FROM THE PEAK'; box=d.textbbox((0,0),t,font=ft); d.text((640-(box[2]-box[0])/2,22),t,font=ft,fill=(248,235,204))
t='BritRun and the lands beyond'; box=d.textbbox((0,0),t,font=fs); d.text((640-(box[2]-box[0])/2,61),t,font=fs,fill=(220,220,195))
for label,cx,cy in [('STABLES',226,506),('BRITRUN MARKET',495,493),('THE CASTLE',795,478),('GOLD DISTRICT',1055,490)]:
    box=d.textbbox((0,0),label,font=fl); w=box[2]-box[0]+18; h=box[3]-box[1]+10
    r=(cx-w/2,cy-h/2,cx+w/2,cy+h/2); d.rounded_rectangle(r,radius=4,fill=(24,31,30,218),outline=(205,179,129),width=1)
    d.text((cx-(box[2]-box[0])/2,cy-(box[3]-box[1])/2-1),label,font=fl,fill=(255,239,197))
d.rounded_rectangle((318,588,962,624),radius=7,fill=(22,31,33),outline=(212,187,135),width=1)
t='TAKE YOUR TIME  •  MOVE TO RETURN'; box=d.textbbox((0,0),t,font=fl); d.text((640-(box[2]-box[0])/2,597),t,font=fl,fill=(248,232,192))
view.convert('RGB').save('/mnt/data/SGGF1Clean2.2_Scenic_Overlook_Panorama.png',quality=95)
