from pathlib import Path
p=Path(__file__).resolve().parent/'main.py'
s=p.read_text(encoding='utf-8')
assert 'VERSION = "F1Clean2.1"' in s
# Give the scenic object its own Luma Draw Engine recipe/kind.
s=s.replace('("door","path","portal","cookpot","hearth","alchemy_table","book","chest")',
            '("door","path","portal","cookpot","hearth","alchemy_table","book","chest","scenic_overlook")')
# append only if not already applied
assert "class F1Clean2_2StateMachine" not in s
s=s.replace('VERSION = "F1Clean2.1"  # Mountain Path grounded Peak endpoint; all other gameplay preserved.',
            'VERSION = "F1Clean2.2"  # Peak Scenic Overlook; grounded Mountain Path endpoint retained.')
insert=r'''

class F1Clean2_2StateMachine(F1Clean2_1StateMachine):
    """F1Clean2.2 adds a summit panorama without disturbing the inherited world."""

    PEAK_OVERLOOK_LINE = (
        "Now aint THAT just a thing.  Luma really did a nice job on that view.  "
        "We hope you enjoyed it. Either way, please leave a comment and let us know. "
        "Enjoy the rest of your adventures"
    )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.peak_overlook_open = False
        self.peak_overlook_outro_active = False

    def start_game(self):
        self.peak_overlook_open = False
        self.peak_overlook_outro_active = False
        super().start_game()

    def _remove_legacy_peak_cave(self, reason):
        """Remove only the obsolete Peak duplicate from a loaded old save."""
        g = self.game
        if g is None:
            return
        before = len(g.objects)
        g.objects = [o for o in g.objects if o.object_id != 'troll_cave_entrance']
        removed = before - len(g.objects)
        if hasattr(g, 'item_meta'):
            g.item_meta.pop('troll_cave_entrance', None)
        if getattr(g, 'selected_object_id', None) == 'troll_cave_entrance':
            g.selected_object_id = None
        if getattr(g, 'carried_object_id', None) == 'troll_cave_entrance':
            g.carried_object_id = None
        if hasattr(g, 'inventory'):
            g.inventory = [oid for oid in g.inventory if oid != 'troll_cave_entrance']
        if removed:
            self._log('F1Clean2.2 SAVE MIGRATION',
                      f'Removed {removed} obsolete Peak Troll Cave doorway object(s) after {reason}; '
                      'the original Mountainside entrance and all other saved state were retained.')

    def start_game(self):
        # F1s/F1Clean2.1 start and all inherited save/game behavior remain intact.
        self.peak_overlook_open = False
        self.peak_overlook_outro_active = False
        super().start_game()
        self._remove_legacy_peak_cave('new/continued game start')

    def _read_save(self, slot):
        super()._read_save(slot)
        self.peak_overlook_open = False
        self.peak_overlook_outro_active = False
        self._remove_legacy_peak_cave(f'load of {slot}')

    def update(self, elapsed_seconds, ui):
        if self.peak_overlook_open:
            # No world clock, AI, danger, NPC or cameo timers advance while admiring the view.
            return None
        return super().update(elapsed_seconds, ui)

    def _activate(self, obj):
        if obj is not None and obj.object_id == 'scenic_overlook':
            g = self.game
            if g is None or g.current_area_id != 'peak':
                return
            if not g.close_to_object(obj):
                self._speech('Step up to the viewing platform to take in the view.')
                return
            self.peak_overlook_open = True
            self._log('SCENIC OVERLOOK',
                      f'Opened from Peak at player=({g.player_x:.1f},{g.player_y:.1f}); '
                      'world simulation paused until a movement key or Escape returns to the summit.')
            self._set_status('Scenic Overlook — take your time.')
            return
        return super()._activate(obj)

    def _return_from_overlook(self):
        g = self.game
        if g is None:
            self.peak_overlook_open = False
            return
        self.peak_overlook_open = False
        self.peak_overlook_outro_active = True
        # The cameo is anchored in the summit scene and remains until the player
        # dismisses the one-shot appreciation dialogue.
        g.c1_flags['d11_cameo_active'] = {
            'event': 'peak_overlook', 'area': 'peak',
            'x': 934.0, 'y': 492.0, 'talked': True, 'leave_at': None
        }
        self._dialogue('Cozmo', self.PEAK_OVERLOOK_LINE,
                       [{'text': 'Thank you, Cozmo!', 'action': 'peak_overlook_close'}])
        self._log('SCENIC OVERLOOK', 'Player returned to the summit; Cozmo appreciation dialogue opened.')
        self._set_status('Back at the Peak.')

    def _finish_peak_overlook_dialogue(self):
        g = self.game
        if g is not None:
            if g.c1_dialogue and g.c1_dialogue.get('speaker') == 'Cozmo':
                g.c1_dialogue = None
                g.c1_dialogue_selected = 0
            g.c1_flags['d11_cameo_active'] = None
        self.peak_overlook_outro_active = False
        self._log('SCENIC OVERLOOK', 'Cozmo finished the summit message and disappeared.')

    def _choose_dialogue(self, index):
        g = self.game
        if g is not None and self.peak_overlook_outro_active and g.c1_dialogue:
            opts = g.c1_dialogue.get('options', [])
            if 0 <= index < len(opts) and opts[index].get('action') == 'peak_overlook_close':
                self._finish_peak_overlook_dialogue()
                return
        return super()._choose_dialogue(index)

    def dispatch(self, event, ui):
        # During the full-screen panorama the movement keys are deliberately
        # repurposed as the return gesture; nothing underneath receives input.
        if self.peak_overlook_open:
            if event.type == pygame.QUIT:
                return super().dispatch(event, ui)
            if event.type == pygame.VIDEORESIZE and not BROWSER:
                return super().dispatch(event, ui)
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE or any(
                    matches(event, self.c1_keys.get(direction, DEFAULT_KEYS[direction]))
                    for direction in ('up', 'down', 'left', 'right')
                ) or event.key in (pygame.K_UP, pygame.K_DOWN, pygame.K_LEFT, pygame.K_RIGHT):
                    self._return_from_overlook()
            return
        # Either the response button or Escape closes the one-shot Cozmo cameo.
        if (self.peak_overlook_outro_active and self.game is not None
                and self.game.c1_dialogue and event.type == pygame.KEYDOWN
                and event.key == pygame.K_ESCAPE):
            self._finish_peak_overlook_dialogue()
            return
        return super().dispatch(event, ui)


class F1Clean2_2Interface(F1666f1sInterface):
    """Luma Draw Engine panorama view layered into the existing SGG interface."""

    def _d1_hint(self, g):
        if getattr(self.machine, 'peak_overlook_open', False):
            return 'SCENIC OVERLOOK   —   TAKE YOUR TIME   —   PRESS WASD OR AN ARROW KEY TO RETURN'
        return super()._d1_hint(g)

    def _draw_game_scene(self, surface, g):
        if not getattr(self.machine, 'peak_overlook_open', False):
            return super()._draw_game_scene(surface, g)

        engine = self.machine.draw_engine
        surface.fill((36, 48, 51))
        engine.draw_asset(surface, 'c1_peak_overlook', pygame.Rect(0, 0, GAME_WIDTH, GAME_HEIGHT))

        # A restrained title plaque identifies the destination without covering
        # the wide valley, river, and town skyline.
        title_box = pygame.Rect(330, 16, 620, 73)
        pygame.draw.rect(surface, (22, 31, 33), title_box, border_radius=9)
        pygame.draw.rect(surface, (212, 187, 135), title_box, 2, border_radius=9)
        title = pygame.font.SysFont('segoeui', 30, bold=True).render(
            'THE VIEW FROM THE PEAK', True, (248, 235, 204))
        subtitle = pygame.font.SysFont('segoeui', 16, italic=True).render(
            'BritRun and the lands beyond', True, (220, 220, 195))
        surface.blit(title, title.get_rect(center=(640, 44)))
        surface.blit(subtitle, subtitle.get_rect(center=(640, 73)))

        # Geographic captions sit over the lower valley, not on top of the main
        # castle or skyline silhouettes.
        labels = [
            ('STABLES', 226, 506),
            ('BRITRUN MARKET', 495, 493),
            ('THE CASTLE', 795, 478),
            ('GOLD DISTRICT', 1055, 490),
        ]
        label_font = pygame.font.SysFont('consolas', 14, bold=True)
        for label, cx, cy in labels:
            txt = label_font.render(label, True, (255, 239, 197))
            box = pygame.Rect(0, 0, txt.get_width() + 18, txt.get_height() + 10)
            box.center = (cx, cy)
            panel = pygame.Surface(box.size, pygame.SRCALPHA)
            panel.fill((24, 31, 30, 190))
            surface.blit(panel, box)
            pygame.draw.rect(surface, (205, 179, 129), box, 1, border_radius=4)
            surface.blit(txt, txt.get_rect(center=box.center))

        footer = pygame.Rect(318, 588, 644, 36)
        pygame.draw.rect(surface, (22, 31, 33), footer, border_radius=7)
        pygame.draw.rect(surface, (212, 187, 135), footer, 1, border_radius=7)
        hint = pygame.font.SysFont('consolas', 15, bold=True).render(
            'TAKE YOUR TIME  •  MOVE TO RETURN', True, (248, 232, 192))
        surface.blit(hint, hint.get_rect(center=footer.center))
'''
marker='\n\nasync def main():\n'
assert marker in s
s=s.replace(marker, insert+marker, 1)
s=s.replace('machine = F1Clean2_1StateMachine(archive, config, warning)',
            'machine = F1Clean2_2StateMachine(archive, config, warning)')
s=s.replace('ui = F1666f1sInterface(machine)', 'ui = F1Clean2_2Interface(machine)')
p.write_text(s,encoding='utf-8')
print('Patched main.py for F1Clean2.2 Scenic Overlook.')
