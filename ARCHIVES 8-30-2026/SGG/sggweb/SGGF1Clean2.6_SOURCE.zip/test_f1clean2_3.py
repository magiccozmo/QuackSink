#!/usr/bin/env python3
"""Focused regression tests for SGGF1Clean2.3 Peak return landing."""
from __future__ import annotations
import ast, hashlib, json, math, pathlib, sys, tarfile, zipfile

ROOT = pathlib.Path(__file__).resolve().parent
DEPLOY = pathlib.Path(sys.argv[1]).resolve()
BASE_DEPLOY = pathlib.Path(sys.argv[2]).resolve()
BASE_SOURCE = ROOT.parent / 'SGGF1Clean2.2'

def check(ok, message):
    if not ok:
        raise AssertionError(message)
    print('PASS:', message)

def digest(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):
            h.update(b)
    return h.hexdigest()

def tree_digest(folder):
    folder=pathlib.Path(folder)
    return {p.relative_to(folder).as_posix():digest(p) for p in sorted(folder.rglob('*')) if p.is_file()}

def segdist(x,y,ax,ay,bx,by):
    dx,dy=bx-ax,by-ay
    t=max(0.0,min(1.0,((x-ax)*dx+(y-ay)*dy)/max(0.01,dx*dx+dy*dy)))
    return math.hypot(x-ax-dx*t,y-ay-dy*t)

def point_in_poly(x,y,poly):
    inside=False
    j=len(poly)-1
    for i in range(len(poly)):
        xi,yi=poly[i]; xj,yj=poly[j]
        if ((yi>y)!=(yj>y)) and (x < (xj-xi)*(y-yi)/(yj-yi+1e-12)+xi):
            inside=not inside
        j=i
    return inside

def poly_distance(x,y,poly):
    if point_in_poly(x,y,poly): return 0.0
    return min(segdist(x,y,*a,*b) for a,b in zip(poly,poly[1:]+poly[:1]))

def nav_error(area,x,y):
    foot_y=y+14.0
    errors=[]
    spec=area.get('navigation',{})
    for poly in spec.get('regions',[]):
        errors.append(poly_distance(x,foot_y,poly))
    for line,width in spec.get('corridors',[]):
        closest=min(segdist(x,foot_y,*a,*b) for a,b in zip(line,line[1:]))
        errors.append(max(0.0,closest-width/2+9))
    return min(errors) if errors else 0.0

# Runtime syntax and version identity.
main_path=ROOT/'main.py'
asset_path=ROOT/'luma_assets_e33.json'
main=main_path.read_text(encoding='utf-8')
ast.parse(main,filename=str(main_path)); compile(main,str(main_path),'exec')
check('VERSION = "F1Clean2.3"' in main,'runtime identifies F1Clean2.3')
check('VERSION = "F1Clean2.2"' not in main,'old runtime version string is no longer active')
new=json.loads(asset_path.read_text(encoding='utf-8'))
old=json.loads((BASE_SOURCE/'luma_assets_e33.json').read_text(encoding='utf-8'))
check(new['version']=='F1Clean2.3','Luma asset JSON identifies F1Clean2.3')

# Only one world connection landing coordinate should change.
old_connections={c['connection_id']:c for c in old['world']['connections']}
new_connections={c['connection_id']:c for c in new['world']['connections']}
check(set(old_connections)==set(new_connections),'all world connections remain present')
changed={k for k in old_connections if old_connections[k]!=new_connections[k]}
check(changed=={'peak_bottom_mountain_path'},'only Peak return connection data changed')
ret=new_connections['peak_bottom_mountain_path']
check(ret['from_area_id']=='peak' and ret['to_area_id']=='mountain_path' and ret['trigger']=='edge' and ret['edge']=='bottom',
      'Peak bottom exit still leads to Mountain Path')
check((ret['arrival_x'],ret['arrival_y'])==(720.0,190.0),'Peak return landing is set to (720,190)')

# The new player anchor is walkable and outside the automatic Peak-entry radius.
mp=next(a for a in new['world']['areas'] if a['area_id']=='mountain_path')
old_error=nav_error(mp,640.0,108.0)
new_error=nav_error(mp,ret['arrival_x'],ret['arrival_y'])
check(old_error>1.0,'former (640,108) return location is outside the Mountain Path walkmesh')
check(new_error<=1.0,'new (720,190) return landing is inside the existing Mountain Path walkmesh')
trigger=(677.7,184.7); radius=22.0
landing_distance=math.hypot(ret['arrival_x']-trigger[0],ret['arrival_y']-trigger[1])
check(landing_distance>radius+15.0,'new landing clears the automatic Peak-entry radius with margin')
check(new_error<=1.0,'upper-path corridor geometry accepts the return landing using the renderer foot anchor')

# No artwork, objects, areas, or unrelated world data changed.
check(old['world']['areas']==new['world']['areas'],'all area definitions and walkmeshes are unchanged')
check(old['world']['objects']==new['world']['objects'],'all world objects are unchanged')
for key in set(old['world'])-{'areas','objects','connections'}:
    check(old['world'][key]==new['world'][key],f'world field {key} is unchanged')
changed_assets={k for k in set(old['assets'])|set(new['assets']) if old['assets'].get(k)!=new['assets'].get(k)}
check(not changed_assets,'all Luma Draw Engine artwork recipes are byte-data equivalent')
check(all(old[k]==new[k] for k in ('schema','renderer','asset_sets') if k in old and k in new),
      'Luma Draw Engine schema and renderer metadata are unchanged')

# Prior version catalogue and playable folders are retained, with new current at top.
vdata=json.loads((DEPLOY/'versions.json').read_text(encoding='utf-8'))['versions']
expected=['SGGF1Clean2.3','SGGF1Clean2.2','SGGF1Clean2.1','SGGF1Clean2','SGGF1.666Cleanup1.0',
          'SGGF1.666f1s','SGGF1.666','SGGF1.6','SGGF1.0','SGGE3.2','SGGE3.1','SGGE2.0']
check([v['version'] for v in vdata]==expected,'front-door catalogue contains 12 curated releases in order')
check(vdata[0].get('current') is True and all(v.get('current') is False for v in vdata[1:]),
      'only Clean2.3 is marked current')
for v in vdata:
    check((DEPLOY/v['path']).is_file(),f"catalogue launch path exists for {v['version']}")
    if v.get('image'): check((DEPLOY/v['image']).is_file(),f"catalogue image path exists for {v['version']}")
for version in expected[1:]:
    a=BASE_DEPLOY/version; b=DEPLOY/version
    check(a.is_dir() and b.is_dir() and tree_digest(a)==tree_digest(b),
          f'previous deployment folder {version} is byte-for-byte unchanged')

# Old Cave setup and Scenic Overlook remain exactly as in Clean2.2.
check(any(o.get('object_id')=='scenic_overlook' and o.get('area_id')=='peak' for o in new['world']['objects']),
      'Scenic Overlook remains in Peak')
check(not any(o.get('object_id')=='troll_cave_entrance' and o.get('area_id')=='peak' for o in new['world']['objects']),
      'duplicate Peak Troll Cave entrance remains removed')
check(any(o.get('object_id')=='mountain_cave_entrance' and o.get('area_id')=='side_of_mountain' for o in new['world']['objects']),
      'original Mountainside Troll Cave entrance remains')

# Runtime copies and packaged payloads agree.
for p in [ROOT/'assets/main.py', DEPLOY/'SGGF1Clean2.3/main.py']:
    check(p.is_file() and digest(p)==digest(main_path),f'runtime main.py matches: {p.relative_to(DEPLOY) if DEPLOY in p.parents else p.name}')
for p in [ROOT/'assets/luma_assets_e33.json', DEPLOY/'SGGF1Clean2.3/luma_assets_e33.json']:
    check(p.is_file() and digest(p)==digest(asset_path),f'runtime Luma JSON matches: {p.name}')
release=DEPLOY/'SGGF1Clean2.3'
apk=release/'sggf1clean2_3.apk'; tar=release/'sggf1clean2_3.tar.gz'
with zipfile.ZipFile(apk) as z:
    check(z.testzip() is None,'runtime APK ZIP passes integrity')
    check(z.read('assets/main.py')==main_path.read_bytes(),'APK main.py equals source')
    check(z.read('assets/luma_assets_e33.json')==asset_path.read_bytes(),'APK Luma JSON equals source')
with tarfile.open(tar,'r:gz') as t:
    check(t.extractfile('assets/main.py').read()==main_path.read_bytes(),'runtime TAR main.py equals source')
    check(t.extractfile('assets/luma_assets_e33.json').read()==asset_path.read_bytes(),'runtime TAR Luma JSON equals source')

# Source package's embedded deployment mirrors the standalone complete deploy.
source_mirror=ROOT.parent/'deploy'
check(tree_digest(source_mirror)==tree_digest(DEPLOY),'source ZIP embedded deploy tree matches complete deployment')

# Outer release ZIPs are checked after build by the calling build script.
print('ALL CLEAN2.3 STATIC REGRESSION CHECKS PASSED')
