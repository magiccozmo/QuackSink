import ast, copy, json, math, re, tarfile, zipfile
from pathlib import Path
BASE=Path(__file__).resolve().parent
old=json.loads((BASE/'BASELINES'/'F1q_luma_assets_e33.json').read_text(encoding='utf-8'))
new=json.loads((BASE/'luma_assets_e33.json').read_text(encoding='utf-8'))
assert new['version']=='F1.666f1r'
assert old['assets']==new['assets'], 'F1r must not redraw any art recipe; pineapple remains exact.'
# Exactly three data edits are permitted: Troll Cave navigation, Frosty home and PPP placement.
expected=copy.deepcopy(old)
expected['version']=new['version']
# Release bookkeeping only; these labels do not modify any art recipe or gameplay data.
expected['art_revision']=new['art_revision']
expected['notes']=new['notes']
old_areas={a['area_id']:a for a in expected['world']['areas']}
new_areas={a['area_id']:a for a in new['world']['areas']}
old_areas['troll_cave']['navigation']=copy.deepcopy(new_areas['troll_cave']['navigation'])
old_npcs={n['npc_id']:n for n in expected['world']['npcs']}
new_npcs={n['npc_id']:n for n in new['world']['npcs']}
old_npcs['troll']['x']=new_npcs['troll']['x']; old_npcs['troll']['y']=new_npcs['troll']['y']
old_objs={o['object_id']:o for o in expected['world']['objects']}
new_objs={o['object_id']:o for o in new['world']['objects']}
for field in ('x','y'): old_objs['purple_passion_pineapple'][field]=new_objs['purple_passion_pineapple'][field]
assert expected==new, 'Unexpected world/schema/data changes.'
assert new_npcs['troll']['x']==560 and new_npcs['troll']['y']==393
assert new_objs['purple_passion_pineapple']['x']==638 and new_objs['purple_passion_pineapple']['y']==370
assert old_objs['purple_passion_pineapple']['kind']==new_objs['purple_passion_pineapple']['kind']
assert old_objs['purple_passion_pineapple']['width']==new_objs['purple_passion_pineapple']['width']
assert old_objs['purple_passion_pineapple']['height']==new_objs['purple_passion_pineapple']['height']
# The floor polygon includes the player spawn, both authored arrival points and the exit trigger.
poly=new_areas['troll_cave']['navigation']['regions'][0]
def inside(x,y,p):
    inside=False; j=len(p)-1
    for i,(xi,yi) in enumerate(p):
        xj,yj=p[j]
        if ((yi>y)!=(yj>y)) and x < (xj-xi)*(y-yi)/(yj-yi)+xi: inside=not inside
        j=i
    return inside
for point in ((640,494),(640,520),(640,560),(560,407),(659,384)):
    assert inside(*point,poly), ('Important cave location outside walkmesh',point)
# Keep the upper rear alcove/wall and outer ceiling off the walkmesh.
for point in ((640,170),(560,220),(1200,120),(40,200)):
    assert not inside(*point,poly), ('Wall/alcove incorrectly walkable',point)
main=(BASE/'main.py').read_text(encoding='utf-8'); ast.parse(main)
assert 'VERSION = "F1.666f1r"' in main
assert 'class F1666f1rStateMachine(F1666f1qStateMachine)' in main
assert 'class F1666f1rInterface(F1666f1qInterface)' in main
assert 'machine = F1666f1rStateMachine(archive, config, warning)' in main
assert 'ui = F1666f1rInterface(machine)' in main
assert 'def e33_sorted_areas(game):' in main
assert 'areas = self.e33_sorted_areas(self.machine.game)' in main
assert 'enumerate(self.e33_sorted_areas(g))' in main
assert "g.current_area_id == 'hellgs_inn' and destination != 'hellgs_inn'" in main
assert "self.e33_fast_travel_open = False" in main
# Save migration must update only default positions and preserve moved/collected/angry state.
assert 'not g.c1_troll_angry' in main and 'not fruit.in_inventory and not fruit.moved' in main
assert "def _read_save(self, slot):" in main
chron=json.loads((BASE/'gallery_chronology_f1r.json').read_text(encoding='utf-8'))
names=[x['name'] for x in chron['images']]
pics=sorted(x.name for x in (BASE/'pics').iterdir() if x.is_file() and x.suffix.lower()=='.png')
assert len(pics)==35 and len(names)==35 and set(names)==set(pics)
assert chron['order']=='oldest_to_newest'
dates=[x['last_change_utc'] for x in chron['images']]
assert dates==sorted(dates)
site=BASE/'deploy'; catalog=json.loads((site/'versions.json').read_text(encoding='utf-8'))
assert catalog['versions'][0]['version']=='SGGF1.666f1r'
assert sum(bool(x.get('current')) for x in catalog['versions'])==1
assert catalog['versions'][0]['current'] is True
for html_name in ('index.html','versions.html'):
    html=(site/html_name).read_text(encoding='utf-8')
    m=re.search(r'const GALLERY_IMAGES = \[(.*?)\];',html,re.S); assert m
    gallery=json.loads('['+m.group(1)+']')
    assert [x['name'] for x in gallery]==names
    assert len({x['url'] for x in gallery})==35
    assert all(x['url'].endswith('/'+__import__('urllib.parse').parse.quote(x['name'],safe='')) for x in gallery)
newdir=site/'SGGF1.666f1r'
assert (newdir/'main.py').read_bytes()==(BASE/'main.py').read_bytes()
assert (newdir/'luma_assets_e33.json').read_bytes()==(BASE/'luma_assets_e33.json').read_bytes()
play=(newdir/'play.html').read_text(encoding='utf-8')
assert 'sggf1666f1r.tar.gz' in play and 'sggf1666f1r.apk' in play and 'F1.666f1r' in play
with zipfile.ZipFile(newdir/'sggf1666f1r.apk') as z:
    assert z.testzip() is None
    assert set(z.namelist())=={'assets/main.py','assets/luma_assets_e33.json'}
    assert z.read('assets/main.py')==(BASE/'main.py').read_bytes()
    assert z.read('assets/luma_assets_e33.json')==(BASE/'luma_assets_e33.json').read_bytes()
with tarfile.open(newdir/'sggf1666f1r.tar.gz','r:gz') as t:
    assert set(t.getnames())=={'assets/main.py','assets/luma_assets_e33.json'}
    assert t.extractfile('assets/main.py').read()==(BASE/'main.py').read_bytes()
    assert t.extractfile('assets/luma_assets_e33.json').read()==(BASE/'luma_assets_e33.json').read_bytes()
assert (site/'SGGF1.666f1q').is_dir(), 'Prior F1q release directory missing.'
for prior_bundle in ('sggf1666f1m.apk','sggf1666f1n.apk','sggf1666f1o.apk','sggf1666f1p.apk','sggf1666f1q.apk'):
    assert (site/'SGGF1.666f1q'/prior_bundle).is_file(), f'Prior runtime archive missing: {prior_bundle}'
print('F1r: JSON preservation, cave floor walkmesh, Frosty/PPP placement, save-migration guards, alphabetical Fast Travel, Hellgs hard lock, 35-image chronology, runtime and site catalogue checks passed.')
