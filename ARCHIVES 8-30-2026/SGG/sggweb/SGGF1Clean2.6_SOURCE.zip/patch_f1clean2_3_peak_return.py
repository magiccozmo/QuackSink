#!/usr/bin/env python3
"""Apply the focused SGGF1Clean2.3 Peak return landing patch to a Clean2.2 source folder."""
from pathlib import Path
import json, sys
root = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parent
asset = root / 'luma_assets_e33.json'
data = json.loads(asset.read_text(encoding='utf-8'))
connection = next(c for c in data['world']['connections'] if c['connection_id'] == 'peak_bottom_mountain_path')
assert connection['from_area_id'] == 'peak' and connection['to_area_id'] == 'mountain_path'
connection['arrival_x'], connection['arrival_y'] = 720.0, 190.0
data['version'] = 'F1Clean2.3'
data['art_revision'] = 'F1Clean2.3 — Peak return lands on the upper Mountain Path walkmesh beyond the summit-entry trigger.'
data.setdefault('notes', []).append('F1Clean2.3: corrected peak_bottom_mountain_path arrival to (720,190), on the upper Mountain Path walkmesh and outside the mountain_path_top_peak proximity radius. This prevents safe-spawn snapping back into Peak.')
asset.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
main = root / 'main.py'
s = main.read_text(encoding='utf-8').replace('VERSION = "F1Clean2.2"', 'VERSION = "F1Clean2.3"', 1)
main.write_text(s, encoding='utf-8')
print('Applied SGGF1Clean2.3 Peak return landing patch.')
