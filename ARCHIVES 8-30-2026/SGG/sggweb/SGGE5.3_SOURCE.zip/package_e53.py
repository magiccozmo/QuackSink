"""SGGE5.3: complete Cloudflare site, preserving E2.0-E5.2 history."""
from pathlib import Path
import ast, copy, hashlib, io, json, subprocess, sys, tarfile, zipfile

ROOT=Path('/mnt/data')
WORK=Path(__file__).resolve().parent
code=(WORK/'main.py').read_bytes()
assets=(WORK/'luma_assets_e33.json').read_bytes()
ast.parse(code.decode('utf-8'))
assert json.loads(assets)['version']=='SGGE5.3'
subprocess.run([sys.executable,str(WORK/'test_e53.py')],cwd=WORK,check=True)

NOTES="""SPIFFY'S GIFT — SGGE5.3 / CASTLE PATH GROUNDED TOPOLOGY REBUILD

Full Cloudflare static-site deployment: upload sgge5.3.zip.
Playable entry: SGGE5.3/play.html (or select E5.3 from the root version list).

Based on field-tested SGGE5.2. One-area redesign only: Castle Path.

What changed:
- Rebuilt the Castle Path scene as one continuous highland landscape, with a
  visible landmass supporting the fortress, gatehouse, road and surrounding
  woodland. The castle entrance is embedded in the ridge, not suspended in sky.
- Replaced the old oversized circular turn pads and segmented road pieces with
  one smoothly curved paved route, with a clear, broad winding approach to the
  castle gate.
- Added stone shoulders, individually placed flagstones, grounded retaining
  edges, rocks, pines, leafy trees, shrubs, ferns, flowers and trail lanterns.
- Eliminated the floating-tree / sky-planted decoration problem by placing all
  foreground nature props on visible terrain. The far tree line is grounded
  against the distant ridge.
- Generated the visible paved road and Castle Path navigation corridor from
  the SAME sampled centerline. Navigation width is 130px and matches the
  playable road more closely than the former 145px corridor.

What did NOT change:
- The Castle Path connections, edge directions, transition targets and
  arrival coordinates are unchanged.
- All other area artwork, geometry, world objects, NPCs, quests, inventory,
  saves and game mechanics are preserved.
- Only the c1_bg_castle_path art recipe and castle_path.navigation corridor
  were changed in the world/asset data. The Python engine changes are limited
  to version labels and a pass-through E5.3 state-machine wrapper.

Preservation:
All prior playable releases E2.0 through E5.2 are copied byte-for-byte into
this complete site ZIP. Only versions.json is updated to register E5.3.

Checks:
Python syntax, LumaDraw command schema, isolated Castle Path asset diff,
unchanged non-Castle-Path world data, unchanged connections and arrival points,
road/nav centerline alignment, all four incoming/edge arrival feet on the
paved corridor, embedded Pygbag APK/TAR contents, complete ZIP CRC and
bytewise historical member preservation.

The actual browser field test remains the final visual/gameplay check.
"""

# The Pygbag runtime payloads contain the exact source used in this release.
apkb=io.BytesIO()
with zipfile.ZipFile(apkb,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as apk:
    apk.writestr('assets/main.py',code)
    apk.writestr('assets/luma_assets_e33.json',assets)
tarb=io.BytesIO()
with tarfile.open(fileobj=tarb,mode='w:gz',compresslevel=9) as tf:
    for name,payload in (('assets/main.py',code),('assets/luma_assets_e33.json',assets)):
        info=tarfile.TarInfo(name)
        info.size=len(payload); info.mode=0o644; info.mtime=0
        tf.addfile(info,io.BytesIO(payload))

previous=ROOT/'sgge5.2.zip'
assert previous.exists(), previous
with zipfile.ZipFile(previous,'r') as old:
    assert old.testzip() is None
    old_names=old.namelist()
    required=('index.html','versions.json','SGGE5.2/play.html','SGGE5.2/favicon.png',
              'SGGE5.2/sgge52.apk','SGGE5.2/sgge52.tar.gz')
    assert all(name in old_names for name in required)
    page=old.read('SGGE5.2/play.html').decode('utf-8')
    assert 'SGGE5.2' in page and 'sgge52' in page
    page=page.replace('SGGE5.2','SGGE5.3').replace('sgge52','sgge53')
    assert 'SGGE5.3' in page and 'sgge53.apk' in page and 'sgge53.tar.gz' in page

    manifest=json.loads(old.read('versions.json'))
    for item in manifest['versions']:
        item['current']=False
    manifest['versions'].insert(0,{
        'version':'SGGE5.3',
        'title':'SGGE 5.3',
        'path':'SGGE5.3/play.html',
        'description':'Castle Path rebuilt as a grounded mountain approach: a continuous winding stone road, fortress embedded in the ridge, rooted woodland, and navigation generated from the same smooth centerline. Existing transitions preserved.',
        'current':True,
    })
    additions=[
        ('SGGE5.3/play.html',page.encode('utf-8')),
        ('SGGE5.3/favicon.png',old.read('SGGE5.2/favicon.png')),
        ('SGGE5.3/sgge53.apk',apkb.getvalue()),
        ('SGGE5.3/sgge53.tar.gz',tarb.getvalue()),
        ('SGGE5.3/README_SGGE53.txt',NOTES.encode('utf-8')),
    ]
    deploy=ROOT/'sgge5.3.zip'
    with zipfile.ZipFile(deploy,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=8) as out:
        for member in old.infolist():
            payload=(json.dumps(manifest,indent=2).encode('utf-8')
                     if member.filename=='versions.json' else old.read(member.filename))
            out.writestr(copy.copy(member),payload)
        for name,payload in additions:
            out.writestr(name,payload)

    with zipfile.ZipFile(deploy,'r') as z:
        assert z.testzip() is None
        assert len(z.namelist())==len(old_names)+len(additions)
        assert len(set(z.namelist()))==len(z.namelist())
        for name in old_names:
            if name!='versions.json':
                assert z.read(name)==old.read(name),name
        assert z.read('index.html')==old.read('index.html')
        vers=json.loads(z.read('versions.json'))['versions']
        assert vers[0]['version']=='SGGE5.3' and vers[0]['current'] is True
        with zipfile.ZipFile(io.BytesIO(z.read('SGGE5.3/sgge53.apk'))) as apk:
            assert apk.testzip() is None
            assert apk.read('assets/main.py')==code
            assert apk.read('assets/luma_assets_e33.json')==assets
        with tarfile.open(fileobj=io.BytesIO(z.read('SGGE5.3/sgge53.tar.gz')),mode='r:gz') as tf:
            assert tf.extractfile('assets/main.py').read()==code
            assert tf.extractfile('assets/luma_assets_e33.json').read()==assets
    print(f'PASS complete deploy: {len(old_names)} historical entries preserved; {len(additions)} new entries added')

source=ROOT/'SGGE5.3_SOURCE.zip'
with zipfile.ZipFile(source,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as out:
    for filename in ('main.py','luma_assets_e33.json','build_e53_castle_path.py','test_e53.py','package_e53.py'):
        out.write(WORK/filename,filename)
    out.write(WORK/'E53_CASTLE_PATH_BACKGROUND.png','E53_CASTLE_PATH_BACKGROUND.png')
    out.write(WORK/'E53_CASTLE_PATH_COMPOSITE.png','E53_CASTLE_PATH_COMPOSITE.png')
    out.write(WORK/'E53_CASTLE_PATH_NAV_AUDIT.png','E53_CASTLE_PATH_NAV_AUDIT.png')
    out.write(WORK/'castle_exterior_ref.png','CASTLE_EXTERIOR_REFERENCE.png')
    out.writestr('BUILD_NOTES.txt',NOTES.encode('utf-8'))
with zipfile.ZipFile(source,'r') as z:
    assert z.testzip() is None

print('DEPLOY:',deploy,deploy.stat().st_size,'bytes')
print('SOURCE:',source,source.stat().st_size,'bytes')
print('SHA256:',hashlib.sha256(deploy.read_bytes()).hexdigest())
