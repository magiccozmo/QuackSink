"""SGGE5.3 -- grounded Castle Path terrain, road and castle approach.

The visible road and the collision/navigation corridor are generated from one
smooth centerline.  The old oversize circular switchback pads and sky-planted
vegetation are removed.  All other game scenes and mechanics remain intact.
"""
from __future__ import annotations
from pathlib import Path
import json, math, random
from PIL import Image, ImageDraw

HERE=Path(__file__).resolve().parent
ASSET_FILE=HERE/'luma_assets_e33.json'
OUT_BG=HERE/'E53_CASTLE_PATH_BACKGROUND.png'
OUT_COMPOSITE=HERE/'E53_CASTLE_PATH_COMPOSITE.png'
J=json.loads(ASSET_FILE.read_text(encoding='utf-8'))
R=random.Random(530104)
C=[]

def RGB(c): return [max(0,min(255,int(round(v)))) for v in c]
def mix(a,b,t): return tuple(int(round(a[i]*(1-t)+b[i]*t)) for i in range(3))
def jitter(c,n=6): return tuple(max(0,min(255,int(round(v+R.uniform(-n,n))))) for v in c)
def rect(x,y,w,h,c,r=0,border=0):
    d={'op':'rect','rect':[int(round(x)),int(round(y)),max(1,int(round(w))),max(1,int(round(h)))],'color':RGB(c)}
    if r:d['radius']=int(round(r))
    if border:d['border']=int(round(border))
    C.append(d)
def poly(points,c,border=0):
    d={'op':'polygon','points':[[int(round(x)),int(round(y))] for x,y in points],'color':RGB(c)}
    if border:d['border']=int(round(border))
    C.append(d)
def line(points,c,w=1):
    C.append({'op':'line','points':[[int(round(x)),int(round(y))] for x,y in points],
              'color':RGB(c),'width':max(1,int(round(w)))})
def oval(x,y,w,h,c,border=0):
    d={'op':'ellipse','rect':[int(round(x)),int(round(y)),max(1,int(round(w))),max(1,int(round(h)))],'color':RGB(c)}
    if border:d['border']=int(round(border))
    C.append(d)
def circ(x,y,r,c,border=0):
    d={'op':'circle','center':[int(round(x)),int(round(y))],
       'radius':max(1,int(round(r))),'color':RGB(c)}
    if border:d['border']=int(round(border))
    C.append(d)

def unit(v):
    d=math.hypot(v[0],v[1]) or 1.0
    return (v[0]/d,v[1]/d)
def lerp(a,b,t): return (a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t)
def sample_line(a,b,step=5.0):
    d=math.dist(a,b); n=max(1,int(math.ceil(d/step)))
    return [lerp(a,b,i/n) for i in range(1,n+1)]

def make_centerline(points,trim=60.0):
    """Rounded polyline. Large-radius quadratic joins; no circular pad blobs."""
    out=[tuple(points[0])]
    for i in range(1,len(points)-1):
        p=points[i]
        u0=unit((p[0]-points[i-1][0],p[1]-points[i-1][1]))
        u1=unit((points[i+1][0]-p[0],points[i+1][1]-p[1]))
        t=min(trim,math.dist(points[i-1],p)*.30,math.dist(points[i+1],p)*.30)
        before=(p[0]-u0[0]*t,p[1]-u0[1]*t)
        after=(p[0]+u1[0]*t,p[1]+u1[1]*t)
        out.extend(sample_line(out[-1],before,5.0))
        for k in range(1,17):
            q=k/16
            x=(1-q)*(1-q)*before[0]+2*(1-q)*q*p[0]+q*q*after[0]
            y=(1-q)*(1-q)*before[1]+2*(1-q)*q*p[1]+q*q*after[1]
            out.append((x,y))
    out.extend(sample_line(out[-1],points[-1],5.0))
    return out

# One continuous uphill road, with broad turns instead of abrupt hairpins.
# It joins both existing transition arrivals: Castle Exterior return at
# (640,129) foot position, and Gold District arrival at (640,524).
CONTROL=[(640.0,44.0),(640.0,175.0),(690.0,235.0),
         (775.0,295.0),(825.0,380.0),(780.0,460.0),
         (685.0,515.0),(640.0,540.0),(640.0,614.0)]
CENTER=make_centerline(CONTROL,trim=60.0)
CUM=[0.0]
for a,b in zip(CENTER,CENTER[1:]): CUM.append(CUM[-1]+math.dist(a,b))
TOTAL=CUM[-1]

def tangent_at(i):
    if i<=0: return unit((CENTER[1][0]-CENTER[0][0],CENTER[1][1]-CENTER[0][1]))
    if i>=len(CENTER)-1: return unit((CENTER[-1][0]-CENTER[-2][0],CENTER[-1][1]-CENTER[-2][1]))
    return unit((CENTER[i+1][0]-CENTER[i-1][0],CENTER[i+1][1]-CENTER[i-1][1]))

def point_at(s):
    s=max(0.0,min(TOTAL,s)); lo=0; hi=len(CUM)-1
    while lo<hi:
        mid=(lo+hi)//2
        if CUM[mid]<s:lo=mid+1
        else:hi=mid
    i=max(1,lo); span=max(.001,CUM[i]-CUM[i-1]); t=(s-CUM[i-1])/span
    p=lerp(CENTER[i-1],CENTER[i],t)
    tan=unit((CENTER[i][0]-CENTER[i-1][0],CENTER[i][1]-CENTER[i-1][1]))
    return p,tan

def half_width(s):
    t=max(0.0,min(1.0,s/TOTAL))
    return 50.0+5.0*t

def ribbon_polygon(extra=0.0):
    left=[]; right=[]
    for i,p in enumerate(CENTER):
        tx,ty=tangent_at(i); nx,ny=-ty,tx; h=half_width(CUM[i])+extra
        left.append((p[0]+nx*h,p[1]+ny*h))
        right.append((p[0]-nx*h,p[1]-ny*h))
    return left+list(reversed(right))

def path_distance(x,y):
    return min(segment_distance((x,y),a,b) for a,b in zip(CENTER,CENTER[1:]))
def segment_distance(p,a,b):
    vx=b[0]-a[0];vy=b[1]-a[1];den=vx*vx+vy*vy
    t=0.0 if den==0 else max(0.0,min(1.0,((p[0]-a[0])*vx+(p[1]-a[1])*vy)/den))
    return math.dist(p,(a[0]+vx*t,a[1]+vy*t))

# Palette: highland grass, weathered limestone and dark green woodland.
sky_top=(73,126,158); sky_low=(189,199,183)
far_blue=(111,140,143); far_green=(94,126,112)
hill_deep=(79,111,83); hill_mid=(93,128,89); hill_light=(117,148,99)
grass=(94,129,84); grass_sun=(126,153,99); grass_shadow=(73,105,74)
rock=(119,119,108); rock_light=(158,154,136); rock_dark=(78,84,78)
wall=(133,135,126); wall_light=(177,173,153); wall_dark=(75,79,74)
stone=(139,133,119); stone_light=(177,169,147); stone_mid=(157,150,132)
stone_dark=(92,91,82); mortar=(88,86,77)
timber=(91,62,45); wood=(121,78,48); gold=(238,187,92)
pine=(38,85,68); pine_light=(65,119,86); leaf=(70,126,74); leaf_light=(103,151,84)
flower_y=(238,207,123); flower_p=(213,172,208); flower_w=(224,227,209)

# ---------------------------------------------------------------------------
# 1) SKY: only clouds and distant mountain silhouettes belong above the ridge.
# ---------------------------------------------------------------------------
for y in range(0,354,7):
    t=max(0.0,min(1.0,y/354))
    rect(0,y,1280,7,mix(sky_top,sky_low,t))
for cx,cy,s in ((155,105,1.0),(390,84,.83),(1035,88,.95),(1170,142,.68)):
    col=(231,235,226)
    for dx,dy,w,h in ((-47,5,77,21),(-19,-7,63,26),(20,-4,69,23),(52,5,48,17)):
        oval(cx+dx*s,cy+dy*s,w*s,h*s,col)
# Distant ridge lies below all clouds and establishes a real horizon.
far=[(0,355)]
for x in range(0,1281,24):
    y=318+17*math.sin(x/136)+10*math.cos(x/57)+4*math.sin(x/21)
    far.append((x,y))
far += [(1280,420),(0,420)]
poly(far,far_blue)
mid=[(0,392)]
for x in range(0,1281,26):
    y=354+20*math.sin(x/157+1.0)+9*math.cos(x/62)+3*math.sin(x/19)
    mid.append((x,y))
mid += [(1280,449),(0,449)]
poly(mid,far_green)
# Very distant treeline is tiny and attached to the far ridge, not scattered in sky.
for x in range(0,1280,17):
    base=365+10*math.sin(x/151)+4*math.sin(x/29)
    h=R.randint(11,23); w=R.randint(5,10)
    col=R.choice([(66,102,88),(75,113,95),(84,120,100)])
    poly([(x-w,base),(x-w*.5,base-h*.45),(x,base-h),(x+w*.55,base-h*.42),(x+w,base)],col)

# ---------------------------------------------------------------------------
# 2) CONTINUOUS MOUNTAIN LANDMASS: a central castle spur with descending
#    shoulders into the lower foothills. The castle and entire route sit on it.
# ---------------------------------------------------------------------------
# Broad upper slope rises to a high plateau directly beneath the fortress.
land_top=[(0,438),(85,418),(170,385),(258,345),(335,291),(410,242),
          (492,207),(570,185),(650,178),(731,184),(811,207),(889,246),
          (960,294),(1040,339),(1135,374),(1210,397),(1280,420)]
poly(land_top+[(1280,640),(0,640)],hill_deep)
# Main grass planes overlap to create a readable downhill slope rather than stripes.
poly([(0,476),(120,438),(222,406),(319,362),(408,317),(512,283),(622,266),
      (740,270),(845,294),(958,340),(1071,380),(1184,417),(1280,444),
      (1280,640),(0,640)],hill_mid)
poly([(0,552),(142,500),(274,470),(398,432),(522,412),(648,414),(785,424),
      (906,452),(1036,475),(1158,502),(1280,535),(1280,640),(0,640)],grass)
poly([(0,615),(165,573),(327,556),(482,536),(646,535),(813,549),(977,572),
      (1135,600),(1280,621),(1280,640),(0,640)],grass_shadow)
# A high rocky shelf directly supports the castle wall and gate foundations.
poly([(352,238),(400,199),(470,183),(558,170),(640,166),(724,171),(812,186),
      (885,212),(932,254),(952,306),(917,331),(841,320),(770,300),(681,288),
      (597,296),(507,315),(423,303),(365,276)],rock_dark)
poly([(365,225),(417,193),(489,180),(574,173),(646,171),(721,179),(800,194),
      (865,219),(909,254),(919,288),(884,306),(817,293),(740,275),(660,265),
      (575,274),(489,289),(418,281),(376,258)],(139,139,125))
# Exposed ledges / soil strata on the lower side of the spur.
for pts,col in [
    ([(344,283),(414,273),(483,292),(509,315),(466,330),(385,322)],(113,112,100)),
    ([(780,285),(865,273),(932,300),(972,339),(913,350),(831,327)],(108,109,98)),
    ([(246,352),(335,326),(409,338),(458,367),(400,383),(305,383)],(105,110,92)),
    ([(901,360),(1005,335),(1097,367),(1153,408),(1068,422),(963,401)],(100,108,91)),
]: poly(pts,col)
# Surface contour seams: restrained, following the slope diagonally.
for pts in [
    [(18,468),(142,430),(250,392),(333,350)],
    [(947,322),(1042,363),(1142,392),(1250,417)],
    [(48,564),(181,526),(295,498),(418,466)],
    [(858,463),(978,484),(1093,515),(1220,548)],
]: line(pts,(128,151,103),2)

# ---------------------------------------------------------------------------
# 3) CASTLE GATE: a fortress built into the hilltop. The road visibly enters
#    the gateway; the wall foundations overlap the rocky shelf below.
# ---------------------------------------------------------------------------
# Keep silhouettes rise behind the rampart.
poly([(380,178),(380,88),(404,88),(404,61),(431,61),(431,84),(458,84),(458,49),
      (485,49),(485,84),(509,84),(509,178)],(105,111,104))
poly([(771,178),(771,84),(795,84),(795,50),(822,50),(822,84),(846,84),(846,62),
      (873,62),(873,86),(899,86),(899,178)],(101,108,101))
# Main curtain wall and lower base course.
rect(385,119,514,95,(129,133,124))
rect(377,194,532,25,(96,100,93))
# Tower masses, with real bases and merlons tied to the wall.
for x in (388,804):
    rect(x,78,88,139,(119,126,119))
    rect(x+8,86,72,125,(148,151,138))
    rect(x-4,72,96,13,(88,95,88))
    for bx in range(x+2,x+95,21):
        rect(bx,59,13,20,(133,139,126))
        rect(bx+2,61,9,16,(159,158,140))
    rect(x+31,105,27,54,(70,76,72))
    rect(x+36,110,17,44,(50,59,58))
    line([(x+44,113),(x+44,150)],(107,112,104),2)
    rect(x+20,180,49,9,(178,173,149))
# Crenellations on the low connecting rampart.
for x in range(480,810,26):
    rect(x,104,15,24,(143,147,135))
    rect(x+3,107,9,17,(165,164,146))
# Gatehouse stone frame: a thick, grounded arch, not a floating portal.
poly([(528,218),(528,142),(543,103),(570,73),(606,53),(640,43),(674,53),
      (710,73),(737,103),(752,142),(752,218)],(86,91,85))
poly([(540,215),(540,142),(555,107),(582,81),(610,64),(640,57),(670,64),
      (698,81),(725,107),(740,142),(740,215)],(164,161,142))
# Dark gate throat and interior passage floor, continuing beyond the top edge.
poly([(550,215),(550,137),(562,108),(585,84),(640,68),(695,84),(718,108),
      (730,137),(730,215)],(48,54,52))
poly([(562,213),(562,139),(575,111),(610,82),(670,82),(705,111),(718,139),(718,213)],(68,76,70))
# Gate timber and ironwork are open enough to read as a passage, not a wall.
rect(566,112,8,75,(90,61,42)); rect(706,112,8,75,(90,61,42))
for x in (590,640,690):
    rect(x-2,121,4,66,(111,75,48))
line([(562,159),(718,159)],(102,104,96),4)
for x in (570,710): circ(x,159,3,(191,155,89))
# Stone blocks on the flanking wall, varied courses and mortar.
for x0,x1 in ((386,555),(725,897)):
    for row,y in enumerate(range(124,211,15)):
        x=x0+(row%2)*10
        while x<x1-10:
            w=R.randint(20,34)
            col=jitter(R.choice([(145,148,136),(129,135,127),(158,157,140),(137,141,132)]),5)
            rect(x,y,w,12,col)
            line([(x+2,y+2),(x+w-3,y+2)],(184,179,157),1)
            x+=w+3
# Buttresses and stone steps hold the approach into the gate.
for x in (553,719):
    poly([(x,205),(x+24,205),(x+39,258),(x-11,258)],(105,111,103))
    poly([(x+6,208),(x+20,208),(x+29,247),(x-2,247)],(151,150,132))
# Gate landing: paving lies beneath the entrance and ties into the road.
poly([(578,230),(702,230),(710,164),(570,164)],(112,111,98))
for row,y in enumerate(range(173,231,13)):
    x=579+(row%2)*12
    while x<702:
        w=R.randint(22,31)
        rect(x,y,w,10,jitter((164,159,141),5))
        line([(x+2,y+2),(x+w-2,y+2)],(197,188,164),1)
        x+=w+3

# ---------------------------------------------------------------------------
# 4) GROUNDED LANDSCAPE DETAILS. Every tree/rock/flower has a base on the
#    actual land surface; nothing is planted in the sky.
# ---------------------------------------------------------------------------
# Grass flecks only on terrain below y=300, and outside the future road ribbon.
for i in range(780):
    x=R.randint(5,1275); y=R.randint(315,637)
    if path_distance(x,y)<82: continue
    col=jitter(R.choice([(125,153,101),(111,144,94),(81,119,80),(146,164,111)]),8)
    h=R.randint(3,9)
    line([(x,y),(x+R.randint(-2,2),y-h)],col,1)

# Helper primitives: all base_y values represent actual contact with ground.
def pine_tree(cx,base_y,scale=1.0,variant=0):
    h=R.randint(80,112)*scale; w=h*.50
    oval(cx-w*.40,base_y-5,w*.80,12*scale,(59,81,61))
    trunk_w=max(3,4.5*scale)
    rect(cx-trunk_w/2,base_y-h*.31,trunk_w,h*.31,(91,67,46))
    for tier in range(5):
        yy=base_y-h*(.36+tier*.125); tierw=w*(.24+tier*.17)
        pts=[(cx-tierw*.72,yy+h*.11),(cx-tierw*.38,yy+h*.04),(cx-tierw*.52,yy-h*.04),
             (cx-tierw*.18,yy-h*.12),(cx,yy-h*.24),(cx+tierw*.20,yy-h*.12),
             (cx+tierw*.53,yy-h*.03),(cx+tierw*.42,yy+h*.04),(cx+tierw*.76,yy+h*.11)]
        col=jitter((42+variant*5,88+variant*4,67+variant*3),7)
        poly(pts,col)
        line([(cx-tierw*.36,yy+h*.015),(cx-tierw*.04,yy-h*.14),(cx+tierw*.31,yy+h*.02)],
             jitter((94,139,91),7),max(1,round(2*scale)))

def leafy_tree(cx,base_y,scale=1.0):
    h=R.randint(74,99)*scale; w=h*.72
    oval(cx-w*.44,base_y-4,w*.88,12*scale,(63,84,62))
    rect(cx-4*scale,base_y-h*.37,8*scale,h*.39,(102,72,48))
    line([(cx,base_y-h*.2),(cx-w*.19,base_y-h*.53)],(105,74,47),max(2,round(3*scale)))
    line([(cx,base_y-h*.31),(cx+w*.2,base_y-h*.61)],(105,74,47),max(2,round(3*scale)))
    for dx,dy,r in [(-.22,-.62,.30),(.04,-.73,.34),(.28,-.63,.29),(-.03,-.53,.34),(-.38,-.52,.22),(.40,-.51,.22)]:
        col=R.choice([(60,112,70),(73,126,75),(86,137,81),(101,149,88)])
        oval(cx+(dx-r/2)*w,base_y+dy*h,w*r,h*r*.82,col)
    for i in range(7):
        x=cx+R.uniform(-.35,.35)*w; y=base_y-R.uniform(.48,.75)*h
        circ(x,y,2.0*scale,R.choice([(135,164,101),(159,176,110),(69,119,74)]))

def boulder(cx,base_y,scale=1.0):
    w=R.randint(30,52)*scale; h=R.randint(20,34)*scale
    oval(cx-w*.58,base_y-3,w*1.16,9*scale,(62,80,62))
    pts=[(cx-w*.55,base_y-h*.20),(cx-w*.37,base_y-h*.74),(cx-w*.04,base_y-h),
         (cx+w*.31,base_y-h*.83),(cx+w*.56,base_y-h*.22),(cx+w*.38,base_y),(cx-w*.38,base_y)]
    poly(pts,jitter((119,122,111),6))
    poly([(cx-w*.35,base_y-h*.72),(cx-w*.03,base_y-h*.95),(cx+w*.18,base_y-h*.78),
          (cx-w*.02,base_y-h*.55)],(157,157,141))

def shrub(cx,base_y,scale=1.0):
    w=R.randint(35,56)*scale; h=R.randint(24,37)*scale
    oval(cx-w*.55,base_y-3,w*1.10,8*scale,(66,88,63))
    for dx,dy,r in [(-.32,-.40,.35),(-.05,-.60,.39),(.27,-.42,.34),(.02,-.30,.39)]:
        oval(cx+(dx-r/2)*w,base_y+dy*h,w*r,h*r,jitter(R.choice([(70,125,73),(85,139,80),(101,151,90)]),5))

# Outer slopes carry trees, rocks and scrub. All planting bases stay on visible ground.
for spec in [
    (82,500,.96,0,'pine'),(205,423,.88,1,'leaf'),(315,355,.73,0,'pine'),
    (1080,505,.95,1,'leaf'),(1180,432,.84,0,'pine'),(965,354,.72,1,'pine'),
    (430,304,.62,0,'pine'),(865,308,.62,1,'leaf'),(151,590,.72,1,'leaf'),
    (1115,590,.72,0,'pine'),(385,555,.74,0,'pine'),(910,552,.78,1,'leaf'),
]:
    x,y,s,v,kind=spec
    if path_distance(x,y)>94:
        (pine_tree if kind=='pine' else leafy_tree)(x,y,s,v) if kind=='pine' else leafy_tree(x,y,s)
for x,y,s in [(270,520,.9),(350,392,.7),(1005,515,.9),(1195,545,.76),
              (118,362,.7),(1130,365,.76),(442,594,.72),(864,596,.72)]:
    if path_distance(x,y)>92: boulder(x,y,s)
for x,y,s in [(155,470,.92),(275,570,.8),(1005,460,.9),(1175,496,.85),
              (55,590,.72),(1220,600,.7),(450,500,.65),(845,500,.72)]:
    if path_distance(x,y)>88: shrub(x,y,s)

# Distant ridge trees have a clear ground contact line at the top of the hill.
for x,y,s in [(90,420,.45),(190,388,.40),(1080,413,.42),(1190,438,.40)]:
    pine_tree(x,y,s,0)

# Flower beds only on the lower shoulders, planted into turf with a visible base.
for cx,cy,scale in [(145,548,1.0),(282,465,.86),(1025,552,1.0),(1160,474,.82),
                    (70,430,.7),(1214,592,.72),(405,590,.74),(900,590,.74)]:
    if path_distance(cx,cy)<86: continue
    oval(cx-34*scale,cy+4,68*scale,15*scale,(65,91,63))
    for i in range(8):
        x=cx+R.uniform(-27,27)*scale; h=R.uniform(10,23)*scale
        line([(x,cy+9),(x+R.uniform(-2,2),cy-h)],jitter((83,137,80),7),2)
        circ(x,cy-h,3*scale,R.choice([flower_y,flower_p,flower_w,(194,208,164)]))

# ---------------------------------------------------------------------------
# 5) THE ROAD: one smooth ribbon from the lower entrance into the castle gate.
#    Edges, cobbles and the walk corridor share this exact centerline.
# ---------------------------------------------------------------------------
# Retaining walls on the outside of selected switchbacks. They are short,
# grounded terrace walls, not floating rails or continuous cartoon outlines.
def retaining_run(points,block=27):
    for a,b in zip(points,points[1:]):
        d=math.dist(a,b)
        if d<12: continue
        tx,ty=unit((b[0]-a[0],b[1]-a[1])); nx,ny=-ty,tx
        line([(a[0],a[1]),(b[0],b[1])],(75,80,72),8)
        line([(a[0]+nx*2,a[1]+ny*2),(b[0]+nx*2,b[1]+ny*2)],(181,172,148),2)
        n=max(1,int(d/block))
        for i in range(n):
            t=(i+.1)/n; x=a[0]+(b[0]-a[0])*t; y=a[1]+(b[1]-a[1])*t
            poly([(x-tx*10-nx*4,y-ty*10-ny*4),(x+tx*10-nx*4,y+ty*10-ny*4),
                  (x+tx*10+nx*4,y+ty*10+ny*4),(x-tx*10+nx*4,y-ty*10+ny*4)],
                 jitter((139,138,123),5))
# Segments are kept outside the track. They act as low supporting walls at bends.
retaining_run([(435,327),(470,339),(496,359)],block=24)
retaining_run([(765,286),(804,304),(828,332)],block=24)
retaining_run([(590,474),(624,491),(650,509)],block=26)

# Ground shadow / cut earth border / stone shoulder / paved surface.
poly(ribbon_polygon(17),(63,74,64))
poly(ribbon_polygon(10),(91,92,81))
poly(ribbon_polygon(4),(132,128,114))
poly(ribbon_polygon(0),(166,158,140))
# Slight warm center wear, inset from the stone edges.
# The pale inset follows the same ribbon and never changes the route geometry.
# Build an inner ribbon at 75% width by temporarily using a custom helper.
def ribbon_scaled(factor):
    left=[];right=[]
    for i,p in enumerate(CENTER):
        tx,ty=tangent_at(i);nx,ny=-ty,tx;h=half_width(CUM[i])*factor
        left.append((p[0]+nx*h,p[1]+ny*h));right.append((p[0]-nx*h,p[1]-ny*h))
    return left+list(reversed(right))
poly(ribbon_scaled(.78),(177,168,148))
# Edge curb blocks are tangent-aligned and sampled along the same continuous curve.
s=8.0
while s<TOTAL-8:
    p,tan=point_at(s); tx,ty=tan; nx,ny=-ty,tx; h=half_width(s)-2
    for side in (-1,1):
        cx=p[0]+nx*side*h; cy=p[1]+ny*side*h
        length=R.uniform(12,18); thick=R.uniform(4,6)
        quad=[(cx-tx*length/2-nx*thick/2,cy-ty*length/2-ny*thick/2),
              (cx+tx*length/2-nx*thick/2,cy+ty*length/2-ny*thick/2),
              (cx+tx*length/2+nx*thick/2,cy+ty*length/2+ny*thick/2),
              (cx-tx*length/2+nx*thick/2,cy-ty*length/2+ny*thick/2)]
        poly(quad,jitter((139,132,115),6))
    s+=R.uniform(15,19)
# Individually laid crosswise flagstones, following the road's local tangent.
s=7.0
while s<TOTAL-7:
    p,(tx,ty)=point_at(s); nx,ny=-ty,tx; half=half_width(s)*.76
    cross=-half+4
    while cross<half-4:
        w=min(R.uniform(18,27),half-4-cross)
        depth=R.uniform(10,15)
        off=R.uniform(-1.0,1.0)
        mx=p[0]+nx*(cross+w/2)+tx*off; my=p[1]+ny*(cross+w/2)+ty*off
        hh=depth/2; skew=R.uniform(-1.2,1.2)
        pts=[(mx-nx*w/2-tx*hh,my-ny*w/2-ty*hh),
             (mx+nx*w/2-tx*hh*.82,my+ny*w/2-ty*hh*.82),
             (mx+nx*(w/2+skew)+tx*hh,my+ny*(w/2+skew)+ty*hh),
             (mx-nx*(w/2-skew)+tx*hh*.84,my-ny*(w/2-skew)+ty*hh*.84)]
        col=jitter(R.choice([(151,145,129),(165,157,139),(139,134,121),
                             (179,169,148),(129,126,116),(158,152,138)]),7)
        poly(pts,col)
        if R.random()<.34:
            line([lerp(pts[3],pts[2],.18),lerp(pts[3],pts[2],.82)],mix(col,(221,211,188),.32),1)
        cross+=w+R.uniform(2.4,3.8)
    s+=R.uniform(12.5,15.5)
# A few uneven worn pavers and shallow grooves at the outside of the route.
for i in range(100):
    s=R.uniform(0,TOTAL); p,(tx,ty)=point_at(s); nx,ny=-ty,tx
    side=R.choice([-1,1]); off=half_width(s)+R.uniform(8,22)
    x=p[0]+nx*side*off; y=p[1]+ny*side*off
    if 10<x<1270 and 44<y<638:
        line([(x,y),(x+R.uniform(3,9),y+R.uniform(-1,2))],jitter((137,130,112),9),1)

# ---------------------------------------------------------------------------
# 6) WAYFINDING: lanterns and markers planted at actual path-side ground bases.
# ---------------------------------------------------------------------------
def trail_lantern(x,y,scale=1.0):
    oval(x-15*scale,y-4*scale,30*scale,9*scale,(57,77,59))
    rect(x-4*scale,y-57*scale,8*scale,57*scale,(91,66,46))
    rect(x-12*scale,y-62*scale,24*scale,7*scale,(132,101,68))
    rect(x-10*scale,y-45*scale,20*scale,26*scale,(78,58,44))
    rect(x-7*scale,y-42*scale,14*scale,20*scale,(241,181,91))
    poly([(x-7*scale,y-42*scale),(x,y-51*scale),(x+7*scale,y-42*scale)],(216,145,73))
    line([(x-13*scale,y-18*scale),(x+13*scale,y-18*scale)],(115,82,52),3*scale)
for x,y,s in [(410,435,.92),(905,397,.90),(421,555,.78),(891,560,.78)]:
    if path_distance(x,y)>half_width(TOTAL)*.5+28: trail_lantern(x,y,s)
# carved trail marker stones at two grounded bends.
for x,y,h in [(392,440,34),(917,355,39)]:
    oval(x-21,y+2,42,12,(61,79,60))
    poly([(x-15,y),(x-12,y-h+9),(x-6,y-h),(x+8,y-h+2),(x+14,y),(x+14,y+5),(x-15,y+5)],(133,131,115))
    line([(x-4,y-h*.55),(x,y-h*.75),(x+5,y-h*.55)],(207,192,155),2)
# Small trail-side fern clusters, bases firmly on turf.
for x,y,s in [(175,508,.9),(1080,500,.9),(285,415,.72),(1005,425,.74),(76,594,.8),(1190,594,.75)]:
    if path_distance(x,y)>85:
        oval(x-14,y-2,28,7,(67,90,64))
        for k in range(7):
            ang=-1.35+k*.43; ex=x+math.cos(ang)*18*s; ey=y-math.sin(ang)*25*s
            line([(x,y),(ex,ey)],(66,124,78),2)
            for q in (.36,.68):
                bx=x+(ex-x)*q; by=y+(ey-y)*q
                oval(bx-5,by-3,10,5,jitter((96,148,88),6))

# Ground contact audit for all manually placed plant/rock/lantern base points.
# (All planting bases are below the ridgeline, y >= 300.)
assert all(y>=300 for x,y,s,*rest in [
    (82,500,.96),(205,423,.88),(315,355,.73),(1080,505,.95),(1180,432,.84),
    (965,354,.72),(430,304,.62),(865,308,.62),(151,590,.72),(1115,590,.72),
    (385,555,.74),(910,552,.78)
])

# ---------------------------------------------------------------------------
# 7) WORLD UPDATE: background and navigation corridor are generated together.
#    Transitions/arrival points/objects/NPCs and all other areas are unchanged.
# ---------------------------------------------------------------------------
J['assets']['c1_bg_castle_path']={'width':1280,'height':640,'commands':C}
AREA=next(a for a in J['world']['areas'] if a['area_id']=='castle_path')
# Downsample the same smooth centerline to a compact, accurate walk corridor.
nav=[]
for i,p in enumerate(CENTER):
    if i==0 or i==len(CENTER)-1 or i%5==0:
        q=[int(round(p[0])),int(round(p[1]))]
        if not nav or q!=nav[-1]:nav.append(q)
# Keep the two transition points exact at the ends.
nav[0]=[640,44]; nav[-1]=[640,614]
AREA['navigation']={'corridors':[[nav,130]]}
J['version']='SGGE5.3'
J['art_revision']='SGGE5.3: Castle Path topology and landscape rebuilt together. The paved road is one smooth grounded switchback from the Gold District foothill to a castle gate built into the ridge; continuous hills, realistic retaining edges, rooted trees, ground-contact rocks and planted flowers replace the floating scenery. The visual road and walkable corridor share one centerline.'
J['notes']='SGGE5.3 updates only Castle Path artwork and its matching navigation corridor. Existing top/bottom connections, arrival coordinates, all other area art/world objects/NPCs and gameplay systems are preserved.'
ASSET_FILE.write_text(json.dumps(J,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')

# ---------------------------------------------------------------------------
# Preview: native-resolution background and an actual player composite.
# ---------------------------------------------------------------------------
def render_commands(image,commands):
    d=ImageDraw.Draw(image)
    for c in commands:
        op=c['op']; col=tuple(c['color'])
        if op=='rect':
            x,y,w,h=c['rect']; d.rectangle((x,y,x+w-1,y+h-1),fill=col)
        elif op=='ellipse':
            x,y,w,h=c['rect']; d.ellipse((x,y,x+w-1,y+h-1),fill=col)
        elif op=='circle':
            x,y=c['center'];r=c['radius'];d.ellipse((x-r,y-r,x+r,y+r),fill=col)
        elif op=='polygon':d.polygon([tuple(p) for p in c['points']],fill=col)
        elif op=='line':d.line([tuple(p) for p in c['points']],fill=col,width=c.get('width',1),joint='curve')
    return image
bg=Image.new('RGB',(1280,640),(20,20,25));render_commands(bg,C);bg.save(OUT_BG)
composite=bg.convert('RGBA')
player=J['assets']['player']; pw,ph=40,58
sprite=Image.new('RGBA',(pw,ph),(0,0,0,0));render_commands(sprite,player['commands'])
# Place Spiffy on the middle of the paved climb, not on a turn edge.
(px,py),_=point_at(TOTAL*.52)
composite.alpha_composite(sprite,(round(px-pw/2),round(py-ph*.70)))
composite.convert('RGB').save(OUT_COMPOSITE)

# Debug preview with walk corridor boundary for geometric QA, not shipped as art.
debug=bg.copy(); dd=ImageDraw.Draw(debug)
pts=[]
for p in CENTER:
    tx,ty=tangent_at(CENTER.index(p)) if False else (0,0)
    pts.append((round(p[0]),round(p[1])))
dd.line(pts,fill=(238,59,48),width=2)
# sampled left/right boundary curves
for side in (-1,1):
    edge=[]
    for i,p in enumerate(CENTER):
        tx,ty=tangent_at(i);nx,ny=-ty,tx;h=half_width(CUM[i])
        edge.append((round(p[0]+nx*side*h),round(p[1]+ny*side*h)))
    dd.line(edge,fill=(247,224,76),width=2)
debug.save(HERE/'E53_CASTLE_PATH_NAV_AUDIT.png')
print(f'Castle Path E5.3: {len(C)} drawing commands, {len(CENTER)} smooth samples, {len(nav)} navigation nodes.')
print(f'Centerline total={TOTAL:.1f}px; visible road width={2*half_width(0):.1f}-{2*half_width(TOTAL):.1f}px; nav width=130px.')
