"""SGGE5.3 Castle Path grounded-topology and preservation checks."""
from pathlib import Path
import ast, json, math, zipfile

ROOT=Path('/mnt/data')
HERE=Path(__file__).resolve().parent
with zipfile.ZipFile(ROOT/'SGGE5.2_SOURCE.zip','r') as oldsrc:
    old=json.loads(oldsrc.read('luma_assets_e33.json'))
    oldmain=oldsrc.read('main.py').decode('utf-8')
new=json.loads((HERE/'luma_assets_e33.json').read_text(encoding='utf-8'))
newmain=(HERE/'main.py').read_text(encoding='utf-8')
ast.parse(newmain)
assert new['version']=='SGGE5.3'
assert 'VERSION = "E5.3"' in newmain
assert newmain.count("SPIFFY'S GIFT  |  E5.3  |") == 2
assert 'class E53StateMachine(E52StateMachine)' in newmain
assert 'machine = E53StateMachine(archive, config, warning)' in newmain

# The main engine change is strictly a version wrapper/label update.
expected_main=oldmain.replace('VERSION = "E5.2"','VERSION = "E5.3"')
expected_main=expected_main.replace("SPIFFY'S GIFT  |  E5.2  |","SPIFFY'S GIFT  |  E5.3  |")
expected_main=expected_main.replace(
    "class E52StateMachine(E51StateMachine):\n    \"\"\"SGGE5.2 Castle Path art-only release; all inherited gameplay is unchanged.\"\"\"\n    pass\n\n\nasync def main():",
    "class E52StateMachine(E51StateMachine):\n    \"\"\"SGGE5.2 Castle Path art-only release; all inherited gameplay is unchanged.\"\"\"\n    pass\n\n\nclass E53StateMachine(E52StateMachine):\n    \"\"\"SGGE5.3 Castle Path visual/navigation alignment release.\"\"\"\n    pass\n\n\nasync def main():")
expected_main=expected_main.replace('machine = E52StateMachine(archive, config, warning)',
                                    'machine = E53StateMachine(archive, config, warning)')
assert newmain==expected_main, 'Unexpected changes to engine/gameplay code'

# Exact scope: one background asset and one Castle Path navigation corridor.
assert set(new['assets'])==set(old['assets'])
for key in old['assets']:
    if key!='c1_bg_castle_path':
        assert new['assets'][key]==old['assets'][key], f'unrelated artwork changed: {key}'
old_world=old['world']; new_world=new['world']
assert set(old_world)==set(new_world)
for key in old_world:
    if key=='areas':
        oa={x['area_id']:x for x in old_world['areas']}
        na={x['area_id']:x for x in new_world['areas']}
        assert set(oa)==set(na)
        for aid in oa:
            if aid!='castle_path':
                assert oa[aid]==na[aid],f'unrelated area changed: {aid}'
            else:
                old_area=dict(oa[aid]); new_area=dict(na[aid])
                old_area.pop('navigation'); new_area.pop('navigation')
                assert old_area==new_area, 'Castle Path properties other than navigation changed'
    else:
        assert old_world[key]==new_world[key],f'world data changed: {key}'
for key in old:
    if key not in ('assets','world','version','art_revision','notes'):
        assert new[key]==old[key], f'unrelated top-level field changed: {key}'

# Castle Path transitions and their arrival positions are byte-for-byte intact.
connections=[c for c in new_world['connections'] if 'castle_path' in c['connection_id']]
old_connections=[c for c in old_world['connections'] if 'castle_path' in c['connection_id']]
assert connections==old_connections

area=next(a for a in new_world['areas'] if a['area_id']=='castle_path')
corridors=area['navigation']['corridors']
assert len(corridors)==1
polyline,width=corridors[0]
assert width==130
assert len(polyline)>=35
assert polyline[0]==[640,44] and polyline[-1]==[640,614]
assert all(0<=x<=1280 and 0<=y<=640 for x,y in polyline)

commands=new['assets']['c1_bg_castle_path']['commands']
assert new['assets']['c1_bg_castle_path']['width']==1280
assert new['assets']['c1_bg_castle_path']['height']==640
assert len(commands)>1900
for i,c in enumerate(commands):
    assert c['op'] in ('rect','line','polygon','circle','ellipse'), (i,c.get('op'))
    assert len(c['color'])==3 and all(isinstance(v,int) and 0<=v<=255 for v in c['color']), (i,c)
    if c['op'] in ('rect','ellipse'):
        assert len(c['rect'])==4 and c['rect'][2]>0 and c['rect'][3]>0, (i,c)
    if c['op']=='line': assert len(c['points'])>=2, (i,c)
    if c['op']=='polygon': assert len(c['points'])>=3, (i,c)
    if c['op']=='circle': assert c['radius']>0, (i,c)
print(f'PASS: {len(commands)} Castle Path commands; other scenes/world data preserved')

# Doorway arrivals and edge transitions all land within the new corridor.
def point_segment_distance(p,a,b):
    vx=b[0]-a[0]; vy=b[1]-a[1]
    den=vx*vx+vy*vy
    t=0.0 if den==0 else max(0.0,min(1.0,((p[0]-a[0])*vx+(p[1]-a[1])*vy)/den))
    return math.dist(p,(a[0]+t*vx,a[1]+t*vy))
def path_distance(x,y):
    return min(point_segment_distance((x,y),a,b) for a,b in zip(polyline,polyline[1:]))
limit=width/2-9
arrival_tests=[
    ('Gold District arrival',(640,510+14)),
    ('Castle Exterior return',(640,115+14)),
    ('Castle Path north edge',(640,44)),
    ('Castle Path south edge',(640,630)),
]
for name,foot in arrival_tests:
    d=path_distance(*foot)
    assert d<=limit, f'{name} misses paved route: {d:.1f}px > {limit:.1f}px'
    print(f'ON ROAD {name}: {d:.1f}px from shared centerline')

# The road and walk corridor must be sourced from the same route generator.
builder=(HERE/'build_e53_castle_path.py').read_text(encoding='utf-8')
assert 'CENTER=make_centerline(CONTROL,trim=60.0)' in builder
assert 'poly(ribbon_polygon(0),(166,158,140))' in builder
assert "AREA['navigation']={'corridors':[[nav,130]]}" in builder
assert 'nav.append(q)' in builder
assert 'All planting bases stay on visible ground' in builder
assert 'assert all(y>=300' in builder
assert 'no circular pad blobs' in builder

# Visual QA artifacts must exist and be nonempty.
for name in ('E53_CASTLE_PATH_BACKGROUND.png','E53_CASTLE_PATH_COMPOSITE.png',
             'E53_CASTLE_PATH_NAV_AUDIT.png','castle_exterior_ref.png'):
    p=HERE/name
    assert p.exists() and p.stat().st_size>10_000,name
print('PASS: road and navigation share one smooth centerline; rooted landscape checks present')
print('PASS SGGE5.3 focused regression')
