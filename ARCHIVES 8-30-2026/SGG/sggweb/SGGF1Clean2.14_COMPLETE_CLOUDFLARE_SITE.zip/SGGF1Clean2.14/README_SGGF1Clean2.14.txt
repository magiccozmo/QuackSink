SPIFFY'S GIFT — SGGF1Clean2.14

BASE: SGGF1Clean2.13. This package correction retains its HELLgs Game Over/Quickload repair, Clean2.11 Redroot legacy-save access correction, and Potent Problem recipe-book tabletop migration. No new gameplay behavior was added for 2.14.

CURATED FRONT DOOR
The front-door catalogue now offers nine playable editions: SGGF1Clean2.14 (current), SGGF1.666Cleanup1.0, SGGF1.666f1s, SGGF1.666, SGGF1.6, SGGF1.0, SGGE3.2, SGGE3.1 and SGGE2.0.

The older SGGE and SGGF1.0/F1.6 editions begin in the ordinary game world, not the HELLgs cell. HELLgs remains available as a distinct optional challenge edition. The selected milestone releases are preserved as historical playable choices.

HELLgs GAME OVER / QUICKLOAD
• The generic C1 death renderer suppresses its ordinary YOU DIED overlay only while the HELLgs game-over flag is active. The HELLgs GAME OVER card remains visible; c1_dead remains set, so the Tea Earned counter and Quickload button continue to render.
• The configured Quickload keybinding (F9 by default) is routed before the older HELLgs terminal input lock.
• Mouse clicks are converted to game coordinates and checked against an enlarged hit area surrounding the visible QUICKLOAD button. Hit-test, input and load-result details are recorded in the flight log.
• Escape still exits the ended challenge to the tool. R, movement and all other ordinary actions remain disabled during HELLgs Game Over.

PRESERVATION
• Clean2.11 Redroot object identity/access behavior, exact-default shelf-flag migration, recipe-book table position and old-save migration are unchanged.
• No Luma drawing recipes, world objects, area geometry, walkmesh, collision, nav regions, area connections, quests, Tea awards or unrelated gameplay behavior were intentionally changed.

TESTING / LIMITATIONS
The source runtime APK/TAR packages are rebuilt from the exact current main.py and Luma JSON. Package/catalogue checks validate nine edition folders, launch routes, preview paths where defined, and source/deploy mirror parity. The eight historical deployment folders are carried forward unchanged.

Pygame is not installed in the build environment. No live browser, WebAssembly, Cloudflare, physical mouse, keyboard, save/load or gameplay field test was performed by Luma. Cozmo's field test is required before the candidate can be promoted to final.
