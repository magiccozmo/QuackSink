CURRENT PLAYABLE EDITION: SGGF1Clean2.14.
PERMANENT LEGACY EDITION: SGGF1.666Cleanup1.0.
This lean deployment intentionally includes only these two selectable releases.
