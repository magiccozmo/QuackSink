SPIFFY'S GIFT — SGG WEB PROJECT

Current edition: SGGM1.6a — Alchemist Shop Renderer Hotfix.

M1.6a corrects the continuous-world startup path so the existing Luma Draw Engine is loaded before the M1 world renders. This enables the authored Alchemist Shop background, its eleven static display props, and the Alchemist sprite. No object mechanics or world geometry changed.

SGGM1.6 and SGGM1.5 remain available as earlier editions; M1.0 and M1.0a are retained as legacy editions. Intermediate M1.1–M1.4 releases remain archived in repository history but are omitted from the trimmed current site package. See versions.json for the browser catalogue.
