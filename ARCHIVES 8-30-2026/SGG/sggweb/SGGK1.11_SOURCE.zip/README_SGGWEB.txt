SPIFFY'S GIFT — COMPLETE SOURCE AND DEPLOYMENT PACKAGE

Current edition: SGGK1.11. Inn Lout can now follow the player from BritRun Market through the Front Gate, Outside Gate, Stables and Plains into Giant Camp. The existing giant patrol, NPC collision check and launch sequence are inherited unchanged from K1.10.

The authoritative source is at the project root (main.py, assets/main.py and luma_assets_e33.json). The complete current static-site tree is deploy/. This package retains the previous 11 editions, including K1.10, K1.9, K1.8 and the eight documented legacy editions.

No GitHub main push or Cloudflare deployment was performed by Luma. Cozmo handles publication and deployment.
