SPIFFY'S GIFT — SGGG1.0

G GENERATION — GLOBAL USAGE LOG AND SESSION MILESTONES

This edition is based on the exact SGGF2.0a source and Cloudflare deployment.
The eight pre-existing playable editions remain preserved in the site catalogue; SGGG1.0 is the ninth and current edition.

Global Usage Log:
- New game sessions are registered anonymously with server-generated temporary session IDs.
- The Worker supplies timestamps and approximate country; no player name, account, or detailed log is sent.
- Selected milestones and active-minute heartbeats are submitted asynchronously. Logging failures never stop gameplay.
- Heartbeats occur only when input or movement has happened recently; idle tabs do not send them.
- Press L to open the private Local Session Log. L is rebindable under Configure Keys.
- The latest logged event is shown below the help line even when contextual hints are turned off.
- The public Global Usage Log is linked from the front page.

Troll Cave:
- Easy mode retains fast travel to and from all ordinary areas, including Troll Cave.
- Normal mode retains fast travel TO discovered areas and FROM all ordinary areas except Troll Cave.
- From Troll Cave in Normal mode, the map is blocked with: "No fast travel allowed from here... this ain't EASY mode."
- Spiffy Challenge retains its existing no-fast-travel rule.
- Pineapple Getaway is recorded only when the player leaves Troll Cave while still carrying or possessing the Purple Passion Pineapple. Walking out counts; Easy-mode fast travel out also counts. It is recorded once per session.

Before public playtesting, update the existing sgg-global-log Worker using the companion GLOBAL_LOG_WORKER_SGGG1.0.js file from the source package. The existing D1 database and schema are unchanged.

Static verification does not replace Cozmo's browser field test. Do not call this release field-tested until he launches it and checks the features in the browser.
