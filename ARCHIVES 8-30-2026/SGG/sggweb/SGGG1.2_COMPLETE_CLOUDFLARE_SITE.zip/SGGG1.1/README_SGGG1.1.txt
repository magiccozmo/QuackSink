SPIFFY'S GIFT — SGGG1.1

G1.1 MAINTENANCE RELEASE — SAVE-BOUND YORKSHIRE TEA AND FASTER COZMO CAMEOS

This release is based on the exact SGGG1.0 source and complete Cloudflare site packages. All nine previous editions remain available and unchanged in the site catalogue; SGGG1.1 is added as the tenth and current edition.

YORKSHIRE TEA REWARDS
- Tea Earned is a counter only; no physical inventory item is created.
- Tea Earned, detected reward events, and claimed reward events are stored in the saved game's c1_flags, which is already serialized in every save snapshot.
- Saving stores the current count; loading restores the count and reward ledger from that save. Loading an earlier snapshot returns to its earlier Tea total rather than stacking another point on top.
- A genuinely new game starts with Tea Earned at zero.
- Easy mode auto-awards one Tea when a designated rewarding Cozmo cameo appears.
- Normal and Spiffy Challenge award one Tea only when the player talks to that specific Cozmo cameo. Leaving its area first removes the cameo and forfeits that reward.
- The six reward cameos each have unique dialogue explaining the reason for the one-Tea award: bucket theft, Naz, vault clip, inn lout, HELLgs escape, and first caravan-chest loot.
- The scenic-overlook Cozmo appearance is non-rewarding and keeps its original appreciation dialogue.
- HELLgs escape rewards remain exclusive to Spiffy Challenge.

COZMO CAMEOS
- Ordinary exploit cameo scheduling delay is one in-game second (down from five).
- Existing safeguards still defer appearance while dialogue/death/area constraints apply.

GLOBAL USAGE LOG
- Public activity list is contained in a fixed-height independently scrolling panel.
- Load older events appends within that panel; the page itself does not grow with the log.
- Refresh preserves the panel's scroll position; automatic refresh pauses while the reader is away from the top.
- Existing Global Log Worker, pagination API, D1 schema, and database are unchanged. No Worker redeployment is required for G1.1.

PRESERVATION
- Easy/Normal/Spiffy Challenge rules, Normal Troll Cave fast-travel block, Pineapple Getaway, global logging, private local session log, and existing game content are retained.
- All previous version folders remain byte-for-byte unchanged in the Cloudflare site package.

Static/package checks do not replace a live browser field test. Cozmo should verify Tea reward behavior in all three modes, save/load restoration, missed-cameo forfeiture in Normal/Challenge, unique dialogue, HELLgs Challenge-only reward, and the scrollable Global Log before accepting this release.
