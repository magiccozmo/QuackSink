SPIFFY'S GIFT — COMPLETE CLOUDFLARE SITE

Current edition: SGGG1.1.

The version chooser contains ten editions: SGGG1.1 (current), SGGG1.0, SGGF2.0a, and all seven earlier legacy editions. All nine previously selectable directories are preserved unchanged from the SGGG1.0 site package.

The public Global Usage Log is available at ./global-log.html and is linked by the GLOBAL LOG button on the front page. The event list uses a fixed-height scrolling panel and loads older entries in pages.

The existing sgg-global-log Worker and D1 database are unchanged. No Worker redeployment or database migration is required for this site release.

G1.1 Tea rules: Easy auto-rewards designated Cozmo cameos; Normal and Spiffy Challenge require talking to the specific cameo. Each rewarding cameo gives one Tea once in the saved-game state, with unique explanation dialogue. The scenic-overlook cameo remains non-rewarding, and HELLgs escape rewards remain Challenge-only.

Browser field testing is required before treating this candidate as accepted.
