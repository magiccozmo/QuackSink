SPIFFY'S GIFT — SGGG1.2

G1.2 MAINTENANCE RELEASE — STABLE CAMEOS, SAFE PLACEMENT, AND THE STOLEN MEAD JOB

This release is based on the exact SGGG1.1 source and complete Cloudflare site packages. All ten prior editions remain in the site catalogue and are retained byte-for-byte; SGGG1.2 is the eleventh selectable edition and the current release.

COZMO CAMEOS AND GLOBAL LOG IDENTITIES
- A Cozmo encounter number identifies the unique reason for the cameo, not the number of times the player has triggered it.
- Repeating the same cause after a save/load records another event but reuses the same public encounter number.
- Different causes have stable numbers: bucket theft #1, Naz #2, vault clip #3, inn-lout resolution #4, HELLgs escape #5, caravan chest #6, scenic-overlook appreciation #7, HELLgs save return #8, first hint #9, final hint #10, spoiler hint #11, and an approved fallback #12.
- Every actual Cozmo appearance remains a separate event record. The public Worker maps cause-specific event types to fixed labels; repeats are not deduplicated.
- Cameos use a visible, walkable, collision-free position check. Placement avoids the player, live NPCs, dead NPC bodies, the guard, solid geometry, and nearby live objects. If no safe position is available, the cameo waits and retries rather than spawning on top of somebody.
- Ordinary cameo scheduling remains one in-game second after the event. Existing G1.1 Tea rules and save-bound reward ledger are retained.

TIPSY TURNIP — THE STOLEN MEAD JOB
- The Inn Lout is placed to the right of the fireplace/cooking pot, away from the exit doorway. His original dialogue, challenge, and follow behavior remain in place.
- Black-Briar Mead is positioned on the player side of the bar and is marked stealable. The player must carry a bucket and place it over the innkeeper's head before taking the bottle.
- Taking the bottle while the innkeeper is bucketed marks it STOLEN in the existing inventory system. The Lout will accept only that stolen bottle. The bottle is consumed when delivered.
- Merely placing the bucket grants no Tea. The bucket Tea cameo is queued only after a successful bucket-assisted theft, and the saved-game reward ledger permits that reward only once. Easy auto-claim and Normal/Challenge talk-to-claim continue to follow G1.1 rules.
- Vendor buy/sell menus are not added in this release; they remain future work.

ALCHEMY SHOP
- The Potent Problem recipe book has been moved to a separate spot on the table, away from Moonflower. Untouched saved legacy positions migrate; custom-moved books are left alone.

GLOBAL USAGE LOG WORKER UPDATE — REQUIRED
- The D1 schema and database are unchanged; no migration is required.
- To get stable Cozmo encounter numbering in the public Global Usage Log, deploy SGGG1.2_GLOBAL_LOG_WORKER.js to the existing Global Log Worker. The older Worker remains API-compatible but will not recognize the new stable cause-specific event labels.
- The game's anonymous logging remains best-effort; a logging/network issue does not block gameplay.

PRESERVATION
- All ten earlier selectable site editions are retained byte-for-byte.
- The existing private session log, Global Usage Log panel, pagination, Tea counter, difficulty rules, and previous content remain in place.

This is a candidate build pending Cozmo's live browser field test. Static checks are documented in SGGG1.2_TEST_RESULTS.txt; they do not replace gameplay testing.
