SPIFFY'S GIFT — CLEAN DEPLOYMENT

CURRENT VERSION: SGGF1Clean2.2

This complete Cloudflare site retains eleven deliberately selected playable editions:
- SGGF1Clean2.2 — current Peak summit and Scenic Overlook.
- SGGF1Clean2.1 — previous grounded Mountain Path Peak approach.
- SGGF1Clean2 — preceding clean release/rollback option.
- SGGF1.666Cleanup1.0 — curated milestone edition.
- SGGF1.666f1s, SGGF1.666, SGGF1.6 and SGGF1.0.
- SGGE3.2, SGGE3.1 and SGGE2.0.

Ordinary intermediate test releases remain excluded. The site is self-contained and has no runtime dependency on GitHub. The new summit is built from JSON Luma Draw Engine recipes. The duplicate Peak Troll Cave door is removed while the original Mountainside entrance remains.
