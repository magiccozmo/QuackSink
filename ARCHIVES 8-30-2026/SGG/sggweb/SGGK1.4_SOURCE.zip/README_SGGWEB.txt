SPIFFY'S GIFT — COMPLETE SOURCE AND DEPLOYMENT PACKAGE

Current edition: SGGK1.3. This release tunes Grella's flight to just below normal player speed, guarantees Cozmo's cameo when the mudcrabs take her, and fixes the anonymous Global Usage Log bridge method-name typo.

The authoritative current source is at the project root (main.py, luma_assets_e33.json and validate_luma_assets.mjs). The complete current runtime folder is deploy/SGGK1.3. SGGK1.2 and all earlier deployed editions remain intact as historical versions.

K1.3 preserves the existing 23-area/44-connection world, save format, Grella escort and one-time saved Tea reward. The reported corpse and Mk 2 sequence is not modified by this patch and remains for field verification. New state uses additional c1_flags fields that migrate into existing saves without resetting them. See deploy/SGGK1.3/SGGK1.3_README.txt, SGGK1.3_TEST_RESULTS.txt and SGGK1.3_LUMA_LOG_Entry039.txt.

No GitHub main push or Cloudflare static-site deployment was performed by Luma. Live browser testing remains for Cozmo's field test.
