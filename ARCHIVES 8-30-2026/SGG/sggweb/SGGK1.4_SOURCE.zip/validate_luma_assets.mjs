#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const here=path.dirname(fileURLToPath(import.meta.url));
const file=path.resolve(process.argv[2]||path.join(here,'luma_assets_e33.json'));
const allowed=new Set(['rect','line','polygon','circle','ellipse']);
const errors=[];
let data;
try { data=JSON.parse(fs.readFileSync(file,'utf8')); }
catch(e){ console.error('Unable to parse '+file+': '+e.message); process.exit(2); }
if(!data.assets||typeof data.assets!=='object'||Array.isArray(data.assets)){console.error('No valid assets object');process.exit(2);}
let recipes=0,commands=0;
for(const [name,recipe] of Object.entries(data.assets)){
  recipes++;
  if(!recipe||!Array.isArray(recipe.commands)){errors.push(name+': commands must be an array');continue;}
  for(let i=0;i<recipe.commands.length;i++){
    commands++;
    const c=recipe.commands[i],where=name+'.commands['+i+']';
    if(!c||typeof c!=='object'||Array.isArray(c)){errors.push(where+': command must be an object');continue;}
    if(!allowed.has(c.op))errors.push(where+': unsupported drawing op '+JSON.stringify(c.op));
    if(!Array.isArray(c.color)||![3,4].includes(c.color.length)||c.color.some(x=>!Number.isInteger(x)||x<0||x>255))
      errors.push(where+': color must be a flat RGB/RGBA array of 3 or 4 integers in 0..255');
  }
}
if(errors.length){console.error('Luma asset validation FAILED: '+errors.length+' error(s) across '+recipes+' recipes / '+commands+' commands.');for(const e of errors)console.error(' - '+e);process.exit(1);}
console.log('Luma asset validation PASSED: '+recipes+' recipes / '+commands+' drawing commands; supported ops and flat RGB/RGBA colours verified.');
