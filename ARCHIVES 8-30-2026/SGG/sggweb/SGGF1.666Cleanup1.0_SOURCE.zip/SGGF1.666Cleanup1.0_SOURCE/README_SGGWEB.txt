SPIFFY'S GIFT — CURATED WEB SOURCE ARCHIVE

Current baseline: SGGF1.666Cleanup1.0, built directly from the verified SGGF1.666f1s source and deployment packages.

The source handoff keeps the complete current game source, Luma asset recipe, runtime packager, cleanup regression checks, the previous current F1s snapshot, the F1r migration comparison baseline, essential project assets/pics, and original source archives for the selected major milestones.

Selected historical playable versions in the paired Cloudflare deployment:
SGGE2.0, SGGE3.1, SGGE3.2, SGGF1.0, SGGF1.6, SGGF1.666, and SGGF1.666f1s.
SGGF1.666Cleanup1.0 is current.

All other intermediate playable releases remain preserved in the complete GitHub repository and Cozmo's local archive; they are intentionally not repeated in this curated distribution.

Gameplay note: This remains the F1.666 development line. HELLgs Inn remains the starting scenario; the later normal-start / optional Challenge Mode change is deferred until after SGGF1.666Final.
