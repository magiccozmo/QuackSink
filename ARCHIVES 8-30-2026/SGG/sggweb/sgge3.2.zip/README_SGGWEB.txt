Spiffy's Gift — SGGE3.2 full Cloudflare Workers direct-upload static site.
Upload sgge3.2.zip to the EXISTING Worker. Root index.html is the VERSION MENU, not the game.
Current edition: /SGGE3.2/play.html ; earlier releases /SGGE3.1/play.html, /SGGE3.0/play.html,
/SGGE2.1/play.html, and /SGGE2.0/index.html remain playable and byte-for-byte preserved.
The root menu loads versions.json; no extra subdirectory navigation is needed.
DeepSeek/Kelp artwork changes ONLY the Castle Vault background in E3.2.
No other art, game objects, navigation, mechanics, or old releases were edited.
Cloudflare Web Analytics retained. Nothing was uploaded to GitHub.
