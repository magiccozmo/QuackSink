SPIFFY'S GIFT — CURATED SOURCE HANDOFF

Current edition: SGGG1.0 (G generation), based on the exact verified SGGF2.0a source and complete Cloudflare deployment archives.

The embedded deploy/ directory is the complete Cloudflare site and retains every prior selectable edition from SGGF2.0a plus the new SGGG1.0 edition. No legacy version or SGGF2.0a was removed. The older source milestone archives remain intact.

G1.0 adds the anonymous Global Usage Log integration, private current-session Local Session Log (L key, rebindable), always-visible latest-event line, public global-log page, activity-only minute heartbeats, and the Normal-mode Troll Cave fast-travel restriction. Pineapple Getaway is recorded once per session only when the player leaves Troll Cave carrying/possessing the Purple Passion Pineapple; Easy-mode fast travel out and ordinary walking out both count.

The SGG Global Log Worker uses the same existing D1 schema. Deploy GLOBAL_LOG_WORKER_SGGG1.0.js to the existing sgg-global-log Worker before public playtesting so the approved event-code labels are enabled.

Static and package checks are recorded in SGGG1.0_TEST_RESULTS.txt. No GitHub main push or Cloudflare site deployment was performed by Luma. Browser field testing remains for Cozmo.
