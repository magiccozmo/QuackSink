SPIFFY'S GIFT — COMPLETE CLOUDFLARE SITE

Current edition: SGGG1.0.
The site contains all eight editions preserved from SGGF2.0a plus SGGG1.0 as the ninth/current edition. None of the existing legacy folders or SGGF2.0a was removed or modified.

The public Global Usage Log is available at ./global-log.html and is linked by the GLOBAL LOG button on the front page. The page omits test sessions from its display.

Before public playtesting, deploy the companion GLOBAL_LOG_WORKER_SGGG1.0.js to the existing sgg-global-log Worker. The existing database schema is compatible.
