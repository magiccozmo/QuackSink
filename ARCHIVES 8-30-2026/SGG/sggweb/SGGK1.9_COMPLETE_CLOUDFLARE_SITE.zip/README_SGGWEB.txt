SPIFFY'S GIFT — COMPLETE CLOUDFLARE SITE

Current edition: SGGK1.9. The Front Gate Little Lantern label is placed on its wooden signboard, and the Castle Hall Mage Lab arch rests on the floor. K1.8's tested Castle Hall / Exterior transition fixes are retained.

The front-door catalogue lists K1.9, K1.8, and the eight legacy editions named in “legacy verions.txt”. Intermediate K1.0-K1.7 and J1.0 folders are omitted from this trimmed package.

No GitHub main push or Cloudflare deployment was performed by Luma.
