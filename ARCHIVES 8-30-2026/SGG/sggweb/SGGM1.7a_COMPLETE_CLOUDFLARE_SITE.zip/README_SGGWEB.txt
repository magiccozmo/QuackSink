Spiffy's Gift — Web project source handoff
Current edition: SGGM1.7a — Kart-lotta Returns to Her Original Market Stall.

SGGM1.7a is a narrowly scoped follow-up to SGGM1.7. Kart-lotta is restored to the exact player coordinate recorded in kartlotta position log.LOG (2986.6, 1010.1), her original K1.12 red produce stall is restored as a separate Luma recipe, and the extra front-centre kiosk is removed. Her six original left-stall stock items are returned to their K1.12 positions.

The central paved walkway and compass medallion, Copper Flask, right-hand provisions stall, Market Guard, other NPCs, remaining items, all routes, portals, walkmesh, arrivals, other areas and mechanics are retained. No death-by-guard, theft, inventory or arrest mechanics are added.

The project includes the complete historical release catalogue and deployment assets. The M1.7a browser bundles are repackaged from the M1.7 Pygbag payload with the updated runtime and JSON files; no fresh Pygbag compilation or live browser run was performed in this environment.
