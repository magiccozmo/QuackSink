import json, math, sys
from pathlib import Path
p=Path(__file__).resolve().parents[1]/'m1_world_layers.json'
d=json.loads(p.read_text())
layers={x['id']:x for x in d['layers']}
city=layers['city_exterior']

def inrect(x,y,r):
    rx,ry,rw,rh=r
    return rx <= x <= rx+rw and ry <= y <= ry+rh

def can(layer,x,y):
    samples=((x,y),(x-10,y-13),(x+10,y-13),(x-10,y+13),(x+10,y+13))
    if not all(any(inrect(sx,sy,r) for r in layer.get('walkmesh',[])) for sx,sy in samples):
        return False
    bx,by,bw,bh=x-10,y-13,20,26
    for rx,ry,rw,rh in layer.get('blocked',[]):
        if bx < rx+rw and bx+bw > rx and by < ry+rh and by+bh > ry:
            return False
    return 0 <= x <= layer['width'] and 0 <= y <= layer['height']

def poly_samples(path,step=8):
    points=path['points']
    for a,b in zip(points,points[1:]):
        dx=b[0]-a[0]; dy=b[1]-a[1]
        dist=math.hypot(dx,dy)
        n=max(1,math.ceil(dist/step))
        for i in range(n+1):
            t=i/n
            yield a[0]+dx*t,a[1]+dy*t,dx,dy

errors=[]
assert d['schema']=='sgg-continuous-world-v1'
assert d.get('version')=='SGGM1.5'
assert d.get('start')=={'layer':'city_exterior','x':3400,'y':1620}
for layer in layers.values():
    if abs(layer['width']/layer['height']-2)>0.01:
        errors.append(f"{layer['id']}: 2:1 ratio invalid")
# exact startup anchor
if not can(city, d['start']['x'], d['start']['y']): errors.append('startup anchor not full-body walkable')
# all portals and arrivals centre/full-body checked
for layer in layers.values():
    for portal in layer.get('portals',[]):
        target=layers.get(portal.get('target_layer'))
        if target is None: errors.append(f"{portal['id']}: missing target layer"); continue
        tx,ty=portal['target_x'],portal['target_y']
        in_bounds = (0 <= tx <= target['width'] and 0 <= ty <= target['height'])
        if not in_bounds:
            errors.append(f"{portal['id']}: target outside bounds")
        if not can(target,tx,ty): errors.append(f"{portal['id']}: arrival {target['id']} ({tx},{ty}) not full-body walkable")
# city outgoing portals + city NPCs full-body
for portal in city.get('portals',[]):
    if not can(city,portal['x'],portal['y']): errors.append(f"city portal {portal['id']} origin not full-body walkable")
for npc in city.get('npcs',[]):
    if not can(city,npc['x'],npc['y']): errors.append(f"city NPC {npc['id']} not full-body walkable")
# every path is sampled through its visible width, with 15 px inside the visual edge
for path in city.get('paths',[]):
    w=path.get('width',80)
    for x,y,dx,dy in poly_samples(path):
        length=math.hypot(dx,dy) or 1
        nx,ny=-dy/length,dx/length
        offsets=[-max(0,w/2-15),0,max(0,w/2-15)]
        for off in offsets:
            sx=x+nx*off; sy=y+ny*off
            if not can(city,sx,sy):
                errors.append(f"road {path['name']} blocked/unwalkable at ({sx:.1f},{sy:.1f})")
                break
        if errors and errors[-1].startswith('road '): break

# Build a 10-unit graph of can_move_to states; all routes, door thresholds,
# NPCs and arrivals must belong to the component from the City Gate start.
step=10
xmin=max(0,int(min(r[0] for r in city['walkmesh'])//step*step)-30)
ymin=max(0,int(min(r[1] for r in city['walkmesh'])//step*step)-30)
xmax=min(city['width'],int(max(r[0]+r[2] for r in city['walkmesh'])//step*step)+30)
ymax=min(city['height'],int(max(r[1]+r[3] for r in city['walkmesh'])//step*step)+30)
start=(int(round(d['start']['x']/step)*step),int(round(d['start']['y']/step)*step))
from collections import deque
q=deque([start]); seen={start}
while q:
    x,y=q.popleft()
    for nxt in ((x+step,y),(x-step,y),(x,y+step),(x,y-step)):
        xx,yy=nxt
        if nxt in seen or xx<xmin or xx>xmax or yy<ymin or yy>ymax: continue
        if can(city,xx,yy): seen.add(nxt); q.append(nxt)

required=[]
required.append(('startup',d['start']['x'],d['start']['y']))
for po in city.get('portals',[]): required.append(('portal '+po['id'],po['x'],po['y']))
for layer in layers.values():
    for po in layer.get('portals',[]):
        if po['target_layer']=='city_exterior': required.append(('arrival '+po['id'],po['target_x'],po['target_y']))
for npc in city.get('npcs',[]): required.append(('NPC '+npc['id'],npc['x'],npc['y']))
for path in city.get('paths',[]):
    for x,y,_,_ in poly_samples(path,10): required.append(('road '+path['id'],x,y))
for label,x,y in required:
    # The grid graph rounds exact world coords to nearest 10 for component membership.
    pt=(int(round(x/step)*step),int(round(y/step)*step))
    if pt not in seen:
        errors.append(f"not in gate-connected city component: {label} ({x:.1f},{y:.1f})")
        break

print(f"city size: {city['width']}x{city['height']}; layers={len(layers)}; directed portals={sum(len(x.get('portals',[])) for x in layers.values())}")
print(f"city walkmesh rectangles={len(city['walkmesh'])}; path segments={len(city['paths'])}; reachable grid nodes={len(seen)}")
print(f"city landmarks={len(city['landmarks'])}; NPCs={len(city['npcs'])}; outgoing portals={len(city['portals'])}")
print(f"required test points={len(required)}")
if errors:
    print('FAIL:')
    for e in errors[:80]: print(' -',e)
    sys.exit(1)
print('PASS: full-body portal/NPC/start checks, road bands, arrivals and gate-connected network')


def find_safe_landing(layer, tx, ty):
    if can(layer, tx, ty): return (tx, ty)
    for radius in (20, 36, 52, 72, 96, 124, 156, 190, 230, 275, 320):
        for index in range(24):
            angle = math.tau * index / 24
            x, y = tx + math.cos(angle) * radius, ty + math.sin(angle) * radius
            if can(layer, x, y): return (x, y)
    candidates = []
    for rx, ry, rw, rh in layer.get('walkmesh', []):
        candidates.append((max(rx+24,min(rx+rw-24,tx)), max(ry+24,min(ry+rh-24,ty))))
        candidates.extend([(rx+40,ry+40),(rx+rw-40,ry+40),(rx+40,ry+rh-40),(rx+rw-40,ry+rh-40),(rx+rw*.5,ry+rh*.5)])
    candidates.sort(key=lambda q: math.hypot(q[0]-tx,q[1]-ty))
    for x, y in candidates:
        if can(layer, x, y): return (float(x), float(y))
    return None

for landmark in city.get('landmarks', []):
    if find_safe_landing(city, landmark['x'], landmark['y']) is None:
        errors.append('no fast-travel landing for ' + landmark['id'])

# Reciprocal return coordinates must also be clear of all city NPCs.
for source in layers.values():
    for portal in source.get('portals', []):
        if portal.get('target_layer') == 'city_exterior':
            for npc in city.get('npcs', []):
                if math.hypot(portal['target_x']-npc['x'], portal['target_y']-npc['y']) < 42:
                    errors.append(f"return arrival {portal['id']} overlaps NPC {npc['id']}")

for landmark in city.get('landmarks', []):
    landing = find_safe_landing(city, landmark['x'], landmark['y'])
    if landing:
        for npc in city.get('npcs', []):
            if math.hypot(landing[0]-npc['x'], landing[1]-npc['y']) < 42:
                errors.append(f"fast-travel landing for {landmark['id']} overlaps NPC {npc['id']}")

if errors:
    print('FINAL FAIL:')
    for e in errors[:80]: print(' -', e)
    sys.exit(1)
print('PASS: all city landmarks have safe fast-travel landings; none overlap a city NPC.')
