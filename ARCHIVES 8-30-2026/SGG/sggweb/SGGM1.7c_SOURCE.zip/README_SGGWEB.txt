Spiffy's Gift — Web project source handoff
Current edition: SGGM1.7c — Kart-lotta's Stall Walkmesh Correction.

SGGM1.7c is a narrowly scoped collision correction built from the exact SGGM1.7b release. The full original K1.12 Kart-lotta stall footprint is now blocked, preventing the player from walking through its awning, posts, counter and displayed goods. The cobbled ground directly in front of the stall remains walkable.

Kart-lotta's recorded position, original K1.12 stall and stock definitions, market artwork, Copper Flask, compass walkway, Alchemy Shop facade and doorway, guard, other NPCs, object ownership/theft metadata, routes, portals, other layers and gameplay mechanics are retained. No new mechanics are added.

The complete historical release catalogue and deployment assets are preserved. The M1.7c browser bundle and APK are repacked from the M1.7b Pygbag payload with the updated runtime and world JSON; no fresh Pygbag compilation or live browser run was performed in this environment.
