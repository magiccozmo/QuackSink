Spiffy's Gift — SGGM1.7a Browser Release

This is the SGGM1.7a release package. Only the Market Square changes described in SGGM1.7a_README.txt are applied. The previous SGGM1.7 release remains preserved alongside this version.

The version catalogue and site launcher identify SGGM1.7a as the current release.
