Spiffy's Gift — SGGM1.7b Browser Release

This is the SGGM1.7b release package, built from the exact SGGM1.7a source and deployment. It applies only the Market Square corrections described in SGGM1.7b_README.txt: removal of the obsolete centre-square blocker, the player-marked Peasant Way street endpoint, and the larger east-side Alchemy Shop facade with a reachable doorway.

All unrelated areas, routes, items, NPCs, mechanics and historical editions are preserved. The root version catalogue identifies SGGM1.7b as current.
