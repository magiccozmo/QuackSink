SPIFFY'S GIFT — SGGF1.666f1m

BASE
Built from Cozmo's pushed SGGF1.666f1l release. This is a new additive release;
no earlier version folder, archive, or historical catalogue entry is overwritten.

SIDE OF MOUNTAIN — COMPLETE REDO
The old flat grey mountain planes and narrow straight central strip are replaced
with a layered mountain-valley backdrop, fractured cliff faces, a broad lower
rock ledge, an alpine switchback cut into the mountain, scattered boulders,
stunted pines, scrub and alpine details. Frosty's cave mouth is integrated into
the cliff around the existing wooden door artwork.

WALKMESH / TRANSITIONS
A grounded corridor follows the visible upper switchback and joins a broad
lower ledge. Existing entry from Southern Wilds lands at the top trailhead;
the top exit remains the existing Southern Wilds connection. Existing arrival
from Troll Cave is supported on the lower ledge. The cave door remains the
same object and is approached from the south toward the existing trigger.

PRESERVED
All connection IDs and arrival coordinates are unchanged. The existing
mountain_cave_entrance object ID, kind, position, dimensions, artwork recipe,
and walk trigger remain unchanged. Every other world object, area, asset,
reward, dialogue, save field, and prior release is retained. The f1l state
machine/interface behavior—including the Southern Wilds horizon exit—is kept
through inheritance. No live browser playtest or deployment is claimed here.
