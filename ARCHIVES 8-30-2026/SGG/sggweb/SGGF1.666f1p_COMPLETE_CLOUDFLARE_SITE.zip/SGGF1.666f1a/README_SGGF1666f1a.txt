SPIFFY'S GIFT — SGGF1.666f1a

PURPOSE
Corrective release for the F1.666f1 front-door card layout. Older entries without artwork now use a single full-width card column; descriptions no longer occupy the empty fixed-width artwork column. Card text blocks explicitly stretch to the available width.

PRESERVATION
F1.666f1 and all earlier releases remain unchanged. The runtime is based on F1.666f1. Only the release version label and Draw Engine version metadata are advanced; the F1.666f1 gameplay and interface behavior are inherited.

RETAINED FRONT-DOOR FEATURES
- Phone and tablet visitors see the same front door and version selector as desktop visitors.
- Gallery button beside the title, displaying the public PNG gallery one picture at a time.
- YouTube playlist button directly beneath Gallery.
- Please Tip / Thank You Ko-fi link in the upper-right corner.
- Every newly added version catalogue entry includes an image field; this correction release also uses hell.png.

RETAINED IN-GAME FEATURES
The in-game YouTube playlist control remains present. F1.666f1 HELLgs fire behavior, collision-only Game Over, fast-travel refusal, saves, Tea, hints and backward-compatible save handling are inherited unchanged.

VALIDATION
- Python AST parse and bytecode compilation passed.
- Prior F1666f1StateMachine and F1666f1Interface definitions are AST-identical.
- APK and TAR runtime packages contain the exact same main.py and Luma assets JSON.
- index.html and versions.html are byte-identical.
- No-art cards receive the no-art class and a single full-width grid track.
- Card text blocks are explicitly full width.
- All 41 prior catalogue entries and their descriptions are preserved; only current flags are cleared before the new entry is inserted.
- All prior Cloudflare game folders and support assets are preserved byte-for-byte.

A live browser/device field test has not been run in this build environment.
