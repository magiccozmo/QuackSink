SPIFFY'S GIFT — SGGF1.666f1l

BASE
Built from Cozmo's pushed SGGF1.666f1k version. All previous releases, the
f1k scenery redraw and all other areas are retained.

SOUTHERN WILDS ROAD CORRECTION
The Plains road now begins on the visible land horizon and winds through the
meadow. It does not climb into the sky. The sky and ground remain separate
visual planes, and the existing layered mountains and individually designed
trees/foliage remain intact.

WALKMESH AND TRANSITION
The entire grassy meadow is walkable from the horizon to the lower edge. The
sky above the land boundary is blocked. The Plains exit marker is at the
horizon; walking north into it activates the existing top connection. Entering
Southern Wilds from Plains now places the player at the grounded trailhead.
The Side of Mountain exit remains at the bottom.

PRESERVED
The top and bottom connection IDs remain intact. The Southern Wilds -> Plains
arrival in Plains and the Side of Mountain arrival remain unchanged. World
objects, other areas, inventory, rewards, dialogue, save schema and backward-
compatible saves are retained. No earlier release folder or archive is replaced.
