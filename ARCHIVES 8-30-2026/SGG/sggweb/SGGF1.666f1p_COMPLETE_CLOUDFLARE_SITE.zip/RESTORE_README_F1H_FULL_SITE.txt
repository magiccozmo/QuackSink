SGGF1.666f1h COMPLETE CLOUDFLARE SITE

This archive is a COMPLETE replacement site bundle, not an incremental overlay.
It contains all 50 catalogue entries: SGGE 2.0-5.7 and SGGF 1.0-1.1, 1.2-1.6,
1.666 through 1.666f1h. Deploy the archive as a complete static asset site.
Do not use an f1a-h overlay archive as a site replacement.
