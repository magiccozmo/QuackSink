SPIFFY'S GIFT — SGGF1.1
Stable-yard object separation and draft-horse art refinement

WHAT CHANGED
- The F1.0 carriage artwork was extracted into its own reusable Luma Draw Engine JSON asset and fixed world object. Its original vector artwork and position are preserved.
- The previous horse was replaced with a new, separately editable dark-bay draft horse recipe. Its proportions, chest, shoulder, neck, legs, hooves and working harness were drawn as an independent JSON asset.
- The original right-hand paddock rails and posts were extracted as a separate foreground-fence asset so that the fence remains in front of the horse, as in F1.0.
- The engine now draws the carriage, horse and foreground fence in the original painter's order, with the driver/vendor and player drawn above them.
- F1.0 save files are upgraded by adding only the three missing static scenery objects and metadata. Existing player progress, inventory, quest flags and NPC state are retained.

WHAT DID NOT CHANGE
- The Stable yard's solid geometry, navigation region, vendor location, road, buildings, yard scenery and all unaffected background commands are preserved.
- Kitty's four art/animation recipes are byte-for-byte unchanged. Her F1.0 chest-to-paddock patrol is unchanged.
- The carriage-driver breakfast handoff, Fearmonger reward, Egg McGuffin Sammich, carriage-unlock flag, Cozmo's four-page Part One finale, visitor comments and other F1.0 gameplay remain intact.
- All historic site releases remain in the Cloudflare deployment package. Only the root version catalog changes to make F1.1 the current release, and a new SGGF1.1 version folder is added.

ART / SOURCE LAYOUT
- luma_assets_e33.json: contains the new stable_carriage, stable_draft_horse and stables_foreground_fence recipes, plus their fixed world-object entries.
- main.py: renders the three static props in stable scene order and migrates F1.0 saves.
- F1.1_HORSE_ASSET_PREVIEW.png: isolated horse recipe preview.
- F1.1_STABLES_PREVIEW.png: full Stable yard composition with the new horse.
- F1.0_MAIN_BASE.py and F1.0_BASE_LUMA_ASSETS.json: exact F1.0 comparison baselines.

DEPLOYMENT
Upload the contents of SGGF1.1_CLOUDFLARE_DEPLOY.zip to the existing Cloudflare static-assets site, preserving the archive's folder structure. The separate comments API Worker and D1 database are unchanged.

SOURCE / TESTING
SGGF1.1_SOURCE.zip contains the updated Python and JSON source, F1.0 comparison baselines, tests, packaging script, previews, release notes and front-door files.
The static regression suite checks syntax, JSON/recipe integrity, exact carriage/fence extraction, Kitty art preservation, stable geometry, F1.0 save migration, F1.0 quest/dialogue/finale behavior, catalog structure, historical deployment preservation, and runtime-payload consistency.

TEST NOTE
Python syntax and static/model regression checks are run during packaging. The game is not launched in a live browser in this build environment; please field-test the deployed F1.1 build before treating it as runtime-verified.
