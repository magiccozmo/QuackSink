SPIFFY'S GIFT — SGGF1.666f1e

BASE
This release is based directly on the immutable SGGF1.666f1c package. It is a
focused correction to the Front Gate / BritRun Market connection and Front Gate
walkmesh. The earlier SGGF1.666f1d archive remains untouched.

FRONT GATE WALKMESH
The old Front Gate walkmesh included a vertical rectangle running from y=44 to
y=560. It let the player walk through the gate facade and into the sky. That
rectangle has been removed. The replacement walkmesh follows the visible paved
left-side approach lane and the central stone staircase down to the foreground.
Navigation continues to use the engine's foot anchor (player body y + 14).

FRONT GATE ↔ MARKET TRANSITION
The old Front Gate → Market transition was attached to the top screen edge,
forcing the player to walk upward into the sky to activate it. The exit now sits
at the bottom of the stone staircase, where the player is on visible ground.
The reciprocal Market → Front Gate arrival was moved from y=115 (sky) to y=520
(on the staircase). Both areas keep their exit arrows, now marking the grounded
bottom-edge connection. The Front Gate → Outside Gate door and the left exit to
Gold District remain separate and unchanged.

PRESERVED
All other area artwork, objects, doors, arrows, save compatibility, HELLgs Inn,
Cozmo exploit events and Tea rewards, hint progression, dialogue, tip behaviour,
and earlier release folders are inherited unchanged from SGGF1.666f1c.

RELEASE RULE
SGGF1.666f1e is a separate immutable release. No existing archive version is overwritten.
