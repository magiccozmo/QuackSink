SPIFFY'S GIFT — SGGF1.666f1g

BASE
This release is based directly on the user's SGGF1.666f1f source release.
It makes the Outside Gate look like the reverse-facing side of the Front Gate.

OUTSIDE GATE ART
The old square single-door portal is replaced by a broad segmented pale-stone
arch, deep recessed opening, cut-stone jambs and keystone details. The existing
iron-braced double-leaf city gate artwork from Front Gate is reused at matching
full width and height. A persistent “Front Gate” arrow marks the reciprocal exit.

FUNCTIONALITY PRESERVED
The city_gate_return object ID, kind="door", area, and original walk-trigger
rectangle are unchanged. The outside_gate_to_front_gate connection and arrival
point are unchanged. The Outside Gate road, walkmesh, Stables exit and all other
areas, arrows, gameplay, saves, Tea rewards, HELLgs behavior and UI are retained.

RELEASE RULE
SGGF1.666f1g is a separate immutable release. Earlier version folders are untouched.
