SPIFFY'S GIFT — SGGF1.666b

BASE / ARCHIVE POLICY
F1.666a is the direct gameplay baseline. F1.666b is a distinct additive release. F1.666 and F1.666a remain preserved as their own source and deployment archives. No existing release archive is replaced.

HELLGS INN
The game retains the HELLgs Inn starting cell, solid barred cell door, folded paper, one-in-game-day OR configured real-time timer, fire sequence and final GAME OVER behavior. No ordinary exit, door interaction or new escape path is added. The folded paper retains its F1.666 wording, including the original "forwarding" typo.

PERMANENT SAVE-COMPATIBILITY POLICY
From this release forward, SGG save loading is designed to remain backward-compatible with earlier saves that use the shared spiffys-gift-save-v1 format. The saved game is authoritative: the saved current area, player coordinates, inventory, object state, NPC state, quests, day, elapsed time and other existing fields take precedence over the new release's start-up defaults. A new release may start in a different area; loading an earlier save still returns the player to the area and coordinates recorded in that save.

The central C12GameModel.from_snapshot migration now works additively and generically:
- Every current world object missing from an older save is supplied once from the current world definition. Existing saved objects are retained with their saved state. There is no per-object allowlist.
- Newly introduced NPCs are initialized from their current world definitions. Existing NPC state is merged over those defaults.
- Newly introduced save fields and nested dictionary entries receive current-model defaults only when absent from the save. Existing saved values are preserved, including nested NPC fields.
- Newly introduced saved set fields receive empty/current defaults when absent.
- Current item metadata is supplied for newly added objects while saved metadata and unknown saved objects are retained.
- New GameObject dataclass fields must have safe defaults so older object records can be upgraded automatically.

Future SGG releases should preserve the shared save schema and this central migration layer. Existing area IDs should remain valid; if an area must ever be retired or renamed, a deliberate area-ID migration/alias is required rather than silently relocating the player. This is a reusable compatibility contract, not another one-object exception.

COZMO — HELLGS RETURN CAMEO
Immediately before any save load, the game remembers the player's current area. If the player was in hellgs_inn before a successful load, the existing D1.1 Cozmo cameo appears in the area and position restored by that save. The trigger therefore checks the pre-load location, while the cameo is placed in the post-load location. Missing or failed loads do not trigger an appearance.

When interacted with, Cozmo says exactly:

Well dayum! I guess you are exploiter after all. This 'game' was truly designed and created for folks like you. Here is some Tea.

The first, third, fifth, and subsequent alternating appearances grant one Yorkshire Tea inventory item. The second, fourth, sixth, and subsequent alternating appearances do not. The appearance counter is stored in persistent settings outside the individual save slots, so loading an older save does not roll it backward. The reward can be claimed only once during each cameo appearance; speaking with Cozmo again during the same appearance does not award another tea. Yorkshire Tea is a score/collection item, not a new consumable or gameplay exploit mechanic.

The cameo uses the existing Cozmo magician and tip-jar artwork and existing interaction path. No other anti-exploit mechanics, cooldowns, escape tricks, or gameplay restrictions are introduced.

TESTING
The static and in-memory regression suite loads a synthetic F1.6 save into the new world and verifies its saved location, coordinates, inventory, object records, item metadata, NPC changes, day and quest flags. It also simulates a future version adding a new object, NPC, save field and set field, confirming all are defaulted without per-ID code. It verifies preservation of dynamic dropped objects, no object duplication, the pre-load HELLgs trigger, Cozmo's post-load location, alternating 1/0/1 tea rewards, the once-per-appearance rule, and no cameo on a failed/no-op load. The new Luma tea asset is validated by the draw engine. A live browser launch and field test remain for Cozmo.
