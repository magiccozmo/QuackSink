SPIFFY'S GIFT — SGGF1.666f1i

BASE
Based directly on the tested SGGF1.666f1h release.

PLAINS UPDATE
The northbound road now narrows in perspective toward a small Giant Camp at the
mountain horizon instead of running up through the sky. The Giant Camp arrow and
label sit at the gateway, and the working transition activates when the player
crosses the horizon approach. Returning from Giant Camp places the player back
at that same approach.

PRESERVED
The Plains horizontal crossroads and Southern Wilds continuation remain in place.
Stables, Mountain Path, Mudcrab River and Southern Wilds exits retain their prior
locations. Their transition definitions, every other area, all existing objects,
rewards, dialogue, inventory, save structure, backward-compatible saves and the
F1.666f1h Outside Gate legacy-save rendering fix are preserved. Older releases
remain separate and untouched.
