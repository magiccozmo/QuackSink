SPIFFY'S GIFT — SGGF1.666f1

RELEASE / ARCHIVE RULE
F1.666f1 is a distinct release based on the exact F1.666f source and Cloudflare deployment archives. F1.666f and every earlier release remain immutable. No existing archive is replaced.

IN-GAME YOUTUBE BUTTON
Adds a YouTube button in the upper game chrome, using the standard red-and-white play mark. Clicking it opens the Spiffy's Gift playlist in a new tab/window:
https://www.youtube.com/watch?v=XZ2GjHXn-kA&list=PLdhINWyYlsB4
This button is a standing requirement for all subsequent SGG game releases, including F1.666Final.

FRONT DOOR / MOBILE ACCESS
The website front door no longer blocks phones or tablets. Mobile visitors see the same version selector as desktop visitors.
A Gallery button sits immediately to the right of the Spiffy's Gift title. A YouTube playlist button sits directly below Gallery. A Please Tip, Thank You button sits at the top-right and opens Cozmo's Ko-fi in a new tab:
https://ko-fi.com/cozmothemagician

GALLERY
The Gallery viewer displays one PNG at a time from the public sggweb/pics directory in the QuackSink repository (loaded from raw.githubusercontent.com, rather than a GitHub directory page). It supports previous/next controls, keyboard navigation and touch swiping. On phones and touch-first tablets it provides zoom controls, pinch zoom and a scrollable image surface for detailed inspection; desktop displays each complete image within the available window.
The gallery includes 17 PNG images. The MP4 and text files in pics are deliberately not listed as still images.

VERSION SELECTOR ARTWORK
The F1.666f1 selection card includes hell.png from sggweb/pics. Every newly added release entry must include its own image field in versions.json. F1.666Final is also designated to use hell.png.

PRESERVED F1.666f GAMEPLAY
The HELLgs two-dimensional fire spread/chasing flame and contact-only Game Over behavior are inherited unchanged. The exact HELLgs fast-travel refusal is unchanged. F1.666f saves, shared storage namespace, Tea/achievement ledger, hint milestones, Cozmo cameos, Quickload and backward-compatible save migration are retained.
No world assets, scene geometry, gameplay, save schema, or save storage keys are changed by this release.

VALIDATION
- Python AST parse and py_compile passed for the packaged game code.
- F1.666f class definitions remain AST-identical to the immutable F1.666f base.
- New YouTube state-machine/interface subclasses are wired into main().
- Front-door scripts include Gallery, YouTube and Ko-fi controls and no device-blocking branch.
- F1.666f1 is present in the version catalogue, marked current, with hell.png artwork.
- All 17 gallery entries are PNG files pointing at the public repository pics directory.
- Runtime APK and TAR bundle contain identical main.py and Luma assets JSON.
- All previous game-version folders and runtime files in the Cloudflare deploy are preserved byte-for-byte.

A live browser/Pygame session was not launched in this build environment. Cozmo's browser/phone field test remains necessary.
