SPIFFY'S GIFT — SGGF1.666f1j

BASE
Built from the pushed and tested SGGF1.666f1i release.

PLAINS POLISH
The mountain backdrop is now a layered, irregular ridge range instead of a row
of simple triangles. The Giant Camp approach has a gently winding packed-earth
surface, verge detail, perspective wheel ruts, scattered gravel and worn patches.
The crossroad and southern road receive restrained surface texture as well.

WALKMESH FIX
The old tall rectangular north corridor that allowed walking into the sky has
been replaced by a polygon following the northbound road and ending at the Giant
Camp horizon entrance. The existing broad lower-ground walkable region remains.
The Giant Camp transition still activates on crossing y=300 near x=640.

PRESERVED
The Stables, Mountain Path, Mudcrab River and Southern Wilds exits retain their
existing positions and connections. All connection IDs, world objects, all
non-Plains areas, rewards, dialogue, inventory, save format and backward-compatible
save behaviour are preserved. The f1i and every earlier release remain unchanged.
