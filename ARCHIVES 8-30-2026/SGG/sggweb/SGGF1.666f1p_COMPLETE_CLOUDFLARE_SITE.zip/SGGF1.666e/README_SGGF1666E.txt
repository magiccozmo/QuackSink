SPIFFY'S GIFT — SGGF1.666e

RELEASE / ARCHIVE RULE
F1.666e is a distinct release based on the exact F1.666d source and Cloudflare deployment now in the repository. F1.666d and every earlier release remain immutable. No existing archive is replaced.

FRONT DOOR DESCRIPTION
This HELLgs Inn-starting release copies the F1.666a front-door description verbatim. It includes:
"woops.. now it IS possible to escape"
No save-load exploit explanation, hint sequence, Tea system detail, or other spoiler is added to the catalogue description.

RUN-SCOPED COZMO / TEA LEDGER
A genuinely new F1.666e run begins when the E game runtime starts with no game model and the run-initialized flag is false. At that point, and only at that point, the in-memory run ledger is reset:
- Tea Earned = 0.
- The five exploit recognitions are cleared.
- Pending exploit recognitions are cleared.
- The legacy Cozmo appearance count is reset.
- Death/reload count = 0.
- Hint stage = 0.
- The fresh game's Cozmo cameo event list, queue, active cameo and Part One Cozmo encounter flag are cleared.

Returning to the main screen and resuming the same game object is not a new run and does not reset the ledger. Opening a different SGG version in another tab does not call or reset the still-open E tab's state machine.

The current-run ledger lives in the active F1.666e state machine's memory. It is deliberately not written to the shared browser config. This prevents an older SGG tab from overwriting the active E run's Tea score, exploit recognitions, death/reload counter or hint progress through a shared config write. Closing/reloading the E runtime begins a new run and therefore begins with a fresh ledger. E-created save snapshots carry one optional top-level run marker. It is not part of the world state or visible to the player. An E save from the same live run keeps its pending cameo state when loaded again. An older-version or different-run save has no matching marker, so E clears only the imported Cozmo cameo event list, pending cameo queue and active cameo actor before processing the current HELLgs escape/hint triggers. Old saved world conditions (for example, a previously dead NPC or opened vault) do not automatically earn current-run Tea.

CROSS-VERSION SAVE GAMES ARE PRESERVED
The shared E1 browser storage namespace and save-slot keys are unchanged from F1.3/F1.4/F1.5/F1.666d:
- spiffys-gift-sgge1-v1:save-quick
- spiffys-gift-sgge1-v1:save-1 through save-3

F1.666e does not delete, clear, rename, migrate away, or overwrite any save slot when a new run starts. Older SGG versions can still write a quicksave in another tab. The already-running E tab can then quickload that save; because its current player location is still HELLgs Inn, the normal F1.666c/D escape trigger sees the pre-load cell location, restores the old save's location, and spawns Cozmo at the loaded destination. That actual gameplay action awards Tea #1. Repeating the escape during the same run does not award another point.

TEA ACHIEVEMENTS AND HINTS
The five once-only gameplay achievements and their event handling remain as in D:
1. hellgs_escape — successful save load initiated from HELLgs Inn and restored outside the cell. Always the first Tea point in a new run.
2. bucket_theft — first theft while the vendor is blinded by the bucket.
3. vault_clip — first clip through the Castle Hall vault seam.
4. naz_guard_death — first time Naz is killed by the guard.
5. lout_guard_death — first time the inn lout is killed by the guard.

Non-HELLgs exploit recognitions discovered earlier in the same run remain pending until the HELLgs escape, preserving escape as Tea #1. Deaths, reloads, hints, launches, installs and old version counters do not award Tea.

The Game Over Quickload button and the 4/10/20-death hint sequence are unchanged from D. The tenth-death interaction uses the improved "I'm willing to give you an even better hint than last time" wording. The final spoiler stays pending until the explicit admission-of-defeat choice is selected. Hint encounters award no Tea.

PRESERVED SYSTEMS
The F1.666d save compatibility / additive migration system, HELLgs cell, note, fire timer, F1.6 world, fast travel, world geometry, bucket/theft/witness system, vault clipping, NPC/guard behavior, Luma recipes, browser bootstrap and game UI are otherwise unchanged. No new escape route is added or blocked.

VALIDATION
- Python AST parse, import and py_compile.
- F1.666d class and historical method preservation checks.
- New-run reset test confirms Tea/events/pending/deaths/hints and Cozmo encounter records clear once at actual start.
- Resume-from-main test confirms the same live run is not reset a second time.
- Save-slot preservation test confirms new-run reset does not touch quick or named save data.
- Two-tab simulation writes a shared quicksave as an older version would; the existing E run reads it, lands in the saved area, produces the HELLgs escape cameo and awards Tea #1.
- Older-version save snapshots containing stale bucket/Naz/vault cameo records or completed old-world conditions do not award Tea or block current-run recognitions.
- Same-run E save markers preserve that run's pending cameo queue; older/different-run saves clear only stale Cozmo cameo bookkeeping.
- E-created saves carry a top-level run marker; older serializers can ignore/drop it without changing shared slot names or save compatibility.
- Catalogue descriptions for every F1.666a-or-later HELLgs-cell start are normalized to the exact F1.666a description, without rewriting any historic release archive.
- The run ledger is not written to shared config; simulated other-tab config writes do not change the active E instance's in-memory ledger.
- Five achievements, hint tiers, final-spoiler acceptance behavior and no-Tea-on-hints regressions.
- Exact F1.666a front-door description verified in the E deployment manifest.
- All prior D Cloudflare deployment members preserved byte-for-byte except the version catalogue; five new E files added.

A live browser/Pygame session was not launched in this build environment. Cozmo's field test remains the final live verification.
