SPIFFY'S GIFT — SGGF1.666f1k

BASE
Built from Cozmo's pushed SGGF1.666f1j version. The f1j Plains work, all older
areas and the existing save/game systems are retained.

SOUTHERN WILDS REDRAW
A complete new meadow-and-mountain-pass scene. The sky remains a distinct upper
plane, the grassy ground remains a separate lower plane, and the trail passes
through a framed mountain saddle. The mountains are layered, irregular ridges
with rock faces and foothills.

The scenery uses individually designed trees rather than repeated round crowns:
an asymmetrical old oak with a twisting trunk and branching crown; a windswept
pine with layered needle boughs; a pale-barked birch; a copper-leaf rowan with
berries; a young hawthorn; and a low juniper. The meadow also gains bracken,
rocks, wildflower drifts, grass tufts, and a detailed dirt trail.

WALKMESH
The upper walkable corridor is a tapered polygon following the actual trail
through the sky portion of the mountain pass. The sky on either side is blocked.
The broad ground region is retained and extends to the bottom edge so the player
can reach the existing Side of Mountain transition at y>=615.

PRESERVED
The Plains exit at the top and Side of Mountain exit at the bottom remain in
their existing positions and use the original connection IDs, arrival points,
and triggers. World objects, all other areas, inventory, rewards, dialogue,
save schema, and backward-compatible saves are unchanged. f1j and all earlier
release folders/catalogue entries remain intact.
