SPIFFY'S GIFT — SGGF1.666f1f

BASE
This release is based directly on the tested SGGF1.666f1e build. It is a
cosmetic Front Gate correction only.

FRONT GATE ART
The central Front Gate object no longer uses the generic brown single-door
sprite with a doorknob. It now displays a full-width, iron-braced double-leaf
city gate sized to the stone arch opening. The broad timber leaves, X-bracing,
heavy iron crossbars, rivets, side hinges, and central rectangular latch make
it read as a monumental castle/city gate rather than a house door.

FUNCTIONALITY PRESERVED
The city_gate_door object ID, kind="door", and walk-trigger rectangle are
unchanged. The existing Front Gate → Outside Gate transition is unchanged.
The F1.666f1e grounded Front Gate / BritRun Market walkmesh, both reciprocal
Market transitions, Gold District route, all exit arrows, all other areas,
saves, gameplay, HELLgs challenge, Cozmo events/rewards and UI are retained.

RELEASE RULE
SGGF1.666f1f is a separate immutable release. No earlier release folder is replaced.
