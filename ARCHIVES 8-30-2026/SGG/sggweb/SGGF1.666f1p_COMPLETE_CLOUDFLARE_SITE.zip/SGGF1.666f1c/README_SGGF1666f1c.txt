SPIFFY'S GIFT — SGGF1.666f1c

BASE
This release is based on the immutable SGGF1.666f1b package. It changes only the Front Gate background art and adds a clearly marked transition arrow at the central city gate. Existing Market and Gold District edge exits, the city-gate door trigger, collision/navigation data, chicken placement, save compatibility, HELLgs fire, Tea ledger, Cozmo hint progression, fast-travel refusal, YouTube button, and all other areas are retained.

FRONT GATE REBUILD
The old Front Gate illustration is replaced with new artwork aligned to the newer BritRun Market, Gold District, Inn Outside and Castle Exterior style: stone gate arch, flanking gatehouse buildings/towers, warm and slate roof treatments, banners, lanterns, garden details, and a broad cobbled forecourt. The main approach terminates at the city gate. The existing Market-side arrival is grounded in an open grassy courtyard rather than a narrow road continuing to the top edge. The separate left-hand route serves the Gold District.

TRANSITIONS
The existing top-edge arrow continues to mark BritRun Market. The existing left-edge arrow continues to mark Gold District. A matching gold arrow and label now explicitly mark the central door transition to Outside Gate. The door object, walk trigger and all transition coordinates remain unchanged.

RELEASE RULE
F1.666f1c is a separate archive. F1.666f1b and all earlier releases are left untouched.
