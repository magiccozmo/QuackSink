SPIFFY'S GIFT — SGGF1.666f1n

BASE: Built directly from the verified SGGF1.666f1m source and deployment archives.

SIDE OF MOUNTAIN: Rebuilt from scratch. The wooden cave door graphic is removed; the cave is a natural dark opening in the cliff. A continuous broad trail now runs along the actual ground from the LEFT-side Southern Wilds exit to the cave.

TRANSITIONS: Southern Wilds return is on the left edge. Entry from Southern Wilds arrives at the left trailhead. The cave remains the existing walk-through door object and preserves its connection ID and destination.

WALKMESH: Rebuilt to cover the broad lower ground and the winding ground-level trail; the old sky-climbing corridor is removed.

PRESERVED: Other areas, assets, objects, mechanics, dialogue, save schema, and prior release folders are retained from F1m.

Browser playtest remains required.
