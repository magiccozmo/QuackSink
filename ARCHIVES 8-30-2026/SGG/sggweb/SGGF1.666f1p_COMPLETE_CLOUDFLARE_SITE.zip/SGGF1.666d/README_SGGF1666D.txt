SPIFFY'S GIFT — SGGF1.666d

RELEASE / ARCHIVE RULE
F1.666d is a separate release based on the pushed F1.666c source and Cloudflare deployment. F1.666, F1.666a, F1.666b and F1.666c remain separate, immutable archives. No existing release archive is replaced.

FRONT DOOR DESCRIPTION
The F1.666d catalogue entry copies the complete F1.666a description verbatim, including:
"woops.. now it IS possible to escape"
No explanation or spoiler for the save-load exploit appears in the front-door description. This same description rule applies to future releases that still start in the HELLgs Inn cell.

TEA IS EARNED ONLY BY PLAYING
The TEA EARNED counter is a gameplay score. A version launch, install, upgrade, old cameo counter, hint appearance, death, reload or dialogue does not award Tea.
The first Tea point is always earned by the actual HELLgs escape: while currently standing in HELLgs Inn, the player successfully loads a save whose restored location is outside HELLgs Inn. The game remembers the pre-load area, restores the save's destination and state, then Cozmo appears at that restored location and the score increases.
The other once-only gameplay achievements are:
1. bucket_theft — first successful theft while the vendor is blinded by the bucket.
2. vault_clip — first clip through the Castle Hall vault seam.
3. naz_guard_death — first time Naz is killed by the guard.
4. lout_guard_death — first time the inn lout is killed by the guard.
Each event earns one score point once. Other exploit discoveries made before the HELLgs escape remain pending; when the player performs the actual escape, Tea #1 is awarded for the escape and pending real discoveries are then credited. Repeating an exploit, repeating dialogue or loading an older save cannot earn the same point twice.
There is no Yorkshire Tea inventory item. The visible TEA EARNED counter remains the score display.

CORRECTION OF F1.666c'S STARTUP CREDIT
F1.666c incorrectly interpreted the old F1.666b `cozmo_exploiter_appearances` setting as proof that the HELLgs escape had already been performed. D removes that false `hellgs_escape` recognition and its startup score exactly once when migrating a C configuration that contains that legacy-derived mark. Any actual non-HELLgs exploit discoveries recorded in C remain recognized and their points are held pending until the genuine HELLgs escape. A genuine gameplay-earned escape score is preserved when the legacy appearance counter does not indicate C's false migration.

GAME OVER QUICKLOAD AND DEATH/RELOAD HINTS
A QUICKLOAD button appears on the Game Over screen after any player death. The configured quickload key (F9 by default) also works from that screen. The death/reload counter begins at zero for each new actual run and increments only after a successful quickload made after death. It is independent of Tea achievements.

At reload 4, when a load returns the player to HELLgs Inn, Cozmo appears. Interacting with him:
Cozmo: "If you REALLY REALLY want, I can gave you a hint"
Choice: "yah, help me out here"
Cozmo: "Are you REALLY SURE?"
Choice: "Yes I'm damn sure! I'm NOT the Spiffing Brit after all"
Cozmo: "Have you considered loading a DIFFERENT save?"

At reload 10, Cozmo speaks without requiring interaction:
"Still trying? I can offer ONE final hint"
On interaction, regardless of whether the player accepted or ignored the first hint:
"I'm willing to give you an even better hint than last time"
Choice: "Yah, i'm still stumped"
Cozmo: "I told Luma to make sure that save games are as forward compatable as possible"
Stage direction: <raises eyebrow like a certain alien>

At reload 20, Cozmo speaks without requiring interaction:
"I'm impressed by your stubborn tenacity, but I am willing to give you a total spoiler if you are willing to admit defeat"
On interaction:
"Ok, if you truly admit defeat I will tell you how to get out of here."
Choice:
"Cozmo, i'm truly stumped but want to see more of this game than these four walls and fire. Please help me out."
Cozmo then says:
"Load into a version where the starting location is NOT Hellgs Inn. Do a quicksave.  open THIS version (or later O_o) and then quickload.  I'll see ya on the other side"
Cozmo vanishes after this final spoiler is explicitly selected.

The twentieth-death encounter is NOT consumed by appearing, being ignored, being approached, interacting, or pressing Escape. It remains available on subsequent successful loads into HELLgs Inn until the player selects the explicit final-spoiler choice. The tenth-death interaction line is the same regardless of whether the player accepted the first hint. None of the hint encounters awards Tea.

SAVE COMPATIBILITY AND PRESERVED GAMEPLAY
The F1.666c central forward-compatible `spiffys-gift-save-v1` migration is preserved: saved areas, coordinates, inventory, world objects, NPCs, quests, day and elapsed time remain authoritative; missing new objects, NPCs, state fields, sets and nested dictionary defaults are added from current-version defaults. Existing area IDs must remain valid; renamed/retired IDs require explicit alias migration.
The HELLgs cell, solid barred door, fire sequence, folded note, fast travel, world geometry, NPC and guard logic, theft/witness logic, bucket exploit, vault clipping and existing area connections are unchanged from F1.666c. No escape path is added, removed or restricted.

VALIDATION
- Python AST parse, module import and py_compile.
- D ledger migration test: remove C's false startup HELLgs credit, reset the false score to zero, preserve real non-HELLgs discoveries as pending, and apply the correction only once.
- Gameplay escape test: only a successful load begun in HELLgs Inn and restored outside awards HELLgs Tea #1.
- Repeated achievement tests: all five exploit achievements are once-only; non-HELLgs events remain pending until the genuine escape.
- Hint tests: the tenth-death interaction uses the improved wording; the twentieth-death cameo remains pending after appearing or being ignored and completes only on the explicit spoiler choice.
- D re-queues an uncompleted hint milestone when a subsequent successful save load returns the player to HELLgs Inn.
- Regression tests: F1.666c world/assets, forward-compatible save migration, fast travel, death Quickload, bucket/theft, vault clip and NPC/guard mechanics remain unchanged.
- F1.666a front-door description is copied verbatim; no exploit spoiler appears.
- All prior Cloudflare deployment entries are retained byte-for-byte except the current-version catalogue; five new F1.666d deployment entries are added.

A live browser/Pygame session was not launched in this build environment. Cozmo's field test remains the final live verification.
