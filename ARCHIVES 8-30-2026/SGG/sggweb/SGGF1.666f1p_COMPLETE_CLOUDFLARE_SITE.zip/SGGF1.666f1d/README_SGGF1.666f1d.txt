SPIFFY'S GIFT — SGGF1.666f1d

BASE
This release is based directly on the immutable SGGF1.666f1c package. It is a
focused Castle Path navigation correction. Prior releases remain untouched.

CASTLE PATH WALKMESH
The walkmesh now follows the paved route continuously from the castle arch,
through the upper bend, and into the existing lower S-curve. The previous
F1.666f1c mesh began at the upper bend and left the paved stretch between the
gate and that bend unmapped. The new corridor uses foot-point coordinates and
keeps the player on the visible stone road instead of allowing movement over
the surrounding grass and hillside.

CASTLE ENTRY TRANSITION
The invisible Castle Exterior threshold is aligned with the player's position
shown in the original new-path reference. Its coordinates are body-centre
coordinates; the matching walkmesh point is 14 px lower at the character's
feet. The direction of approach and the visible transition arrow are retained.

PRESERVED
All other areas, art, doors, exit arrows, collision rules, save compatibility,
HELLgs Inn challenge, Cozmo exploit/Tea rewards, hint progression, narration,
YouTube link, and Ko-fi/tip behaviour are inherited unchanged from F1.666f1c.

RELEASE RULE
SGGF1.666f1d is a separate release. SGGF1.666f1c and all earlier archives are left untouched.
