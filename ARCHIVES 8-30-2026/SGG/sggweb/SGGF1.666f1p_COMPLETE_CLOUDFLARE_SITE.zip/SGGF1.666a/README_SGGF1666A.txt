SPIFFY'S GIFT — SGGF1.666a

BASE
F1.666 is the direct gameplay and world baseline. The prior F1.666 release remains preserved as-is in its own archive. This new release is a separate additive version; it does not replace or edit F1.666.

HELLgs INN
The game still starts in the same small stone cell called HELLgs Inn. Its only visible exit is the same solid barred cell door drawn into the background and backed by collision geometry. It is not a world object, is not interactable, and has no ordinary door transition. Stone walls and the closed cell door remain solid. The cell floor remains walkable.

A folded paper lies on the floor. Pick it up, open Inventory, select the paper, and press E to read. The paper text is intentionally unchanged from F1.666:

Welcome brave exploiter to version F1.666 of Spiffy's Gift.
I look forwarding to meeting you.
Signed Cozmo

BACKWARD SAVE COMPATIBILITY — THE F1.666a FIX
F1.6 quicksaves can now load in F1.666a. F1.6 saves do not contain the HELLgs paper object because that object did not exist when they were made. During the normal save-load migration, F1.666a adds only the missing default hellgs_note object and its item metadata before the existing world-object validation runs.

The migration does not replace the saved world state. It preserves the saved area, player coordinates, inventory, existing object records, quest flags, day, elapsed time, and other saved fields. The old saved area and coordinates therefore take precedence over the new HELLgs Inn starting location. The loader does not create a new exit or a special escape mechanic; it simply restores compatibility with the cross-version quickload path that Cozmo is testing.

END CONDITION
The existing HELLgs Inn fire end condition remains one in-game day OR the selected real-time timer, whichever comes first. Initial End Timer in Minutes remains a persistent settings slider, range 1–1440 minutes, default 60 minutes. Press T to advance one in-game day. The fire still surges through the gate, consumes the player, and causes a final GAME OVER; R does not respawn the player.

SCOPE / PRESERVATION
No new area, normal exit, door object, or Hellgs area connection has been added. Existing F1.666 gameplay systems, including the ordinary fast-travel system and its existing destination list, are retained. The only gameplay code change is the backward-save migration for hellgs_note. The existing version F1.666 archive and Cloudflare deployment are not modified or replaced.

FRONT-DOOR VERSION DESCRIPTION
The F1.666 front-door description is carried forward unchanged, with this addition appended: "woops.. now it IS possible to escape".

TESTING
Static checks include an actual in-memory load of a synthetic F1.6-format save through the same C131GameModel.from_snapshot migration path used by quickload. The test verifies that the old area, player coordinates, inventory, quest flags, and existing objects survive while exactly one default hellgs_note object is supplied. A second pass verifies an already-present paper object is not duplicated. Packaging checks verify that F1.666 historical deployment files remain preserved and that F1.666a is added as a distinct new release. A live browser launch remains for Cozmo's field test.
