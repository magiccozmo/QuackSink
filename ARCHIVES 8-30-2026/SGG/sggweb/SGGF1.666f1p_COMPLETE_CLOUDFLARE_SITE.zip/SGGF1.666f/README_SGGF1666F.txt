SPIFFY'S GIFT — SGGF1.666f

RELEASE / ARCHIVE RULE
F1.666f is a distinct release based on the exact F1.666e source and Cloudflare deployment archives. F1.666e and every earlier release remain immutable. No existing archive is replaced.

FRONT DOOR DESCRIPTION
This HELLgs Inn-starting release copies the F1.666a front-door description verbatim, including:
"woops.. now it IS possible to escape"
The catalogue description does not add save-load exploit instructions, the hint sequence, Tea system details, or other spoilers.

HELLgs FIRE — TWO-DIMENSIONAL SPREAD AND PLAYER CONTACT
The old single vertical fire wall and bottom-edge Game Over shortcut are replaced. The fire now spreads from the barred doorway across a 36-by-11 grid covering the cell interior. Staggered ignition times create an irregular, room-filling wave rather than a straight wall. A separate flame tongue begins pursuing the player after the initial spread delay.

The player can still use normal directional movement during the fire sequence, so the player can attempt to evade the flames. The fire sequence closes menus and other overlays that could cover the scene or prevent the challenge from playing out. Game Over occurs only after an active spreading-fire tile overlaps the player's collision rectangle or the pursuing flame reaches the player collision bounds. The old remaining-time field remains available for compatibility with earlier saves, but it no longer independently triggers death.

HELLgs FAST TRAVEL
Pressing M in HELLgs Inn refuses fast travel, does not open the map, and displays this exact message:
"no fast travel allowed here, didja really think it would be THAT easy?"
Fast travel outside the cell continues through the inherited F1.666e handler.

PRESERVED F1.666e SYSTEMS
F1.666e save compatibility and additive migration remain in place. Shared save slots and the E1 browser storage namespace are not renamed, deleted, or cleared. Existing saved locations, player/world state, inventory, NPC state, quests and world objects continue to be loaded through the inherited save system.

The per-run Tea / exploit ledger, Cozmo cameo bookkeeping, 4/10/20 death-and-reload hints, Quickload button, five once-only exploit recognitions, and prior HELLgs escape behavior are inherited unchanged. No Tea is awarded for the two F changes themselves. The F1.666a front-door description remains the exact safe description for this cell-start release.

VALIDATION
- Python AST parsing, module py_compile and preparation-script py_compile.
- Every inherited F1.666e class is AST-identical to its immutable E baseline; F adds only its new state-machine/interface subclasses and app wiring.
- Exact HELLgs fast-travel refusal tested; existing outside-cell fast travel remains functional.
- 36-by-11 fire field reaches the whole room and physically contacts the normal spawn location.
- Separate pursuing flame advances faster than the maximum configured player movement.
- Starting the fire closes modal UI and the fast-travel overlay while keeping directional movement available.
- A zeroed legacy countdown does not cause Game Over without fire/player contact.
- Actual fire/player contact triggers Game Over; the inherited Quickload control remains available.
- Cloudflare deploy retains all 200 previous entries byte-for-byte except the version catalogue and adds five F files.
- APK and TAR runtime payloads contain the exact tested main.py and asset JSON.
- The F deployment catalogue uses the exact F1.666a-safe description for every HELLgs cell-start release A through F.

A live browser/Pygame launch was not run because Pygame is not installed in the build environment. Cozmo's field test remains necessary.
