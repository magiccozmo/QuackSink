SPIFFY'S GIFT — SGGF1.666c

RELEASE / ARCHIVE RULE
F1.666c is a separate release based on the exact F1.666b source and Cloudflare deployment pushed to magiccozmo/QuackSink. F1.666, F1.666a and F1.666b remain separate, immutable archives. No existing release archive is replaced.

FRONT DOOR DESCRIPTION
The F1.666c catalogue entry deliberately copies the complete F1.666a description verbatim, including:
"woops.. now it IS possible to escape"
It does not include F1.666b's explanation of the save-load exploit.

HELLGS ESCAPE / SAVE COMPATIBILITY
The game continues to start in HELLgs Inn. The F1.666b forward-compatible save migration is preserved. On a successful save load, the game remembers the player's current area before loading. If that area was hellgs_inn and the loaded save places the player elsewhere, Cozmo appears in the location restored by the save. A failed or missing save does not trigger the appearance. The loaded save's area, coordinates, inventory and game state remain authoritative.

COZMO'S FIVE ONCE-ONLY EXPLOIT RECOGNITIONS
Each distinct event is recognized globally once, outside individual save slots. When Cozmo appears for that event, it earns one point on the visible TEA EARNED counter:
1. hellgs_escape — successfully load away from HELLgs Inn. This is always Tea #1.
2. bucket_theft — the first successful unwitnessed theft while the vendor/guard is blinded by the bucket. Stealing further items under the same bucket does not create another appearance or point.
3. vault_clip — the first clip through the Castle Hall vault seam.
4. naz_guard_death — the first time Naz is killed by the guard.
5. lout_guard_death — the first time the inn lout is killed by the guard.

The five event flags and TEA EARNED total are stored in the shared persistent settings, not in an individual save slot. Repeated exploits, repeated dialogue, and loading an older save do not award the same point again. If an older save already records one of the D1.1 bucket/Naz cameos, that completed recognition is migrated instead of replayed. If a non-HELLgs recognition is found before the escape, its score point is held until the HELLgs escape is credited, ensuring the first earned Tea point remains the escape.

TEA IS A SCORE, NOT AN INVENTORY ITEM
F1.666c uses a visible TEA EARNED: N counter. It does not create a Yorkshire Tea object, consume inventory space, or add a new item interaction. The old F1.666b alternating tea-item reward is retired in this release.

F1.666b COUNTER MIGRATION
F1.666b's legacy setting cozmo_exploiter_appearances counted successful loads from HELLgs Inn. If an existing shared configuration has one or more such appearances, F1.666c converts them into the single once-only hellgs_escape recognition and initializes TEA EARNED to 1. It does not replay that already-recognized escape cameo. This preserves the fact that the player had already discovered the escape in an earlier release.

GAME OVER QUICKLOAD AND DEATH/RELOAD HINTS
A QUICKLOAD button appears on the Game Over screen after any player death. The configured quickload key (F9 by default) also works from that screen. The internal death/reload count begins at zero for each new actual run and increments only after a successful quickload made after death. This counter is independent of the five exploit achievements and is kept outside individual save slots.

When a successful post-death quickload returns the player to HELLgs Inn, Cozmo provides these no-tea hints once each, in order:

At reload 4:
Cozmo: "If you REALLY REALLY want, I can gave you a hint"
Choice: "yah, help me out here"
Cozmo: "Are you REALLY SURE?"
Choice: "Yes I'm damn sure! I'm NOT the Spiffing Brit after all"
Cozmo: "Have you considered loading a DIFFERENT save?"

At reload 10, Cozmo speaks before interaction:
"Still trying? I can offer ONE final hint"
On interaction: "You really want another hint?"
Choice: "Yah, i'm still stumped"
Cozmo: "I told Luma to make sure that save games are as forward compatable as possible"
Stage direction: <raises eyebrow like a certain alien>

At reload 20, Cozmo speaks before interaction:
"I'm impressed by your stubborn tenacity, but I am willing to give you a total spoiler if you are willing to admit defeat"
On interaction: "Ok, if you truly admit defeat I will tell you how to get out of here."
Choice: "Cozmo, i'm truly stumped but want to see more of this game than these four walls and fire. Please help me out."
Final spoiler:
"Load into a version where the starting location is NOT Hellgs Inn. Do a quicksave.  open THIS version (or later O_o) and then quickload.  I'll see ya on the other side"
Cozmo vanishes after delivering the final spoiler.

The three death/reload hint appearances never award Tea. The milestones are independent of the five exploit-achievement appearances.

PRESERVED GAMEPLAY
The HELLgs cell, solid barred door, fire sequence, folded note, fast travel, world geometry, NPC logic, theft/witness logic, bucket exploit, vault clipping and existing area connections are unchanged from F1.666b. No new exit, escape route, anti-exploit restriction or exploit patch was added. The world/asset JSON differs from F1.666b only in the version identifier and release notes.

VALIDATION
- Python AST parse, import and py_compile passed.
- In-memory score-ledger tests passed: each of five events is once-only; HELLgs escape is first; earlier event points are held pending until escape.
- Runtime cameo-queue tests passed for bucket theft, Naz guard death (waiting for BritRun Market), vault clipping, inn-lout guard death and HELLgs escape.
- Runtime hint-tier tests passed for the fourth, tenth and twentieth successful death quickloads back into HELLgs; hint cameos do not award Tea.
- Regression checks confirm F1.666b's shared save migration, F1.6 fast-travel path, HELLgs timer/death logic, core D1.1 bucket/Naz mechanics, world data and Luma assets remain unchanged.
- Catalogue description matches F1.666a exactly.
- The Cloudflare deployment carries every previous deployment entry forward byte-for-byte except the version catalogue, and adds a separate F1.666c runtime.

A live browser/Pygame session was not launched in this build environment. Cozmo's field test remains the final live verification.
