SPIFFY'S GIFT — SGGF1.666f1h

BASE
Based directly on the user's SGGF1.666f1g release.

FIX
The Outside Gate now renders the same 200x128 double-leaf city gate as Front Gate
at game coordinates (540,316), regardless of older saved object dimensions. This
fixes quicksaves created before f1g, which still carry the original 90x122 rect.

PRESERVED
The city_gate_return object identity and saved state are not rewritten. Its original
walk_trigger remains [590,383,104,21] with approach=north. All area definitions,
connections, world art, walkmesh, Stables exit, arrows, rewards, dialogue, saves
and gameplay systems are preserved. All older releases remain separate.
