SPIFFY'S GIFT — CLEAN DEPLOYMENT

CURRENT VERSION: SGGF1Clean2.5

This complete Cloudflare site retains eleven deliberately selected playable editions:
- SGGF1Clean2.5 — current curated archive release; the Clean2.4 game is unchanged.
- SGGF1Clean2.4 — Frosty's Cave Entrance save/hover correction.
- SGGF1Clean2.2 — Scenic Overlook summit experience.
- SGGF1.666Cleanup1.0 — curated F1 milestone consolidation.
- SGGF1.666f1s, SGGF1.666, SGGF1.6, SGGF1.0, SGGE3.2, SGGE3.1 and SGGE2.0 — preserved legacy milestones.

Intermediate SGGF1Clean2, SGGF1Clean2.1 and SGGF1Clean2.3 test releases are omitted from this compact bundle. Their original historical archives are not deleted or overwritten.

This is an archive/package update only. The Clean2.4 game runtime, world state, areas, objects, exits, walkmeshes, artwork recipes, save compatibility and gameplay remain unchanged.
