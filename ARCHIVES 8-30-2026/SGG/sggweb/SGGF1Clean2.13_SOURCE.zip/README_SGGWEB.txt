SPIFFY'S GIFT — SOURCE HANDOFF
Current edition: SGGF1Clean2.13.
Permanent legacy edition: SGGF1.666Cleanup1.0.
The source handoff retains only those two complete release snapshots, plus the shared current source, assets, project documentation and build/test tools. Intermediate releases remain available in Cozmo's GitHub repository and local archives.
