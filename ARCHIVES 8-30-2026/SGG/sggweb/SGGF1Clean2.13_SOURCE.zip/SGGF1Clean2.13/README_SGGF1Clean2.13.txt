SPIFFY'S GIFT — SGGF1Clean2.13

BASELINE: The exact SGGF1Clean2.11 source and complete deployment ZIPs retrieved from GitHub main commit b2a98a0d3c3b1b7a6566699f70667eae817355d8. Clean2.13 carries forward Clean2.11's Redroot legacy-save access correction and Potent Problem recipe-book tabletop migration.

HELLgs GAME OVER / QUICKLOAD REPAIR

• The generic C1 death renderer suppresses its ordinary YOU DIED overlay only while the HELLgs game-over flag is active. The separate HELLgs GAME OVER card remains visible; c1_dead remains set, so the Tea Earned counter and Quickload button continue to render.
• The configured Quickload keybinding (F9 by default) is routed before the older HELLgs terminal input lock.
• Mouse clicks are converted to game coordinates and checked against an enlarged hit area surrounding the visible QUICKLOAD button. Hit-test, input and load-result details are recorded in the flight log.
• Escape still exits the ended challenge to the tool. R, movement and all other ordinary actions remain disabled during HELLgs Game Over.

PRESERVATION

• Clean2.11 Redroot object identity/access behavior, exact-default shelf-flag migration, recipe-book table position and old-save migration are unchanged.
• No Luma drawing recipes, world objects, area geometry, walkmesh, collision, nav regions, area connections, quests, Tea awards, or other gameplay behavior was changed intentionally.
• The front-door deployment catalogue is deliberately curated to exactly two choices: SGGF1Clean2.13 (current) and SGGF1.666Cleanup1.0 (permanent legacy release). All other intermediate Clean2 and historical source archives remain in Cozmo's repository/local archive, not in this lean delivery.

TESTING / LIMITATIONS

The source syntax is checked, JSON parses, runtime APK/TAR integrity and payload mirrors are checked, the deployment catalogue contains only the current release plus the unchanged Cleanup1.0 legacy release, and the source-embedded deploy mirror matches the standalone Cloudflare ZIP. A focused test file covers the terminal Quickload routing and preservation invariants.

Pygame is not installed in the build environment. No live browser, WebAssembly, Cloudflare, physical mouse, keyboard, save/load or gameplay field test was performed by Luma. Cozmo's field test is required before the candidate can be promoted to final.
