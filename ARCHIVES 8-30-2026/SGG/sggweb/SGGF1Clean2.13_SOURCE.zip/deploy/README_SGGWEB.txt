SPIFFY'S GIFT — COMPLETE CLOUDFLARE SITE
Current playable edition: SGGF1Clean2.13.
Permanent legacy edition: SGGF1.666Cleanup1.0.
The version selector intentionally contains only these two editions. All intermediate releases remain in Cozmo's repository and local archives, not in this lean deployment.
