CURRENT PLAYABLE EDITION: SGGF1Clean2.13.
PERMANENT LEGACY EDITION: SGGF1.666Cleanup1.0.
This lean deployment intentionally includes only these two selectable releases.
