Spiffy’s Gift static Cloudflare site. Current edition: SGGJ1.0. Previous editions, including SGGK1.12, are preserved. J1.0 is a spatial continuity pass; deploy the complete site folder as a unit.
