"""Build and validate SGGF1.1 source and Cloudflare deployment ZIPs."""
from pathlib import Path
import ast
import copy
import gzip
import hashlib
import io
import json
import re
import subprocess
import sys
import tarfile
import zipfile

ROOT = Path('/mnt/data')
WORK = Path(__file__).resolve().parent
BASE_DEPLOY = ROOT / 'SGGF1.0_CLOUDFLARE_DEPLOY.zip'
MAIN = WORK / 'main.py'
ASSETS = WORK / 'luma_assets_e33.json'
PLAY = WORK / 'F1_play.html'
README = WORK / 'README_SGGF11.txt'
DEPLOY = ROOT / 'SGGF1.1_CLOUDFLARE_DEPLOY.zip'
SOURCE = ROOT / 'SGGF1.1_SOURCE.zip'

code = MAIN.read_bytes()
assets = ASSETS.read_bytes()
page = PLAY.read_text(encoding='utf-8')
manifest_bytes = (WORK / 'deploy' / 'versions.json').read_bytes()
manifest = json.loads(manifest_bytes)

ast.parse(code.decode('utf-8'))
subprocess.run([sys.executable, '-m', 'py_compile', str(MAIN)], cwd=WORK, check=True)
subprocess.run([sys.executable, str(WORK / 'test_f11.py')], cwd=WORK, check=True)
assert BASE_DEPLOY.exists(), BASE_DEPLOY
assert all(x in page for x in ('SGGF1.1', 'sggf11.apk', 'sggf11.tar.gz', 'archive:"sggf11"'))
assert 'sggf10' not in page and 'SGGF1.0' not in page
assert manifest['versions'][0]['version'] == 'SGGF1.1'
assert manifest['versions'][0]['current'] is True
assert manifest['versions'][1]['version'] == 'SGGF1.0'
assert all(not x.get('current') for x in manifest['versions'][1:])
assert len(manifest['versions']) == 28

# Runtime payloads contain only the exact current source + JSON asset pack.
apkb = io.BytesIO()
with zipfile.ZipFile(apkb, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as apk:
    apk.writestr('assets/main.py', code)
    apk.writestr('assets/luma_assets_e33.json', assets)

tarb = io.BytesIO()
with gzip.GzipFile(fileobj=tarb, mode='wb', compresslevel=9, mtime=0) as gz:
    with tarfile.open(fileobj=gz, mode='w') as tf:
        for name, payload in (('assets/main.py', code), ('assets/luma_assets_e33.json', assets)):
            info = tarfile.TarInfo(name)
            info.size = len(payload)
            info.mode = 0o644
            info.mtime = 0
            tf.addfile(info, io.BytesIO(payload))

with zipfile.ZipFile(BASE_DEPLOY, 'r') as old:
    assert old.testzip() is None
    old_names = old.namelist()
    assert len(old_names) == 140
    assert all(name in old_names for name in (
        'index.html', 'versions.html', 'versions.json', '_headers',
        'SGGF1.0/play.html', 'SGGF1.0/favicon.png',
        'SGGF1.0/sggf10.apk', 'SGGF1.0/sggf10.tar.gz', 'SGGF1.0/README_SGGF10.txt'))
    favicon = old.read('SGGF1.0/favicon.png')
    additions = [
        ('SGGF1.1/play.html', page.encode('utf-8')),
        ('SGGF1.1/favicon.png', favicon),
        ('SGGF1.1/sggf11.apk', apkb.getvalue()),
        ('SGGF1.1/sggf11.tar.gz', tarb.getvalue()),
        ('SGGF1.1/README_SGGF11.txt', README.read_bytes()),
    ]
    with zipfile.ZipFile(DEPLOY, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=8) as out:
        for member in old.infolist():
            payload = manifest_bytes if member.filename == 'versions.json' else old.read(member.filename)
            out.writestr(copy.copy(member), payload)
        for name, payload in additions:
            out.writestr(name, payload)

# Re-open and deeply validate final deploy archive and source archive inputs.
with zipfile.ZipFile(DEPLOY, 'r') as z:
    assert z.testzip() is None
    names = z.namelist()
    assert len(names) == len(old_names) + len(additions) == 145
    assert len(set(names)) == len(names)
    with zipfile.ZipFile(BASE_DEPLOY, 'r') as old:
        for name in old_names:
            expected = manifest_bytes if name == 'versions.json' else old.read(name)
            assert z.read(name) == expected, f'Unexpected historical/site change: {name}'
    for name, payload in additions:
        assert z.read(name) == payload, f'New file mismatch: {name}'
    final_doc = json.loads(z.read('versions.json'))
    assert len(final_doc['versions']) == 28
    assert final_doc['versions'][0]['version'] == 'SGGF1.1'
    assert final_doc['versions'][0]['current'] is True
    assert all(v['current'] is False for v in final_doc['versions'][1:])
    for v in final_doc['versions']:
        assert re.fullmatch(r'SGG[A-Z]\d+(?:\.\d+)*', v['version'])
        assert re.fullmatch(r'SGG[A-Z]\d+(?:\.\d+)*\/(?:play|index)\.html', v['path'])
    with zipfile.ZipFile(io.BytesIO(z.read('SGGF1.1/sggf11.apk'))) as runtime:
        assert runtime.testzip() is None
        assert runtime.namelist() == ['assets/main.py', 'assets/luma_assets_e33.json']
        assert runtime.read('assets/main.py') == code
        assert runtime.read('assets/luma_assets_e33.json') == assets
    with tarfile.open(fileobj=io.BytesIO(z.read('SGGF1.1/sggf11.tar.gz')), mode='r:gz') as runtime:
        assert runtime.extractfile('assets/main.py').read() == code
        assert runtime.extractfile('assets/luma_assets_e33.json').read() == assets
    final_page = z.read('SGGF1.1/play.html').decode('utf-8')
    assert 'archive:"sggf11"' in final_page and 'sggf11.apk' in final_page and 'sggf11.tar.gz' in final_page
    for name in ('index.html','versions.html'):
        html = z.read(name).decode('utf-8')
        assert 'isPhoneOrTablet' in html and 'navigator.userAgentData?.mobile' in html
    print(f'PASS deployment: all {len(old_names)} F1.0 site entries preserved (only version catalog advanced); {len(additions)} F1.1 entries added.')

# Build metadata after all hashes and checks are known.
meta = {
    'version': 'SGGF1.1',
    'based_on': 'SGGF1.0',
    'scope': 'Extracted original carriage artwork into its own fixed JSON world object; replaced the baked-in horse with an independently editable dark-bay draft-horse recipe; extracted the right-side paddock rails/posts as a separate foreground object. No intended gameplay changes.',
    'preserved': ['F1.0 player progress/save schema', 'Kitty animation recipes and patrol', 'Stables background commands outside the extracted coach/horse/fence regions', 'Stables solid geometry/navigation/vendor location', 'Fearmonger reward and Egg McGuffin Sammich', 'driver breakfast handoff and carriage unlock', 'Cozmo four-page Part One finale', 'visitor comments feature', 'all historical site releases'],
    'source_main_sha256': hashlib.sha256(code).hexdigest(),
    'assets_json_sha256': hashlib.sha256(assets).hexdigest(),
    'previous_deploy_sha256': hashlib.sha256(BASE_DEPLOY.read_bytes()).hexdigest(),
    'deploy_sha256': hashlib.sha256(DEPLOY.read_bytes()).hexdigest(),
    'deploy_bytes': DEPLOY.stat().st_size,
    'historical_site_entry_count_preserved': len(old_names),
    'new_deployment_files': [name for name, _ in additions],
    'release_catalog_versions': len(manifest['versions']),
    'independent_assets': {
        'stable_carriage': {'size': [373, 248], 'commands': 56},
        'stable_draft_horse': {'size': [200, 200], 'commands': 65, 'coat': 'dark bay / chestnut with black mane and lower legs'},
        'stables_foreground_fence': {'size': [137, 62], 'commands': 5},
    },
    'stable_background_command_count': 648,
    'static_regression': 'PASS: Python AST/py_compile, Luma engine load, all recipe commands supported, exact coach/fence extraction, Kitty artwork equality, Stable geometry/remaining background command equality, F1.0 save migration, original quest/driver/finale regression harness, mobile gate and catalog checks, deployment ZIP CRC, all original 140 site entries preserved apart from version catalog, F1.1 APK/tar payload equality.',
    'runtime_note': 'The game was not launched in a live browser during this build; please field-test the deployed release before treating browser runtime behavior as verified.',
}
(WORK / 'F1.1_BUILD_META.json').write_text(json.dumps(meta, indent=2) + '\n', encoding='utf-8')

# The source archive includes direct F1.0 baselines, current source/assets, tests,
# reproducible asset/packaging scripts, previews and the root front-door files.
source_files = [
    ('main.py', MAIN),
    ('luma_assets_e33.json', ASSETS),
    ('README_SGGF11.txt', README),
    ('F1_play.html', PLAY),
    ('test_f11.py', WORK / 'test_f11.py'),
    ('make_f11_changes.py', WORK / 'make_f11_changes.py'),
    ('render_preview.py', WORK / 'render_preview.py'),
    ('package_f11.py', WORK / 'package_f11.py'),
    ('F1.1_BUILD_META.json', WORK / 'F1.1_BUILD_META.json'),
    ('F1.1_HORSE_ASSET_PREVIEW.png', WORK / 'F1.1_HORSE_ASSET_PREVIEW.png'),
    ('F1.1_STABLES_PREVIEW.png', WORK / 'F1.1_STABLES_PREVIEW.png'),
    ('F1.0_MAIN_BASE.py', WORK / 'F1.0_MAIN_BASE.py'),
    ('F1.0_BASE_LUMA_ASSETS.json', WORK / 'F1.0_BASE_LUMA_ASSETS.json'),
    ('F1.0_BUILD_META.json', WORK / 'F1_BUILD_META.json'),
    ('F1.0_STABLES_BACKGROUND_PREVIEW.png', WORK / 'F1_STABLES_BACKGROUND_PREVIEW.png'),
    ('deploy/index.html', WORK / 'deploy/index.html'),
    ('deploy/versions.html', WORK / 'deploy/versions.html'),
    ('deploy/versions.json', WORK / 'deploy/versions.json'),
    ('deploy/_headers', WORK / 'deploy/_headers'),
]
with zipfile.ZipFile(SOURCE, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as out:
    for arcname, path in source_files:
        assert path.exists(), f'Missing source component: {path}'
        out.write(path, arcname)
with zipfile.ZipFile(SOURCE, 'r') as z:
    assert z.testzip() is None
    assert z.read('main.py') == code
    assert z.read('luma_assets_e33.json') == assets
    assert z.read('F1_play.html') == page.encode('utf-8')
    assert set(n for n,_ in source_files) == set(z.namelist())

print('DEPLOY:', DEPLOY, DEPLOY.stat().st_size, 'bytes')
print('DEPLOY SHA256:', hashlib.sha256(DEPLOY.read_bytes()).hexdigest())
print('SOURCE:', SOURCE, SOURCE.stat().st_size, 'bytes')
print('SOURCE SHA256:', hashlib.sha256(SOURCE.read_bytes()).hexdigest())
print('MAIN SHA256:', meta['source_main_sha256'])
print('ASSETS SHA256:', meta['assets_json_sha256'])
