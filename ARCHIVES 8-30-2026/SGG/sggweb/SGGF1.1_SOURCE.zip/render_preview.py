from pathlib import Path
import json
from PIL import Image, ImageDraw
S=3
D=json.loads(Path('/mnt/data/sgg_f11_work/luma_assets_e33.json').read_text())
AS=D['assets']

def draw_recipe(im, recipe, x, y, w=None, h=None):
    a=AS[recipe]
    w=w or a['width']; h=h or a['height']
    sx=w/a['width']; sy=h/a['height']
    # im is 3x full-size; coordinates in world scale.
    dr=ImageDraw.Draw(im)
    for c in a['commands']:
        col=tuple(c.get('color',(255,255,255)))
        op=c['op']
        if op in ('rect','ellipse'):
            rx,ry,rw,rh=c['rect']; box=((x+rx*sx)*S,(y+ry*sy)*S,(x+(rx+rw)*sx)*S,(y+(ry+rh)*sy)*S)
            if op=='rect':
                radius=c.get('radius',0)*S*min(sx,sy)
                if radius:
                    dr.rounded_rectangle(box,radius=radius,fill=col,outline=col if c.get('border',0) else None,width=max(1,int(c.get('border',0)*S*min(sx,sy))))
                else:
                    dr.rectangle(box,fill=col)
                    if c.get('border',0): dr.rectangle(box,outline=col,width=max(1,int(c['border']*S*min(sx,sy))))
            else:
                if c.get('border',0):
                    dr.ellipse(box,outline=col,width=max(1,int(c['border']*S*(sx+sy)/2)))
                else: dr.ellipse(box,fill=col)
        elif op=='polygon':
            pts=[((x+px*sx)*S,(y+py*sy)*S) for px,py in c['points']]
            if c.get('border',0):
                dr.polygon(pts,fill=col)
                # approximate border with jointed thick polyline
                dr.line(pts+[pts[0]],fill=col,width=max(1,int(c['border']*S*(sx+sy)/2)),joint='curve')
            else: dr.polygon(pts,fill=col)
        elif op=='line':
            pts=[((x+px*sx)*S,(y+py*sy)*S) for px,py in c['points']]
            dr.line(pts,fill=col,width=max(1,int(c.get('width',1)*S*(sx+sy)/2)),joint='curve')
        elif op=='circle':
            cx,cy=c['center']; r=c['radius']*S*(sx+sy)/2
            box=((x+cx*sx)*S-r,(y+cy*sy)*S-r,(x+cx*sx)*S+r,(y+cy*sy)*S+r)
            if c.get('border',0): dr.ellipse(box,outline=col,width=max(1,int(c['border']*S*(sx+sy)/2)))
            else: dr.ellipse(box,fill=col)

def downsample(im): return im.resize((1280,640),Image.Resampling.LANCZOS)
bg=Image.new('RGBA',(1280*S,640*S),(0,0,0,0))
draw_recipe(bg,'c1_bg_stables',0,0,1280,640)
draw_recipe(bg,'stable_carriage',565,235,373,248)
draw_recipe(bg,'stable_draft_horse',865,265,200,200)
draw_recipe(bg,'stables_foreground_fence',930,360,137,62)
# Render the current vendor role at the same centre/size as the game engine.
role= D.get('render_roles',{}).get('vendor','vendor')
if role in AS:
    draw_recipe(bg,role,1024-76/2,447-108/2,76,108)
# Add an understated label below the scene so this asset preview is self-identifying.
out=downsample(bg).convert('RGB')
out.save('/mnt/data/sgg_f11_work/F1.1_STABLES_PREVIEW.png',quality=95)

# Independent transparent horse recipe preview, native dimensions scaled x3 for inspection.
horse=Image.new('RGBA',(200*S,200*S),(0,0,0,0))
draw_recipe(horse,'stable_draft_horse',0,0,200,200)
horse.resize((600,600),Image.Resampling.LANCZOS).save('/mnt/data/sgg_f11_work/F1.1_HORSE_ASSET_PREVIEW.png')
