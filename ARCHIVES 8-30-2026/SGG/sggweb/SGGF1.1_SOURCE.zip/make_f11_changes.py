from pathlib import Path
import json, copy, hashlib

WORK = Path(__file__).resolve().parent
MAIN = WORK / 'main.py'
ASSET = WORK / 'luma_assets_e33.json'

# Save original F1.0 files to keep an exact comparison baseline in the source package.
(WORK / 'F1.0_MAIN_BASE.py').write_bytes(MAIN.read_bytes())
(WORK / 'F1.0_BASE_LUMA_ASSETS.json').write_bytes(ASSET.read_bytes())

D = json.loads(ASSET.read_text(encoding='utf-8'))
assert D['version'] == 'SGGF1.0'
areas = {a['area_id']: a for a in D['world']['areas']}
stables = areas['stables']
assert stables['background_asset'] == 'c1_bg_stables'
commands = D['assets']['c1_bg_stables']['commands']
assert len(commands) == 727

# Extract the exact carriage/shadow vector commands and translate them into a local asset.
def translate_command(c, dx, dy):
    c = copy.deepcopy(c)
    if 'rect' in c:
        x, y, w, h = c['rect']
        c['rect'] = [x + dx, y + dy, w, h]
    if 'points' in c:
        c['points'] = [[x + dx, y + dy] for x, y in c['points']]
    if 'center' in c:
        x, y = c['center']
        c['center'] = [x + dx, y + dy]
    return c

carriage_cmds = [translate_command(c, -565, -235) for c in commands[564:620]]
assert len(carriage_cmds) == 56
D['assets']['stable_carriage'] = {
    'width': 373,
    'height': 248,
    'commands': carriage_cmds,
}

# Preserve the original right-hand paddock rails/posts as an independent foreground recipe.
fence_indices = [639, 641, 648, 649, 650]
fence_cmds = [translate_command(commands[i], -930, -360) for i in fence_indices]
D['assets']['stables_foreground_fence'] = {
    'width': 137,
    'height': 62,
    'commands': fence_cmds,
}

# A new, self-contained JSON drawing recipe for a sturdy dark-bay working draft horse.
# The silhouette is deliberately low and powerful rather than long-necked or spindly.
H = []
def add(op, **kw):
    H.append({'op': op, **kw})
# Soft ground contact and harness traces toward the carriage.
add('ellipse', rect=[29, 181, 151, 11], color=[44, 49, 35])
add('line', points=[[0, 111], [34, 112], [81, 108], [122, 107]], color=[83, 54, 36], width=6)
add('line', points=[[0, 127], [34, 130], [81, 128], [121, 124]], color=[173, 119, 67], width=4)
add('line', points=[[3, 110], [39, 110], [83, 106]], color=[218, 172, 104], width=2)

# Tail behind the rump.
add('polygon', points=[[47, 94], [37, 98], [34, 115], [22, 132], [17, 147], [25, 150], [39, 136], [49, 119], [57, 105]], color=[49, 35, 29], border=0)
add('line', points=[[31, 128], [23, 143]], color=[91, 57, 39], width=3)
add('line', points=[[40, 119], [32, 141]], color=[78, 49, 36], width=2)

# Far-side legs; broad joints and straight, weight-bearing cannons.
add('polygon', points=[[51, 121], [68, 125], [70, 145], [65, 160], [66, 181], [58, 184], [55, 164], [48, 145]], color=[116, 64, 41], border=2)
add('polygon', points=[[117, 121], [134, 122], [140, 143], [144, 160], [140, 182], [131, 183], [130, 162], [121, 145]], color=[112, 61, 39], border=2)

# Main body: long barrel, full hindquarter and substantial shoulder/chest.
add('polygon', points=[[34, 105], [38, 89], [50, 80], [70, 76], [94, 78], [116, 82], [133, 91], [143, 108], [139, 128], [126, 143], [104, 149], [78, 148], [55, 140], [40, 129]], color=[112, 57, 35], border=3)
add('ellipse', rect=[40, 82, 54, 60], color=[139, 72, 43])
add('ellipse', rect=[69, 87, 70, 52], color=[126, 62, 38])
add('ellipse', rect=[111, 87, 34, 57], color=[101, 50, 34])
# Warm planes across the rump and barrel, with restrained muscle definition.
add('polygon', points=[[43, 100], [50, 87], [67, 83], [85, 88], [76, 103], [59, 113]], color=[158, 86, 51])
add('line', points=[[51, 116], [68, 126], [90, 130]], color=[91, 43, 31], width=3)
add('line', points=[[79, 94], [101, 98], [119, 112]], color=[159, 83, 50], width=3)
add('line', points=[[87, 135], [109, 138], [124, 129]], color=[91, 43, 31], width=2)

# Near-side hind leg, closer to the viewer.
add('polygon', points=[[62, 125], [80, 130], [84, 148], [79, 163], [79, 184], [68, 188], [65, 167], [58, 150]], color=[137, 68, 41], border=2)
add('polygon', points=[[63, 171], [80, 171], [81, 183], [77, 190], [64, 189], [61, 183]], color=[99, 52, 36])
add('line', points=[[69, 142], [71, 159], [69, 177]], color=[173, 93, 54], width=2)

# Near-side foreleg, strong upper forearm and clean tapered cannon.
add('polygon', points=[[108, 122], [127, 123], [132, 143], [128, 159], [128, 180], [119, 189], [111, 183], [111, 163], [105, 145]], color=[143, 70, 41], border=2)
add('polygon', points=[[111, 171], [129, 171], [131, 184], [126, 192], [112, 190], [108, 183]], color=[105, 54, 36])
add('line', points=[[119, 143], [121, 160], [120, 179]], color=[181, 98, 57], width=2)

# Lower fetlock feathering and dark, broad working hooves.
for pts in (
    [[58, 174], [54, 182], [59, 185], [68, 183], [70, 176]],
    [[75, 177], [73, 185], [79, 188], [85, 184], [83, 177]],
    [[111, 176], [106, 184], [113, 189], [122, 187], [123, 179]],
    [[130, 174], [128, 183], [135, 188], [144, 184], [142, 176]],
):
    add('polygon', points=pts, color=[80, 42, 31])
for rect in ([57, 183, 13, 10], [73, 185, 13, 9], [109, 187, 15, 8], [130, 184, 15, 10]):
    add('polygon', points=[[rect[0], rect[1]], [rect[0]+rect[2], rect[1]], [rect[0]+rect[2]-2, rect[1]+rect[3]], [rect[0]+2, rect[1]+rect[3]]], color=[43, 36, 31], border=1)
    add('line', points=[[rect[0]+3, rect[1]+3], [rect[0]+rect[2]-3, rect[1]+3]], color=[111, 86, 64], width=1)

# Neck and powerful shoulder rise: thick connection from chest to poll.
add('polygon', points=[[111, 111], [117, 91], [128, 73], [135, 52], [140, 34], [151, 27], [166, 33], [170, 47], [162, 65], [157, 85], [150, 108], [139, 130], [124, 134]], color=[123, 62, 38], border=3)
add('polygon', points=[[118, 105], [128, 83], [139, 64], [143, 44], [153, 35], [163, 40], [155, 61], [150, 82], [140, 108]], color=[153, 77, 45])
add('line', points=[[125, 99], [135, 78], [143, 62]], color=[181, 99, 58], width=3)
add('line', points=[[132, 116], [144, 98], [150, 80]], color=[89, 43, 31], width=2)

# Head, ears and muzzle; short, proportionate head facing right.
add('polygon', points=[[146, 41], [151, 30], [160, 26], [175, 29], [188, 37], [193, 46], [189, 55], [180, 60], [166, 56], [155, 51]], color=[129, 65, 40], border=2)
add('polygon', points=[[174, 40], [187, 41], [194, 47], [190, 54], [178, 56], [171, 50]], color=[160, 91, 59])
add('polygon', points=[[151, 32], [148, 13], [157, 27], [160, 34]], color=[62, 43, 34], border=1)
add('polygon', points=[[160, 29], [170, 12], [171, 34], [166, 38]], color=[58, 40, 32], border=1)
add('ellipse', rect=[171, 39, 6, 6], color=[235, 213, 164])
add('circle', center=[175, 42], radius=2, color=[27, 24, 22])
add('circle', center=[190, 48], radius=2, color=[49, 31, 25])
add('line', points=[[184, 55], [191, 53]], color=[78, 42, 32], width=2)
# Small, natural star and a narrow blaze, rather than an oversized white marking.
add('polygon', points=[[157, 33], [161, 30], [164, 33], [161, 39]], color=[235, 220, 186])
add('line', points=[[162, 37], [166, 45]], color=[231, 212, 174], width=2)

# Black mane follows the crest of the neck rather than forming a detached spike.
add('polygon', points=[[126, 79], [132, 61], [137, 42], [141, 28], [151, 20], [161, 22], [155, 31], [149, 47], [145, 64], [137, 81]], color=[48, 35, 30])
add('polygon', points=[[143, 31], [149, 19], [159, 17], [166, 24], [159, 28], [154, 38]], color=[40, 31, 28])
add('line', points=[[134, 60], [139, 42], [148, 28]], color=[87, 57, 43], width=2)
add('line', points=[[140, 69], [146, 52], [153, 38]], color=[78, 50, 39], width=2)

# Leather working collar, breast strap, bridle and buckles.
add('polygon', points=[[120, 88], [132, 86], [145, 103], [143, 116], [132, 126], [122, 119], [130, 109], [130, 99]], color=[55, 38, 29], border=1)
add('line', points=[[120, 91], [132, 109], [143, 115]], color=[190, 136, 75], width=4)
add('line', points=[[126, 86], [139, 102], [146, 106]], color=[224, 176, 103], width=2)
add('line', points=[[134, 104], [123, 125]], color=[82, 52, 34], width=4)
add('line', points=[[155, 39], [174, 48], [186, 48]], color=[68, 43, 31], width=3)
add('line', points=[[157, 46], [170, 54], [183, 57]], color=[192, 139, 81], width=2)
add('line', points=[[175, 50], [178, 58]], color=[203, 159, 99], width=2)
add('rect', rect=[137, 107, 6, 7], color=[215, 174, 105], border=1, radius=1)

# Feather/fetlock highlights and a few coat strokes keep the finish readable at native scale.
add('line', points=[[45, 113], [54, 122], [65, 126]], color=[181, 105, 62], width=2)
add('line', points=[[96, 91], [111, 98], [119, 111]], color=[176, 96, 55], width=2)
add('line', points=[[58, 174], [63, 180]], color=[183, 112, 67], width=2)
add('line', points=[[113, 177], [118, 182]], color=[181, 105, 62], width=2)

assert all(c['op'] in {'rect','line','polygon','circle','ellipse'} for c in H)
assert max(x for c in H for x in ([c['rect'][0]+c['rect'][2]] if 'rect' in c else [pt[0] for pt in c.get('points', [])] if 'points' in c else [c['center'][0]+c.get('radius',0)] if 'center' in c else [0])) <= 200
D['assets']['stable_draft_horse'] = {'width': 200, 'height': 200, 'commands': H}

# Remove only the old baked-in carriage, horse, and right-side fence layer.
remove = set(range(564, 638)) | set(fence_indices)
D['assets']['c1_bg_stables']['commands'] = [c for i,c in enumerate(commands) if i not in remove]
assert len(D['assets']['c1_bg_stables']['commands']) == 648

# Add the three scene objects. They are fixed scenery objects, never inventory items.
new_objects = [
    {'object_id':'stable_carriage', 'name':'Stable Carriage', 'kind':'stable_carriage', 'area_id':'stables',
     'x':565, 'y':235, 'width':373, 'height':248, 'takeable':False, 'stealable':False, 'on_shelf':False},
    {'object_id':'stable_draft_horse', 'name':'Draft Horse', 'kind':'stable_draft_horse', 'area_id':'stables',
     'x':865, 'y':265, 'width':200, 'height':200, 'takeable':False, 'stealable':False, 'on_shelf':False},
    {'object_id':'stables_foreground_fence', 'name':'Paddock Fence Foreground', 'kind':'stables_foreground_fence', 'area_id':'stables',
     'x':930, 'y':360, 'width':137, 'height':62, 'takeable':False, 'stealable':False, 'on_shelf':False},
]
ids = {o['object_id'] for o in D['world']['objects']}
assert not ids.intersection(o['object_id'] for o in new_objects)
chest_idx = next(i for i,o in enumerate(D['world']['objects']) if o['object_id']=='stable_caravan_chest')
D['world']['objects'][chest_idx:chest_idx] = new_objects
D['version'] = 'SGGF1.1'
D['art_revision'] = 'F1.1 — Stable coach, draft horse and paddock foreground fence are independent JSON assets/world objects.'
notes = D.get('notes')
if isinstance(notes, list):
    notes.append('SGGF1.1: the carriage, new dark-bay draft horse and foreground paddock fence are independent world objects backed by separate Luma JSON recipes. Stables geometry and Kitty recipes remain unchanged from F1.0.')
elif isinstance(notes, str):
    D['notes'] = notes + '\nSGGF1.1: the carriage, new dark-bay draft horse and foreground paddock fence are independent world objects backed by separate Luma JSON recipes. Stables geometry and Kitty recipes remain unchanged from F1.0.'

ASSET.write_text(json.dumps(D, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

# Patch the engine-facing Python code: fixed scenery is rendered before vendors and actors.
s = MAIN.read_text(encoding='utf-8')
assert 'VERSION = "F1.0"  # First official Part One release.' in s
s = s.replace('VERSION = "F1.0"  # First official Part One release.',
              'VERSION = "F1.1"  # Independent Stables carriage and draft horse assets.')
old = """        engine.draw_asset(surface,g.current_area.background_asset,pygame.Rect(0,0,GAME_WIDTH,GAME_HEIGHT))\n        for v in g.current_area.vendors:\n"""
new = """        engine.draw_asset(surface,g.current_area.background_asset,pygame.Rect(0,0,GAME_WIDTH,GAME_HEIGHT))\n        # F1.1: independent Stables props. Keep their original depth order:\n        # carriage first, horse second, the original fence rails/posts above\n        # the horse, then the live driver/vendor and the player.\n        if g.current_area_id == 'stables':\n            by_id = {o.object_id: o for o in g.live_objects()}\n            for oid in ('stable_carriage', 'stable_draft_horse', 'stables_foreground_fence'):\n                prop = by_id.get(oid)\n                if prop is not None:\n                    engine.draw_asset(surface, prop.kind, prop.rect())\n        for v in g.current_area.vendors:\n"""
assert old in s
s = s.replace(old, new, 1)
old_skip = """        for obj in g.live_objects():\n            # The remodeled shop and inn exits belong to the scene backgrounds.\n"""
new_skip = """        for obj in g.live_objects():\n            # F1.1 scenery props were drawn above in the stable scene's fixed\n            # painter order; do not draw them a second time or treat them as items.\n            if obj.object_id in ('stable_carriage', 'stable_draft_horse', 'stables_foreground_fence'):\n                continue\n            # The remodeled shop and inn exits belong to the scene backgrounds.\n"""
assert old_skip in s
s = s.replace(old_skip, new_skip, 1)
# Old F1.0 saves have no records for these new scenery objects; upgrade only by adding their static records.
old_mig = """                if spec['object_id'] not in existing and spec['object_id'] in ('inn_hearth_c13', 'mountain_cave_entrance'):\n"""
new_mig = """                if spec['object_id'] not in existing and spec['object_id'] in (\n                        'inn_hearth_c13', 'mountain_cave_entrance',\n                        'stable_carriage', 'stable_draft_horse', 'stables_foreground_fence'):\n"""
assert old_mig in s
s = s.replace(old_mig, new_mig, 1)
old_meta = """                    if spec['object_id'] in ('inn_hearth_c13', 'mountain_cave_entrance'):\n"""
new_meta = """                    if spec['object_id'] in (\n                            'inn_hearth_c13', 'mountain_cave_entrance',\n                            'stable_carriage', 'stable_draft_horse', 'stables_foreground_fence'):\n"""
assert old_meta in s
s = s.replace(old_meta, new_meta, 1)
# F1 visible labels and class documentation.
s = s.replace('# SGGF1.0 — Part One finale, carriage breakfast quest, and Stables patrol.',
              '# SGGF1.1 — independent Stables carriage and draft horse art; gameplay unchanged.')
s = s.replace('"""F1.0 gameplay layer: Fearmonger\'s sandwich, hungry driver, Part One."""',
              '"""F1.1 gameplay layer: F1.0 quest/finale retained; Stables props separated."""')
s = s.replace("self._set_status('SGGF1.0: Part One finale, carriage breakfast, and rebuilt Stables.')",
              "self._set_status('SGGF1.1: independent carriage and draft horse; Part One remains intact.')")
s = s.replace('"""F1.0 display: new Stables kitty route and F1.0 header, E5.7 comments retained."""',
              '"""F1.1 display: stable prop layering; Kitty route and E5.7 comments retained."""')
s = s.replace('label = "SPIFFY\'S GIFT  |  F1.0  |  "',
              'label = "SPIFFY\'S GIFT  |  F1.1  |  "')
MAIN.write_text(s, encoding='utf-8')

print('Wrote', MAIN, MAIN.stat().st_size)
print('Wrote', ASSET, ASSET.stat().st_size)
print('Background commands', len(D['assets']['c1_bg_stables']['commands']))
print('New assets', [(n,D['assets'][n]['width'],D['assets'][n]['height'],len(D['assets'][n]['commands'])) for n in ('stable_carriage','stable_draft_horse','stables_foreground_fence')])
print('New objects', [o for o in D['world']['objects'] if o['object_id'] in ('stable_carriage','stable_draft_horse','stables_foreground_fence')])
