SPIFFY'S GIFT — SGGE5.7 / ANONYMOUS VISITOR COMMENTS

Full Cloudflare static-site deployment: upload SGG_E57_CLOUDFLARE_DEPLOY.zip.
Playable entry: SGGE5.7/play.html (or select E5.7 from the root version list).

Based directly on the latest SGGE5.6 source and full Cloudflare site archive.
This is a focused visitor-comment release.

One feature added:
- A LEAVE A COMMENT button appears in the top bar between Menu and Please Tip.
  Existing Export Log and Menu controls remain available; the top bar reads from
  left to right: Please Tip | Export Log | Leave a Comment | Menu.
- The form accepts an anonymous plain-text message of up to 1,000 characters.
  It does not ask visitors for a name, email address, login or account.
- Submission uses the separately deployed Spiffy's Gift Comments API at
  https://spiffys-gift-comments-api.magiccozmo.workers.dev/comment.
- The form reports sending, success, or an error to the visitor. Escape or
  Cancel closes the form; Ctrl+Enter sends the message.
- The API stores the message in the existing D1 comments table; private inbox
  access remains on the separate /admin page and is not exposed in the game.

What did NOT change:
- E5.6 game-world and asset JSON is preserved byte-for-byte.
- Castle Path art, navigation, transitions, all other artwork, NPCs, objects,
  quests, inventory, game saves, local settings, and gameplay mechanics remain
  as in E5.6.
- The E5.6 state machine and interface are inherited; the new subclass handles
  only the comment form and its network result.
- All previously archived playable releases are preserved byte-for-byte.
  The root index, headers and historical release folders are untouched; only
  versions.json is updated and the SGGE5.7 folder is added.
- The game Worker remains a static-assets-only site. Comment handling remains
  in the separate comments API Worker and D1 database.

Checks performed:
- Python syntax and exact-change audit against the E5.6 main.py source.
- After removing only E5.7 feature code and release labels, main.py reconstructs
  the E5.6 baseline exactly.
- E5.6 Luma art/world JSON SHA-256 is unchanged.
- Anonymous POST uses JSON, honours the 1,000-character cap, and reports the
  API response in the game UI.
- Header control rectangles do not overlap at the fixed 1360px browser width.
- Static play page references the E5.7 versioned APK and TAR files.
- Deployment ZIP CRC, APK/TAR embedded source, and bytewise preservation of all
  historical site members verified.

Browser field testing of the comment form remains the final check after deploy.
