Spiffy's Gift — Web project source handoff
Current edition: SGGM1.7 — BritRun Market Square Reimagined.

M1.7 replaces the M1.6a city-market placeholder with a new Luma Draw Engine scene while preserving the M1.6a continuous-world layout. Inn remains north, Alchemy Shop east, Kart-lotta remains in the middle, and the Market Guard now appears in the square. The ten K1.12 market objects are restored as static M1 display props with their original takeable/stealable, owner, value, and permission distinctions recorded for later mechanics.

World routes, portals and walkmesh were intentionally retained unchanged. The market art is a new M1 Draw Engine recipe; the old SGGE market screenshot is not reused.

The project includes the complete historical release catalogue and deployment assets. Runtime bundles are repackaged from the exact M1.6a Pygbag payload with the updated M1.7 Python, world and Luma asset files. No fresh Pygbag compilation or live browser run was performed in this environment.
