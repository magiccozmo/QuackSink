SPIFFY'S GIFT — SGG WEB SOURCE

Current release: SGGM1.2. M1.2 is based on the exact M1.1 source and complete Cloudflare site packages. It changes BritRun's city topology, the four existing city NPC positions, and city-side arrival points for the gate and connected doors. The rest of the continuous world, gameplay behavior, UI, interior NPCs and art assets are retained. Older source and deployment editions remain preserved.
