SPIFFY'S GIFT — SGG WEB SOURCE

Current release: SGGM1.2, based on the exact SGGM1.1 source and complete Cloudflare site packages. This milestone changes BritRun's city topology and existing city NPC positions only, plus the city-side reciprocal transition arrivals needed by the new doors and south-wall gate. Gameplay behavior, UI, interior NPCs and art assets are unchanged.
