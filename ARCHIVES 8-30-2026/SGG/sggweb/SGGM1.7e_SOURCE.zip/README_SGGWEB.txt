Spiffy's Gift — Web project source handoff
Current edition: SGGM1.7d — Alchemy Shop Door Approach Correction.

This release makes one collision change at the Alchemy Shop entrance: the narrow west-jamb blocker [3800,1090,18,92] is removed so the Market Square walkmesh connects to the existing automatic door threshold. The shop facade, east jamb, sill, doorway, portal destination, artwork and interior are unchanged. All other market art, routes, world layers, NPCs, objects, metadata and gameplay remain intact.

The complete-site package retains SGGM1.0 and SGGM1.7c as previous M-series reference milestones and SGGM1.7d as current. Intermediate M1 test editions are omitted from this package only; all non-M1 historical editions and milestone source archives remain. Historical GitHub releases have not been deleted or rewritten.

The existing Pygbag tar/APK payloads were repacked with the updated runtime and world JSON. No fresh Pygbag compilation or live browser/Pygame test was performed in this environment. See the SGGM1.7d Luma Log and test results.
