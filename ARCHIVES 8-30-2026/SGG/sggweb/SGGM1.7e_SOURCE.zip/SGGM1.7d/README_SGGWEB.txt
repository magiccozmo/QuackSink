Spiffy's Gift — SGGM1.7d Browser Release

Only the Alchemy Shop doorway approach collision was corrected. The west-side blocker [3800,1090,18,92] was removed so the existing plaza walkmesh reaches the automatic doorway trigger. The facade, upper blocker, east jamb, sill, artwork, door, interior destination, and all other gameplay remain unchanged.

Intermediate M1 test versions are omitted from this package. SGGM1.0 and SGGM1.7c remain as prior M-series reference editions; non-M1 history is retained.
