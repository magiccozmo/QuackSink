const fs = require('fs');
const assert = require('assert');
const root = __dirname + '/..';
const base = JSON.parse(fs.readFileSync(root + '/SGGM1.7c/m1_world_layers.json', 'utf8'));
const current = JSON.parse(fs.readFileSync(root + '/SGGM1.7d/m1_world_layers.json', 'utf8'));
const baseCity = base.layers.find(layer => layer.id === 'city_exterior');
const city = current.layers.find(layer => layer.id === 'city_exterior');
const westJamb = [3800, 1090, 18, 92];
assert.strictEqual(base.version, 'SGGM1.7c');
assert.strictEqual(current.version, 'SGGM1.7d');
assert.strictEqual(baseCity.blocked.filter(r => JSON.stringify(r) === JSON.stringify(westJamb)).length, 1);
assert.strictEqual(city.blocked.filter(r => JSON.stringify(r) === JSON.stringify(westJamb)).length, 0);
assert.deepStrictEqual(city.walkmesh, baseCity.walkmesh);
assert.deepStrictEqual(city.portals, baseCity.portals);
assert.deepStrictEqual(current.layers.filter(x => x.id !== 'city_exterior'), base.layers.filter(x => x.id !== 'city_exterior'));
function body(x, y) { return [x - 10, y - 13, 20, 26]; }
function overlaps(a, b) { return a[0] < b[0] + b[2] && a[0] + a[2] > b[0] && a[1] < b[1] + b[3] && a[1] + a[3] > b[1]; }
function canMove(x, y, blockers) {
  const samples = [[x, y], [x - 10, y - 13], [x + 10, y - 13], [x - 10, y + 13], [x + 10, y + 13]];
  const inWalkmesh = point => city.walkmesh.some(r => point[0] >= r[0] && point[0] <= r[0] + r[2] && point[1] >= r[1] && point[1] <= r[1] + r[3]);
  return samples.every(inWalkmesh) && !blockers.some(r => overlaps(body(x, y), r));
}
assert(canMove(3790, 1140, baseCity.blocked));
assert(!canMove(3792, 1140, baseCity.blocked));
for (let x = 3790; x <= 3830; x += 2) assert(canMove(x, 1140, city.blocked), `new doorway approach blocked at x=${x}`);
const portal = city.portals.find(p => p.id === 'city_to_alchemy');
assert(portal);
assert.strictEqual(portal.radius * 0.55, 28.6);
assert(Math.hypot(3830 - portal.x, 1140 - portal.y) <= portal.radius * 0.55);
const oldMain = fs.readFileSync(root + '/SGGM1.7c/main.py', 'utf8');
const newMain = fs.readFileSync(root + '/SGGM1.7d/main.py', 'utf8');
assert.strictEqual(newMain.replaceAll('SGGM1.7d', 'SGGM1.7c').replaceAll('M1.7d', 'M1.7c'), oldMain);
console.log('PASS SGGM1.7d Alchemy door approach geometry');
