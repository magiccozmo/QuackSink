SPIFFY'S GIFT — SGGG1.3

G1.3 PRIVACY AND GLOBAL LOG REFINEMENT

This is an additive maintenance release. It follows the SGGG1.1 source lineage and carries forward the SGGG1.2 gameplay layer: stable Cozmo encounter numbers, collision-safe cameos, the Tipsy Turnip stolen Black-Briar Mead job, the Inn Lout position/follow changes, Alchemy Shop spacing, and save-bound Tea rules.

PLAYER-CONTROLLED LOCATION
The site front page displays Cloudflare's approximate country and city under the GLOBAL LOG link. The player can select NONE OF YOUR BUSINESS before starting. That clears the display and sends share_location=false. The Worker stores ANONYMOUS and does not save country/city. A missing consent field defaults to anonymous.

GLOBAL LOG
The Worker computes session duration from session start to each event, shows only the latest Still active heartbeat for each session, and uses small cursor-based batches of up to 50 records. The fixed-height independent scrolling panel remains.

DEPLOYMENT
Upload the complete Cloudflare site ZIP to the Spiffy's Gift site. Separately replace the code in the existing sgg-global-log Worker with SGGG1.3_GLOBAL_LOG_WORKER.js. Keep the existing D1 binding DB -> sgg-global-usage. No database migration is required.

This candidate has passed static package checks; live gameplay and browser testing remain for Cozmo.
