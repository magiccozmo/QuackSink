const CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
  "Content-Type": "application/json; charset=utf-8",
  "Cache-Control": "no-store"
};

const PUBLIC_LABELS = {
  session_start: "Started a new game session",
  heartbeat: "Still active",
  difficulty_easy: "Selected Easy mode",
  difficulty_normal: "Selected Normal mode",
  difficulty_spiffy_challenge: "Selected Spiffy Challenge",
  achievement_bucket_theft: "Market Mischief",
  achievement_naz_guard_death: "Unexpected Justice",
  achievement_vault_clip: "Unexpected Shortcut",
  achievement_lout_guard_death: "Inn Business Settled",
  achievement_hellgs_escape: "The Great Escape",
  achievement_caravan_chest_first_loot: "Hidden Cache",
  troll_cave_pineapple_exit: "Pineapple Getaway",
  quest_accepted: "New Adventure",
  quest_completed: "Quest Complete",
  kart_lotta_befriended: "Market Friendship",
  carriage_unlocked: "Road Ahead",
  cozmo_finale: "Part One Reached",
  potion_crafted: "Brewmaster",
  soup_cooked: "Kitchen Magic",
  soup_consumed: "Soup Power",
  scenic_overlook: "Admired View",
  spiffy_challenge_started: "Spiffy Challenge started",
  hellgs_challenge_started: "HELLgs challenge started",
  hellgs_game_over: "HELLgs challenge ended"
};

const ACHIEVEMENT_EVENTS = new Set([
  "achievement_bucket_theft", "achievement_naz_guard_death",
  "achievement_vault_clip", "achievement_lout_guard_death",
  "achievement_hellgs_escape", "achievement_caravan_chest_first_loot",
  "troll_cave_pineapple_exit", "quest_completed", "carriage_unlocked",
  "cozmo_finale", "potion_crafted", "soup_cooked", "scenic_overlook",
  "hellgs_challenge_started", "hellgs_game_over", "kart_lotta_befriended"
]);
const ALLOWED_EVENTS = new Set([
  ...Object.keys(PUBLIC_LABELS), "area_discovered", "cozmo_encounter"
]);

function respond(data, status = 200) {
  return new Response(JSON.stringify(data), {status, headers:CORS_HEADERS});
}
function timestamp() { return new Date().toISOString(); }

export default {
  async fetch(request, env) {
    if (request.method === "OPTIONS") return new Response(null, {status:204, headers:CORS_HEADERS});
    const url = new URL(request.url);
    const path = url.pathname.replace(/\/+$/, "") || "/";

    try {
      if (path === "/health" && request.method === "GET") {
        const result = await env.DB.prepare(
          "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"
        ).all();
        return respond({status:"connected", database:"sgg-global-usage", tables:result.results.map(row => row.name)});
      }

      if (path === "/session" && request.method === "POST") {
        let body;
        try { body = await request.json(); } catch (_) { return respond({error:"Invalid JSON"},400); }
        const gameVersion = String(body.game_version || "").trim();
        const difficulty = String(body.difficulty || "").trim();
        if (!/^SGGG\d+(?:\.\d+)?$/i.test(gameVersion) || gameVersion.length > 40)
          return respond({error:"Invalid game_version"},400);
        if (!["easy","normal","spiffy_challenge"].includes(difficulty))
          return respond({error:"Invalid difficulty"},400);

        const sessionId = crypto.randomUUID();
        const startedAt = timestamp();
        const region = request.cf?.country || "Unknown";
        await env.DB.prepare(
          `INSERT INTO sessions (session_id,game_version,difficulty,region,started_at)
           VALUES (?,?,?,?,?)`
        ).bind(sessionId,gameVersion,difficulty,region,startedAt).run();
        await env.DB.prepare(
          `INSERT INTO events (session_id,event_type,description,occurred_at)
           VALUES (?,?,?,?)`
        ).bind(sessionId,"session_start",PUBLIC_LABELS.session_start,startedAt).run();
        return respond({status:"created",session_id:sessionId,started_at:startedAt},201);
      }

      if (path === "/event" && request.method === "POST") {
        let body;
        try { body = await request.json(); } catch (_) { return respond({error:"Invalid JSON"},400); }
        const sessionId = String(body.session_id || "").trim();
        const eventType = String(body.event_type || "").trim();
        if (!/^[0-9a-f-]{36}$/i.test(sessionId)) return respond({error:"Invalid session_id"},400);
        if (!ALLOWED_EVENTS.has(eventType)) return respond({error:"Event type is not approved"},400);

        const session = await env.DB.prepare(
          "SELECT session_id FROM sessions WHERE session_id=?"
        ).bind(sessionId).first();
        if (!session) return respond({error:"Session not found"},404);

        const recent = await env.DB.prepare(
          `SELECT COUNT(*) AS total FROM events
           WHERE session_id=? AND occurred_at >= ?`
        ).bind(sessionId,new Date(Date.now()-60000).toISOString()).first();
        if (Number(recent?.total || 0) >= 30)
          return respond({error:"Session event rate limit reached"},429);

        if (eventType === "heartbeat") {
          const recentHeartbeat = await env.DB.prepare(
            `SELECT occurred_at FROM events WHERE session_id=? AND event_type='heartbeat'
             ORDER BY event_id DESC LIMIT 1`
          ).bind(sessionId).first();
          if (recentHeartbeat && Date.now()-Date.parse(recentHeartbeat.occurred_at) < 60000)
            return respond({status:"ignored",reason:"Heartbeat received too recently"});
        }

        if (ACHIEVEMENT_EVENTS.has(eventType)) {
          const prior = await env.DB.prepare(
            "SELECT event_id FROM events WHERE session_id=? AND event_type=? LIMIT 1"
          ).bind(sessionId,eventType).first();
          if (prior) return respond({status:"ignored",reason:"This achievement was already recorded for the session"});
        }

        let description = PUBLIC_LABELS[eventType];
        if (eventType === "area_discovered" || eventType === "cozmo_encounter") {
          const count = await env.DB.prepare(
            "SELECT COUNT(*) AS total FROM events WHERE session_id=? AND event_type=?"
          ).bind(sessionId,eventType).first();
          const number = Number(count?.total || 0) + 1;
          description = eventType === "area_discovered" ? `Area Discovery #${number}` : `Cozmo Encounter #${number}`;
        }
        if (!description) return respond({error:"Event type is not approved"},400);
        const occurredAt = timestamp();
        await env.DB.prepare(
          `INSERT INTO events (session_id,event_type,description,occurred_at)
           VALUES (?,?,?,?)`
        ).bind(sessionId,eventType,description,occurredAt).run();
        return respond({status:"recorded",event_type:eventType,description,occurred_at:occurredAt},201);
      }

      if (path === "/log" && request.method === "GET") {
        const rawLimit = Number(url.searchParams.get("limit") || 50);
        const rawOffset = Number(url.searchParams.get("offset") || 0);
        const limit = Number.isInteger(rawLimit) ? Math.min(Math.max(rawLimit,1),100) : 50;
        const offset = Number.isInteger(rawOffset) ? Math.min(Math.max(rawOffset,0),1000000) : 0;
        const result = await env.DB.prepare(
          `SELECT events.event_id, substr(events.session_id,1,8) AS session,
                  events.event_type,events.description,events.occurred_at,
                  sessions.game_version,sessions.difficulty,sessions.region
           FROM events INNER JOIN sessions ON events.session_id=sessions.session_id
           ORDER BY events.event_id DESC LIMIT ? OFFSET ?`
        ).bind(limit,offset).all();
        return respond({status:"ok",count:result.results.length,limit,offset,events:result.results});
      }

      return respond({error:"Not found",available_endpoints:["GET /health","POST /session","POST /event","GET /log"]},404);
    } catch (_) {
      return respond({error:"Request failed"},500);
    }
  }
};
