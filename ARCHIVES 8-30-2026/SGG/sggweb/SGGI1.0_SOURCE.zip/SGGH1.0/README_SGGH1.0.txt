Spiffy's Gift — SGGH1.0

Baseline: SGGG1.5. This release changes only Kartlotta's two quest-stage dialogue lines and adds optional browser voice playback hooks at the corresponding dialogue triggers.

Kartlotta's first meeting now says: "That lout at the inn is so annoying. He wants to fondle my tomatoes and squeeze my cabbages." The original response choices and actions are unchanged.

After the inn lout is resolved, the first return conversation says: "Oh, you are NOW my HERO. You can do whatever you want with my veggies." The original "Thank you, Karlotta." reward action is unchanged. The later generic permission dialogue is unchanged and does not trigger voice playback.

Optional browser voice assets, when supplied, belong in the site-root audio_clip/ folder with these exact names:
- kartlotta_meet.wav
- kartlotta_hero.wav

The WAV files were not present at build time. The browser bridge is wired to request them, but audible playback has not been tested. Missing audio does not block dialogue or quest progression.

All other game areas, save compatibility, quest state, player choices, permissions, rewards, public logging, and historical releases are preserved from SGGG1.5.
