SPIFFY'S GIFT — SGGG1.4

G1.4 fixes the player-controlled location handoff, records successful saves and loads in the public Global Log, and keeps the active run difficulty independent of the loaded save. The in-game HUD shows the current difficulty, and the front page displays SGGG1.4 after “Browser Edition Archive”.

Privacy: the browser defaults to ANONYMOUS unless the player explicitly chooses to share approximate Cloudflare country/city. NONE OF YOUR BUSINESS is carried through both the launch URL and same-tab sessionStorage. The Worker stores no country or city for opted-out sessions.

Save/load: Game Saved and Save Loaded are public activity events. Failed operations are not logged. Save loads never replace the current run difficulty or award Tea. The current run difficulty remains authoritative while inherited HELLgs save handling runs, preserving the cross-version escape exploit.

Deployment: upload the COMPLETE_CLOUDFLARE_SITE ZIP to the existing Spiffy’s Gift site. Replace the code in the existing sgg-global-log Worker with SGGG1.4_GLOBAL_LOG_WORKER.js. Preserve the existing D1 binding DB -> sgg-global-usage. No migration is required.

G1.4 is statically checked but awaits Cozmo’s live browser field test. Luma has not deployed the site or Worker.
