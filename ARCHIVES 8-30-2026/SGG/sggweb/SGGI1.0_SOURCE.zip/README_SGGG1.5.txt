SPIFFY'S GIFT — SGGG1.5

G1.5 is a narrowly scoped Kitty Caravan cameo-placement fix. On the first successful hidden-chest loot, Cozmo is now placed at the player-marked clear road position to the LEFT of the rear of the Stables carriage (world position approximately 405, 500). This avoids overlapping Kitty, whose animated patrol is drawn separately from the model NPC list used by the generic cameo placement search.

The Kitty Caravan event keeps its existing one-in-game-second queue delay, the existing placement collision/walkmesh checks, the first-loot-only recognition, and the existing Tea reward interaction. If the specifically designated tile is temporarily occupied, the queued encounter waits for that tile rather than falling back to a point in Kitty's patrol area.

All other Cozmo cameo locations and placement logic are unchanged. G1.4 save/load events, difficulty integrity, privacy handoff, Global Log behavior, gameplay, saves, artwork, areas, and historical editions are retained.

Deployment: upload the COMPLETE_CLOUDFLARE_SITE ZIP to the existing Spiffy's Gift site. The Global Log Worker is unchanged from G1.4; no Worker replacement or D1 migration is needed. Keep the existing DB -> sgg-global-usage binding intact.

Static checks passed. Browser gameplay was not live-tested by Luma; Cozmo's field test remains necessary.
