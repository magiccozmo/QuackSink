SPIFFY'S GIFT — SGGF1.666f1p.1

BASE: Exact, GitHub-verified SGGF1.666f1p source and complete Cloudflare site archives.

RELEASE TYPE: Site-only maintenance release. This is a new release number; it does not replace or overwrite F1p.

SCOPE: One front-door gallery usability adjustment only. The gallery Close button has been moved out of the zoom-control group and into its own separated header position. At viewport widths up to 900px (including tablet portrait), it occupies the top-right header position while Prev/Next and zoom controls sit on a separate row. This prevents accidental gallery closure while trying to press the + zoom button.

UNCHANGED: All game code, game content, art assets, movement, transitions, dialogue, inventory, saves, backward compatibility, historical game releases, gallery images, image URLs, gallery zoom/swipe/pinch behavior, and version catalogue entries.

NOTE: The playable game remains SGGF1.666f1p. No new game content or playable game version was introduced.

TESTING: Both original F1p ZIPs passed integrity checks before modification. HTML structure and required gallery controls are checked in all four synchronized front-door HTML copies. The complete Cloudflare site retains every historical release directory; all ZIPs are integrity-tested after packaging. Static responsive-CSS and HTML structure checks passed. Automated browser rendering was attempted but blocked by the container browser policy (ERR_BLOCKED_BY_ADMINISTRATOR), so visual viewport geometry and physical-device confirmation remain untested.
