SPIFFY'S GIFT — SGGF1.666f1r

BASE: Exact current SGGF1.666f1q source and complete Cloudflare site packages from GitHub main (commit b217036a84c06cc901e28dbe741ec44d834e72a8).

CHANGES: Troll Cave walkmesh reshaped to follow only the visible lower cavern floor; Frosty and the Purple Passion Pineapple moved from the raised rear alcove onto the main floor; gallery ordered oldest-to-newest; Fast Travel area names sorted A–Z; hard Fast Travel refusal when in HELLgs Inn, including destination jumps if a travel overlay is already open.

UNCHANGED: Cave and Frosty art recipes, pineapple art recipe, dimensions and pickup logic, soup and chase mechanics, doors/transition anchors/connections, every other world area and object, backward-compatible save schema, previous release directories, and the F1p.1 gallery Close/zoom fix.

SAVE MIGRATION: Older F1q saves migrate only pristine Frosty/pineapple default positions. Moved or collected objects, player-altered state and an angry/chasing Frosty remain untouched. Player positions outside the new Troll Cave floor polygon are safely relocated only when a Troll Cave save is loaded.

GALLERY SOURCE: All current 35 .png files from GitHub main /pics; ordered by GitHub path history timestamp ascending, alphabetically resolving identical timestamps.

TESTS: Run `python test_SGGF1.666f1r.py` from this folder.
