SPIFFY'S GIFT — SGGF1.666f1q

BASE: Exact current SGGF1.666f1p.1 source and complete Cloudflare site packages, recovered from the current GitHub main commit.

TROLL CAVE REDRAW: Replaces the former flat oval ice arena with a deeper, irregular vaulted cavern: fractured ceiling, layered rock/ice walls, a dark rear alcove, broad faceted floor, natural ice formations and a shadowed passage. Frosty has a new, more substantial faceted ice-troll design while retaining his existing sprite dimensions and three angry-state frame cycling.

EXIT: Removes the wooden door artwork from the Troll Cave scene. The cave exit is now a natural dark opening painted into the background, visually consistent with entering/exiting a cave mouth. The existing troll_cave_exit object remains kind=door as an invisible interaction/transition anchor; its object ID, area, coordinates, dimensions, walk trigger, connection, arrival point and state-machine behavior are unchanged.

PINEAPPLE: The Purple Passion Pineapple asset recipe and world-object record are unchanged. Its position, dimensions, pickup behavior and Frosty-trigger behavior are unchanged.

PRESERVED: All other scene art assets, world areas, object records, NPC behavior, movement, transitions, inventory, dialogue, Tea, saves, save-slot compatibility, timers, hints, backward compatibility, previous releases and the F1p.1 gallery Close/zoom fix. The front-door gallery is refreshed to include every PNG currently present in the repository pics folder (34 files at build time).

FUTURE NOTE: This release does not add new NPC/player movement animation; existing Frosty animation frame cycling and all current character motion behavior are retained.

TESTING: Automated preservation tests verify only c1_bg_troll_cave and Frosty’s four troll recipes differ in the Luma assets; pineapple recipe and all world records are identical. Python syntax, gallery count/URLs, runtime archive contents, site catalogue, and both complete ZIP archives are checked. Live browser playtest remains for Cozmo.
